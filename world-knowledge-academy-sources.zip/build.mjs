// Assemble les sources en un seul fichier HTML autonome (aucune dépendance, ouvrable hors ligne).
// node build.mjs  ->  dist/index.html (document complet) et dist/app.html (fragment pour l'aperçu publié)
import fs from "node:fs";
const r = p => fs.readFileSync(new URL(p, import.meta.url), "utf8");
export const DATA = ["countries", "world", "bank", "bank_prat", "bank_plus", "countries_plus", "knowledge", "situations", "lang_vocab", "lang_en", "lang_es", "mapdata", "db_export"].map(f => `src/data/${f}.js`);
export const ENGINE = ["util", "generators", "extra", "lang", "store", "engine", "features"].map(f => `src/engine/${f}.js`);
export const UI = ["core", "learn", "langs", "world", "notebook", "data", "me"].map(f => `src/ui/${f}.js`);
const data = DATA.map(r).join("\n");
const engine = ENGINE.map(r).join("\n");
const safe = s => s.replace(/<\/script/gi, "<\\/script");
const frag = r("src/ui/shell.html")
  .replace("/*__CSS__*/", () => r("src/ui/styles.css"))
  .replace("/*__DATA__*/", () => safe(data))
  .replace("/*__ENGINE__*/", () => safe(engine))
  .replace("/*__UI__*/", () => safe(UI.map(r).join("\n")));
fs.mkdirSync(new URL("dist/", import.meta.url), { recursive: true });
fs.writeFileSync(new URL("dist/app.html", import.meta.url), frag);
const head = frag.split("<style>")[0], rest = frag.slice(head.length);
const styleEnd = rest.indexOf("</style>") + 8;
fs.writeFileSync(new URL("dist/index.html", import.meta.url),
  `<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n${head}${rest.slice(0, styleEnd)}\n</head>\n<body>\n${rest.slice(styleEnd)}\n</body>\n</html>\n`);
console.log("dist/index.html et dist/app.html :", Math.round(frag.length / 1024), "Ko");
