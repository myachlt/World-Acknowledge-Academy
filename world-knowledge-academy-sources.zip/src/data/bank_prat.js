/* World Knowledge Academy — Banque « Connaissances pratiques et vie quotidienne » (couche DONNÉES)
 * Règles juridiques et financières : DROIT FRANÇAIS sauf mention contraire, état connu en juin 2026.
 * Contenu pédagogique : il ne remplace pas l'avis d'un professionnel (avocat, notaire, médecin, conseiller).
 */
(function (W) {
  const B = W.WKA.data.bank;
  const AS = "2026-06";
  const Q = (sub, d, q, a, w, ex, info, ctx, src, nature, asOf, extra) =>
    B.push(Object.assign({ cat: "prat", sub, d, q, a, w, ex, info, ctx: ctx || "", src, nature: nature || "contemp", asOf: nature === "hist" || nature === "sci" ? null : (asOf || AS) }, extra || {}));

  // ---------------- DROIT ET LÉGISLATION ----------------
  const DR = "Droit et législation";
  Q(DR, 1, "En France, combien de jours ouvrables de congés payés un salarié à temps plein acquiert-il par mois de travail effectif ?", "2,5 jours", ["2 jours", "3 jours", "1,5 jour"],
    "Le Code du travail prévoit 2,5 jours ouvrables par mois de travail effectif, soit 30 jours ouvrables (5 semaines) pour une année complète.",
    "Depuis la loi du 22 avril 2024, un salarié en arrêt maladie d'origine non professionnelle acquiert aussi des congés : 2 jours ouvrables par mois, dans la limite de 24 jours par an.",
    "Comparaison internationale : les États-Unis n'imposent aucun congé payé au niveau fédéral ; le Royaume-Uni en impose 5,6 semaines, jours fériés inclus.", "Code du travail, art. L3141-3 ; service-public.fr");
  Q(DR, 2, "Quelle est la durée légale du travail hebdomadaire en France ?", "35 heures", ["39 heures", "40 heures", "32 heures"],
    "La durée légale est fixée à 35 heures par semaine depuis les lois Aubry (2000-2002). Au-delà, les heures sont des heures supplémentaires, majorées.",
    "La durée légale n'est pas une durée maximale : le maximum est de 10 heures par jour et 48 heures par semaine (44 heures en moyenne sur 12 semaines).", "", "Code du travail, art. L3121-27 et L3121-20");
  Q(DR, 3, "Quelle est la durée maximale initiale de la période d'essai d'un cadre en CDI (hors accord de branche) ?", "4 mois", ["2 mois", "3 mois", "6 mois"],
    "La loi fixe la durée maximale initiale à 2 mois pour les ouvriers et employés, 3 mois pour les agents de maîtrise et techniciens, 4 mois pour les cadres.",
    "Elle ne peut être renouvelée qu'une fois, et seulement si un accord de branche étendu le prévoit et si le contrat le mentionne.", "", "Code du travail, art. L1221-19 à L1221-21");
  Q(DR, 3, "Après la signature d'une rupture conventionnelle, de combien de jours chaque partie dispose-t-elle pour se rétracter ?", "15 jours calendaires", ["7 jours ouvrés", "1 mois", "48 heures"],
    "Chaque partie dispose de 15 jours calendaires pour se rétracter. La convention est ensuite envoyée à l'administration (DREETS) pour homologation.",
    "Contrairement à la démission, la rupture conventionnelle ouvre en principe droit à l'allocation chômage.", "La rupture conventionnelle (2008) est un mode de rupture amiable du CDI, distinct du licenciement et de la démission.", "Code du travail, art. L1237-13 et L1237-14");
  Q(DR, 2, "Un salarié qui démissionne a-t-il droit, en principe, à l'allocation chômage ?", "Non, sauf cas de démission dite légitime ou projet de reconversion validé", ["Oui, toujours", "Oui, s'il a plus de 2 ans d'ancienneté", "Non, jamais, sans exception"],
    "La démission est volontaire : elle n'ouvre pas droit à l'allocation, sauf exceptions (démission « légitime », par exemple pour suivre un conjoint, ou démission pour un projet de reconversion professionnelle validé).",
    "Après 121 jours sans emploi, un démissionnaire peut demander un réexamen de sa situation.", "", "France Travail ; règlement d'assurance chômage");
  Q(DR, 3, "Quel est le préavis légal de licenciement pour un salarié ayant au moins 2 ans d'ancienneté (sauf faute grave) ?", "2 mois", ["1 mois", "3 mois", "15 jours"],
    "Le Code du travail prévoit 1 mois entre 6 mois et 2 ans d'ancienneté, 2 mois au-delà de 2 ans. La convention collective ou le contrat peuvent être plus favorables.",
    "En cas de faute grave ou lourde, il n'y a ni préavis ni indemnité de licenciement.", "", "Code du travail, art. L1234-1");
  Q(DR, 2, "Quelle juridiction règle les litiges individuels entre un salarié et son employeur ?", "Le conseil de prud'hommes", ["Le tribunal administratif", "Le tribunal de commerce", "La cour d'assises"],
    "Le conseil de prud'hommes est composé de conseillers non professionnels, désignés pour moitié par les organisations de salariés et pour moitié par les organisations d'employeurs.",
    "Une phase de conciliation précède le jugement.", "Les conflits collectifs (grèves, accords) relèvent d'autres procédures.", "Code du travail, art. L1411-1");
  Q(DR, 3, "Quelle est la durée maximale d'un CDD « classique », renouvellements compris (cas général) ?", "18 mois", ["12 mois", "24 mois", "36 mois"],
    "La durée maximale est en principe de 18 mois, renouvellements inclus. Des exceptions existent (9 mois ou 24 mois selon le motif).",
    "À la fin d'un CDD, le salarié perçoit en principe une indemnité de fin de contrat (« prime de précarité ») égale à 10 % de la rémunération brute totale.", "", "Code du travail, art. L1242-8 et L1243-8");
  Q(DR, 2, "En droit pénal français, comment classe-t-on les infractions, de la moins grave à la plus grave ?", "Contravention, délit, crime", ["Délit, contravention, crime", "Crime, délit, contravention", "Faute, délit, crime"],
    "Les contraventions sont jugées par le tribunal de police, les délits par le tribunal correctionnel, les crimes par la cour d'assises (ou la cour criminelle départementale).",
    "Les cours criminelles départementales, composées de magistrats professionnels, jugent depuis 2023 la plupart des crimes punis de 15 ou 20 ans de réclusion.", "", "Code pénal, art. 111-1", "hist");
  Q(DR, 4, "Quelle juridiction se trouve au sommet de l'ordre administratif français ?", "Le Conseil d'État", ["La Cour de cassation", "Le Conseil constitutionnel", "La Cour des comptes"],
    "La France a deux ordres de juridiction : judiciaire (sommet : Cour de cassation) et administratif (sommet : Conseil d'État), qui juge les litiges avec l'administration.",
    "Le Tribunal des conflits tranche les questions de compétence entre les deux ordres.", "Le Conseil constitutionnel n'appartient à aucun des deux ordres : il contrôle la conformité des lois à la Constitution.", "Constitution ; Code de justice administrative", "hist");
  Q(DR, 2, "Vous achetez un produit en ligne. De combien de jours disposez-vous pour vous rétracter, sans avoir à vous justifier ?", "14 jours", ["7 jours", "30 jours", "Aucun délai : la vente est définitive"],
    "Pour un achat à distance (internet, téléphone) ou hors établissement, le consommateur dispose de 14 jours à compter de la réception du bien.",
    "Ce droit n'existe pas en principe pour un achat en magasin : un échange ou remboursement y est un geste commercial, sauf défaut du produit.", "Des exceptions existent : biens personnalisés, denrées périssables, contenus numériques déjà téléchargés…", "Code de la consommation, art. L221-18");
  Q(DR, 3, "Quelle est la durée de la garantie légale de conformité pour un bien neuf acheté auprès d'un professionnel ?", "2 ans", ["6 mois", "1 an", "5 ans"],
    "Le vendeur professionnel doit répondre des défauts de conformité qui apparaissent dans les 2 ans suivant la délivrance d'un bien neuf. Le défaut est présumé exister au moment de l'achat.",
    "Cette garantie est gratuite et obligatoire ; elle ne doit pas être confondue avec une garantie commerciale ou une extension payante.", "", "Code de la consommation, art. L217-3 et suivants");
  Q(DR, 2, "Pour une location vide (non meublée), quel est le montant maximal du dépôt de garantie ?", "1 mois de loyer hors charges", ["2 mois de loyer hors charges", "3 mois de loyer charges comprises", "Il est libre"],
    "Le dépôt de garantie est plafonné à 1 mois de loyer hors charges pour un logement vide, et à 2 mois pour un logement meublé.",
    "Il doit être restitué sous 1 mois si l'état des lieux de sortie est conforme à celui d'entrée, sous 2 mois sinon.", "", "Loi du 6 juillet 1989, art. 22 et 25-6");
  Q(DR, 3, "Quel est en principe le préavis du locataire qui quitte un logement vide situé hors zone tendue ?", "3 mois", ["1 mois", "2 mois", "6 mois"],
    "Le préavis est de 3 mois pour un logement vide, réduit à 1 mois en zone tendue ou dans certains cas (mutation, perte d'emploi, raisons de santé, bénéficiaire du RSA…). Il est de 1 mois en meublé.",
    "Le congé doit être envoyé par lettre recommandée, acte de commissaire de justice ou remis en main propre contre signature.", "", "Loi du 6 juillet 1989, art. 15");
  Q(DR, 3, "Pendant quelle période l'expulsion d'un locataire est-elle en principe suspendue en France (trêve hivernale) ?", "Du 1er novembre au 31 mars", ["Du 1er décembre au 28 février", "Du 15 octobre au 15 avril", "Du 1er novembre au 30 avril"],
    "Pendant la trêve hivernale, aucune expulsion locative ne peut en principe être exécutée, même si une décision de justice l'a ordonnée.",
    "Les fournisseurs ne peuvent pas non plus couper l'électricité ou le gaz pour impayés pendant cette période (une réduction de puissance reste possible pour l'électricité).", "", "Code des procédures civiles d'exécution, art. L412-6");
  Q(DR, 4, "Depuis le 1er janvier 2025, quels logements sont considérés comme non décents et ne peuvent plus être mis en location en France métropolitaine ?", "Les logements classés G au DPE", ["Les logements classés E, F et G", "Les logements sans ascenseur", "Les logements de moins de 20 m²"],
    "La loi Climat et résilience fixe un calendrier : classe G non décente depuis 2025, F à partir de 2028, E à partir de 2034.",
    "Le DPE (diagnostic de performance énergétique) classe les logements de A à G.", "Une surface minimale existe mais elle est de 9 m² (avec 2,20 m de hauteur) ou un volume de 20 m³.", "Loi du 22 août 2021 (Climat et résilience)");
  Q(DR, 2, "Où peut-on enregistrer un PACS en France ?", "En mairie ou chez un notaire", ["Uniquement au tribunal", "Uniquement à la préfecture", "À l'église ou en mairie"],
    "Depuis le 1er novembre 2017, l'enregistrement des PACS a été transféré des tribunaux aux mairies. Il peut aussi être fait par un notaire.",
    "Le PACS crée une solidarité pour les dettes de la vie courante, mais pas de droit à l'héritage automatique : un testament est nécessaire.", "", "Code civil, art. 515-3");
  Q(DR, 4, "Le conjoint survivant marié paie-t-il des droits de succession sur ce qu'il hérite de son époux ?", "Non, il en est totalement exonéré", ["Oui, 20 % après un abattement de 100 000 €", "Oui, 60 %", "Seulement au-delà de 1 million d'euros"],
    "Depuis la loi TEPA de 2007, le conjoint survivant et le partenaire de PACS sont exonérés de droits de succession.",
    "Les enfants bénéficient d'un abattement de 100 000 € chacun sur la part reçue de chaque parent, puis d'un barème progressif.", "La « réserve héréditaire » protège les enfants : une partie du patrimoine leur revient obligatoirement.", "Code général des impôts, art. 796-0 bis ; art. 779");
  Q(DR, 3, "Quel principe énonce l'article 1240 du Code civil (ancien article 1382) ?", "Celui qui cause un dommage à autrui par sa faute doit le réparer", ["Nul n'est censé ignorer la loi", "Toute personne est présumée innocente", "Le contrat fait la loi des parties"],
    "« Tout fait quelconque de l'homme, qui cause à autrui un dommage, oblige celui par la faute duquel il est arrivé à le réparer. » C'est le fondement de la responsabilité civile.",
    "La responsabilité civile vise à réparer (indemniser) ; la responsabilité pénale vise à punir une infraction. Un même fait peut engager les deux.", "", "Code civil, art. 1240", "hist");
  Q(DR, 2, "Combien de députés compte l'Assemblée nationale ?", "577", ["348", "500", "925"],
    "L'Assemblée nationale compte 577 députés élus pour 5 ans au scrutin uninominal majoritaire à deux tours.",
    "Le Sénat compte 348 sénateurs élus au suffrage universel indirect. Réunis en Congrès à Versailles, ils peuvent réviser la Constitution.", "", "Code électoral, art. LO119 ; assemblee-nationale.fr");
  Q(DR, 4, "En droit de l'Union européenne, quelle est la différence entre un règlement et une directive ?", "Le règlement s'applique directement ; la directive fixe un objectif que chaque État doit transposer", ["La directive est plus contraignante que le règlement", "Le règlement ne concerne que les entreprises", "Il n'y a aucune différence"],
    "Un règlement est obligatoire dans tous ses éléments et directement applicable. Une directive lie les États quant au résultat, en leur laissant le choix des moyens et un délai de transposition.",
    "Le RGPD est un règlement ; la directive « temps de travail » de 2003 a été transposée dans chaque droit national.", "Le principe de primauté du droit de l'UE sur le droit national a été affirmé par l'arrêt Costa c/ ENEL (1964).", "TFUE, art. 288", "hist");
  Q(DR, 3, "Quel texte de 1789 fait partie du « bloc de constitutionnalité » français ?", "La Déclaration des droits de l'homme et du citoyen", ["Le Code civil", "La Charte des droits fondamentaux de l'UE", "La Convention européenne des droits de l'homme"],
    "Le préambule de la Constitution de 1958 renvoie à la DDHC de 1789 et au préambule de 1946 ; le Conseil constitutionnel leur reconnaît valeur constitutionnelle depuis 1971.",
    "La Charte de l'environnement (2004) fait aussi partie du bloc de constitutionnalité.", "", "Conseil constitutionnel, décision Liberté d'association, 1971", "hist");

  // ---------------- FINANCE PERSONNELLE ----------------
  const FI = "Finance personnelle";
  Q(FI, 1, "Sur une fiche de paie, qu'obtient-on en retirant les cotisations salariales du salaire brut ?", "Le salaire net (avant impôt)", ["Le salaire super-brut", "Le coût employeur", "Le revenu fiscal de référence"],
    "Brut − cotisations salariales = net avant impôt. On retire ensuite le prélèvement à la source pour obtenir le « net à payer ».",
    "Depuis 2024, la fiche de paie affiche aussi un « montant net social », utilisé pour calculer certaines prestations sociales.", "Le coût total pour l'employeur ajoute au brut les cotisations patronales.", "service-public.fr, bulletin de paie");
  Q(FI, 2, "Depuis quand l'impôt sur le revenu est-il prélevé à la source en France ?", "Le 1er janvier 2019", ["Le 1er janvier 2015", "Le 1er janvier 2022", "Depuis toujours"],
    "Le prélèvement à la source collecte l'impôt au moment du versement du revenu, avec un taux calculé par l'administration fiscale.",
    "La déclaration annuelle reste obligatoire : elle permet de régulariser l'impôt dû.", "", "Loi de finances pour 2017", "hist");
  Q(FI, 4, "Un contribuable est dans la tranche marginale d'imposition à 30 %. Que signifie ce taux ?", "Seule la part de revenu au-delà du seuil de cette tranche est imposée à 30 %", ["Tout son revenu est imposé à 30 %", "Il paie 30 % de son salaire brut", "Il est exonéré au-dessous de 30 000 €"],
    "L'impôt sur le revenu est progressif par tranches : chaque tranche de revenu est imposée à son propre taux. Le taux moyen réellement payé est donc toujours inférieur au taux marginal.",
    "Passer dans une tranche supérieure ne fait jamais baisser le revenu après impôt : c'est une idée reçue.", "Exercice de raisonnement : calculer le taux moyen montre l'écart avec le taux marginal.", "Code général des impôts, art. 197");
  Q(FI, 3, "Vous placez 1 000 € à 5 % par an, intérêts capitalisés. De combien disposez-vous au bout de 2 ans ?", "1 102,50 €", ["1 100,00 €", "1 105,00 €", "1 050,00 €"],
    "Année 1 : 1 000 × 1,05 = 1 050 €. Année 2 : 1 050 × 1,05 = 1 102,50 €. Les intérêts de la première année produisent eux-mêmes des intérêts : ce sont les intérêts composés.",
    "Règle de 72 : en divisant 72 par le taux, on estime le nombre d'années pour doubler un capital (ici environ 14 ans).", "", "Calcul financier", "sci");
  Q(FI, 2, "Quel est le plafond de dépôt du Livret A pour une personne physique ?", "22 950 €", ["10 000 €", "15 300 €", "50 000 €"],
    "Le plafond est de 22 950 € (hors intérêts capitalisés) depuis 2013. Les intérêts sont exonérés d'impôt et de prélèvements sociaux.",
    "Son taux est fixé par l'État selon une formule liée à l'inflation et aux taux du marché : il évolue plusieurs fois par décennie.", "", "Code monétaire et financier, art. D221-2");
  Q(FI, 3, "Que mesure le TAEG d'un crédit ?", "Le coût total du crédit (intérêts, frais, assurance obligatoire) exprimé en taux annuel", ["Uniquement le taux d'intérêt nominal", "Le taux d'inflation prévu", "La commission de la banque centrale"],
    "Le taux annuel effectif global inclut tous les frais obligatoires. C'est l'indicateur à utiliser pour comparer deux offres de prêt.",
    "Il ne peut pas dépasser le « taux d'usure », plafond fixé chaque trimestre par la Banque de France.", "", "Code de la consommation, art. L314-1");
  Q(FI, 4, "Quel taux d'endettement maximal (assurance comprise) les banques doivent-elles en principe respecter pour un crédit immobilier en France ?", "35 %", ["25 %", "33 % hors assurance", "50 %"],
    "Le Haut Conseil de stabilité financière impose depuis 2022 un taux d'effort maximal de 35 % des revenus, assurance incluse, et une durée maximale de 25 ans (27 ans dans certains cas).",
    "Les banques disposent d'une marge de dérogation limitée à 20 % de leurs dossiers.", "", "Décision HCSF n° D-HCSF-2021-7");
  Q(FI, 2, "Votre épargne rapporte 3 % par an et l'inflation est de 4 %. Que se passe-t-il pour votre pouvoir d'achat ?", "Il diminue d'environ 1 % par an", ["Il augmente de 3 %", "Il augmente de 7 %", "Il ne change pas"],
    "Le rendement réel est approximativement le rendement nominal moins l'inflation : 3 % − 4 % = −1 %. L'épargne grossit en euros mais achète moins.",
    "C'est pourquoi on compare les placements en taux « réel » et non seulement « nominal ».", "", "Notion d'économie", "sci");
  Q(FI, 3, "Après combien d'années l'assurance-vie bénéficie-t-elle d'une fiscalité plus favorable sur les gains en cas de rachat ?", "8 ans", ["2 ans", "5 ans", "15 ans"],
    "Après 8 ans, les gains bénéficient d'un abattement annuel (4 600 € pour une personne seule, 9 200 € pour un couple) et d'un taux réduit.",
    "L'assurance-vie permet aussi de transmettre un capital aux bénéficiaires désignés avec une fiscalité spécifique.", "", "Code général des impôts, art. 125-0 A");
  Q(FI, 2, "Quelle est la différence principale entre une action et une obligation ?", "L'action est une part du capital d'une entreprise ; l'obligation est une part d'une dette", ["L'action est garantie par l'État", "L'obligation donne un droit de vote", "Il n'y a aucune différence"],
    "Un actionnaire est copropriétaire de l'entreprise (dividendes, droit de vote, risque de perte). Un détenteur d'obligation est un prêteur qui perçoit des intérêts.",
    "Les obligations sont en général moins risquées que les actions, mais rapportent moins sur le long terme.", "", "AMF, guide de l'épargnant", "sci");
  Q(FI, 2, "Comment fonctionne le système de retraite de base français ?", "Par répartition : les cotisations des actifs financent les pensions des retraités actuels", ["Par capitalisation : chacun épargne pour sa propre retraite", "Uniquement par l'impôt", "Par une épargne obligatoire placée en Bourse"],
    "Le régime par répartition repose sur la solidarité entre générations. Son équilibre dépend du rapport entre cotisants et retraités.",
    "La capitalisation existe en complément (PER, épargne salariale).", "", "info-retraite.fr", "hist");
  Q(FI, 3, "Que permet surtout la diversification d'un portefeuille de placements ?", "Réduire le risque global sans forcément réduire le rendement attendu", ["Garantir l'absence de pertes", "Éviter l'impôt", "Doubler le rendement"],
    "En répartissant son épargne entre plusieurs actifs, secteurs et zones géographiques, on limite l'impact d'une mauvaise performance isolée.",
    "Un ETF (ou « tracker ») réplique un indice entier, ce qui permet une diversification à faible coût.", "", "AMF", "sci");
  Q(FI, 1, "Selon la règle budgétaire dite « 50/30/20 », à quoi sont consacrés les 20 % ?", "À l'épargne et au remboursement des dettes", ["Aux loisirs", "Au logement", "Aux impôts"],
    "La règle propose 50 % pour les besoins essentiels, 30 % pour les envies, 20 % pour l'épargne et le désendettement. C'est un repère, pas une norme.",
    "Elle a été popularisée par Elizabeth Warren dans un livre de 2005.", "", "Notion de gestion budgétaire", "sci");

  // ---------------- VIE PROFESSIONNELLE ----------------
  const VP = "Vie professionnelle";
  Q(VP, 2, "Que signifie l'acronyme SMART pour formuler un objectif ?", "Spécifique, mesurable, atteignable, réaliste, temporellement défini", ["Simple, moderne, ambitieux, rapide, tenace", "Stratégique, motivant, accepté, révisable, transparent", "Solide, mesuré, adapté, raisonné, terminé"],
    "Un objectif SMART est formulé de façon précise et vérifiable : « augmenter le taux de réponse client de 80 % à 90 % d'ici juin » plutôt que « mieux répondre aux clients ».",
    "Le A est parfois traduit par « ambitieux » ou « accepté » selon les écoles.", "", "Management par objectifs (Doran, 1981)", "sci");
  Q(VP, 2, "Quel outil représente les tâches d'un projet sur une ligne de temps, avec leur durée et leurs dépendances ?", "Le diagramme de Gantt", ["La matrice SWOT", "Le diagramme d'Ishikawa", "La matrice RACI"],
    "Le diagramme de Gantt, popularisé par Henry Gantt vers 1910, montre l'enchaînement des tâches et permet d'identifier le chemin critique.",
    "La matrice RACI répartit les rôles (Réalise, Approuve, Consulté, Informé) ; le diagramme d'Ishikawa recherche les causes d'un problème.", "", "Gestion de projet", "sci");
  Q(VP, 3, "Dans la matrice d'Eisenhower, que faire d'une tâche importante mais non urgente ?", "La planifier", ["La faire immédiatement", "La déléguer", "L'abandonner"],
    "Urgent et important : faire tout de suite. Important non urgent : planifier. Urgent non important : déléguer. Ni l'un ni l'autre : éliminer.",
    "Les tâches importantes non urgentes (formation, prévention, stratégie) sont souvent les plus négligées et les plus utiles.", "", "Gestion du temps", "sci");
  Q(VP, 3, "Que désigne le principe de Pareto appliqué au travail ?", "Environ 80 % des effets proviennent d'environ 20 % des causes", ["Il faut travailler 80 % du temps et se reposer 20 %", "80 % des projets échouent", "Il faut déléguer 80 % des tâches"],
    "Observé par l'économiste Vilfredo Pareto sur la répartition des richesses, ce principe empirique aide à prioriser : quelques clients, défauts ou tâches pèsent la majorité des résultats.",
    "Le ratio 80/20 n'est qu'un ordre de grandeur, pas une loi exacte.", "", "Qualité et management", "sci");
  Q(VP, 3, "Que signifient les quatre étapes de la roue de Deming (PDCA) ?", "Planifier, faire, vérifier, agir", ["Préparer, décider, contrôler, archiver", "Produire, distribuer, commercialiser, analyser", "Proposer, débattre, choisir, appliquer"],
    "Plan-Do-Check-Act est une boucle d'amélioration continue au cœur des démarches qualité (ISO 9001, Lean).",
    "W. Edwards Deming l'a diffusée au Japon dans les années 1950.", "", "Démarche qualité", "sci");
  Q(VP, 3, "Quelle norme internationale concerne le management de la qualité ?", "ISO 9001", ["ISO 14001", "ISO 45001", "ISO 27001"],
    "ISO 9001 : qualité. ISO 14001 : environnement. ISO 45001 : santé et sécurité au travail. ISO 27001 : sécurité de l'information.",
    "On parle de démarche QSE pour l'intégration qualité, sécurité, environnement.", "", "Organisation internationale de normalisation (iso.org)", "hist");
  Q(VP, 4, "En négociation, que désigne la BATNA (MESORE en français) ?", "La meilleure solution de repli si la négociation échoue", ["Le prix de départ annoncé", "La concession maximale acceptable", "Le délai maximal de la négociation"],
    "Connaître sa meilleure alternative permet de savoir quand quitter la table : on n'accepte pas un accord moins bon que sa solution de repli.",
    "Le concept vient du livre Getting to Yes (Fisher et Ury, 1981), issu du projet de négociation de Harvard.", "", "Négociation raisonnée", "sci");
  Q(VP, 2, "Dans Excel, que permet le symbole $ dans la référence $A$1 ?", "De figer la colonne et la ligne lors de la copie d'une formule", ["D'afficher une valeur en dollars", "De protéger la cellule contre la modification", "De masquer la cellule"],
    "Une référence absolue ($A$1) ne change pas quand on recopie la formule ; A1 est relative ; $A1 et A$1 sont mixtes.",
    "La touche F4 bascule entre ces types de références.", "", "Bureautique", "sci");
  Q(VP, 3, "Sur la série 2, 3, 3, 4, 40, quelle mesure résume le mieux la valeur « typique » ?", "La médiane (3)", ["La moyenne (10,4)", "Le maximum (40)", "L'étendue (38)"],
    "La moyenne (10,4) est tirée vers le haut par la valeur extrême 40. La médiane, valeur centrale de la série ordonnée, résiste aux valeurs aberrantes.",
    "C'est pourquoi on parle souvent de salaire médian plutôt que de salaire moyen.", "Question de raisonnement : toujours regarder la distribution avant de résumer un chiffre.", "Statistique descriptive", "sci");
  Q(VP, 3, "À partir de quel effectif une entreprise doit-elle mettre en place un comité social et économique (CSE) ?", "11 salariés", ["20 salariés", "50 salariés", "250 salariés"],
    "Le CSE est obligatoire dès 11 salariés pendant 12 mois consécutifs. Ses attributions s'élargissent à partir de 50 salariés.",
    "Le CSE a remplacé en 2018-2020 les délégués du personnel, le comité d'entreprise et le CHSCT.", "", "Code du travail, art. L2311-2");
  Q(VP, 2, "Lors d'un conflit entre collègues, quelle approche de communication non violente est recommandée ?", "Décrire les faits, exprimer son ressenti et son besoin, formuler une demande précise", ["Rappeler les erreurs passées de l'autre", "Éviter le sujet jusqu'à ce qu'il disparaisse", "Faire arbitrer immédiatement par la direction"],
    "La communication non violente (Marshall Rosenberg) suit quatre étapes : observation, sentiment, besoin, demande. Elle évite le jugement et ouvre la discussion.",
    "Le format « quand…, je me sens…, parce que j'ai besoin de…, est-ce que tu pourrais… ? » en est la traduction pratique.", "", "Marshall B. Rosenberg, 1999", "sci");
  Q(VP, 4, "Quelle analyse croise forces, faiblesses (internes) et opportunités, menaces (externes) ?", "L'analyse SWOT", ["L'analyse PESTEL", "Les cinq forces de Porter", "La matrice BCG"],
    "SWOT : Strengths, Weaknesses, Opportunities, Threats. PESTEL analyse l'environnement (politique, économique, social, technologique, écologique, légal) ; Porter, l'intensité concurrentielle d'un secteur.",
    "La matrice BCG classe les activités selon la croissance du marché et la part de marché.", "", "Stratégie d'entreprise", "sci");

  // ---------------- VIE QUOTIDIENNE ----------------
  const VQ = "Vie quotidienne";
  Q(VQ, 2, "Quand doit avoir lieu le premier contrôle technique d'une voiture particulière neuve en France ?", "Dans les 6 mois précédant son 4e anniversaire", ["Après 2 ans", "Après 5 ans", "Tous les ans dès l'achat"],
    "Le premier contrôle a lieu avant les 4 ans du véhicule, puis tous les 2 ans.",
    "Un contrôle technique est aussi exigé lors de la vente d'un véhicule de plus de 4 ans (moins de 6 mois).", "", "Code de la route, art. R323-22");
  Q(VQ, 1, "Quelle assurance automobile est obligatoire au minimum ?", "La responsabilité civile (assurance « au tiers »)", ["L'assurance tous risques", "L'assurance vol", "L'assurance bris de glace"],
    "Tout véhicule terrestre à moteur doit être assuré au minimum en responsabilité civile, qui couvre les dommages causés aux autres.",
    "Les garanties tous risques, vol ou bris de glace sont facultatives.", "", "Code des assurances, art. L211-1");
  Q(VQ, 2, "Quelle mention signifie qu'un aliment peut être consommé après la date, sans danger, mais avec une qualité éventuellement moindre ?", "« À consommer de préférence avant le… » (DDM)", ["« À consommer jusqu'au… » (DLC)", "« Fabriqué le… »", "« Date d'emballage »"],
    "La DLC (« à consommer jusqu'au ») concerne les produits périssables : on ne doit pas les consommer après. La DDM est une date de qualité, pas de sécurité.",
    "Mieux comprendre ces dates réduit le gaspillage alimentaire.", "", "Règlement (UE) n° 1169/2011", "hist");
  Q(VQ, 3, "Quelle est la différence entre un kilowatt (kW) et un kilowattheure (kWh) ?", "Le kW mesure une puissance, le kWh une énergie consommée", ["Ce sont deux unités identiques", "Le kWh mesure une puissance", "Le kW mesure un prix"],
    "Un appareil de 2 kW qui fonctionne 3 heures consomme 6 kWh. La facture d'électricité facture l'énergie (kWh) et un abonnement lié à la puissance souscrite (kVA).",
    "Diviser sa consommation par deux revient souvent à réduire la durée d'utilisation des appareils les plus puissants (chauffage, eau chaude).", "Question de calcul : énergie = puissance × durée.", "Physique appliquée", "sci");
  Q(VQ, 3, "Dans un tableau électrique domestique, à quoi sert un interrupteur différentiel 30 mA ?", "À protéger les personnes contre l'électrocution en coupant en cas de fuite de courant", ["À limiter la consommation", "À protéger contre la foudre uniquement", "À compter l'énergie consommée"],
    "Il détecte une différence entre le courant qui entre et celui qui sort d'un circuit (fuite vers la terre, par exemple à travers un corps) et coupe en quelques millisecondes.",
    "Les disjoncteurs divisionnaires protègent, eux, les circuits contre les surcharges et courts-circuits.", "", "Norme NF C 15-100", "sci");
  Q(VQ, 2, "Quelle carte permet d'être pris en charge pour des soins médicalement nécessaires lors d'un séjour temporaire dans un autre pays de l'UE ?", "La carte européenne d'assurance maladie (CEAM)", ["La carte Vitale", "Le passeport", "La carte d'identité"],
    "La CEAM se demande gratuitement à l'Assurance maladie et donne accès aux soins dans les mêmes conditions que les assurés du pays visité.",
    "Elle fonctionne dans l'UE, l'EEE et en Suisse, mais pas au Royaume-Uni pour tous les cas depuis le Brexit (une carte GHIC existe côté britannique).", "", "ameli.fr");
  Q(VQ, 2, "Combien de temps conseille-t-on de conserver ses avis d'imposition sur le revenu ?", "Au moins 3 ans", ["6 mois", "1 an", "Jusqu'à la retraite"],
    "L'administration fiscale peut en principe revenir sur les 3 années précédentes (délai de reprise). Les bulletins de paie, eux, sont à conserver jusqu'à la liquidation de la retraite.",
    "Les factures d'électricité et de gaz se conservent 5 ans.", "", "service-public.fr, durées de conservation");
  Q(VQ, 2, "Quel est l'organisme qui gère en ligne les demandes de titres (permis de conduire, carte grise, papiers d'identité) en France ?", "L'ANTS (Agence nationale des titres sécurisés)", ["La CAF", "France Travail", "L'URSSAF"],
    "Les démarches se font sur le site de l'ANTS ; pour la carte d'identité et le passeport, il faut ensuite un rendez-vous en mairie pour les empreintes.",
    "La pré-demande en ligne fait gagner du temps lors du rendez-vous en mairie.", "", "ants.gouv.fr");
  Q(VQ, 3, "Pour une même distance, quel mode de transport émet généralement le moins de CO₂ par passager en France ?", "Le train", ["L'avion", "La voiture avec un seul occupant", "L'autocar"],
    "Grâce à une électricité très décarbonée, le TGV émet en France quelques grammes de CO₂ par passager-kilomètre, contre plus de 100 g pour une voiture avec un seul occupant et davantage pour l'avion sur courte distance.",
    "L'autocar plein est aussi peu émetteur, mais reste au-dessus du train électrique en France.", "", "ADEME, Base Empreinte");

  // ---------------- SANTÉ ET PRÉVENTION ----------------
  const SA = "Santé et prévention";
  Q(SA, 1, "Quel est le numéro d'appel d'urgence européen, valable dans tous les pays de l'UE ?", "112", ["911", "999", "15"],
    "Le 112 fonctionne gratuitement dans toute l'UE, depuis un fixe ou un mobile. En France : 15 (SAMU), 17 (police), 18 (pompiers), 114 (par SMS pour les personnes sourdes ou malentendantes).",
    "Le 911 est le numéro des États-Unis et du Canada ; le 999 celui du Royaume-Uni (où le 112 fonctionne aussi).", "", "Commission européenne ; gouvernement.fr");
  Q(SA, 1, "Dans quel ordre agir face à un accident ?", "Protéger, alerter, secourir", ["Secourir, alerter, protéger", "Alerter, secourir, protéger", "Secourir, protéger, alerter"],
    "On protège d'abord (soi-même, la victime et les témoins, pour éviter un sur-accident), puis on alerte les secours, enfin on secourt.",
    "Lors de l'appel, on indique le lieu précis, la nature de l'accident, le nombre de victimes et leur état.", "", "Croix-Rouge française ; protection civile", "sci");
  Q(SA, 2, "Une personne est inconsciente mais respire normalement. Que faire ?", "La placer en position latérale de sécurité (PLS) et alerter", ["Commencer un massage cardiaque", "Lui donner à boire", "La laisser sur le dos sans bouger"],
    "La PLS évite que la langue ou des vomissements n'obstruent les voies respiratoires. On surveille ensuite sa respiration en attendant les secours.",
    "Si elle ne respire pas ou respire anormalement : alerter, masser (100 à 120 compressions par minute) et utiliser un défibrillateur dès qu'il est disponible.", "", "Recommandations de premiers secours (référentiels nationaux)", "sci");
  Q(SA, 3, "Quel est le bon geste immédiat face à une brûlure thermique peu étendue ?", "La refroidir sous l'eau tempérée environ 15 minutes", ["Appliquer de la glace directement", "Mettre du beurre ou de l'huile", "Percer les cloques"],
    "La « règle des 15 » : eau à environ 15 °C, à une quinzaine de centimètres, pendant environ 15 minutes. Cela limite l'aggravation de la brûlure et la douleur.",
    "Une brûlure étendue, profonde, au visage, aux mains ou chez un enfant justifie un avis médical rapide (15).", "", "Croix-Rouge française", "sci");
  Q(SA, 3, "Pourquoi le monoxyde de carbone (CO) est-il particulièrement dangereux ?", "Il est inodore et invisible, et prend la place de l'oxygène dans le sang", ["Il sent fortement le gaz", "Il est uniquement irritant pour les yeux", "Il n'est dangereux qu'en extérieur"],
    "Le CO, produit par une combustion incomplète (chaudière mal entretenue, chauffage d'appoint), se fixe sur l'hémoglobine. Maux de tête, nausées et somnolence doivent alerter.",
    "Le détecteur de fumée (DAAF) est obligatoire dans les logements depuis 2015 ; le détecteur de CO est recommandé.", "", "Santé publique France", "sci");
  Q(SA, 2, "Quelle durée minimale d'activité physique d'intensité modérée l'OMS recommande-t-elle chaque semaine aux adultes ?", "150 minutes", ["30 minutes", "60 minutes", "500 minutes"],
    "L'OMS recommande 150 à 300 minutes d'activité modérée (ou 75 à 150 minutes d'activité soutenue) par semaine, plus du renforcement musculaire deux fois par semaine.",
    "Réduire le temps passé assis est un objectif à part entière.", "", "OMS, lignes directrices 2020", "sci");
  Q(SA, 3, "Pourquoi les antibiotiques sont-ils inefficaces contre un rhume ou la grippe ?", "Ces maladies sont causées par des virus, alors que les antibiotiques agissent sur les bactéries", ["Parce que les doses sont trop faibles", "Parce que le rhume guérit trop vite", "Ils sont efficaces mais déconseillés"],
    "Les antibiotiques ciblent des structures propres aux bactéries. Les prendre sans raison favorise l'antibiorésistance, une menace sanitaire majeure.",
    "Le slogan « Les antibiotiques, c'est pas automatique » date de 2002.", "", "Assurance maladie ; OMS", "sci");
  Q(SA, 3, "Quels signes doivent faire penser à un AVC et appeler immédiatement le 15 ?", "Visage paralysé, faiblesse d'un bras, trouble de la parole", ["Fièvre et toux", "Démangeaisons et rougeurs", "Douleur au genou"],
    "L'acronyme anglais FAST (Face, Arm, Speech, Time) rappelle que chaque minute compte : les traitements sont d'autant plus efficaces qu'ils sont précoces.",
    "En France, on dénombre environ 140 000 AVC par an.", "", "Santé publique France", "sci");
  Q(SA, 2, "Combien d'heures de sommeil sont recommandées pour un adulte ?", "Entre 7 et 9 heures", ["Entre 4 et 5 heures", "Exactement 10 heures", "Peu importe"],
    "Les sociétés savantes recommandent 7 à 9 heures pour les adultes. Un manque chronique de sommeil est associé à des risques cardiovasculaires, métaboliques et d'accidents.",
    "La lumière des écrans le soir retarde la sécrétion de mélatonine.", "", "Inserm ; American Academy of Sleep Medicine", "sci");

  // ---------------- CULTURE NUMÉRIQUE ----------------
  const NU = "Culture numérique";
  Q(NU, 1, "Comment s'appelle une arnaque qui imite un organisme connu pour vous faire saisir vos identifiants ou coordonnées bancaires ?", "L'hameçonnage (phishing)", ["Le spam", "Le cookie", "Le pare-feu"],
    "L'hameçonnage passe par courriel, SMS (smishing) ou appel. Les signes : urgence, menace, lien vers une adresse qui ne correspond pas au vrai site, demande de données confidentielles.",
    "Une banque ne vous demandera jamais vos codes par téléphone ou courriel.", "", "cybermalveillance.gouv.fr", "contemp");
  Q(NU, 2, "Le cadenas affiché dans la barre d'adresse (HTTPS) garantit-il qu'un site est fiable ?", "Non : il garantit seulement que la connexion est chiffrée", ["Oui, c'est un label officiel de confiance", "Oui, s'il est vert", "Non, il signifie que le site est dangereux"],
    "Le HTTPS protège les données en transit contre l'interception. Mais un site frauduleux peut parfaitement obtenir un certificat HTTPS.",
    "Vérifiez toujours l'adresse exacte du site, en particulier le nom de domaine.", "", "ANSSI", "sci");
  Q(NU, 2, "Qu'est-ce que l'authentification à deux facteurs ?", "Combiner deux preuves d'identité différentes, par exemple un mot de passe et un code reçu sur son téléphone", ["Avoir deux mots de passe", "Se connecter depuis deux appareils", "Changer de mot de passe deux fois par an"],
    "Elle combine quelque chose que l'on sait (mot de passe), que l'on possède (téléphone, clé) ou que l'on est (empreinte). Un mot de passe volé ne suffit plus.",
    "C'est l'une des mesures les plus efficaces contre le piratage de comptes.", "", "ANSSI ; CNIL", "sci");
  Q(NU, 2, "En quelle année le RGPD est-il entré en application ?", "2018", ["2008", "2012", "2021"],
    "Le règlement général sur la protection des données s'applique depuis le 25 mai 2018 dans toute l'UE. En France, la CNIL veille à son respect.",
    "Il donne notamment un droit d'accès, de rectification, d'effacement et de portabilité de ses données.", "Les amendes peuvent atteindre 4 % du chiffre d'affaires mondial.", "Règlement (UE) 2016/679", "hist");
  Q(NU, 3, "Que recommande la règle de sauvegarde « 3-2-1 » ?", "3 copies des données, sur 2 supports différents, dont 1 hors site", ["Sauvegarder 3 fois par jour pendant 2 semaines", "3 mots de passe, 2 appareils, 1 coffre-fort", "Supprimer les fichiers de plus de 3 ans"],
    "Cette règle protège contre la panne d'un support, le vol, l'incendie ou un rançongiciel (ransomware) qui chiffrerait aussi les sauvegardes connectées.",
    "Une sauvegarde déconnectée ou « immuable » est la meilleure parade contre les rançongiciels.", "", "ANSSI", "sci");
  Q(NU, 3, "Que fait le système DNS sur Internet ?", "Il traduit les noms de domaine en adresses IP", ["Il chiffre les courriels", "Il bloque les virus", "Il accélère le Wi-Fi"],
    "Quand vous tapez un nom de site, un serveur DNS fournit l'adresse IP numérique du serveur à joindre. C'est « l'annuaire » d'Internet.",
    "Le DNS a été conçu en 1983 par Paul Mockapetris.", "", "IETF, RFC 1034-1035", "hist");
  Q(NU, 3, "Pourquoi un assistant d'intelligence artificielle générative peut-il donner une réponse fausse avec assurance ?", "Il produit le texte le plus plausible statistiquement, sans vérifier les faits par défaut", ["Parce qu'il ment volontairement", "Parce qu'il est connecté à des sites peu fiables uniquement", "Cela n'arrive jamais"],
    "Les grands modèles de langage prédisent la suite d'un texte. Sans source vérifiée, ils peuvent inventer des faits : on parle d'« hallucinations ».",
    "Bonne pratique : demander les sources, recouper, et vérifier toute information importante.", "", "CNIL ; recommandations sur l'IA générative", "contemp");
  Q(NU, 2, "Combien de bits contient un octet ?", "8", ["2", "10", "16"],
    "Un octet (byte) contient 8 bits et peut prendre 256 valeurs. Un bit vaut 0 ou 1.",
    "En informatique, 1 kio = 1 024 octets, alors que 1 ko = 1 000 octets selon le Système international.", "", "Informatique fondamentale", "sci");
  Q(NU, 4, "Un ordinateur ralentit quand de nombreux programmes sont ouverts. Quelle ressource est le plus souvent saturée ?", "La mémoire vive (RAM)", ["Le disque dur, parce qu'il est plein de photos", "L'écran", "La batterie"],
    "La RAM stocke temporairement les programmes en cours d'exécution. Quand elle est pleine, le système utilise le disque comme mémoire d'appoint, beaucoup plus lent.",
    "Le stockage (SSD, disque dur) conserve les fichiers ; la RAM est vidée à l'extinction.", "Question de raisonnement : relier un symptôme à une cause matérielle.", "Informatique fondamentale", "sci");
})(typeof window !== "undefined" ? window : globalThis);
