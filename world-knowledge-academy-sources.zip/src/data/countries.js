/* World Knowledge Academy — Données pays (couche DONNÉES)
 * -----------------------------------------------------------------
 * Chaque ligne : [iso2, nom, forme "de …", capitale, continent, population (millions),
 *                 superficie (km²), monnaie, langues officielles, régime, voisins terrestres,
 *                 lat, lon (capitale), notoriété 1-5, anecdote]
 *
 * Sources et fiabilité :
 *  - Population : ONU, World Population Prospects 2024 (estimation mi-2024), arrondie.
 *    Donnée ÉVOLUTIVE : les questions générées ne testent que des ordres de grandeur
 *    ou des comparaisons avec un écart minimal de 25 %, pour rester vraies malgré l'arrondi.
 *  - Superficie : superficie totale (terres + eaux intérieures), CIA World Factbook / ONU.
 *  - Régime politique : classification simplifiée, ÉVOLUTIVE (coups d'État, réformes).
 *  - Capitales, langues, monnaies : constitutions et sites officiels ; cas particuliers signalés
 *    dans CAPITAL_NOTES et exclus des questions automatiques lorsque le sujet est contesté.
 * Date de dernière vérification de l'ensemble : voir META.
 */
(function (W) {
  const META = {
    populationSource: "ONU, World Population Prospects 2024 (estimations mi-2024, arrondies)",
    areaSource: "CIA World Factbook / Division statistique de l'ONU (superficie totale)",
    politicalSource: "Constitutions et sites officiels des gouvernements",
    verifiedAt: "2026-06",
    verifiedNote: "Vérification sur connaissances arrêtées en juin 2026. À revérifier avant toute mise en production."
  };

  const CONTINENTS = {
    EU: { name: "Europe", du: "d'Europe" },
    AS: { name: "Asie", du: "d'Asie" },
    AF: { name: "Afrique", du: "d'Afrique" },
    NA: { name: "Amérique du Nord et centrale", du: "d'Amérique du Nord et centrale" },
    SA: { name: "Amérique du Sud", du: "d'Amérique du Sud" },
    OC: { name: "Océanie", du: "d'Océanie" }
  };

  const CURRENCIES = {
    EUR: "euro", GBP: "livre sterling", CHF: "franc suisse", PLN: "złoty", CZK: "couronne tchèque",
    HUF: "forint", RON: "leu roumain", SEK: "couronne suédoise", NOK: "couronne norvégienne",
    DKK: "couronne danoise", ISK: "couronne islandaise", UAH: "hryvnia", RUB: "rouble russe",
    RSD: "dinar serbe", BYN: "rouble biélorusse", MDL: "leu moldave", ALL: "lek", MKD: "denar",
    BAM: "mark convertible", CNY: "yuan (renminbi)", INR: "roupie indienne", JPY: "yen",
    KRW: "won sud-coréen", KPW: "won nord-coréen", IDR: "roupie indonésienne", PKR: "roupie pakistanaise",
    BDT: "taka", VND: "dong", THB: "baht", PHP: "peso philippin", MYR: "ringgit", SGD: "dollar de Singapour",
    MMK: "kyat", KHR: "riel", LAK: "kip", MNT: "tugrik", KZT: "tenge", UZS: "sum", AFN: "afghani",
    IRR: "rial iranien", IQD: "dinar irakien", SAR: "riyal saoudien", AED: "dirham émirien",
    QAR: "riyal qatari", ILS: "shekel", TRY: "livre turque", JOD: "dinar jordanien", LBP: "livre libanaise",
    SYP: "livre syrienne", NPR: "roupie népalaise", LKR: "roupie srilankaise", GEL: "lari", AMD: "dram",
    AZN: "manat azerbaïdjanais", OMR: "rial omanais", YER: "rial yéménite", KWD: "dinar koweïtien",
    BTN: "ngultrum", TJS: "somoni", KGS: "som", TMT: "manat turkmène", BND: "dollar de Brunei",
    USD: "dollar américain", NGN: "naira", EGP: "livre égyptienne", ETB: "birr", CDF: "franc congolais",
    ZAR: "rand", KES: "shilling kényan", TZS: "shilling tanzanien", DZD: "dinar algérien",
    MAD: "dirham marocain", TND: "dinar tunisien", LYD: "dinar libyen", SDG: "livre soudanaise",
    GHS: "cedi", XOF: "franc CFA (UEMOA)", XAF: "franc CFA (CEMAC)", AOA: "kwanza", MZN: "metical",
    MGA: "ariary", RWF: "franc rwandais", UGX: "shilling ougandais", SOS: "shilling somalien",
    ZWG: "ZiG (or du Zimbabwe)", ZMW: "kwacha zambien", NAD: "dollar namibien", BWP: "pula",
    SSP: "livre sud-soudanaise", ERN: "nakfa", DJF: "franc de Djibouti", MRU: "ouguiya",
    GNF: "franc guinéen", LRD: "dollar libérien", SLE: "leone", MWK: "kwacha malawite",
    BIF: "franc burundais", MUR: "roupie mauricienne", CVE: "escudo cap-verdien", LSL: "loti",
    SZL: "lilangeni", CAD: "dollar canadien", MXN: "peso mexicain", BRL: "real", ARS: "peso argentin",
    CLP: "peso chilien", COP: "peso colombien", PEN: "sol", VES: "bolívar", BOB: "boliviano",
    PYG: "guarani", UYU: "peso uruguayen", CUP: "peso cubain", GTQ: "quetzal", PAB: "balboa",
    CRC: "colón costaricien", HTG: "gourde", DOP: "peso dominicain", JMD: "dollar jamaïcain",
    HNL: "lempira", NIO: "córdoba", BZD: "dollar bélizien", GYD: "dollar guyanien", SRD: "dollar surinamais",
    AUD: "dollar australien", NZD: "dollar néo-zélandais", PGK: "kina", FJD: "dollar fidjien",
    WST: "tala", TOP: "paʻanga", VUV: "vatu", SBD: "dollar des îles Salomon"
  };

  const LANGUAGES = {
    fr: "français", de: "allemand", it: "italien", es: "espagnol", pt: "portugais", en: "anglais",
    ga: "irlandais", nl: "néerlandais", lb: "luxembourgeois", rm: "romanche", pl: "polonais",
    cs: "tchèque", sk: "slovaque", hu: "hongrois", ro: "roumain", bg: "bulgare", el: "grec",
    sv: "suédois", no: "norvégien", fi: "finnois", da: "danois", is: "islandais", uk: "ukrainien",
    ru: "russe", hr: "croate", sr: "serbe", sl: "slovène", et: "estonien", lv: "letton",
    lt: "lituanien", be: "biélorusse", sq: "albanais", mk: "macédonien", bs: "bosnien",
    cnr: "monténégrin", la: "latin", ca: "catalan", mt: "maltais", tr: "turc", zh: "chinois mandarin",
    hi: "hindi", ja: "japonais", ko: "coréen", id: "indonésien", ur: "ourdou", bn: "bengali",
    vi: "vietnamien", th: "thaï", fil: "filipino", ms: "malais", ta: "tamoul", my: "birman",
    km: "khmer", lo: "lao", mn: "mongol", kk: "kazakh", uz: "ouzbek", ps: "pachto", prs: "dari",
    fa: "persan", ar: "arabe", ku: "kurde", he: "hébreu", ne: "népalais", si: "cinghalais",
    ka: "géorgien", hy: "arménien", az: "azéri", dz: "dzongkha", tg: "tadjik", ky: "kirghiz",
    tk: "turkmène", tet: "tétoum", am: "amharique", sw: "swahili", ber: "tamazight (berbère)",
    so: "somali", rw: "kinyarwanda", mg: "malgache", ny: "chichewa", rn: "kirundi", st: "sesotho",
    ss: "swati", tn: "setswana", sg: "sango", ti: "tigrinya", qu: "quechua", ay: "aymara",
    gn: "guarani", ht: "créole haïtien", mi: "maori", tpi: "tok pisin", fj: "fidjien",
    sm: "samoan", to: "tongien", bi: "bichelamar", zu: "zoulou", xh: "xhosa", af: "afrikaans",
    gil: "gilbertin", tvl: "tuvaluan", na: "nauruan"
  };

  const GOV = {
    PRES: "République présidentielle",
    SEMI: "République semi-présidentielle",
    PARL: "République parlementaire",
    DIR: "République fédérale à gouvernement collégial (directoire)",
    MPARL: "Monarchie constitutionnelle (parlementaire)",
    MABS: "Monarchie absolue",
    UNI: "État à parti unique",
    THEO: "République islamique (théocratie élective)",
    MIL: "Régime militaire de transition",
    TRANS: "Autorités de transition / situation instable",
    VAT: "Monarchie absolue élective (Saint-Siège)"
  };

  // [iso, nom, du, capitale, cont, popM, superficie, monnaie, langues, régime, voisins, lat, lon, notoriété, anecdote]
  const ROWS = [
    // ---------- EUROPE ----------
    ["FR","France","de la France","Paris","EU",66.5,643801,"EUR","fr","SEMI","BE LU DE CH IT MC ES AD BR SR",48.86,2.35,1,"Grâce à ses territoires d'outre-mer, la France est le pays qui couvre le plus de fuseaux horaires (12, 13 avec l'Antarctique)."],
    ["DE","Allemagne","de l'Allemagne","Berlin","EU",84.6,357588,"EUR","de","PARL","DK PL CZ AT CH FR LU BE NL",52.52,13.4,1,"L'Allemagne partage des frontières avec 9 pays, record de l'Union européenne."],
    ["IT","Italie","de l'Italie","Rome","EU",59.3,302073,"EUR","it","PARL","FR CH AT SI SM VA",41.9,12.5,1,"L'Italie entoure entièrement deux États souverains : Saint-Marin et le Vatican."],
    ["ES","Espagne","de l'Espagne","Madrid","EU",47.9,505990,"EUR","es","MPARL","FR PT AD MA",40.42,-3.7,1,"Par Ceuta et Melilla, l'Espagne possède une frontière terrestre avec le Maroc, en Afrique."],
    ["PT","Portugal","du Portugal","Lisbonne","EU",10.4,92212,"EUR","pt","SEMI","ES",38.72,-9.14,2,"La frontière entre le Portugal et l'Espagne est l'une des plus anciennes d'Europe, quasi inchangée depuis le XIIIᵉ siècle."],
    ["GB","Royaume-Uni","du Royaume-Uni","Londres","EU",69.1,243610,"GBP","en","MPARL","IE",51.51,-0.13,1,"Le Royaume-Uni n'a pas de constitution codifiée en un seul texte."],
    ["IE","Irlande","de l'Irlande","Dublin","EU",5.3,70273,"EUR","ga en","PARL","GB",53.35,-6.26,2,"La harpe est le symbole officiel de l'État irlandais."],
    ["BE","Belgique","de la Belgique","Bruxelles","EU",11.8,30689,"EUR","nl fr de","MPARL","FR LU DE NL",50.85,4.35,1,"Bruxelles accueille les principales institutions de l'UE et le siège de l'OTAN."],
    ["NL","Pays-Bas","des Pays-Bas","Amsterdam","EU",18.2,41850,"EUR","nl","MPARL","BE DE",52.37,4.9,1,"Amsterdam est la capitale constitutionnelle, mais le gouvernement et le Parlement siègent à La Haye."],
    ["LU","Luxembourg","du Luxembourg","Luxembourg","EU",0.67,2586,"EUR","lb fr de","MPARL","FR BE DE",49.61,6.13,2,"Le Luxembourg est le dernier grand-duché souverain au monde."],
    ["CH","Suisse","de la Suisse","Berne","EU",8.9,41285,"CHF","de fr it rm","DIR","FR DE AT LI IT",46.95,7.45,1,"La Suisse n'a pas officiellement de « capitale » : Berne est la « ville fédérale »."],
    ["AT","Autriche","de l'Autriche","Vienne","EU",9.1,83879,"EUR","de","PARL","DE CZ SK HU SI IT CH LI",48.21,16.37,2,"Vienne accueille l'un des quatre grands sièges de l'ONU, ainsi que l'OPEP et l'AIEA."],
    ["PL","Pologne","de la Pologne","Varsovie","EU",38.5,312696,"PLN","pl","PARL","DE CZ SK UA BY LT RU",52.23,21.01,2,"La vieille ville de Varsovie, détruite en 1944, a été reconstruite à l'identique et inscrite au patrimoine mondial."],
    ["CZ","Tchéquie","de la Tchéquie","Prague","EU",10.7,78871,"CZK","cs","PARL","DE PL SK AT",50.08,14.44,2,"La Tchéquie et la Slovaquie se sont séparées pacifiquement le 1ᵉʳ janvier 1993 (« divorce de velours »)."],
    ["SK","Slovaquie","de la Slovaquie","Bratislava","EU",5.5,49035,"EUR","sk","PARL","CZ PL UA HU AT",48.15,17.11,3,"Bratislava est la seule capitale limitrophe de deux autres pays (Autriche et Hongrie)."],
    ["HU","Hongrie","de la Hongrie","Budapest","EU",9.7,93028,"HUF","hu","PARL","AT SK UA RO RS HR SI",47.5,19.04,2,"Budapest est née en 1873 de la fusion de Buda, Óbuda et Pest."],
    ["RO","Roumanie","de la Roumanie","Bucarest","EU",19.0,238397,"RON","ro","SEMI","HU UA MD BG RS",44.43,26.1,2,"Le Palais du Parlement à Bucarest est l'un des plus grands bâtiments administratifs du monde."],
    ["BG","Bulgarie","de la Bulgarie","Sofia","EU",6.8,110879,"EUR","bg","PARL","RO RS MK GR TR",42.7,23.32,3,"La Bulgarie a adopté l'euro le 1ᵉʳ janvier 2026. L'alphabet cyrillique y a été développé au Xᵉ siècle."],
    ["GR","Grèce","de la Grèce","Athènes","EU",10.0,131957,"EUR","el","PARL","AL MK BG TR",37.98,23.73,1,"La Grèce compte environ 6 000 îles et îlots, dont seulement une centaine sont habités."],
    ["SE","Suède","de la Suède","Stockholm","EU",10.6,450295,"SEK","sv","MPARL","NO FI",59.33,18.07,2,"Stockholm est bâtie sur 14 îles."],
    ["NO","Norvège","de la Norvège","Oslo","EU",5.6,385207,"NOK","no","MPARL","SE FI RU",59.91,10.75,2,"Le fonds souverain norvégien, alimenté par le pétrole, est le plus grand du monde."],
    ["FI","Finlande","de la Finlande","Helsinki","EU",5.6,338455,"EUR","fi sv","PARL","SE NO RU",60.17,24.94,2,"La Finlande compte environ 188 000 lacs."],
    ["DK","Danemark","du Danemark","Copenhague","EU",6.0,42933,"DKK","da","MPARL","DE",55.68,12.57,2,"Le Danemark n'a qu'une seule frontière terrestre, avec l'Allemagne (environ 68 km)."],
    ["IS","Islande","de l'Islande","Reykjavik","EU",0.39,103000,"ISK","is","PARL","",64.15,-21.94,2,"L'Althing islandais, fondé en 930, est souvent cité comme le plus ancien parlement encore en activité."],
    ["UA","Ukraine","de l'Ukraine","Kyiv","EU",37.9,603550,"UAH","uk","SEMI","PL SK HU RO MD BY RU",50.45,30.52,2,"L'Ukraine est le plus grand pays situé entièrement en Europe."],
    ["RU","Russie","de la Russie","Moscou","EU",144.8,17098246,"RUB","ru","SEMI","NO FI EE LV LT PL BY UA GE AZ KZ CN MN KP",55.76,37.62,1,"La Russie s'étend sur 11 fuseaux horaires et partage des frontières terrestres avec 14 pays.",true],
    ["HR","Croatie","de la Croatie","Zagreb","EU",3.9,56594,"EUR","hr","PARL","SI HU RS BA ME",45.81,15.98,2,"La Croatie a adopté l'euro et rejoint l'espace Schengen le 1ᵉʳ janvier 2023."],
    ["RS","Serbie","de la Serbie","Belgrade","EU",6.7,77474,"RSD","sr","PARL","HU RO BG MK HR BA ME",44.79,20.45,3,"Belgrade est située au confluent du Danube et de la Save. (Superficie hors Kosovo.)"],
    ["SI","Slovénie","de la Slovénie","Ljubljana","EU",2.1,20273,"EUR","sl","PARL","IT AT HU HR",46.06,14.51,3,"Plus de la moitié de la Slovénie est couverte de forêts."],
    ["EE","Estonie","de l'Estonie","Tallinn","EU",1.4,45339,"EUR","et","PARL","LV RU",59.44,24.75,3,"L'Estonie a été le premier pays à permettre le vote par Internet à des élections nationales (2007)."],
    ["LV","Lettonie","de la Lettonie","Riga","EU",1.9,64589,"EUR","lv","PARL","EE LT BY RU",56.95,24.11,3,"Le centre historique de Riga possède l'une des plus grandes concentrations d'architecture Art nouveau d'Europe."],
    ["LT","Lituanie","de la Lituanie","Vilnius","EU",2.9,65300,"EUR","lt","SEMI","LV BY PL RU",54.69,25.28,3,"La Lituanie fut la première république soviétique à proclamer son indépendance, le 11 mars 1990."],
    ["BY","Biélorussie","de la Biélorussie","Minsk","EU",9.1,207600,"BYN","be ru","PRES","PL LT LV RU UA",53.9,27.57,3,"La forêt de Białowieża, partagée avec la Pologne, abrite la plus grande population de bisons d'Europe."],
    ["MD","Moldavie","de la Moldavie","Chișinău","EU",3.0,33846,"MDL","ro","PARL","RO UA",47.01,28.86,4,"La Moldavie abrite Mileștii Mici, l'une des plus grandes caves à vin du monde."],
    ["AL","Albanie","de l'Albanie","Tirana","EU",2.8,28748,"ALL","sq","PARL","ME MK GR",41.33,19.82,3,"Les Albanais se désignent eux-mêmes « Shqiptarë », et leur pays « Shqipëria »."],
    ["MK","Macédoine du Nord","de la Macédoine du Nord","Skopje","EU",1.8,25713,"MKD","mk sq","PARL","RS BG GR AL",42.0,21.43,4,"Le pays a pris le nom de Macédoine du Nord en 2019 après l'accord de Prespa avec la Grèce."],
    ["BA","Bosnie-Herzégovine","de la Bosnie-Herzégovine","Sarajevo","EU",3.2,51209,"BAM","bs hr sr","PARL","HR RS ME",43.86,18.41,3,"La présidence de la Bosnie-Herzégovine est collégiale : trois membres, un par peuple constitutif."],
    ["ME","Monténégro","du Monténégro","Podgorica","EU",0.63,13812,"EUR","cnr","PARL","HR BA RS AL",42.44,19.26,4,"Le Monténégro utilise l'euro sans être membre de l'Union européenne."],
    ["MC","Monaco","de Monaco","Monaco","EU",0.038,2.02,"EUR","fr","MPARL","FR",43.73,7.42,2,"Monaco est le deuxième plus petit État du monde et le plus densément peuplé."],
    ["VA","Vatican","du Vatican","Cité du Vatican","EU",0.0008,0.44,"EUR","it la","VAT","IT",41.9,12.45,2,"Le Vatican est le plus petit État du monde (0,44 km²)."],
    ["SM","Saint-Marin","de Saint-Marin","Saint-Marin","EU",0.034,61,"EUR","it","PARL","IT",43.94,12.45,3,"Saint-Marin revendique le titre de plus ancienne république du monde (fondation traditionnelle en 301)."],
    ["AD","Andorre","d'Andorre","Andorre-la-Vieille","EU",0.08,468,"EUR","ca","MPARL","FR ES",42.51,1.52,3,"Andorre a deux coprinces : le président de la République française et l'évêque d'Urgell."],
    ["LI","Liechtenstein","du Liechtenstein","Vaduz","EU",0.04,160,"CHF","de","MPARL","CH AT",47.14,9.52,3,"Le Liechtenstein est l'un des deux seuls pays doublement enclavés au monde (avec l'Ouzbékistan)."],
    ["MT","Malte","de Malte","La Valette","EU",0.54,316,"EUR","mt en","PARL","",35.9,14.51,3,"Le maltais est la seule langue sémitique officielle de l'Union européenne."],
    ["CY","Chypre","de Chypre","Nicosie","AS",1.36,9251,"EUR","el tr","PRES","",35.17,33.36,3,"Nicosie est la dernière capitale divisée d'Europe, coupée par une zone tampon de l'ONU.",true],

    // ---------- ASIE ----------
    ["CN","Chine","de la Chine","Pékin","AS",1419.3,9596961,"CNY","zh","UNI","KP RU MN KZ KG TJ AF PK IN NP BT MM LA VN",39.9,116.4,1,"Malgré sa taille, la Chine n'utilise qu'un seul fuseau horaire officiel."],
    ["IN","Inde","de l'Inde","New Delhi","AS",1450.9,3287263,"INR","hi en","PARL","PK CN NP BT BD MM",28.61,77.21,1,"L'Inde est devenue en 2023 le pays le plus peuplé du monde selon l'ONU, devant la Chine."],
    ["JP","Japon","du Japon","Tokyo","AS",123.8,377975,"JPY","ja","MPARL","",35.68,139.69,1,"Le Japon compte plus de 14 000 îles selon un recensement officiel publié en 2023."],
    ["KR","Corée du Sud","de la Corée du Sud","Séoul","AS",51.7,100210,"KRW","ko","PRES","KP",37.57,126.98,1,"L'alphabet coréen, le hangeul, a été créé au XVᵉ siècle sous le roi Sejong."],
    ["KP","Corée du Nord","de la Corée du Nord","Pyongyang","AS",26.5,120540,"KPW","ko","UNI","CN KR RU",39.03,125.75,2,"Les deux Corées sont toujours techniquement en guerre : l'armistice de 1953 n'a jamais été suivi d'un traité de paix."],
    ["ID","Indonésie","de l'Indonésie","Jakarta","AS",283.5,1904569,"IDR","id","PRES","MY PG TL",-6.21,106.85,2,"Plus grand archipel du monde, l'Indonésie construit une nouvelle capitale, Nusantara, sur l'île de Bornéo."],
    ["PK","Pakistan","du Pakistan","Islamabad","AS",251.3,796095,"PKR","ur en","PARL","IN CN AF IR",33.68,73.05,2,"Islamabad est une capitale planifiée, construite dans les années 1960."],
    ["BD","Bangladesh","du Bangladesh","Dacca","AS",173.6,148460,"BDT","bn","PARL","IN MM",23.81,90.41,3,"Le Bangladesh est l'un des pays les plus densément peuplés du monde (hors micro-États)."],
    ["VN","Viêt Nam","du Viêt Nam","Hanoï","AS",101.0,331212,"VND","vi","UNI","CN LA KH",21.03,105.85,2,"La baie d'Halong compte près de 2 000 îles et îlots calcaires."],
    ["TH","Thaïlande","de la Thaïlande","Bangkok","AS",71.7,513120,"THB","th","MPARL","MM LA KH MY",13.76,100.5,2,"La Thaïlande est le seul pays d'Asie du Sud-Est à n'avoir jamais été colonisé par une puissance européenne."],
    ["PH","Philippines","des Philippines","Manille","AS",115.8,300000,"PHP","fil en","PRES","",14.6,120.98,2,"Le pays doit son nom au roi Philippe II d'Espagne."],
    ["MY","Malaisie","de la Malaisie","Kuala Lumpur","AS",35.6,330803,"MYR","ms","MPARL","TH ID BN",3.14,101.69,2,"Le roi de Malaisie est élu pour cinq ans parmi les neuf souverains des États malais."],
    ["SG","Singapour","de Singapour","Singapour","AS",5.8,735,"SGD","en ms zh ta","PARL","",1.35,103.82,2,"Singapour est une cité-État : la ville et le pays ne font qu'un."],
    ["MM","Birmanie","de la Birmanie","Naypyidaw","AS",54.5,676578,"MMK","my","MIL","BD IN CN LA TH",19.76,96.08,3,"Naypyidaw a remplacé Rangoun comme capitale en 2005."],
    ["KH","Cambodge","du Cambodge","Phnom Penh","AS",17.6,181035,"KHR","km","MPARL","TH LA VN",11.56,104.92,3,"Le temple d'Angkor Vat figure sur le drapeau cambodgien."],
    ["LA","Laos","du Laos","Vientiane","AS",7.8,236800,"LAK","lo","UNI","CN VN KH TH MM",17.97,102.63,3,"Le Laos est le seul pays enclavé d'Asie du Sud-Est."],
    ["MN","Mongolie","de la Mongolie","Oulan-Bator","AS",3.5,1564116,"MNT","mn","SEMI","RU CN",47.89,106.91,3,"La Mongolie est le pays souverain le moins densément peuplé du monde."],
    ["KZ","Kazakhstan","du Kazakhstan","Astana","AS",20.6,2724900,"KZT","kk ru","PRES","RU CN KG UZ TM",51.17,71.45,2,"Le Kazakhstan est le plus grand pays enclavé du monde.",true],
    ["UZ","Ouzbékistan","de l'Ouzbékistan","Tachkent","AS",36.4,448978,"UZS","uz","PRES","KZ KG TJ AF TM",41.3,69.24,3,"L'Ouzbékistan est doublement enclavé : tous ses voisins sont eux aussi sans accès à la mer."],
    ["AF","Afghanistan","de l'Afghanistan","Kaboul","AS",42.6,652230,"AFN","ps prs","TRANS","IR TM UZ TJ CN PK",34.53,69.17,2,"Le corridor du Wakhan relie l'Afghanistan à la Chine sur environ 75 km de frontière."],
    ["IR","Iran","de l'Iran","Téhéran","AS",91.6,1648195,"IRR","fa","THEO","IQ TR AM AZ TM AF PK",35.69,51.39,2,"Le calendrier officiel iranien est un calendrier solaire dont l'année commence à l'équinoxe de printemps (Norouz)."],
    ["IQ","Irak","de l'Irak","Bagdad","AS",46.0,438317,"IQD","ar ku","PARL","TR IR KW SA JO SY",33.31,44.36,2,"L'Irak correspond en grande partie à l'ancienne Mésopotamie, entre le Tigre et l'Euphrate."],
    ["SA","Arabie saoudite","de l'Arabie saoudite","Riyad","AS",34.0,2149690,"SAR","ar","MABS","JO IQ KW QA AE OM YE",24.71,46.68,1,"L'Arabie saoudite ne possède aucun cours d'eau permanent."],
    ["AE","Émirats arabes unis","des Émirats arabes unis","Abou Dabi","AS",11.0,83600,"AED","ar","MABS","SA OM",24.45,54.38,2,"Les Émirats sont une fédération de sept émirats, dont Dubaï et Abou Dabi."],
    ["QA","Qatar","du Qatar","Doha","AS",3.0,11586,"QAR","ar","MABS","SA",25.29,51.53,2,"Le Qatar n'a qu'une seule frontière terrestre, avec l'Arabie saoudite."],
    ["IL","Israël","d'Israël","Jérusalem","AS",9.4,22072,"ILS","he","PARL","LB SY JO EG",31.77,35.21,2,"L'hébreu moderne a été revivifié comme langue parlée à partir de la fin du XIXᵉ siècle.",false,"disputed"],
    ["TR","Turquie","de la Turquie","Ankara","AS",87.5,783562,"TRY","tr","PRES","GR BG GE AM AZ IR IQ SY",39.93,32.86,1,"Istanbul est à cheval sur deux continents, séparés par le Bosphore.",true],
    ["JO","Jordanie","de la Jordanie","Amman","AS",11.6,89342,"JOD","ar","MPARL","IL SY IQ SA",31.95,35.93,3,"Pétra, cité nabatéenne taillée dans le grès rose, est le site le plus visité de Jordanie."],
    ["LB","Liban","du Liban","Beyrouth","AS",5.8,10452,"LBP","ar","PARL","SY IL",33.89,35.5,3,"Le cèdre du Liban, présent sur le drapeau, est cité dans la Bible et l'épopée de Gilgamesh."],
    ["SY","Syrie","de la Syrie","Damas","AS",24.7,185180,"SYP","ar","TRANS","TR IQ JO IL LB",33.51,36.29,2,"Damas est l'une des plus anciennes villes habitées en continu au monde."],
    ["NP","Népal","du Népal","Katmandou","AS",29.7,147181,"NPR","ne","PARL","CN IN",27.72,85.32,3,"Le drapeau népalais est le seul drapeau national non rectangulaire."],
    ["LK","Sri Lanka","du Sri Lanka","Sri Jayawardenepura Kotte","AS",23.0,65610,"LKR","si ta","SEMI","",6.9,79.92,3,"Colombo est la plus grande ville et le centre économique, mais la capitale officielle est Sri Jayawardenepura Kotte."],
    ["GE","Géorgie","de la Géorgie","Tbilissi","AS",3.8,69700,"GEL","ka","PARL","RU AZ AM TR",41.72,44.79,3,"La Géorgie est l'une des plus anciennes régions viticoles au monde (vin en amphores qvevri).",true],
    ["AM","Arménie","de l'Arménie","Erevan","AS",2.95,29743,"AMD","hy","PARL","GE AZ IR TR",40.18,44.51,3,"L'Arménie est devenue en 301 le premier État à adopter le christianisme comme religion officielle.",true],
    ["AZ","Azerbaïdjan","de l'Azerbaïdjan","Bakou","AS",10.3,86600,"AZN","az","PRES","RU GE AM IR TR",40.41,49.87,3,"Bakou est la capitale située la plus bas au monde, à environ 28 m sous le niveau de la mer.",true],
    ["OM","Oman","d'Oman","Mascate","AS",5.3,309500,"OMR","ar","MABS","AE SA YE",23.59,58.41,3,"Le sultanat d'Oman possède une exclave, Moussandam, sur le détroit d'Ormuz."],
    ["YE","Yémen","du Yémen","Sanaa","AS",40.6,527968,"YER","ar","TRANS","SA OM",15.37,44.19,3,"La vieille ville de Shibam est surnommée « le Manhattan du désert » pour ses tours en terre crue."],
    ["KW","Koweït","du Koweït","Koweït","AS",4.9,17818,"KWD","ar","TRANS","IQ SA",29.38,47.99,3,"Le dinar koweïtien est l'unité monétaire de plus forte valeur au monde."],
    ["BT","Bhoutan","du Bhoutan","Thimphou","AS",0.79,38394,"BTN","dz","MPARL","CN IN",27.47,89.64,4,"Le Bhoutan mesure son développement avec l'indice du « bonheur national brut »."],
    ["TJ","Tadjikistan","du Tadjikistan","Douchanbé","AS",10.6,143100,"TJS","tg","PRES","AF CN KG UZ",38.56,68.79,4,"Plus de 90 % du territoire tadjik est montagneux."],
    ["KG","Kirghizistan","du Kirghizistan","Bichkek","AS",7.2,199951,"KGS","ky ru","PRES","KZ CN TJ UZ",42.87,74.59,4,"Le lac Issyk-Koul est l'un des plus grands lacs de montagne du monde."],
    ["TM","Turkménistan","du Turkménistan","Achgabat","AS",7.5,488100,"TMT","tk","PRES","KZ UZ AF IR",37.95,58.38,4,"Le cratère de Darvaza, la « porte de l'Enfer », brûle depuis des décennies."],
    ["TL","Timor oriental","du Timor oriental","Dili","AS",1.4,14874,"USD","tet pt","SEMI","ID",-8.56,125.57,4,"Le Timor oriental est devenu indépendant en 2002 et a rejoint l'ASEAN en 2025."],
    ["BN","Brunei","de Brunei","Bandar Seri Begawan","AS",0.46,5765,"BND","ms","MABS","MY",4.9,114.94,4,"Le territoire de Brunei est coupé en deux parties par la Malaisie."],

    // ---------- AFRIQUE ----------
    ["NG","Nigeria","du Nigeria","Abuja","AF",232.7,923768,"NGN","en","PRES","BJ NE TD CM",9.06,7.49,1,"Le Nigeria est le pays le plus peuplé d'Afrique ; Abuja a remplacé Lagos comme capitale en 1991."],
    ["EG","Égypte","de l'Égypte","Le Caire","AF",116.5,1001450,"EGP","ar","PRES","LY SD IL",30.04,31.24,1,"Environ 95 % des Égyptiens vivent sur moins de 5 % du territoire, le long du Nil.",true],
    ["ET","Éthiopie","de l'Éthiopie","Addis-Abeba","AF",132.1,1104300,"ETB","am","PARL","ER DJ SO KE SS SD",9.03,38.74,2,"L'Éthiopie utilise son propre calendrier, en retard d'environ 7 à 8 ans sur le calendrier grégorien."],
    ["CD","RD Congo","de la RD Congo","Kinshasa","AF",109.3,2344858,"CDF","fr","SEMI","CG CF SS UG RW BI TZ ZM AO",-4.32,15.31,2,"Kinshasa et Brazzaville se font face sur le fleuve Congo : les deux capitales les plus proches du monde (hors Rome/Vatican)."],
    ["ZA","Afrique du Sud","de l'Afrique du Sud","Pretoria","AF",64.0,1221037,"ZAR","en af zu xh","PARL","NA BW ZW MZ SZ LS",-25.75,28.19,1,"L'Afrique du Sud a trois capitales : Pretoria (exécutif), Le Cap (législatif) et Bloemfontein (judiciaire). Elle compte 12 langues officielles."],
    ["KE","Kenya","du Kenya","Nairobi","AF",56.4,580367,"KES","sw en","PRES","ET SO TZ UG SS",-1.29,36.82,2,"Nairobi possède un parc national à ses portes, où l'on voit girafes et rhinocéros avec les gratte-ciel en fond."],
    ["TZ","Tanzanie","de la Tanzanie","Dodoma","AF",68.6,947303,"TZS","sw en","PRES","KE UG RW BI CD ZM MW MZ",-6.16,35.75,2,"Dodoma est la capitale officielle, mais Dar es Salaam reste la plus grande ville. Le Kilimandjaro y culmine à 5 895 m."],
    ["DZ","Algérie","de l'Algérie","Alger","AF",46.8,2381741,"DZD","ar ber","PRES","TN LY NE ML MR MA",36.75,3.06,1,"L'Algérie est le plus grand pays d'Afrique depuis la partition du Soudan en 2011."],
    ["MA","Maroc","du Maroc","Rabat","AF",38.1,446550,"MAD","ar ber","MPARL","DZ ES",34.02,-6.84,1,"La superficie indiquée exclut le Sahara occidental, territoire au statut non réglé selon l'ONU."],
    ["TN","Tunisie","de la Tunisie","Tunis","AF",12.3,163610,"TND","ar","PRES","DZ LY",36.81,10.18,2,"Le site de Carthage se trouve aujourd'hui dans la banlieue de Tunis."],
    ["LY","Libye","de la Libye","Tripoli","AF",7.4,1759540,"LYD","ar","TRANS","EG SD TD NE DZ TN",32.89,13.19,2,"Environ 90 % de la Libye est désertique."],
    ["SD","Soudan","du Soudan","Khartoum","AF",50.4,1886068,"SDG","ar en","TRANS","EG LY TD CF SS ET ER",15.5,32.56,2,"Le Soudan compte davantage de pyramides que l'Égypte (environ 200, à Méroé notamment)."],
    ["GH","Ghana","du Ghana","Accra","AF",34.4,238533,"GHS","en","PRES","CI BF TG",5.6,-0.19,2,"Le Ghana fut en 1957 la première colonie d'Afrique subsaharienne à obtenir son indépendance."],
    ["CI","Côte d'Ivoire","de la Côte d'Ivoire","Yamoussoukro","AF",31.9,322463,"XOF","fr","PRES","LR GN ML BF GH",6.83,-5.29,2,"Yamoussoukro est la capitale politique, Abidjan la capitale économique. Le pays est le premier producteur mondial de cacao."],
    ["SN","Sénégal","du Sénégal","Dakar","AF",18.5,196722,"XOF","fr","PRES","MR ML GN GW GM",14.72,-17.47,2,"Dakar est le point le plus occidental de l'Afrique continentale (pointe des Almadies)."],
    ["ML","Mali","du Mali","Bamako","AF",24.5,1240192,"XOF","fr","MIL","DZ NE BF CI GN SN MR",12.64,-8.0,2,"Tombouctou fut un grand centre intellectuel de l'islam aux XVᵉ et XVIᵉ siècles. Depuis 2023, le français n'y est plus langue officielle mais langue de travail.",false,"lang-note"],
    ["NE","Niger","du Niger","Niamey","AF",27.0,1267000,"XOF","fr","MIL","DZ LY TD NG BJ BF ML",13.51,2.11,3,"Le Niger a l'un des taux de fécondité les plus élevés du monde.",false,"lang-note"],
    ["BF","Burkina Faso","du Burkina Faso","Ouagadougou","AF",23.5,274200,"XOF","fr","MIL","ML NE BJ TG GH CI",12.37,-1.53,2,"Le FESPACO de Ouagadougou est le plus grand festival de cinéma africain.",false,"lang-note"],
    ["CM","Cameroun","du Cameroun","Yaoundé","AF",29.1,475442,"XAF","fr en","PRES","NG TD CF CG GA",3.87,11.52,2,"Le Cameroun est souvent surnommé « l'Afrique en miniature » pour la diversité de ses paysages."],
    ["AO","Angola","de l'Angola","Luanda","AF",37.9,1246700,"AOA","pt","PRES","CD CG ZM NA",-8.84,13.23,3,"L'enclave de Cabinda est séparée du reste de l'Angola par une bande de territoire de la RD Congo."],
    ["MZ","Mozambique","du Mozambique","Maputo","AF",34.6,801590,"MZN","pt","PRES","TZ MW ZM ZW ZA SZ",-25.97,32.57,3,"Le drapeau du Mozambique est l'un des seuls au monde à représenter une arme moderne (une kalachnikov)."],
    ["MG","Madagascar","de Madagascar","Antananarivo","AF",32.0,587041,"MGA","mg fr","MIL","",-18.88,47.51,2,"Environ 90 % des espèces sauvages de Madagascar ne vivent nulle part ailleurs."],
    ["RW","Rwanda","du Rwanda","Kigali","AF",14.3,26338,"RWF","rw fr en sw","PRES","UG TZ BI CD",-1.95,30.06,3,"Le Parlement rwandais compte l'une des plus fortes proportions de femmes au monde."],
    ["UG","Ouganda","de l'Ouganda","Kampala","AF",50.0,241550,"UGX","en sw","PRES","KE SS CD RW TZ",0.35,32.58,3,"Le lac Victoria, partagé avec le Kenya et la Tanzanie, est le plus grand lac d'Afrique."],
    ["SO","Somalie","de la Somalie","Mogadiscio","AF",19.0,637657,"SOS","so ar","TRANS","DJ ET KE",2.05,45.32,3,"La Somalie possède la plus longue côte d'Afrique continentale."],
    ["ZW","Zimbabwe","du Zimbabwe","Harare","AF",16.6,390757,"ZWG","en","PRES","ZM MZ ZA BW",-17.83,31.05,3,"Le pays tire son nom du Grand Zimbabwe, cité de pierre médiévale."],
    ["ZM","Zambie","de la Zambie","Lusaka","AF",21.3,752612,"ZMW","en","PRES","CD TZ MW MZ ZW BW NA AO",-15.39,28.32,3,"Les chutes Victoria, sur le Zambèze, sont partagées entre la Zambie et le Zimbabwe."],
    ["NA","Namibie","de la Namibie","Windhoek","AF",3.0,825615,"NAD","en","PRES","AO ZM BW ZA",-22.56,17.08,3,"Le désert du Namib est considéré comme le plus ancien désert du monde."],
    ["BW","Botswana","du Botswana","Gaborone","AF",2.5,581730,"BWP","en tn","PARL","NA ZM ZW ZA",-24.63,25.92,3,"Le delta de l'Okavango est un delta intérieur : le fleuve se perd dans le désert du Kalahari."],
    ["SS","Soudan du Sud","du Soudan du Sud","Djouba","AF",11.9,619745,"SSP","en","PRES","SD ET KE UG CD CF",4.85,31.58,4,"Indépendant depuis 2011, le Soudan du Sud est le plus jeune État reconnu par l'ONU."],
    ["ER","Érythrée","de l'Érythrée","Asmara","AF",3.5,117600,"ERN","ti ar en","UNI","SD ET DJ",15.32,38.93,4,"Asmara est inscrite au patrimoine mondial pour son architecture moderniste italienne des années 1930."],
    ["DJ","Djibouti","de Djibouti","Djibouti","AF",1.17,23200,"DJF","fr ar","PRES","ER ET SO",11.59,43.15,3,"Le lac Assal, à Djibouti, est le point le plus bas d'Afrique (environ –155 m)."],
    ["TD","Tchad","du Tchad","N'Djamena","AF",20.3,1284000,"XAF","fr ar","PRES","LY SD CF CM NG NE",12.13,15.06,3,"Le lac Tchad a perdu environ 90 % de sa surface depuis les années 1960."],
    ["CF","Centrafrique","de la Centrafrique","Bangui","AF",5.3,622984,"XAF","fr sg","PRES","TD SD SS CD CG CM",4.39,18.56,4,"Le sango est l'une des rares langues africaines devenue langue nationale commune à tout un pays."],
    ["CG","Congo","du Congo","Brazzaville","AF",6.3,342000,"XAF","fr","PRES","GA CM CF CD AO",-4.27,15.28,3,"Brazzaville fut la capitale de la France libre en 1940."],
    ["GA","Gabon","du Gabon","Libreville","AF",2.5,267668,"XAF","fr","PRES","CM CG",0.42,9.47,3,"Environ 85 % du Gabon est couvert de forêt tropicale."],
    ["MR","Mauritanie","de la Mauritanie","Nouakchott","AF",5.2,1030700,"MRU","ar","PRES","DZ ML SN",18.08,-15.98,3,"Le train du désert mauritanien, transportant du minerai de fer, est l'un des plus longs du monde."],
    ["GN","Guinée","de la Guinée","Conakry","AF",14.8,245857,"GNF","fr","MIL","GW SN ML CI LR SL",9.64,-13.58,3,"Les fleuves Niger, Sénégal et Gambie prennent leur source dans le massif du Fouta-Djalon."],
    ["BJ","Bénin","du Bénin","Porto-Novo","AF",14.5,114763,"XOF","fr","PRES","TG BF NE NG",6.5,2.6,3,"Porto-Novo est la capitale officielle, Cotonou le siège du gouvernement. Le vaudou y est une religion reconnue."],
    ["TG","Togo","du Togo","Lomé","AF",9.5,56785,"XOF","fr","PARL","GH BF BJ",6.13,1.22,3,"Le Togo est l'un des pays les plus étroits d'Afrique : environ 50 km de côte."],
    ["LR","Liberia","du Liberia","Monrovia","AF",5.6,111369,"LRD","en","PRES","SL GN CI",6.3,-10.8,3,"Fondé par des esclaves affranchis américains, le Liberia a proclamé son indépendance en 1847."],
    ["SL","Sierra Leone","de la Sierra Leone","Freetown","AF",8.6,71740,"SLE","en","PRES","GN LR",8.48,-13.23,4,"Freetown fut fondée à la fin du XVIIIᵉ siècle pour accueillir d'anciens esclaves libérés."],
    ["MW","Malawi","du Malawi","Lilongwe","AF",21.7,118484,"MWK","en ny","PRES","TZ MZ ZM",-13.96,33.79,4,"Le lac Malawi abrite plus d'espèces de poissons que tout autre lac au monde."],
    ["BI","Burundi","du Burundi","Gitega","AF",14.0,27834,"BIF","rn fr en","PRES","RW TZ CD",-3.43,29.93,4,"Gitega a remplacé Bujumbura comme capitale politique en 2019."],
    ["MU","Maurice","de Maurice","Port-Louis","AF",1.27,2040,"MUR","en fr","PARL","",-20.16,57.5,3,"Le dodo, oiseau endémique de Maurice, a disparu à la fin du XVIIᵉ siècle."],
    ["CV","Cap-Vert","du Cap-Vert","Praia","AF",0.52,4033,"CVE","pt","PARL","",14.93,-23.51,4,"L'archipel était inhabité avant l'arrivée des Portugais au XVᵉ siècle."],
    ["LS","Lesotho","du Lesotho","Maseru","AF",2.3,30355,"LSL","st en","MPARL","ZA",-29.31,27.48,4,"Le Lesotho est entièrement enclavé dans l'Afrique du Sud, et tout son territoire est situé au-dessus de 1 400 m."],
    ["SZ","Eswatini","de l'Eswatini","Mbabane","AF",1.24,17364,"SZL","ss en","MABS","ZA MZ",-26.31,31.14,4,"Le Swaziland a été renommé Eswatini en 2018. Mbabane est la capitale administrative, Lobamba la capitale royale et législative."],

    // ---------- AMÉRIQUE DU NORD ET CENTRALE ----------
    ["US","États-Unis","des États-Unis","Washington","NA",345.4,9833517,"USD","en","PRES","CA MX",38.9,-77.04,1,"La frontière entre les États-Unis et le Canada (environ 8 900 km) est la plus longue frontière terrestre du monde."],
    ["CA","Canada","du Canada","Ottawa","NA",39.7,9984670,"CAD","en fr","MPARL","US",45.42,-75.7,1,"Le Canada possède le plus long littoral du monde (plus de 200 000 km)."],
    ["MX","Mexique","du Mexique","Mexico","NA",130.9,1964375,"MXN","es","PRES","US GT BZ",19.43,-99.13,1,"Mexico est bâtie sur l'ancienne Tenochtitlan, capitale aztèque fondée sur un lac."],
    ["CU","Cuba","de Cuba","La Havane","NA",11.0,109884,"CUP","es","UNI","",23.11,-82.37,2,"Cuba est la plus grande île des Caraïbes."],
    ["GT","Guatemala","du Guatemala","Guatemala","NA",18.4,108889,"GTQ","es","PRES","MX BZ HN SV",14.63,-90.51,3,"Le Guatemala abrite Tikal, l'une des plus grandes cités mayas."],
    ["PA","Panama","du Panama","Panama","NA",4.5,75417,"PAB","es","PRES","CR CO",8.98,-79.52,3,"Le canal de Panama, ouvert en 1914, est sous contrôle panaméen depuis le 31 décembre 1999."],
    ["CR","Costa Rica","du Costa Rica","San José","NA",5.1,51100,"CRC","es","PRES","NI PA",9.93,-84.08,3,"Le Costa Rica a aboli son armée en 1948."],
    ["HT","Haïti","d'Haïti","Port-au-Prince","NA",11.8,27750,"HTG","fr ht","TRANS","DO",18.59,-72.31,3,"Haïti est devenue en 1804 la première république noire indépendante, issue d'une révolte d'esclaves."],
    ["DO","République dominicaine","de la République dominicaine","Saint-Domingue","NA",11.4,48671,"DOP","es","PRES","HT",18.49,-69.93,3,"Saint-Domingue abrite la première cathédrale construite dans les Amériques."],
    ["JM","Jamaïque","de la Jamaïque","Kingston","NA",2.8,10991,"JMD","en","MPARL","",17.97,-76.79,3,"La Jamaïque est le berceau du reggae et de Bob Marley."],
    ["HN","Honduras","du Honduras","Tegucigalpa","NA",10.8,112492,"HNL","es","PRES","GT SV NI",14.07,-87.19,4,"Le site maya de Copán est célèbre pour son escalier hiéroglyphique."],
    ["NI","Nicaragua","du Nicaragua","Managua","NA",7.0,130373,"NIO","es","PRES","HN CR",12.11,-86.24,4,"Le lac Nicaragua abrite des requins bouledogues d'eau douce."],
    ["SV","Salvador","du Salvador","San Salvador","NA",6.3,21041,"USD","es","PRES","GT HN",13.69,-89.22,4,"Le Salvador est le plus petit pays d'Amérique centrale continentale et le seul sans façade sur la mer des Caraïbes."],
    ["BZ","Belize","du Belize","Belmopan","NA",0.42,22966,"BZD","en","MPARL","MX GT",17.25,-88.77,4,"Le Belize est le seul pays d'Amérique centrale dont l'anglais est la langue officielle."],

    // ---------- AMÉRIQUE DU SUD ----------
    ["BR","Brésil","du Brésil","Brasília","SA",212.0,8515767,"BRL","pt","PRES","AR BO CO GY PY PE SR UY VE FR",-15.79,-47.88,1,"Le Brésil touche tous les pays d'Amérique du Sud sauf le Chili et l'Équateur."],
    ["AR","Argentine","de l'Argentine","Buenos Aires","SA",45.7,2780400,"ARS","es","PRES","CL BO PY BR UY",-34.6,-58.38,1,"L'Aconcagua (6 961 m), en Argentine, est le plus haut sommet des Amériques."],
    ["CL","Chili","du Chili","Santiago","SA",19.8,756102,"CLP","es","PRES","PE BO AR",-33.45,-70.67,2,"Le Chili mesure environ 4 300 km de long pour 177 km de large en moyenne."],
    ["CO","Colombie","de la Colombie","Bogota","SA",52.9,1141748,"COP","es","PRES","PA VE BR PE EC",4.71,-74.07,2,"La Colombie est le seul pays d'Amérique du Sud bordé à la fois par le Pacifique et la mer des Caraïbes."],
    ["PE","Pérou","du Pérou","Lima","SA",34.2,1285216,"PEN","es qu ay","PRES","EC CO BR BO CL",-12.05,-77.04,2,"Le Machu Picchu a été construit au XVᵉ siècle sous l'empereur inca Pachacutec."],
    ["VE","Venezuela","du Venezuela","Caracas","SA",28.4,916445,"VES","es","TRANS","CO BR GY",10.48,-66.9,2,"Le Salto Ángel est la plus haute chute d'eau du monde (979 m)."],
    ["EC","Équateur","de l'Équateur","Quito","SA",18.1,283561,"USD","es","PRES","CO PE",-0.18,-78.47,2,"Le sommet du Chimborazo est le point de la surface terrestre le plus éloigné du centre de la Terre."],
    ["BO","Bolivie","de la Bolivie","Sucre","SA",12.4,1098581,"BOB","es qu ay gn","PRES","BR PY AR CL PE",-19.04,-65.26,2,"Sucre est la capitale constitutionnelle, La Paz le siège du gouvernement. Le salar d'Uyuni est le plus grand désert de sel du monde."],
    ["PY","Paraguay","du Paraguay","Asunción","SA",6.9,406752,"PYG","es gn","PRES","AR BO BR",-25.26,-57.58,3,"Le guarani y est à la fois une langue officielle et le nom de la monnaie."],
    ["UY","Uruguay","de l'Uruguay","Montevideo","SA",3.4,176215,"UYU","es","PRES","AR BR",-34.9,-56.16,3,"L'Uruguay a organisé et remporté la première Coupe du monde de football, en 1930."],
    ["GY","Guyana","du Guyana","Georgetown","SA",0.83,214969,"GYD","en","PRES","VE BR SR",6.8,-58.16,4,"Le Guyana est le seul pays d'Amérique du Sud dont la langue officielle est l'anglais."],
    ["SR","Suriname","du Suriname","Paramaribo","SA",0.63,163820,"SRD","nl","PRES","GY BR FR",5.85,-55.2,4,"Le Suriname est le seul pays d'Amérique du Sud de langue officielle néerlandaise."],

    // ---------- OCÉANIE ----------
    ["AU","Australie","de l'Australie","Canberra","OC",26.7,7692024,"AUD","en","MPARL","",-35.28,149.13,1,"Canberra a été choisie comme compromis entre Sydney et Melbourne."],
    ["NZ","Nouvelle-Zélande","de la Nouvelle-Zélande","Wellington","OC",5.2,268021,"NZD","en mi","MPARL","",-41.29,174.78,2,"La Nouvelle-Zélande fut en 1893 le premier pays autonome à accorder le droit de vote aux femmes."],
    ["PG","Papouasie-Nouvelle-Guinée","de la Papouasie-Nouvelle-Guinée","Port Moresby","OC",10.6,462840,"PGK","tpi en","MPARL","ID",-9.44,147.18,3,"Plus de 800 langues y sont parlées, record mondial."],
    ["FJ","Fidji","des Fidji","Suva","OC",0.93,18274,"FJD","en fj hi","PARL","",-18.14,178.44,3,"L'archipel compte plus de 300 îles, dont environ un tiers sont habitées."],
    ["WS","Samoa","des Samoa","Apia","OC",0.22,2842,"WST","sm en","PARL","",-13.83,-171.76,4,"En 2011, les Samoa ont sauté le 30 décembre pour passer à l'ouest de la ligne de changement de date."],
    ["TO","Tonga","des Tonga","Nukuʻalofa","OC",0.10,747,"TOP","to en","MPARL","",-21.14,-175.2,4,"Les Tonga sont le seul royaume polynésien jamais colonisé."],
    ["VU","Vanuatu","du Vanuatu","Port-Vila","OC",0.33,12189,"VUV","bi en fr","PARL","",-17.73,168.32,4,"Le Vanuatu fut un condominium franco-britannique jusqu'en 1980."],
    ["SB","Îles Salomon","des Îles Salomon","Honiara","OC",0.82,28896,"SBD","en","MPARL","",-9.43,159.95,4,"Guadalcanal fut le théâtre d'une grande bataille de la guerre du Pacifique en 1942-1943."],
    ["KI","Kiribati","des Kiribati","Tarawa-Sud","OC",0.13,811,"AUD","en gil","PRES","",1.33,172.98,5,"Kiribati est le seul pays situé dans les quatre hémisphères."],
    ["TV","Tuvalu","des Tuvalu","Funafuti","OC",0.01,26,"AUD","tvl en","MPARL","",-8.52,179.2,5,"Tuvalu tire une part importante de ses revenus de son nom de domaine Internet « .tv »."]
  ];

  // Pays enclavés (sans accès à la haute mer). La Caspienne est conventionnellement considérée comme une mer fermée.
  const LANDLOCKED = "AT CH CZ SK HU LU LI AD SM VA RS MK BY MD KZ UZ TM KG TJ AF MN NP BT LA ML NE BF TD CF SS ET UG RW BI ZM ZW MW BW LS SZ BO PY AM AZ".split(" ");

  // Capitales à usage particulier : on les mentionne dans la fiche mais on ne les teste pas en génération automatique.
  const CAPITAL_NOTES = {
    IL: "Israël désigne Jérusalem comme capitale ; ce statut n'est pas reconnu par la majorité des États et de l'ONU, et la plupart des ambassades sont à Tel-Aviv. Question exclue de la génération automatique.",
    NL: "Capitale constitutionnelle : Amsterdam. Siège du gouvernement : La Haye.",
    BO: "Capitale constitutionnelle : Sucre. Siège du gouvernement : La Paz.",
    CI: "Capitale politique : Yamoussoukro. Capitale économique : Abidjan.",
    BJ: "Capitale officielle : Porto-Novo. Siège du gouvernement : Cotonou.",
    ZA: "Trois capitales : Pretoria (exécutif), Le Cap (législatif), Bloemfontein (judiciaire).",
    LK: "Capitale officielle : Sri Jayawardenepura Kotte. Plus grande ville : Colombo.",
    CH: "Berne est la « ville fédérale » : la Constitution ne désigne pas de capitale.",
    YE: "Capitale constitutionnelle : Sanaa (contrôlée par les Houthis). Le gouvernement reconnu siège à Aden.",
    SZ: "Capitale administrative : Mbabane. Capitale royale et législative : Lobamba."
  };
  // Pays dont la capitale n'est pas testée automatiquement (cas contesté ou double capitale ambiguë).
  const CAPITAL_SKIP = ["IL", "YE", "ZA"];

  const countries = ROWS.map(r => ({
    iso: r[0], name: r[1], du: r[2], capital: r[3], cont: r[4], pop: r[5], area: r[6],
    cur: r[7], langs: r[8].split(" "), gov: r[9], borders: r[10] ? r[10].split(" ") : [],
    lat: r[11], lon: r[12], tier: r[13], fact: r[14], trans: !!r[15], flags: r[16] || null,
    landlocked: LANDLOCKED.includes(r[0]),
    capitalNote: CAPITAL_NOTES[r[0]] || null,
    density: r[5] * 1e6 / r[6]
  }));

  W.WKA = W.WKA || {};
  W.WKA.data = W.WKA.data || {};
  Object.assign(W.WKA.data, { META, CONTINENTS, CURRENCIES, LANGUAGES, GOV, countries, CAPITAL_SKIP });
})(typeof window !== "undefined" ? window : globalThis);
