/* World Knowledge Academy — Banque de questions rédigées et vérifiées (couche DONNÉES)
 * Format : Q(catégorie, sous-catégorie, difficulté 1-5, question, bonne réponse, [3 distracteurs],
 *           explication, information complémentaire, contexte, source, nature, asOf?)
 * nature : "hist" (fait historique, stable), "sci" (fait scientifique), "geo" (géographie physique),
 *          "contemp" (donnée contemporaine évolutive, toujours datée via asOf)
 * L'identifiant et l'empreinte de contenu sont calculés par le moteur (engine/fingerprint).
 */
(function (W) {
  const B = [];
  const Q = (cat, sub, d, q, a, w, ex, info, ctx, src, nature, asOf) =>
    B.push({ cat, sub, d, q, a, w, ex, info, ctx: ctx || "", src: src || "", nature: nature || "hist", asOf: asOf || null });

  // ======================= GÉOGRAPHIE (physique, régions) =======================
  Q("geo","Géographie physique",1,"Quel pays possède la plus grande superficie au monde ?","Russie",["Canada","Chine","États-Unis"],
    "La Russie est le plus grand pays du monde avec environ 17,1 millions de km². Elle s'étend sur deux continents, l'Europe et l'Asie, et compte onze fuseaux horaires.",
    "La Russie partage ses frontières terrestres avec 14 pays.","Le Canada, deuxième, fait environ 10 millions de km², soit à peine plus de la moitié.","CIA World Factbook","geo");
  Q("geo","Géographie physique",1,"Quel est le plus haut sommet du monde ?","L'Everest",["Le K2","Le Kangchenjunga","L'Aconcagua"],
    "L'Everest culmine à 8 848,86 m (mesure sino-népalaise de 2020), à la frontière entre le Népal et la Chine (Tibet).",
    "Il est appelé Sagarmatha en népalais et Chomolungma en tibétain.","Le K2 (8 611 m), au Pakistan et en Chine, est le deuxième sommet mondial et réputé plus difficile.","Mesure conjointe Chine-Népal, 2020","geo");
  Q("geo","Géographie physique",2,"Quel est le plus long fleuve d'Afrique ?","Le Nil",["Le Congo","Le Niger","Le Zambèze"],
    "Le Nil mesure environ 6 650 km. Il naît de la rencontre du Nil Blanc (depuis la région des Grands Lacs) et du Nil Bleu (depuis l'Éthiopie) à Khartoum.",
    "Le débat Nil/Amazone pour le titre de plus long fleuve du monde dépend de la source retenue pour l'Amazone.","Le Congo est le deuxième fleuve du monde par le débit, après l'Amazone.","Encyclopædia Britannica","geo");
  Q("geo","Géographie physique",2,"Quel est le plus grand désert chaud du monde ?","Le Sahara",["Le désert d'Arabie","Le Gobi","Le Kalahari"],
    "Le Sahara couvre environ 9 millions de km², presque la superficie des États-Unis.",
    "Si l'on compte les déserts froids, l'Antarctique est le plus grand désert du monde.","Un désert se définit par la faiblesse des précipitations (moins de 250 mm par an), pas par la chaleur.","Britannica","geo");
  Q("geo","Géographie physique",2,"Quel océan est le plus grand ?","L'océan Pacifique",["L'océan Atlantique","L'océan Indien","L'océan Austral"],
    "Le Pacifique couvre environ 165 millions de km², soit près d'un tiers de la surface terrestre, plus que l'ensemble des terres émergées.",
    "Il doit son nom à Magellan, qui le trouva calme en 1520.","La fosse des Mariannes, dans le Pacifique, est le point le plus profond des océans (environ 10 900 m).","NOAA","geo");
  Q("geo","Géographie physique",3,"Quel est le lac le plus profond du monde ?","Le lac Baïkal",["Le lac Tanganyika","La mer Caspienne","Le lac Supérieur"],
    "Le lac Baïkal, en Sibérie, atteint environ 1 640 m de profondeur. Il contient environ 20 % de l'eau douce liquide de surface de la planète.",
    "C'est aussi le plus ancien lac du monde (environ 25 millions d'années).","Il est inscrit au patrimoine mondial de l'UNESCO depuis 1996.","UNESCO","geo");
  Q("geo","Géographie physique",3,"Quelle chaîne de montagnes sépare l'Europe de l'Asie selon la convention la plus courante ?","L'Oural",["Le Caucase","L'Altaï","Les Carpates"],
    "Par convention, la limite Europe-Asie suit l'Oural, le fleuve Oural, la mer Caspienne puis le Caucase et les détroits turcs.",
    "Cette frontière est une construction culturelle : il n'y a pas de séparation tectonique nette.","Le géographe Tatichtchev a proposé l'Oural comme limite au XVIIIᵉ siècle.","Britannica","geo");
  Q("geo","Géographie physique",2,"Quel fleuve traverse le plus de pays au monde ?","Le Danube",["Le Nil","Le Rhin","Le Mékong"],
    "Le Danube traverse ou longe 10 pays : Allemagne, Autriche, Slovaquie, Hongrie, Croatie, Serbie, Roumanie, Bulgarie, Moldavie et Ukraine.",
    "Il arrose quatre capitales : Vienne, Bratislava, Budapest et Belgrade.","Il se jette dans la mer Noire par un vaste delta classé au patrimoine mondial.","Commission internationale pour la protection du Danube","geo");
  Q("geo","Continents et régions",1,"Sur quel continent se trouve le désert d'Atacama ?","Amérique du Sud",["Afrique","Asie","Océanie"],
    "L'Atacama s'étend dans le nord du Chili, entre l'océan Pacifique et les Andes.",
    "C'est le désert non polaire le plus aride du monde : certaines stations n'ont jamais enregistré de pluie.","Sa sécheresse et son altitude en font un site majeur pour l'astronomie (ALMA, VLT).","ESO","geo");
  Q("geo","Continents et régions",3,"Quel détroit sépare l'Europe de l'Afrique ?","Le détroit de Gibraltar",["Le détroit du Bosphore","Le détroit de Messine","Le détroit d'Ormuz"],
    "Le détroit de Gibraltar relie la Méditerranée à l'Atlantique. Il ne mesure qu'environ 14 km dans sa partie la plus étroite.",
    "Dans l'Antiquité, ses rives étaient appelées les « colonnes d'Hercule ».","Le Bosphore sépare l'Europe de l'Asie à Istanbul.","Britannica","geo");
  Q("geo","Territoires et dépendances",3,"À quel pays le Groenland est-il rattaché ?","Au Danemark",["À la Norvège","Au Canada","À l'Islande"],
    "Le Groenland est un territoire autonome au sein du Royaume du Danemark, avec son propre gouvernement depuis 1979 et une autonomie élargie depuis 2009.",
    "C'est la plus grande île du monde (environ 2,17 millions de km²) qui ne soit pas un continent.","Le Groenland a quitté la Communauté européenne en 1985, tout en restant danois.","Gouvernement du Groenland","contemp","2026-06");
  Q("geo","Territoires et dépendances",4,"Quel est le statut de la Nouvelle-Calédonie ?","Collectivité française sui generis",["Département d'outre-mer","État indépendant associé à la France","Territoire sous tutelle de l'ONU"],
    "La Nouvelle-Calédonie dispose d'un statut unique (titre XIII de la Constitution) issu de l'accord de Nouméa de 1998.",
    "Trois référendums d'autodétermination (2018, 2020, 2021) ont vu le « non » à l'indépendance l'emporter.","Son avenir institutionnel fait l'objet de négociations depuis l'accord de Bougival (2025).","Constitution française, titre XIII","contemp","2026-06");
  Q("geo","Grandes villes",2,"Selon le rapport de l’ONU de 2018, quelle était l’agglomération la plus peuplée du monde ?","Tokyo",["Shanghai","New Delhi","Mexico"],
    "Selon le rapport de l'ONU World Urbanization Prospects 2018, l'aire urbaine de Tokyo comptait environ 37 millions d'habitants.",
    "Les classements varient beaucoup selon la définition de « ville » : en 2025, l'ONU a révisé sa méthode et place Jakarta en tête.","Comparer des villes exige une définition commune : commune, agglomération ou aire métropolitaine.","ONU, World Urbanization Prospects 2018 et 2025","contemp","2025");
  Q("geo","Géographie physique",4,"Quel est le point le plus bas des terres émergées ?","Les rives de la mer Morte",["La dépression de Qattara","Le lac Assal","La vallée de la Mort"],
    "Les rives de la mer Morte, entre Israël, la Cisjordanie et la Jordanie, se situent à environ 430 m sous le niveau de la mer, et ce niveau baisse d'environ 1 m par an.",
    "Sa salinité (environ 34 %) permet de flotter sans effort.","La baisse du niveau est liée aux prélèvements d'eau du Jourdain et à l'exploitation des minéraux.","Britannica","geo");
  Q("geo","Population et démographie",2,"Quel est le pays le plus peuplé du monde selon l'ONU depuis 2023 ?","L'Inde",["La Chine","Les États-Unis","L'Indonésie"],
    "Selon les projections de l'ONU, l'Inde a dépassé la Chine en 2023 et compte plus de 1,4 milliard d'habitants.",
    "La population chinoise a commencé à diminuer en 2022.","L'âge médian en Inde est d'environ 28 ans contre environ 39 en Chine.","ONU, World Population Prospects 2024","contemp","2024");
  Q("geo","Géographie physique",5,"Quel sommet est le plus éloigné du centre de la Terre ?","Le Chimborazo",["L'Everest","Le Kilimandjaro","Le Denali"],
    "En raison du renflement équatorial de la Terre, le Chimborazo (Équateur, 6 263 m) est le point de la surface le plus éloigné du centre de la Terre, à environ 6 384 km.",
    "L'Everest reste le plus haut sommet par rapport au niveau de la mer.","La Terre est un ellipsoïde aplati : son rayon équatorial dépasse le rayon polaire d'environ 21 km.","IGN / Institut géographique de l'Équateur","geo");

  // ======================= POLITIQUE & GÉOPOLITIQUE =======================
  Q("pol","Organisations internationales",1,"Combien de membres permanents compte le Conseil de sécurité de l'ONU ?","5",["3","7","10"],
    "Les cinq membres permanents sont la Chine, les États-Unis, la France, le Royaume-Uni et la Russie. Chacun dispose d'un droit de veto.",
    "Le Conseil compte aussi 10 membres non permanents élus pour deux ans.","La Russie occupe depuis 1991 le siège de l'URSS ; la République populaire de Chine a remplacé la République de Chine (Taïwan) en 1971.","Charte des Nations unies, art. 23","hist");
  Q("pol","Organisations internationales",2,"Où se trouve le siège de l'OTAN ?","Bruxelles",["Washington","Genève","Paris"],
    "Le siège de l'OTAN est à Bruxelles depuis 1967. Il était auparavant à Paris, jusqu'au retrait de la France du commandement militaire intégré décidé par de Gaulle en 1966.",
    "La France a réintégré le commandement intégré en 2009.","Le commandement militaire allié (SHAPE) est installé à Mons, en Belgique.","nato.int","hist");
  Q("pol","Institutions européennes",2,"Quelle institution de l'UE est élue au suffrage universel direct ?","Le Parlement européen",["La Commission européenne","Le Conseil européen","Le Conseil de l'Union européenne"],
    "Les députés européens sont élus tous les cinq ans au suffrage universel direct depuis 1979.",
    "La dernière élection a eu lieu en juin 2024 ; la suivante est prévue en 2029.","La Commission est proposée par le Conseil européen et approuvée par le Parlement.","Traité sur l'Union européenne, art. 14","hist");
  Q("pol","Institutions européennes",3,"Quelle institution européenne a le quasi-monopole de l'initiative législative ?","La Commission européenne",["Le Parlement européen","La Cour de justice de l'UE","Le Conseil européen"],
    "Dans la procédure législative ordinaire, la Commission propose les textes, que le Parlement et le Conseil de l'UE adoptent ensemble.",
    "Le Parlement et le Conseil peuvent demander à la Commission de présenter une proposition.","Ce mécanisme reflète la vocation de la Commission à représenter l'intérêt général de l'Union.","TFUE, art. 289 et 294","hist");
  Q("pol","Institutions européennes",4,"Quel traité a créé la Communauté économique européenne (CEE) ?","Le traité de Rome",["Le traité de Paris","Le traité de Maastricht","Le traité de Lisbonne"],
    "Le traité de Rome a été signé le 25 mars 1957 par six pays : Allemagne de l'Ouest, Belgique, France, Italie, Luxembourg et Pays-Bas.",
    "Le même jour fut signé le traité créant Euratom.","Le traité de Paris (1951) avait créé la CECA ; celui de Maastricht (1992) l'Union européenne.","EUR-Lex","hist");
  Q("pol","Systèmes électoraux",3,"Combien de grands électeurs faut-il obtenir pour être élu président des États-Unis ?","270",["218","300","538"],
    "Le collège électoral compte 538 grands électeurs ; la majorité absolue est de 270.",
    "Il est arrivé cinq fois qu'un candidat soit élu avec moins de voix populaires que son adversaire, la dernière en 2016.","Le nombre de grands électeurs d'un État est égal à son nombre de représentants et de sénateurs.","Constitution des États-Unis, art. II et 12ᵉ amendement","hist");
  Q("pol","Régimes politiques",2,"Sous la Vᵉ République, quelle est la durée du mandat présidentiel en France depuis 2002 ?","5 ans",["7 ans","4 ans","6 ans"],
    "Le quinquennat a été adopté par référendum en 2000 et appliqué à partir de l'élection de 2002. Le septennat était en vigueur auparavant.",
    "Depuis 2008, le président ne peut exercer plus de deux mandats consécutifs.","Le passage au quinquennat a aligné le mandat présidentiel sur celui des députés.","Constitution du 4 octobre 1958, art. 6","hist");
  Q("pol","Régimes politiques",3,"Qu'est-ce qu'un régime parlementaire ?","Un régime où le gouvernement est responsable devant le Parlement",["Un régime où le président est élu par le Parlement et ne peut être renversé","Un régime sans chef de l'État","Un régime où le Parlement nomme les juges"],
    "Dans un régime parlementaire, le gouvernement doit disposer de la confiance du Parlement, qui peut le renverser (motion de censure, vote de défiance). En contrepartie, l'exécutif peut souvent dissoudre l'assemblée.",
    "Le Royaume-Uni est l'archétype du régime parlementaire, né d'une évolution historique plutôt que d'un texte unique.","Le régime présidentiel (États-Unis) repose au contraire sur une séparation stricte des pouvoirs.","Science politique, définitions classiques","hist");
  Q("pol","Conflits et traités",3,"Quel traité de 1648 a mis fin à la guerre de Trente Ans ?","Les traités de Westphalie",["Le traité d'Utrecht","Le traité des Pyrénées","Le traité de Vienne"],
    "Signés à Münster et Osnabrück, les traités de Westphalie ont fondé un ordre européen reposant sur la souveraineté des États.",
    "On parle encore de « système westphalien » pour désigner un monde d'États souverains.","La guerre de Trente Ans (1618-1648) a dévasté le Saint-Empire romain germanique.","Britannica","hist");
  Q("pol","Conflits et traités",4,"En quelle année ont été signés les accords d'Oslo entre Israël et l'OLP ?","1993",["1978","1988","2000"],
    "Les accords d'Oslo I ont été signés le 13 septembre 1993 à Washington par Yitzhak Rabin et Yasser Arafat. Ils prévoyaient une autonomie palestinienne transitoire.",
    "Rabin, Arafat et Shimon Peres ont reçu le prix Nobel de la paix en 1994.","Les accords de Camp David (1978) concernaient la paix entre l'Égypte et Israël.","Archives de l'ONU","hist");
  Q("pol","Organisations internationales",3,"Quelle ville accueille la Cour internationale de justice ?","La Haye",["Genève","New York","Strasbourg"],
    "La CIJ, principal organe judiciaire de l'ONU, siège au palais de la Paix à La Haye. Elle règle des différends entre États.",
    "La Cour pénale internationale, qui juge des individus, siège aussi à La Haye mais est distincte de l'ONU.","La Cour européenne des droits de l'homme siège à Strasbourg et dépend du Conseil de l'Europe.","icj-cij.org","hist");
  Q("pol","Organisations internationales",4,"Combien de juges composent la Cour internationale de justice ?","15",["9","12","27"],
    "Les 15 juges sont élus pour neuf ans par l'Assemblée générale et le Conseil de sécurité de l'ONU.",
    "Un tiers de la Cour est renouvelé tous les trois ans.","Deux juges ne peuvent être de la même nationalité.","Statut de la CIJ, art. 3","hist");
  Q("pol","Organisations internationales",2,"Quel est le dernier État admis à l'ONU (en 2011) ?","Le Soudan du Sud",["Le Monténégro","Le Timor oriental","Le Kosovo"],
    "Le Soudan du Sud a proclamé son indépendance le 9 juillet 2011 et a été admis à l'ONU le 14 juillet 2011, devenant le 193ᵉ État membre.",
    "Le Kosovo n'est pas membre de l'ONU : sa reconnaissance divise les États membres.","Son indépendance est issue d'un référendum prévu par l'accord de paix de 2005.","un.org","hist");
  Q("pol","Grandes puissances",4,"Quel pays a quitté l'OPEP en janvier 2024 ?","L'Angola",["Le Qatar","L'Équateur","Le Nigeria"],
    "L'Angola a annoncé son départ en décembre 2023, effectif au 1ᵉʳ janvier 2024, en désaccord avec les quotas de production.",
    "Le Qatar avait quitté l'OPEP en 2019 pour se concentrer sur le gaz naturel liquéfié.","L'Équateur est sorti en 2020.","opec.org","contemp","2024");
  Q("pol","Systèmes électoraux",4,"Quel mode de scrutin est utilisé pour l'élection des députés à la Chambre des communes britannique ?","Le scrutin uninominal majoritaire à un tour",["La proportionnelle intégrale","Le scrutin à deux tours","Le vote alternatif"],
    "Le « first past the post » attribue chaque circonscription au candidat arrivé en tête, même sans majorité absolue.",
    "Un référendum de 2011 sur l'adoption du vote alternatif a été rejeté à 67,9 %.","Ce mode de scrutin favorise les grands partis et peut créer de fortes distorsions entre voix et sièges.","UK Parliament","hist");
  Q("pol","Conflits et traités",5,"Quel traité de 1494 a partagé le Nouveau Monde entre l'Espagne et le Portugal ?","Le traité de Tordesillas",["Le traité de Saragosse","Le traité de Madrid","La bulle Inter caetera seule"],
    "Le traité de Tordesillas fixait une ligne à 370 lieues à l'ouest du Cap-Vert : à l'ouest pour l'Espagne, à l'est pour le Portugal.",
    "C'est ce qui explique que le Brésil soit lusophone.","Le traité de Saragosse (1529) a prolongé ce partage dans le Pacifique.","Britannica","hist");

  // ======================= HISTOIRE =======================
  Q("hist","Antiquité",1,"Quelle civilisation a construit les pyramides de Gizeh ?","L'Égypte ancienne",["Les Mésopotamiens","Les Romains","Les Mayas"],
    "Les pyramides de Gizeh ont été construites sous l'Ancien Empire, vers 2600-2500 av. J.-C., pour les pharaons Khéops, Khéphren et Mykérinos.",
    "La pyramide de Khéops est la seule des Sept Merveilles du monde antique encore debout.","Elle fut la plus haute construction humaine pendant près de 4 000 ans.","Britannica","hist");
  Q("hist","Antiquité",2,"En quelle année situe-t-on traditionnellement la fondation de Rome ?","753 av. J.-C.",["509 av. J.-C.","476 apr. J.-C.","1000 av. J.-C."],
    "Selon la tradition, Romulus fonda Rome le 21 avril 753 av. J.-C.",
    "509 av. J.-C. est la date traditionnelle de la fondation de la République romaine.","L'archéologie montre une occupation du site dès le Xᵉ siècle av. J.-C.","Tite-Live, Histoire romaine","hist");
  Q("hist","Antiquité",2,"Quel événement marque conventionnellement la fin de l'Empire romain d'Occident ?","La déposition de Romulus Augustule en 476",["Le sac de Rome en 410","La prise de Constantinople en 1453","Le partage de l'Empire en 395"],
    "En 476, le chef germanique Odoacre dépose le dernier empereur d'Occident, Romulus Augustule, et renvoie les insignes impériaux à Constantinople.",
    "L'Empire romain d'Orient (byzantin) subsiste jusqu'en 1453.","Cette date marque conventionnellement le passage de l'Antiquité au Moyen Âge.","Britannica","hist");
  Q("hist","Antiquité",3,"Quel code de lois babylonien est l'un des plus anciens connus ?","Le code d'Hammurabi",["Les Douze Tables","Le code de Justinien","Le code d'Ur-Nammu"],
    "Gravé vers 1750 av. J.-C. sur une stèle de basalte, il compte 282 lois. La stèle est conservée au musée du Louvre.",
    "Le code d'Ur-Nammu (vers 2100 av. J.-C.) est plus ancien mais nous est parvenu de façon fragmentaire.","Le principe « œil pour œil » y apparaît (loi du talion).","Musée du Louvre","hist");
  Q("hist","Moyen Âge",2,"En quelle année Charlemagne est-il couronné empereur ?","800",["732","843","987"],
    "Charlemagne est couronné empereur d'Occident par le pape Léon III à Rome le 25 décembre 800.",
    "843 correspond au traité de Verdun, qui partage son empire entre ses petits-fils.","732 est la date de la bataille de Poitiers, 987 celle de l'avènement d'Hugues Capet.","Britannica","hist");
  Q("hist","Moyen Âge",3,"Quelle année marque la prise de Constantinople par les Ottomans ?","1453",["1204","1389","1492"],
    "Le sultan Mehmed II prend Constantinople le 29 mai 1453, mettant fin à l'Empire byzantin.",
    "La ville devient la capitale ottomane ; elle sera officiellement renommée Istanbul en 1930.","En 1204, Constantinople avait été pillée par les croisés de la quatrième croisade.","Britannica","hist");
  Q("hist","Moyen Âge",3,"Quel texte anglais de 1215 limite le pouvoir du roi ?","La Magna Carta",["Le Bill of Rights","L'Habeas Corpus Act","Les Provisions d'Oxford"],
    "Le roi Jean sans Terre accepte la Grande Charte en 1215 face à ses barons. Elle établit que le roi est soumis à la loi.",
    "Le Bill of Rights date de 1689 et l'Habeas Corpus Act de 1679.","Elle est souvent présentée comme un texte fondateur des libertés publiques.","British Library","hist");
  Q("hist","Moyen Âge",4,"Quel empire fondé au XIIIᵉ siècle fut le plus grand empire terrestre contigu de l'histoire ?","L'Empire mongol",["L'Empire ottoman","L'Empire perse achéménide","L'Empire carolingien"],
    "Fondé par Gengis Khan en 1206, l'Empire mongol s'étendait à son apogée de la Corée à l'Europe de l'Est, environ 24 millions de km².",
    "L'Empire britannique fut plus vaste, mais il n'était pas d'un seul tenant.","La Pax mongolica a facilité les échanges sur les routes de la soie.","Britannica","hist");
  Q("hist","Révolutions",1,"Quel jour la Bastille a-t-elle été prise ?","14 juillet 1789",["4 août 1789","21 janvier 1793","10 août 1792"],
    "La prise de la Bastille, forteresse-prison symbole de l'arbitraire royal, est devenue l'emblème de la Révolution française.",
    "La fête nationale du 14 juillet commémore officiellement la fête de la Fédération du 14 juillet 1790.","Le 4 août 1789 correspond à l'abolition des privilèges.","Archives nationales","hist");
  Q("hist","Révolutions",2,"Quel document les colonies américaines adoptent-elles le 4 juillet 1776 ?","La Déclaration d'indépendance",["La Constitution des États-Unis","Le Bill of Rights","Les Articles de la Confédération"],
    "Rédigée principalement par Thomas Jefferson, elle proclame la séparation des treize colonies d'avec la Grande-Bretagne.",
    "La Constitution date de 1787, le Bill of Rights de 1791.","La France de Louis XVI soutint militairement les insurgés.","National Archives (États-Unis)","hist");
  Q("hist","Révolutions",3,"En quelle année a eu lieu la révolution d'Octobre en Russie ?","1917",["1905","1921","1924"],
    "Les bolcheviks prennent le pouvoir à Petrograd les 24 et 25 octobre 1917 du calendrier julien, soit les 6 et 7 novembre du calendrier grégorien.",
    "Une première révolution, en février 1917, avait renversé le tsar Nicolas II.","L'URSS est fondée en décembre 1922.","Britannica","hist");
  Q("hist","Révolutions",4,"Quel pays a connu la révolution des Œillets en 1974 ?","Le Portugal",["L'Espagne","La Grèce","Le Chili"],
    "Le 25 avril 1974, un coup d'État militaire renverse le régime autoritaire de l'Estado Novo, quasi sans violence.",
    "Son nom vient des œillets placés dans les canons des fusils par la population.","Elle accélère l'indépendance des colonies portugaises (Angola, Mozambique, Guinée-Bissau…).","Britannica","hist");
  Q("hist","Guerres mondiales",1,"En quelle année a commencé la Seconde Guerre mondiale en Europe ?","1939",["1914","1938","1941"],
    "Elle commence le 1ᵉʳ septembre 1939 avec l'invasion de la Pologne par l'Allemagne. La France et le Royaume-Uni déclarent la guerre le 3 septembre.",
    "1938 est l'année des accords de Munich et de l'annexion de l'Autriche.","1941 marque l'entrée en guerre de l'URSS (juin) et des États-Unis (décembre).","Britannica","hist");
  Q("hist","Guerres mondiales",2,"Quel événement déclenche la Première Guerre mondiale ?","L'assassinat de l'archiduc François-Ferdinand",["L'invasion de la Belgique","Le naufrage du Lusitania","La révolution russe"],
    "Le 28 juin 1914 à Sarajevo, Gavrilo Princip assassine l'héritier du trône austro-hongrois. Le jeu des alliances entraîne l'Europe dans la guerre en quelques semaines.",
    "L'invasion de la Belgique (août 1914) provoque l'entrée en guerre du Royaume-Uni.","Le naufrage du Lusitania (1915) contribue à retourner l'opinion américaine.","Britannica","hist");
  Q("hist","Guerres mondiales",3,"Quelle bataille de 1942-1943 est souvent considérée comme le tournant de la guerre à l'Est ?","Stalingrad",["Koursk","Moscou","Leningrad"],
    "La capitulation de la 6ᵉ armée allemande du maréchal Paulus, le 2 février 1943, marque le début du recul allemand sur le front de l'Est.",
    "Koursk (juillet 1943) fut la plus grande bataille de chars de l'histoire.","La ville s'appelle aujourd'hui Volgograd.","Britannica","hist");
  Q("hist","Guerres mondiales",4,"Quelle conférence de février 1945 réunit Roosevelt, Churchill et Staline ?","Yalta",["Potsdam","Téhéran","Casablanca"],
    "La conférence de Yalta, en Crimée, organise l'après-guerre : occupation de l'Allemagne, création de l'ONU, entrée en guerre de l'URSS contre le Japon.",
    "Téhéran (1943) fut leur première rencontre ; à Potsdam (1945), Truman et Attlee remplacent Roosevelt et Churchill.","Yalta est souvent associée, de façon simplifiée, au « partage du monde ».","Britannica","hist");
  Q("hist","Guerre froide",1,"En quelle année le mur de Berlin est-il tombé ?","1989",["1961","1991","1990"],
    "Le mur tombe dans la nuit du 9 au 10 novembre 1989, après l'annonce confuse de l'ouverture des frontières par Günter Schabowski.",
    "Il avait été construit à partir du 13 août 1961.","La réunification allemande intervient le 3 octobre 1990.","Bundesregierung","hist");
  Q("hist","Guerre froide",2,"Quelle crise de 1962 a rapproché le monde d'une guerre nucléaire ?","La crise des missiles de Cuba",["Le blocus de Berlin","La crise de Suez","La guerre de Corée"],
    "En octobre 1962, les États-Unis découvrent des missiles soviétiques à Cuba. Après 13 jours de tension, Khrouchtchev accepte de les retirer.",
    "En contrepartie secrète, les États-Unis retirent leurs missiles Jupiter de Turquie.","Une ligne directe Washington-Moscou (le « téléphone rouge ») est créée en 1963.","JFK Library","hist");
  Q("hist","Guerre froide",3,"Quel pacte militaire réunissait l'URSS et ses alliés d'Europe de l'Est ?","Le pacte de Varsovie",["Le Comecon","Le Kominform","Le traité de Brest-Litovsk"],
    "Créé en 1955 en réponse à l'entrée de la RFA dans l'OTAN, il est dissous en 1991.",
    "Le Comecon (1949) était une organisation économique, pas militaire.","Ses troupes sont intervenues en Tchécoslovaquie en 1968 pour mettre fin au Printemps de Prague.","Britannica","hist");
  Q("hist","Décolonisation",2,"En quelle année l'Inde a-t-elle obtenu son indépendance ?","1947",["1950","1945","1962"],
    "L'Inde devient indépendante le 15 août 1947, en même temps que la partition qui crée le Pakistan.",
    "La partition entraîne d'immenses déplacements de population et des violences faisant des centaines de milliers de morts.","L'Inde devient une république en 1950 avec l'entrée en vigueur de sa constitution.","Britannica","hist");
  Q("hist","Décolonisation",3,"En quelle année l'Algérie est-elle devenue indépendante ?","1962",["1954","1958","1960"],
    "Après la guerre d'Algérie (1954-1962) et les accords d'Évian, l'indépendance est proclamée le 5 juillet 1962.",
    "1954 marque le début de l'insurrection (Toussaint rouge, 1ᵉʳ novembre).","1960 est « l'année de l'Afrique », avec 17 indépendances, dont 14 anciennes colonies françaises.","Britannica","hist");
  Q("hist","Décolonisation",4,"Quelle conférence de 1955 réunit 29 pays d'Asie et d'Afrique ?","La conférence de Bandung",["La conférence de Berlin","La conférence de Brazzaville","La conférence de Belgrade"],
    "Organisée en Indonésie, elle affirme la solidarité des pays décolonisés et leur refus de s'aligner sur les deux blocs.",
    "La conférence de Belgrade (1961) fonde le Mouvement des non-alignés.","La conférence de Berlin (1884-1885) avait au contraire organisé le partage colonial de l'Afrique.","Britannica","hist");
  Q("hist","Histoire contemporaine",2,"En quelle année l'URSS a-t-elle été dissoute ?","1991",["1989","1990","1993"],
    "L'URSS est dissoute le 26 décembre 1991, au lendemain de la démission de Mikhaïl Gorbatchev.",
    "Quinze États indépendants en sont issus.","Les accords de Belovej (8 décembre 1991) avaient acté la fin de l'Union entre Russie, Ukraine et Biélorussie.","Britannica","hist");
  Q("hist","Histoire contemporaine",3,"En quelle année Nelson Mandela devient-il président de l'Afrique du Sud ?","1994",["1990","1991","1999"],
    "Après les premières élections multiraciales d'avril 1994, il est investi le 10 mai 1994.",
    "Il avait été libéré en février 1990 après 27 ans de détention.","Il n'a exercé qu'un seul mandat, jusqu'en 1999.","Nelson Mandela Foundation","hist");
  Q("hist","Grandes personnalités",3,"Qui a été la première femme Première ministre au monde ?","Sirimavo Bandaranaike",["Golda Meir","Indira Gandhi","Margaret Thatcher"],
    "Elle devient Première ministre de Ceylan (actuel Sri Lanka) en 1960.",
    "Indira Gandhi (1966), Golda Meir (1969) et Margaret Thatcher (1979) lui succèdent dans l'histoire.","Sa fille, Chandrika Kumaratunga, deviendra présidente du Sri Lanka.","Britannica","hist");
  Q("hist","Grandes civilisations",4,"Quelle civilisation a bâti Machu Picchu ?","Les Incas",["Les Aztèques","Les Mayas","Les Olmèques"],
    "Machu Picchu a été construit au XVᵉ siècle, probablement comme domaine de l'empereur Pachacutec.",
    "Le site, jamais trouvé par les conquistadors, a été popularisé en 1911 par Hiram Bingham.","L'Empire inca, ou Tawantinsuyu, s'étendait de l'Équateur au Chili actuel.","UNESCO","hist");
  Q("hist","Grandes civilisations",5,"Quelle écriture a été déchiffrée grâce à la pierre de Rosette ?","Les hiéroglyphes égyptiens",["L'écriture cunéiforme","Le linéaire B","L'écriture maya"],
    "Jean-François Champollion annonce le déchiffrement en 1822, grâce à un même décret gravé en hiéroglyphes, en démotique et en grec ancien.",
    "La pierre, découverte en 1799 pendant l'expédition d'Égypte, est conservée au British Museum.","Le linéaire B a été déchiffré par Michael Ventris en 1952.","British Museum","hist");

  // ======================= ÉCONOMIE & FINANCE =======================
  Q("eco","Banques centrales",1,"Où se trouve le siège de la Banque centrale européenne ?","Francfort",["Bruxelles","Luxembourg","Paris"],
    "La BCE siège à Francfort-sur-le-Main, en Allemagne, depuis sa création en 1998.",
    "Son objectif principal est la stabilité des prix, avec une cible d'inflation de 2 % à moyen terme.","Le choix de Francfort s'explique en partie par le prestige de la Bundesbank.","ecb.europa.eu","hist");
  Q("eco","Banques centrales",2,"Comment s'appelle la banque centrale des États-Unis ?","La Réserve fédérale",["Le Trésor américain","Wall Street","La Banque des États-Unis"],
    "La Federal Reserve (« Fed ») a été créée en 1913. Son mandat est double : stabilité des prix et plein emploi.",
    "Elle est composée de 12 banques régionales et d'un conseil des gouverneurs à Washington.","Le Trésor gère les finances publiques ; la Fed conduit la politique monétaire.","federalreserve.gov","hist");
  Q("eco","Concepts économiques",1,"Que mesure le PIB ?","La valeur de la production d'un pays sur une période",["La richesse totale accumulée d'un pays","Le budget de l'État","La dette publique"],
    "Le produit intérieur brut additionne les valeurs ajoutées produites sur le territoire, en général sur un an.",
    "Le PIB mesure un flux, pas un patrimoine.","Il ne mesure ni les inégalités, ni le bien-être, ni l'épuisement des ressources : d'où des indicateurs complémentaires comme l'IDH.","INSEE","sci");
  Q("eco","Concepts économiques",2,"Qu'appelle-t-on la stagflation ?","Une stagnation économique combinée à une forte inflation",["Une baisse générale des prix","Une croissance forte sans inflation","Une hausse des taux d'intérêt"],
    "La stagflation combine croissance faible, chômage élevé et inflation forte, comme après les chocs pétroliers des années 1970.",
    "Une baisse générale et durable des prix s'appelle la déflation.","Elle pose un dilemme aux banques centrales : relever les taux freine l'inflation mais aggrave la récession.","Banque de France","sci");
  Q("eco","Concepts économiques",3,"Comment appelle-t-on un indicateur combinant revenu, santé et éducation, publié par le PNUD ?","L'indice de développement humain (IDH)",["Le coefficient de Gini","L'indice de Big Mac","Le PIB en parité de pouvoir d'achat"],
    "L'IDH a été créé en 1990 par l'économiste Mahbub ul Haq, avec la contribution d'Amartya Sen. Il agrège espérance de vie, niveau d'éducation et revenu par habitant.",
    "Le coefficient de Gini mesure les inégalités de revenus.","L'indice Big Mac, publié par The Economist, illustre de façon ludique la parité de pouvoir d'achat.","PNUD","sci");
  Q("eco","Commerce et organisations",2,"Quelle organisation a succédé au GATT en 1995 ?","L'Organisation mondiale du commerce",["Le Fonds monétaire international","La Banque mondiale","L'OCDE"],
    "L'OMC est créée le 1ᵉʳ janvier 1995 à l'issue de l'Uruguay Round. Son siège est à Genève.",
    "La Chine y adhère en 2001, la Russie en 2012.","Le GATT (1947) ne couvrait que les marchandises ; l'OMC couvre aussi les services et la propriété intellectuelle.","wto.org","hist");
  Q("eco","Commerce et organisations",3,"Quels accords de 1944 ont créé le FMI et la Banque mondiale ?","Les accords de Bretton Woods",["Le plan Marshall","Les accords de la Jamaïque","Les accords du Plaza"],
    "Signés aux États-Unis en juillet 1944, ils instaurent un système de changes fixes centré sur le dollar, lui-même convertible en or.",
    "Ce système prend fin en 1971, quand Nixon suspend la convertibilité du dollar en or.","Les accords de la Jamaïque (1976) officialisent les changes flottants.","FMI","hist");
  Q("eco","Matières premières",2,"Quel pays est le premier producteur mondial de cacao ?","La Côte d'Ivoire",["Le Ghana","Le Brésil","L'Équateur"],
    "La Côte d'Ivoire produit environ 40 % du cacao mondial, devant le Ghana.",
    "Le cacao est originaire d'Amérique : les Mayas et les Aztèques le consommaient déjà.","Les cours du cacao ont atteint des records historiques en 2024 en raison de mauvaises récoltes.","ICCO (Organisation internationale du cacao)","contemp","2024");
  Q("eco","Matières premières",3,"Quel pays possède les plus importantes réserves prouvées de pétrole ?","Le Venezuela",["L'Arabie saoudite","La Russie","L'Irak"],
    "Selon l'OPEP, le Venezuela détient environ 300 milliards de barils de réserves prouvées, en grande partie du pétrole extra-lourd de la ceinture de l'Orénoque.",
    "L'Arabie saoudite reste beaucoup plus productrice grâce à un pétrole plus facile à extraire.","Les réserves « prouvées » dépendent des prix et des technologies : elles évoluent.","OPEP, Annual Statistical Bulletin","contemp","2024");
  Q("eco","Monnaies",2,"Depuis quelle année les pièces et billets en euros circulent-ils ?","2002",["1999","1992","2001"],
    "L'euro existe sous forme scripturale depuis le 1ᵉʳ janvier 1999 ; pièces et billets sont mis en circulation le 1ᵉʳ janvier 2002 dans 12 pays.",
    "1992 est l'année de la signature du traité de Maastricht, qui prévoit la monnaie unique.","Chaque pièce porte une face commune et une face nationale.","ecb.europa.eu","hist");
  Q("eco","Monnaies",3,"Quelle est la monnaie du Japon ?","Le yen",["Le yuan","Le won","Le ringgit"],
    "Le yen a été introduit en 1871 pendant l'ère Meiji. Son symbole est ¥.",
    "Le yuan est chinois, le won coréen, le ringgit malaisien.","Le yen est l'une des principales monnaies de réserve mondiales.","Banque du Japon","hist");
  Q("eco","Entreprises",3,"Dans quel pays a été fondée l'entreprise Samsung ?","Corée du Sud",["Japon","Chine","Taïwan"],
    "Samsung a été fondé en 1938 à Daegu par Lee Byung-chul, à l'origine comme entreprise de commerce.",
    "Le nom signifie « trois étoiles » en coréen.","C'est un chaebol, conglomérat familial typique de l'économie sud-coréenne.","Samsung","hist");
  Q("eco","Entreprises",4,"Quelle entreprise taïwanaise est le premier fabricant mondial de semi-conducteurs sous contrat ?","TSMC",["Foxconn","MediaTek","Acer"],
    "TSMC (Taiwan Semiconductor Manufacturing Company) fabrique les puces les plus avancées pour Apple, Nvidia ou AMD.",
    "Foxconn est un assembleur d'électronique, pas un fondeur de puces.","La concentration de cette industrie à Taïwan est un enjeu géopolitique majeur.","TSMC, rapports annuels","contemp","2025");
  Q("eco","Concepts économiques",4,"Qu'est-ce que l'« assouplissement quantitatif » ?","Le rachat massif de titres par une banque centrale",["Une baisse des impôts","Une dévaluation décidée par l'État","La réduction des dépenses publiques"],
    "La banque centrale crée de la monnaie pour acheter des obligations, afin de faire baisser les taux d'intérêt à long terme lorsque les taux directeurs sont déjà proches de zéro.",
    "La Banque du Japon l'a utilisé dès 2001, la Fed après 2008, la BCE à partir de 2015.","On parle de « quantitative easing » (QE).","Banque de France","sci");
  Q("eco","Commerce et organisations",4,"Quel pays a été le premier exportateur mondial de marchandises ces dernières années ?","La Chine",["Les États-Unis","L'Allemagne","Le Japon"],
    "La Chine est le premier exportateur mondial de marchandises depuis 2009, devant les États-Unis et l'Allemagne.",
    "Les États-Unis restent le premier importateur mondial.","Pour les services, les États-Unis sont premiers exportateurs.","OMC, World Trade Statistical Review","contemp","2024");
  Q("eco","Concepts économiques",5,"Quel économiste a théorisé l'avantage comparatif ?","David Ricardo",["Adam Smith","John Maynard Keynes","Karl Marx"],
    "Dans ses Principes (1817), Ricardo montre avec l'exemple du vin portugais et du drap anglais qu'un pays gagne à se spécialiser même s'il n'a aucun avantage absolu.",
    "Adam Smith avait théorisé l'avantage absolu en 1776.","C'est l'un des fondements théoriques du libre-échange.","Britannica","hist");

  // ======================= SCIENCES & TECHNOLOGIES =======================
  Q("sci","Chimie",1,"Quel est le symbole chimique de l'or ?","Au",["Ag","Or","Go"],
    "Au vient du latin aurum. Ag (argentum) désigne l'argent.",
    "L'or est l'un des métaux les moins réactifs : il ne rouille pas et ne se ternit pas.","Son numéro atomique est 79.","IUPAC","sci");
  Q("sci","Chimie",2,"Quel gaz est le plus abondant dans l'atmosphère terrestre ?","L'azote",["L'oxygène","Le dioxyde de carbone","L'argon"],
    "L'air sec contient environ 78 % d'azote (diazote), 21 % d'oxygène et 0,93 % d'argon.",
    "Le CO₂ ne représente qu'environ 0,042 % de l'air, mais joue un rôle majeur dans l'effet de serre.","L'oxygène atmosphérique provient de la photosynthèse.","NOAA","sci");
  Q("sci","Physique",2,"Quelle est la vitesse approximative de la lumière dans le vide ?","300 000 km/s",["300 000 km/h","30 000 km/s","3 000 000 km/s"],
    "Elle vaut exactement 299 792 458 m/s, valeur fixée par définition depuis 1983 pour définir le mètre.",
    "La lumière du Soleil met environ 8 min 20 s pour atteindre la Terre.","Selon la relativité restreinte d'Einstein (1905), aucune information ne peut voyager plus vite.","BIPM","sci");
  Q("sci","Physique",3,"Quelle est l'unité de la force dans le Système international ?","Le newton",["Le joule","Le pascal","Le watt"],
    "Un newton est la force qui communique une accélération de 1 m/s² à une masse de 1 kg.",
    "Le joule mesure l'énergie, le pascal la pression, le watt la puissance.","L'unité honore Isaac Newton, auteur des lois du mouvement (1687).","BIPM","sci");
  Q("sci","Physique",4,"Quelle particule a été observée au CERN en 2012 ?","Le boson de Higgs",["Le neutrino","Le quark top","Le graviton"],
    "Annoncée le 4 juillet 2012 par les expériences ATLAS et CMS du LHC, elle confirme le mécanisme qui donne leur masse aux particules élémentaires.",
    "Peter Higgs et François Englert ont reçu le prix Nobel de physique 2013.","Le graviton reste hypothétique ; le quark top a été découvert en 1995 au Fermilab.","CERN","sci");
  Q("sci","Biologie",1,"Quel organe pompe le sang dans le corps humain ?","Le cœur",["Le foie","Les poumons","Les reins"],
    "Le cœur bat en moyenne 60 à 100 fois par minute au repos chez l'adulte, soit plus de 100 000 fois par jour.",
    "Il fait circuler environ 5 litres de sang par minute au repos.","William Harvey a décrit la circulation sanguine en 1628.","Inserm","sci");
  Q("sci","Biologie",2,"Combien de chromosomes possède une cellule humaine typique ?","46",["23","44","48"],
    "Une cellule humaine contient 23 paires de chromosomes, dont une paire de chromosomes sexuels.",
    "Les gamètes (ovules, spermatozoïdes) n'en contiennent que 23.","La trisomie 21 correspond à la présence de trois chromosomes 21.","Inserm","sci");
  Q("sci","Biologie",3,"Quels scientifiques ont décrit la structure en double hélice de l'ADN en 1953 ?","James Watson et Francis Crick",["Louis Pasteur et Robert Koch","Gregor Mendel et Charles Darwin","Marie et Pierre Curie"],
    "Leur modèle s'appuie notamment sur la célèbre « photo 51 » de diffraction aux rayons X obtenue par Rosalind Franklin et Raymond Gosling.",
    "Watson, Crick et Maurice Wilkins ont reçu le prix Nobel en 1962 ; Rosalind Franklin était décédée en 1958.","Le rôle de Franklin a longtemps été sous-estimé.","Nature, 1953","sci");
  Q("sci","Astronomie",1,"Quelle est la plus grande planète du système solaire ?","Jupiter",["Saturne","Neptune","la Terre"],
    "Jupiter est une géante gazeuse dont la masse vaut environ 2,5 fois celle de toutes les autres planètes réunies.",
    "Sa Grande Tache rouge est une tempête observée depuis plus de 150 ans.","On lui connaît plus de 90 lunes, dont Ganymède, la plus grande du système solaire.","NASA","sci");
  Q("sci","Astronomie",2,"Depuis 2006, combien de planètes compte officiellement le système solaire ?","8",["9","7","10"],
    "En 2006, l'Union astronomique internationale a reclassé Pluton comme planète naine.",
    "Une planète doit avoir « fait le ménage » sur son orbite, ce que Pluton ne fait pas.","Cérès, Éris, Hauméa et Makémaké sont d'autres planètes naines.","UAI, résolution B5 (2006)","sci");
  Q("sci","Astronomie",3,"En quelle année l'homme a-t-il marché sur la Lune pour la première fois ?","1969",["1961","1965","1972"],
    "Neil Armstrong pose le pied sur la Lune le 21 juillet 1969 (heure UTC) lors de la mission Apollo 11, suivi de Buzz Aldrin.",
    "1961 est l'année du premier vol habité, celui de Youri Gagarine.","1972 marque la dernière mission habitée sur la Lune (Apollo 17).","NASA","sci");
  Q("sci","Astronomie",4,"Quel télescope spatial, lancé en 2021, observe principalement dans l'infrarouge ?","James Webb",["Hubble","Kepler","Gaia"],
    "Le télescope spatial James Webb, lancé le 25 décembre 2021 par une fusée Ariane 5, est placé au point de Lagrange L2, à 1,5 million de km de la Terre.",
    "Son miroir principal mesure 6,5 m, contre 2,4 m pour Hubble.","L'infrarouge permet d'observer les premières galaxies, dont la lumière est décalée vers le rouge.","NASA / ESA","sci");
  Q("sci","Médecine",2,"Qui a découvert la pénicilline en 1928 ?","Alexander Fleming",["Louis Pasteur","Robert Koch","Edward Jenner"],
    "Fleming observe qu'une moisissure (Penicillium) empêche la croissance de bactéries dans une boîte de culture oubliée.",
    "Son usage médical de masse date de la Seconde Guerre mondiale grâce à Florey et Chain.","Edward Jenner a mis au point le premier vaccin (variole) en 1796.","Nobel Prize","sci");
  Q("sci","Médecine",3,"Quelle maladie a été déclarée éradiquée par l'OMS en 1980 ?","La variole",["La poliomyélite","La rougeole","Le paludisme"],
    "La variole est la seule maladie humaine éradiquée à ce jour, grâce à une campagne mondiale de vaccination.",
    "La poliomyélite est en voie d'éradication mais persiste dans quelques pays.","La peste bovine est la seule maladie animale éradiquée (2011).","OMS","sci");
  Q("sci","Technologies et IA",2,"Qui a inventé le World Wide Web ?","Tim Berners-Lee",["Bill Gates","Vint Cerf","Steve Jobs"],
    "Tim Berners-Lee propose le Web en 1989 au CERN, près de Genève. Le premier site est mis en ligne en 1991.",
    "Internet (le réseau) est plus ancien : Vint Cerf et Bob Kahn ont conçu le protocole TCP/IP dans les années 1970.","Le CERN a placé le Web dans le domaine public en 1993.","CERN","sci");
  Q("sci","Technologies et IA",3,"Comment s'appelle le test proposé en 1950 pour évaluer si une machine peut imiter l'intelligence humaine ?","Le test de Turing",["Le test de Lovelace","Le test de von Neumann","Le test de Shannon"],
    "Alan Turing propose le « jeu de l'imitation » dans l'article Computing Machinery and Intelligence (1950).",
    "Turing a aussi contribué au déchiffrement d'Enigma pendant la Seconde Guerre mondiale.","Le terme « intelligence artificielle » apparaît en 1956 à la conférence de Dartmouth.","Mind, 1950","sci");
  Q("sci","Technologies et IA",4,"Quel programme de DeepMind a battu le champion de go Lee Sedol en 2016 ?","AlphaGo",["Deep Blue","Watson","AlphaFold"],
    "AlphaGo a gagné 4 parties sur 5 à Séoul en mars 2016, combinant réseaux de neurones et recherche arborescente.",
    "Deep Blue (IBM) a battu Garry Kasparov aux échecs en 1997.","AlphaFold prédit la structure des protéines ; ses auteurs ont reçu une partie du prix Nobel de chimie 2024.","DeepMind","sci");
  Q("sci","Énergie",2,"Quelle réaction se produit au cœur du Soleil ?","La fusion nucléaire",["La fission nucléaire","La combustion","La radioactivité alpha"],
    "Au cœur du Soleil, à environ 15 millions de degrés, des noyaux d'hydrogène fusionnent pour former de l'hélium en libérant de l'énergie.",
    "Les centrales nucléaires actuelles utilisent au contraire la fission (cassure de noyaux lourds).","Le projet ITER, à Cadarache, vise à démontrer la faisabilité de la fusion contrôlée.","CEA","sci");
  Q("sci","Physique",5,"Quel physicien a formulé le principe d'incertitude en 1927 ?","Werner Heisenberg",["Niels Bohr","Erwin Schrödinger","Max Planck"],
    "Le principe d'incertitude énonce qu'on ne peut connaître simultanément avec une précision arbitraire la position et la quantité de mouvement d'une particule.",
    "Heisenberg a reçu le prix Nobel de physique en 1932.","C'est un pilier de la mécanique quantique, débattu notamment lors du congrès Solvay de 1927.","Nobel Prize","sci");
  Q("sci","Chimie",5,"Quel élément possède le numéro atomique 1 ?","L'hydrogène",["L'hélium","Le lithium","Le carbone"],
    "L'hydrogène possède un seul proton. C'est l'élément le plus abondant de l'Univers (environ 74 % de la masse de matière ordinaire).",
    "Son nom, donné par Lavoisier, signifie « qui engendre l'eau ».","Henry Cavendish l'a identifié comme substance distincte en 1766.","IUPAC","sci");

  // ======================= CULTURES & SOCIÉTÉS =======================
  Q("cult","Langues",1,"Quelle langue compte le plus de locuteurs natifs au monde ?","Le chinois mandarin",["L'anglais","L'espagnol","L'hindi"],
    "Le mandarin compte environ 940 millions de locuteurs natifs, devant l'espagnol et l'anglais.",
    "En comptant les locuteurs en langue seconde, l'anglais est la langue la plus parlée au monde.","Les estimations varient selon les sources (ici Ethnologue).","Ethnologue","contemp","2025");
  Q("cult","Langues",3,"De quelle famille de langues le finnois fait-il partie ?","Ouralienne",["Indo-européenne","Germanique","Slave"],
    "Le finnois appartient à la branche finno-ougrienne de la famille ouralienne, comme l'estonien et, plus lointainement, le hongrois.",
    "Le suédois, langue officielle aussi en Finlande, est une langue germanique.","Le finnois compte 15 cas grammaticaux.","Britannica","hist");
  Q("cult","Langues",4,"Quelle langue est parlée au Pays basque et n'a aucune parenté démontrée avec d'autres langues vivantes ?","Le basque (euskara)",["Le catalan","L'occitan","Le galicien"],
    "Le basque est un isolat linguistique : c'est probablement la seule langue pré-indo-européenne encore parlée en Europe occidentale.",
    "Il est co-officiel dans la communauté autonome basque et en Navarre (Espagne).","Le catalan, l'occitan et le galicien sont des langues romanes.","Britannica","hist");
  Q("cult","Religions",2,"Quelle ville est sainte à la fois pour le judaïsme, le christianisme et l'islam ?","Jérusalem",["La Mecque","Rome","Bethléem"],
    "Jérusalem abrite le mur des Lamentations, l'église du Saint-Sépulcre et la mosquée al-Aqsa.",
    "La vieille ville est inscrite au patrimoine mondial depuis 1981.","La Mecque est la ville sainte de l'islam, interdite aux non-musulmans.","UNESCO","hist");
  Q("cult","Religions",3,"Quel livre est le texte sacré du sikhisme ?","Le Guru Granth Sahib",["Les Vedas","Le Tipitaka","L'Avesta"],
    "Le Guru Granth Sahib est considéré par les sikhs comme leur guru éternel. Il est conservé au Temple d'or d'Amritsar.",
    "Le sikhisme a été fondé au XVᵉ siècle au Pendjab par Guru Nanak.","Les Vedas sont hindous, le Tipitaka bouddhiste, l'Avesta zoroastrien.","Britannica","hist");
  Q("cult","Religions",4,"Quelle religion compte le plus de fidèles en Indonésie ?","L'islam",["L'hindouisme","Le bouddhisme","Le christianisme"],
    "Environ 87 % des Indonésiens sont musulmans, ce qui fait de l'Indonésie le pays comptant le plus de musulmans au monde.",
    "Bali est majoritairement hindouiste.","L'Indonésie reconnaît officiellement six religions.","Recensement indonésien / Pew Research Center","contemp","2023");
  Q("cult","Gastronomie",1,"De quel pays le plat appelé paella est-il originaire ?","Espagne",["Italie","Mexique","Portugal"],
    "La paella est née dans la région de Valence, à l'origine un plat paysan à base de riz, de lapin, de poulet et de haricots.",
    "Le mot désigne aussi la poêle large dans laquelle on la cuisine.","Le riz a été introduit en Espagne par les Arabes au Moyen Âge.","Britannica","hist");
  Q("cult","Gastronomie",2,"Quelle cuisine nationale a été inscrite la première au patrimoine immatériel de l'UNESCO, en 2010 ?","Le repas gastronomique des Français",["La cuisine japonaise (washoku)","La diète méditerranéenne","La cuisine coréenne (kimjang)"],
    "Le « repas gastronomique des Français » est inscrit en novembre 2010, le même jour que la cuisine traditionnelle mexicaine et la diète méditerranéenne.",
    "Le washoku japonais est inscrit en 2013, le kimjang coréen la même année.","L'UNESCO distingue une pratique sociale, pas des recettes.","UNESCO","hist");
  Q("cult","Gastronomie",3,"De quel pays le kimchi est-il un plat emblématique ?","La Corée",["Le Japon","La Chine","Le Viêt Nam"],
    "Le kimchi est un mélange de légumes lacto-fermentés, le plus souvent du chou et du piment.",
    "Le kimjang, préparation collective du kimchi pour l'hiver, est inscrit au patrimoine immatériel de l'UNESCO.","Le piment n'a été introduit en Corée qu'au XVIᵉ ou XVIIᵉ siècle.","UNESCO","hist");
  Q("cult","Patrimoine",1,"Dans quelle ville se trouve le Colisée ?","Rome",["Athènes","Naples","Istanbul"],
    "Le Colisée, ou amphithéâtre flavien, est inauguré en 80 apr. J.-C. sous l'empereur Titus. Il pouvait accueillir environ 50 000 spectateurs.",
    "Il est l'une des « nouvelles sept merveilles du monde » désignées en 2007.","On y organisait des combats de gladiateurs et des chasses d'animaux.","UNESCO","hist");
  Q("cult","Patrimoine",2,"Dans quel pays se trouve le Taj Mahal ?","Inde",["Pakistan","Iran","Bangladesh"],
    "Le Taj Mahal, à Agra, a été construit au XVIIᵉ siècle par l'empereur moghol Shah Jahan en mémoire de son épouse Mumtaz Mahal.",
    "Environ 20 000 artisans auraient participé à sa construction.","Il est inscrit au patrimoine mondial depuis 1983.","UNESCO","hist");
  Q("cult","Patrimoine",4,"Quel pays compte le plus de sites inscrits au patrimoine mondial de l'UNESCO ?","L'Italie",["La Chine","La France","L'Espagne"],
    "L'Italie compte 61 sites, juste devant la Chine (60), après la session de 2025.",
    "Les deux pays se disputent la première place depuis plusieurs années.","Le classement évolue à chaque session annuelle du Comité du patrimoine mondial.","UNESCO, liste du patrimoine mondial (2025)","contemp","2025");
  Q("cult","Arts et littérature",1,"Qui a peint La Joconde ?","Léonard de Vinci",["Michel-Ange","Raphaël","Botticelli"],
    "Léonard de Vinci la peint entre 1503 et 1519 environ. Elle est conservée au musée du Louvre.",
    "Elle a été volée en 1911 par Vincenzo Peruggia et retrouvée en 1913 à Florence.","Le modèle serait Lisa Gherardini, épouse du marchand florentin Francesco del Giocondo.","Musée du Louvre","hist");
  Q("cult","Arts et littérature",2,"Qui a écrit « Cent ans de solitude » ?","Gabriel García Márquez",["Jorge Luis Borges","Pablo Neruda","Mario Vargas Llosa"],
    "Publié en 1967, le roman raconte l'histoire de la famille Buendía dans le village imaginaire de Macondo.",
    "García Márquez, colombien, a reçu le prix Nobel de littérature en 1982.","C'est un chef-d'œuvre du « réalisme magique ».","Nobel Prize","hist");
  Q("cult","Arts et littérature",3,"Quel écrivain russe a écrit « Guerre et Paix » ?","Léon Tolstoï",["Fiodor Dostoïevski","Anton Tchekhov","Alexandre Pouchkine"],
    "Publié entre 1865 et 1869, le roman suit plusieurs familles aristocratiques pendant les guerres napoléoniennes.",
    "Il compte plus de 500 personnages.","Tolstoï est aussi l'auteur d'« Anna Karénine ».","Britannica","hist");
  Q("cult","Arts et littérature",4,"Quel architecte a conçu l'Opéra de Sydney ?","Jørn Utzon",["Frank Gehry","Oscar Niemeyer","Renzo Piano"],
    "L'architecte danois Jørn Utzon remporte le concours en 1957. Le bâtiment est inauguré en 1973.",
    "Utzon a quitté le projet en 1966 et n'a jamais vu le bâtiment terminé.","Il est inscrit au patrimoine mondial depuis 2007.","UNESCO","hist");
  Q("cult","Personnalités",2,"Quelle femme a reçu deux prix Nobel dans deux disciplines scientifiques différentes ?","Marie Curie",["Irène Joliot-Curie","Rosalind Franklin","Dorothy Hodgkin"],
    "Marie Curie a reçu le prix Nobel de physique en 1903 et celui de chimie en 1911.",
    "Sa fille Irène Joliot-Curie a reçu le prix Nobel de chimie en 1935.","Elle repose au Panthéon depuis 1995, première femme honorée pour ses propres mérites.","Nobel Prize","hist");
  Q("cult","Festivals et événements",2,"Dans quelle ville a lieu le célèbre carnaval du sambodrome ?","Rio de Janeiro",["Salvador de Bahia","São Paulo","Buenos Aires"],
    "Le sambodrome de Rio, conçu par Oscar Niemeyer, accueille depuis 1984 le défilé des écoles de samba.",
    "Le carnaval de Salvador de Bahia est réputé pour son ambiance de rue, autour des trios elétricos.","Le carnaval a lieu avant le mercredi des Cendres, début du carême.","Ville de Rio","hist");
  Q("cult","Festivals et événements",3,"Quelle fête hindoue est appelée « fête des lumières » ?","Diwali",["Holi","Navratri","Pongal"],
    "Diwali célèbre la victoire de la lumière sur les ténèbres ; on y allume des lampes à huile (diyas).",
    "Holi est la fête des couleurs, au printemps.","Diwali est aussi célébrée par les jaïns et les sikhs.","Britannica","hist");

  // ======================= ENVIRONNEMENT & MONDE =======================
  Q("env","Biodiversité",1,"Quel est le plus grand animal ayant jamais vécu sur Terre ?","La baleine bleue",["Le Brachiosaure","L'éléphant d'Afrique","Le requin-baleine"],
    "La baleine bleue peut dépasser 30 m et 150 tonnes. Aucun dinosaure connu n'atteignait cette masse.",
    "Son cœur pèse autant qu'une petite voiture.","Chassée presque jusqu'à l'extinction au XXᵉ siècle, elle est protégée depuis 1966.","NOAA","sci");
  Q("env","Biodiversité",2,"Quel est l'animal terrestre le plus rapide ?","Le guépard",["L'antilope pronghorn","Le lion","Le lévrier"],
    "Le guépard peut atteindre environ 100 à 110 km/h sur de courtes distances.",
    "Le pronghorn, plus lent en pointe, peut maintenir une vitesse élevée bien plus longtemps.","Le faucon pèlerin, en piqué, dépasse 300 km/h.","National Geographic","sci");
  Q("env","Biodiversité",3,"Dans quel pays vit naturellement le lémurien ?","Madagascar",["Indonésie","Brésil","Congo"],
    "Les lémuriens sont endémiques de Madagascar : ils n'existent nulle part ailleurs à l'état sauvage.",
    "On en compte plus d'une centaine d'espèces, dont beaucoup sont menacées.","L'isolement de l'île depuis environ 88 millions d'années explique ce fort endémisme.","UICN","sci");
  Q("env","Biodiversité",4,"Quelle organisation publie la Liste rouge des espèces menacées ?","L'UICN",["Le WWF","Greenpeace","Le PNUE"],
    "L'Union internationale pour la conservation de la nature, fondée en 1948 à Fontainebleau, publie cette liste depuis 1964.",
    "Plus de 45 000 espèces y sont classées menacées d'extinction.","Les catégories vont de « préoccupation mineure » à « éteinte ».","iucnredlist.org","contemp","2025");
  Q("env","Climat",2,"Quel gaz à effet de serre d'origine humaine contribue le plus au réchauffement ?","Le dioxyde de carbone",["Le méthane","La vapeur d'eau","L'ozone"],
    "Le CO₂, issu surtout de la combustion des énergies fossiles, est responsable d'environ deux tiers du forçage radiatif dû aux gaz à effet de serre de longue durée.",
    "Le méthane est environ 80 fois plus réchauffant que le CO₂ sur 20 ans, mais présent en bien plus faible quantité.","La vapeur d'eau est le principal gaz à effet de serre naturel, mais agit en rétroaction.","GIEC, AR6","sci");
  Q("env","Climat",2,"En quelle année a été adopté l'Accord de Paris sur le climat ?","2015",["1997","2009","2021"],
    "Adopté lors de la COP21 en décembre 2015, il vise à contenir le réchauffement nettement sous 2 °C et si possible à 1,5 °C.",
    "1997 est l'année du protocole de Kyoto.","Les États-Unis s'en sont retirés deux fois (décision de 2017 effective en 2020, puis en 2025-2026).","CCNUCC","hist");
  Q("env","Climat",3,"Que signifie le sigle GIEC ?","Groupe d'experts intergouvernemental sur l'évolution du climat",["Groupe international d'études climatiques","Grand institut européen du climat","Groupement intergouvernemental pour l'environnement et le carbone"],
    "Créé en 1988 par l'Organisation météorologique mondiale et le PNUE, il évalue l'état des connaissances scientifiques sans mener lui-même de recherches.",
    "Il a reçu le prix Nobel de la paix en 2007 avec Al Gore.","Son 6ᵉ rapport d'évaluation (AR6) a été achevé en 2023.","ipcc.ch","hist");
  Q("env","Océans",2,"Quel est le plus grand récif corallien du monde ?","La Grande Barrière de corail",["Le récif du Belize","Le récif de Nouvelle-Calédonie","Le triangle de corail"],
    "Située au large du Queensland (Australie), elle s'étend sur plus de 2 300 km.",
    "C'est la plus grande structure construite par des organismes vivants.","Elle subit des épisodes de blanchissement répétés liés au réchauffement des océans.","UNESCO","geo");
  Q("env","Océans",4,"Quelle est la profondeur approximative de la fosse des Mariannes ?","Environ 11 000 m",["Environ 5 000 m","Environ 8 800 m","Environ 15 000 m"],
    "Le Challenger Deep, point le plus profond connu, atteint environ 10 900 m.",
    "Seules quelques personnes l'ont atteint, dont James Cameron en solitaire en 2012.","La pression y dépasse 1 000 fois la pression atmosphérique.","NOAA","geo");
  Q("env","Géologie",2,"Comment appelle-t-on la théorie qui explique le mouvement des continents ?","La tectonique des plaques",["La dérive glaciaire","L'érosion continentale","La théorie du rebond"],
    "Les plaques lithosphériques se déplacent de quelques centimètres par an sur l'asthénosphère.",
    "Alfred Wegener a proposé la dérive des continents dès 1912, mais la théorie n'a été acceptée que dans les années 1960.","La Pangée, supercontinent, s'est fragmentée il y a environ 200 millions d'années.","USGS","sci");
  Q("env","Géologie",3,"Quelle échelle mesure l'énergie libérée par un séisme et a remplacé l'échelle de Richter pour les grands séismes ?","L'échelle de magnitude de moment",["L'échelle de Mercalli","L'échelle de Beaufort","L'échelle de Mohs"],
    "La magnitude de moment (Mw) est calculée à partir de la surface de la faille et du glissement. Chaque degré correspond à environ 32 fois plus d'énergie.",
    "L'échelle de Mercalli mesure l'intensité (les effets ressentis), celle de Beaufort le vent, celle de Mohs la dureté des minéraux.","Le séisme le plus puissant enregistré est celui de Valdivia (Chili, 1960), de magnitude 9,5.","USGS","sci");
  Q("env","Géologie",4,"Qu'appelle-t-on la « ceinture de feu » ?","Une zone de volcans et séismes autour du Pacifique",["Une zone désertique d'Afrique","Une chaîne de volcans sous-marins de l'Atlantique","La couche chaude du manteau terrestre"],
    "Elle concentre environ 75 % des volcans actifs et 90 % des séismes du globe, le long des zones de subduction.",
    "Le Japon, l'Indonésie, le Chili et la côte ouest américaine en font partie.","La dorsale médio-atlantique est en revanche une zone d'écartement des plaques.","USGS","sci");
  Q("env","Énergies renouvelables",2,"Quel pays possède le plus grand barrage hydroélectrique du monde en puissance installée ?","La Chine",["Le Brésil","Les États-Unis","La Russie"],
    "Le barrage des Trois-Gorges, sur le Yangzi, a une puissance installée de 22,5 GW.",
    "Sa construction a déplacé plus d'un million de personnes.","Le barrage d'Itaipu, entre Brésil et Paraguay, a longtemps produit davantage d'électricité certaines années.","China Three Gorges Corporation","contemp","2025");
  Q("env","Énergies renouvelables",3,"Quel pays produit la quasi-totalité de son électricité à partir de sources renouvelables (hydroélectricité et géothermie) ?","L'Islande",["Le Danemark","L'Allemagne","Les Pays-Bas"],
    "L'Islande produit la quasi-totalité de son électricité grâce à l'hydroélectricité (environ 70 %) et à la géothermie (environ 30 %).",
    "La géothermie chauffe aussi environ 90 % des logements islandais.","Le pays se situe sur la dorsale médio-atlantique, d'où son intense activité volcanique.","Orkustofnun (Autorité nationale de l'énergie d'Islande)","contemp","2024");
  Q("env","Espèces animales",3,"Quel oiseau ne peut pas voler mais est le plus grand oiseau vivant ?","L'autruche",["L'émeu","Le casoar","Le condor"],
    "L'autruche peut mesurer 2,7 m et peser plus de 140 kg. Elle court jusqu'à environ 70 km/h.",
    "Ses œufs sont les plus gros de tous les oiseaux vivants.","Le condor des Andes est l'un des plus grands oiseaux volants.","Britannica","sci");
  Q("env","Espèces animales",5,"Quel animal est capable de survivre au vide spatial ?","Le tardigrade",["Le cafard","La méduse Turritopsis","Le rotifère"],
    "En 2007, la mission FOTON-M3 a exposé des tardigrades au vide spatial : une partie a survécu et s'est reproduite.",
    "Ces animaux microscopiques entrent en cryptobiose en se déshydratant presque totalement.","La méduse Turritopsis dohrnii est dite « immortelle » car elle peut rajeunir.","Current Biology, 2008","sci");
  Q("env","Ressources naturelles",3,"Quelle forêt est souvent appelée « poumon de la planète » ?","L'Amazonie",["La taïga sibérienne","La forêt du bassin du Congo","La forêt de Bornéo"],
    "L'Amazonie couvre environ 5,5 millions de km², dont 60 % au Brésil. Elle abrite environ 10 % des espèces connues.",
    "L'expression est trompeuse : la forêt consomme presque autant d'oxygène qu'elle en produit. Les océans (phytoplancton) produisent environ la moitié de l'oxygène.","Son rôle majeur est le stockage du carbone et la régulation des pluies.","WWF / Nature","sci");
  Q("env","Ressources naturelles",4,"Quel minerai est la principale source d'aluminium ?","La bauxite",["L'hématite","La cassitérite","La galène"],
    "La bauxite est transformée en alumine (procédé Bayer) puis en aluminium par électrolyse.",
    "Elle doit son nom au village des Baux-de-Provence, où elle fut identifiée en 1821.","L'hématite donne le fer, la cassitérite l'étain, la galène le plomb.","USGS","sci");

  W.WKA = W.WKA || {};
  W.WKA.data = W.WKA.data || {};
  W.WKA.data.bank = B;
})(typeof window !== "undefined" ? window : globalThis);
