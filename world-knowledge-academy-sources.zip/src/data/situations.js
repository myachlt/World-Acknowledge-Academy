/* World Knowledge Academy — Apprendre par situations (couche DONNÉES)
 * Chaque situation : un contexte concret, un document éventuel, puis plusieurs étapes (questions) à résoudre.
 */
(function (W) {
  const S = [
    {
      id: "paie", title: "Comprendre sa fiche de paie", domain: "prat", sub: "Finance personnelle", lvl: 2, asOf: "2026-06", src: "service-public.fr, bulletin de paie (exemple simplifié)",
      context: "Vous venez de recevoir votre premier bulletin de paie. Voici les lignes principales, simplifiées.",
      doc: { type: "table", title: "Bulletin de paie — mars (extrait simplifié)", cols: ["Rubrique", "Montant"], rows: [["Salaire de base (151,67 h)", "2 500,00 €"], ["Total des cotisations et contributions salariales", "− 540,00 €"], ["Net à payer avant impôt sur le revenu", "1 960,00 €"], ["Net imposable", "2 031,00 €"], ["Impôt sur le revenu prélevé à la source (taux 4,5 %)", "− 91,40 €"], ["Net payé", "1 868,60 €"], ["Total versé par l'employeur (coût total)", "3 480,00 €"]], note: "Exemple fictif aux chiffres cohérents." },
      steps: [
        { q: "Quel est le salaire brut ?", a: "2 500,00 €", w: ["1 960,00 €", "3 480,00 €", "1 868,60 €"], ex: "Le salaire brut est le salaire de base (ici pour 151,67 heures, soit 35 h par semaine). C'est le montant inscrit au contrat." },
        { q: "Quel montant arrive réellement sur votre compte bancaire ?", a: "1 868,60 €", w: ["1 960,00 €", "2 031,00 €", "2 500,00 €"], ex: "Le « net payé » est le net avant impôt diminué du prélèvement à la source : 1 960,00 − 91,40 = 1 868,60 €." },
        { q: "Sur quel montant le taux de prélèvement à la source est-il appliqué ?", a: "Le net imposable (2 031,00 €)", w: ["Le salaire brut (2 500,00 €)", "Le net avant impôt (1 960,00 €)", "Le coût employeur (3 480,00 €)"], ex: "4,5 % × 2 031,00 € = 91,40 €. Le net imposable est un peu supérieur au net avant impôt, car une partie de la CSG et la CRDS ne sont pas déductibles." },
        { q: "Que représentent les 540,00 € de cotisations salariales ?", a: "Le financement de la protection sociale (santé, retraite, chômage…)", w: ["Un impôt sur le revenu supplémentaire", "La rémunération de l'employeur", "Une épargne bloquée à votre nom"], ex: "Les cotisations financent la sécurité sociale, les retraites de base et complémentaires, l'assurance chômage, etc. Elles ouvrent des droits." },
        { q: "Pourquoi le « coût total » pour l'employeur (3 480 €) dépasse-t-il le brut ?", a: "Parce que l'employeur paie aussi des cotisations patronales", w: ["Parce que le salarié rembourse l'employeur", "Parce qu'il inclut l'impôt sur le revenu", "C'est une erreur du bulletin"], ex: "Aux 2 500 € bruts s'ajoutent environ 980 € de cotisations patronales. Le coût du travail est donc nettement supérieur au salaire perçu." }
      ]
    },
    {
      id: "location", title: "Louer un appartement", domain: "prat", sub: "Droit et législation", lvl: 2, asOf: "2026-06", src: "Loi du 6 juillet 1989 ; décret du 26 août 1987 (réparations locatives)",
      context: "Vous visitez un deux-pièces vide (non meublé) à Lyon, en zone tendue. L'annonce indique : loyer 820 € hors charges, charges 60 €, DPE classe D.",
      doc: { type: "text", title: "Annonce", body: "T2 de 45 m², 3e étage sans ascenseur, Lyon 7e. Loyer : 820 € + 60 € de charges. Dépôt de garantie demandé : 1 640 €. Bail de 3 ans. DPE : D. Disponible le 1er du mois prochain." },
      steps: [
        { q: "Le dépôt de garantie demandé (1 640 €) est-il conforme ?", a: "Non : il est limité à 1 mois de loyer hors charges, soit 820 €", w: ["Oui, 2 mois sont autorisés", "Oui, il est libre", "Non, il est limité à 880 € charges comprises"], ex: "Pour un logement vide, le dépôt de garantie ne peut dépasser 1 mois de loyer hors charges. 2 mois ne sont autorisés que pour un meublé." },
        { q: "Qui doit payer le remplacement d'un joint de robinet usé ?", a: "Le locataire (entretien courant)", w: ["Le propriétaire", "Le syndic", "La mairie"], ex: "Le décret de 1987 liste les réparations locatives à la charge du locataire (petit entretien). Les grosses réparations et la vétusté restent à la charge du propriétaire." },
        { q: "Qui doit financer le remplacement d'une chaudière hors d'usage à cause de son âge ?", a: "Le propriétaire", w: ["Le locataire", "Les deux à parts égales", "L'assurance du locataire"], ex: "Le bailleur doit délivrer un logement décent et en bon état d'usage, et prendre en charge les réparations dues à la vétusté." },
        { q: "Dans ce logement situé en zone tendue, quel préavis devrez-vous respecter pour partir ?", a: "1 mois", w: ["3 mois", "2 mois", "Aucun"], ex: "En zone tendue, le préavis du locataire d'un logement vide est réduit à 1 mois (contre 3 mois en principe ailleurs)." },
        { q: "Quel document est indispensable pour comparer l'état du logement à l'entrée et à la sortie ?", a: "L'état des lieux", w: ["Le DPE", "La quittance de loyer", "Le règlement de copropriété"], ex: "L'état des lieux d'entrée et de sortie, établi contradictoirement, sert de base pour retenir éventuellement une somme sur le dépôt de garantie." }
      ]
    },
    {
      id: "inflation", title: "Un pays face à une forte inflation", domain: "eco", sub: "Concepts économiques", lvl: 3, asOf: null, src: "Notions de macroéconomie ; Banque de France",
      context: "Le pays B connaît une inflation de 25 % sur un an. Sa monnaie a perdu 40 % de sa valeur face au dollar, et l'État finance une partie de son déficit par la création monétaire.",
      doc: { type: "chart", kind: "line", title: "Pays B : inflation annuelle", unit: "%", labels: ["An 1", "An 2", "An 3", "An 4"], series: [{ name: "Inflation", values: [4, 9, 18, 25] }], note: "Données d'entraînement (fictives)." },
      steps: [
        { q: "Quel mécanisme décrit dans le contexte alimente directement l'inflation ?", a: "Le financement du déficit par création monétaire", w: ["La baisse des impôts", "La hausse de la productivité", "L'augmentation des exportations"], ex: "Plus de monnaie pour une même quantité de biens fait monter les prix. C'est un mécanisme classique des inflations élevées." },
        { q: "Pourquoi la dépréciation de la monnaie aggrave-t-elle l'inflation ?", a: "Les produits importés (énergie, aliments, composants) coûtent plus cher", w: ["Elle fait baisser les salaires", "Elle réduit la quantité de monnaie", "Elle supprime les importations"], ex: "C'est « l'inflation importée ». Elle est d'autant plus forte que le pays dépend des importations." },
        { q: "Qui perd le plus de pouvoir d'achat dans cette situation ?", a: "Les épargnants et les ménages aux revenus fixes non indexés", w: ["Les emprunteurs à taux fixe", "Les exportateurs", "Les propriétaires d'actifs réels"], ex: "L'inflation réduit la valeur réelle de l'épargne et des revenus fixes. À l'inverse, elle allège le poids réel des dettes à taux fixe." },
        { q: "Quelle mesure une banque centrale indépendante prendrait-elle en priorité ?", a: "Relever fortement ses taux directeurs et cesser de financer l'État", w: ["Baisser les taux à zéro", "Imprimer davantage de monnaie", "Fixer les prix de tous les produits"], ex: "Hausse des taux et arrêt de la monétisation du déficit sont les outils classiques. Le contrôle des prix crée en général des pénuries." }
      ]
    },
    {
      id: "adhesion", title: "Un pays veut rejoindre l'Union européenne", domain: "pol", sub: "Institutions européennes", lvl: 4, asOf: "2026-06", src: "Traité sur l'Union européenne, art. 49 ; critères de Copenhague",
      context: "Le pays C, voisin de l'UE, dépose sa candidature. Il organise des élections libres mais son système judiciaire est jugé peu indépendant.",
      doc: null,
      steps: [
        { q: "Quel article du traité sur l'Union européenne encadre l'adhésion ?", a: "L'article 49", w: ["L'article 50", "L'article 5", "L'article 100"], ex: "L'article 49 TUE prévoit que tout État européen respectant les valeurs de l'article 2 peut demander à devenir membre. L'article 50 organise, lui, la sortie (utilisé pour le Brexit)." },
        { q: "Quel critère pose problème pour le pays C ?", a: "Le critère politique : l'État de droit, avec une justice indépendante", w: ["Le critère monétaire : il n'a pas l'euro", "Le critère militaire : il n'est pas dans l'OTAN", "Le critère démographique"], ex: "Les critères de Copenhague exigent des institutions stables garantissant la démocratie, l'État de droit et les droits de l'homme. L'adoption de l'euro n'est pas une condition d'adhésion." },
        { q: "Comment le Conseil de l'UE décide-t-il d'accepter un nouveau membre ?", a: "À l'unanimité", w: ["À la majorité qualifiée", "À la majorité simple", "Par décision de la Commission seule"], ex: "L'unanimité est requise, après avis de la Commission et approbation du Parlement européen. Chaque État membre doit ensuite ratifier le traité d'adhésion." },
        { q: "Que doit faire le pays C pendant les négociations ?", a: "Reprendre dans son droit l'« acquis communautaire », chapitre par chapitre", w: ["Quitter toutes les autres organisations", "Adopter immédiatement l'euro", "Renoncer à sa langue officielle"], ex: "L'acquis est découpé en 35 chapitres de négociation (concurrence, environnement, justice…). Le processus prend souvent une décennie ou plus." }
      ]
    },
    {
      id: "phishing", title: "Un courriel suspect de votre banque", domain: "prat", sub: "Culture numérique", lvl: 1, asOf: "2026-06", src: "cybermalveillance.gouv.fr",
      context: "Vous recevez ce message un dimanche soir.",
      doc: { type: "text", title: "De : Service Sécurité <securite@banque-secure-verif.com>", body: "Objet : URGENT – Votre compte sera bloqué sous 24 h\n\nCher client,\nUne activité inhabituelle a été détectée. Pour éviter le blocage définitif de votre compte, confirmez immédiatement votre identité en cliquant ici et en saisissant votre identifiant, votre mot de passe et le code reçu par SMS.\n\nLe service sécurité" },
      steps: [
        { q: "Quel élément est le signal d'alerte le plus fort ?", a: "La demande de saisir mot de passe et code SMS via un lien", w: ["Le fait qu'il soit envoyé un dimanche", "La formule « Cher client »", "La présence d'un objet"], ex: "Aucune banque ne demande vos identifiants complets et un code de validation par courriel. Le code SMS permettrait au fraudeur de valider une opération." },
        { q: "Que révèle l'adresse de l'expéditeur ?", a: "Un nom de domaine qui n'est pas celui de votre banque", w: ["Que le message est forcément authentique", "Rien du tout", "Que le message vient d'un collègue"], ex: "Les fraudeurs utilisent des domaines qui « ressemblent » à un nom officiel. Vérifiez toujours le domaine exact." },
        { q: "Quelle est la bonne réaction ?", a: "Ne pas cliquer, contacter sa banque par ses canaux habituels et signaler le message", w: ["Cliquer pour vérifier si c'est vrai", "Répondre pour demander des précisions", "Transférer à tous ses contacts"], ex: "On peut signaler sur signal-spam.fr ou au 33700 pour les SMS. En cas de doute, appeler le numéro inscrit au dos de sa carte." }
      ]
    },
    {
      id: "secours", title: "Un passant s'effondre dans la rue", domain: "prat", sub: "Santé et prévention", lvl: 1, asOf: null, src: "Référentiels de premiers secours ; Croix-Rouge française",
      context: "Un homme s'effondre devant vous sur le trottoir. Il ne répond pas quand vous lui parlez.",
      doc: null,
      steps: [
        { q: "Quelle est votre toute première action ?", a: "Vérifier qu'il n'y a pas de danger pour vous et la victime (circulation…)", w: ["Lui donner de l'eau", "Le relever immédiatement", "Chercher ses papiers"], ex: "Protéger d'abord, pour éviter un sur-accident. Puis alerter, puis secourir." },
        { q: "Il ne respire pas normalement. Que faites-vous ?", a: "Appeler le 15 (ou 112), commencer le massage cardiaque et faire chercher un défibrillateur", w: ["Le mettre en PLS et attendre", "Attendre que quelqu'un d'autre agisse", "Lui faire boire du sucre"], ex: "Un arrêt cardiaque se traite par compressions thoraciques (100 à 120 par minute, environ 5 à 6 cm de profondeur) et défibrillation précoce. Chaque minute compte." },
        { q: "Le défibrillateur automatisé arrive. Peut-on l'utiliser sans formation ?", a: "Oui : il guide l'utilisateur à la voix et ne délivre un choc que si nécessaire", w: ["Non, seul un médecin peut l'utiliser", "Non, c'est interdit au public", "Oui, mais seulement après 30 minutes"], ex: "En France, tout le monde peut utiliser un défibrillateur depuis 2007. L'appareil analyse le rythme cardiaque lui-même." }
      ]
    },
    {
      id: "credit", title: "Choisir entre deux offres de crédit auto", domain: "prat", sub: "Finance personnelle", lvl: 3, asOf: null, src: "Code de la consommation ; calcul illustratif",
      context: "Vous empruntez 15 000 € pour une voiture. Deux banques vous font une offre.",
      doc: { type: "table", title: "Comparaison des offres", cols: ["", "Banque 1", "Banque 2"], rows: [["Durée", "48 mois", "60 mois"], ["Mensualité", "345 €", "285 €"], ["TAEG", "3,9 %", "4,5 %"], ["Coût total du crédit", "1 560 €", "2 100 €"]], note: "Données d'entraînement (fictives), arrondies." },
      steps: [
        { q: "Quelle offre coûte le moins cher au total ?", a: "La banque 1", w: ["La banque 2", "Elles coûtent la même chose", "On ne peut pas savoir"], ex: "Le coût total est de 1 560 € contre 2 100 €. La mensualité plus faible de la banque 2 s'explique par une durée plus longue et un taux plus élevé." },
        { q: "Comment vérifier le coût total à partir de la mensualité ?", a: "Mensualité × nombre de mois − capital emprunté", w: ["Capital × TAEG", "Mensualité × 12", "TAEG × durée"], ex: "Banque 1 : 345 × 48 = 16 560 € ; 16 560 − 15 000 = 1 560 €. Banque 2 : 285 × 60 = 17 100 € ; 17 100 − 15 000 = 2 100 €." },
        { q: "Quel indicateur légal permet de comparer directement les offres ?", a: "Le TAEG", w: ["La mensualité", "La durée", "Le nom de la banque"], ex: "Le TAEG inclut intérêts, frais et assurance obligatoire. À durée égale, le plus bas TAEG est le moins cher." },
        { q: "Après avoir signé, de combien de jours disposez-vous pour renoncer au crédit à la consommation ?", a: "14 jours", w: ["7 jours", "30 jours", "Aucun"], ex: "Le délai de rétractation d'un crédit à la consommation est de 14 jours calendaires à compter de l'acceptation de l'offre." }
      ]
    },
    {
      id: "hotel-london", title: "Arriver à l'hôtel à Londres", domain: "en", sub: "Situations", lvl: 2, asOf: null, src: "Dialogue original",
      context: "Vous arrivez à la réception d'un hôtel londonien. Écoutez ou lisez le dialogue, puis répondez.",
      doc: { type: "dialogue", lang: "en", title: "At the front desk", lines: [["Receptionist", "Good evening, welcome to the Kingsway Hotel. How can I help you?"], ["You", "Hi, I have a reservation under the name Martin, for three nights."], ["Receptionist", "Let me check… Yes, a double room with breakfast. Could I see your passport, please?"], ["You", "Of course, here you are. What time is breakfast served?"], ["Receptionist", "From seven to ten in the restaurant on the ground floor. Checkout is at eleven. Your room is on the fourth floor; the lift is just behind you."]] },
      steps: [
        { q: "How many nights has the guest booked?", a: "Three", w: ["Two", "Four", "One"], ex: "« for three nights »." },
        { q: "Que signifie « the lift » en anglais britannique ?", a: "L'ascenseur", w: ["L'escalier", "La sortie", "Le bagagiste"], ex: "« Lift » (britannique) = « elevator » (américain). De même, « ground floor » (GB) correspond au « first floor » américain : le rez-de-chaussée." },
        { q: "Quelle phrase est la plus polie pour demander le Wi-Fi ?", a: "Could you tell me the Wi-Fi password, please?", w: ["Give me the Wi-Fi password.", "I want Wi-Fi.", "Where is Wi-Fi, now?"], ex: "« Could you… please? » est la formule polie standard. En anglais, l'impératif seul paraît sec." },
        { q: "Breakfast is served…", a: "from 7 to 10 on the ground floor", w: ["from 7 to 11 on the fourth floor", "from 10 to 11 in the room", "all day"], ex: "« From seven to ten in the restaurant on the ground floor ». Le check-out est à 11 h." }
      ]
    },
    {
      id: "hotel-madrid", title: "Llegar a un hotel en Madrid", domain: "es", sub: "Situations", lvl: 2, asOf: null, src: "Dialogue original",
      context: "Vous arrivez à la réception d'un hôtel à Madrid. Écoutez ou lisez le dialogue, puis répondez.",
      doc: { type: "dialogue", lang: "es", title: "En la recepción", lines: [["Recepcionista", "Buenas tardes, bienvenido al Hotel Prado. ¿En qué puedo ayudarle?"], ["Usted", "Hola, tengo una reserva a nombre de Martin para dos noches."], ["Recepcionista", "Un momento… Sí, una habitación individual sin desayuno. ¿Me deja su documento de identidad, por favor?"], ["Usted", "Claro, aquí tiene. ¿Hay aparcamiento en el hotel?"], ["Recepcionista", "Sí, en el sótano. Cuesta veinte euros al día. Su habitación es la 312, en la tercera planta."]] },
      steps: [
        { q: "¿Cuántas noches va a quedarse el cliente?", a: "Dos", w: ["Tres", "Una", "Cuatro"], ex: "« para dos noches »." },
        { q: "La habitación incluye…", a: "No incluye el desayuno", w: ["Desayuno y cena", "Solo el desayuno", "Aparcamiento gratuito"], ex: "« una habitación individual sin desayuno »." },
        { q: "Que signifie « el sótano » ?", a: "Le sous-sol", w: ["Le toit", "Le jardin", "L'accueil"], ex: "« Sótano » = sous-sol. « Aparcamiento » (Espagne) se dit plutôt « estacionamiento » en Amérique latine." },
        { q: "Pourquoi la réceptionniste dit-elle « ayudarle » et non « ayudarte » ?", a: "Elle vouvoie le client (forme de politesse « usted »)", w: ["C'est une faute", "Elle parle à plusieurs personnes", "« ayudarte » n'existe pas"], ex: "« Usted » + 3e personne du singulier est la forme de politesse ; « le » est le pronom correspondant. Avec « tú », on dirait « ayudarte »." }
      ]
    },
    {
      id: "achat", title: "Un aspirateur tombe en panne après 8 mois", domain: "prat", sub: "Droit et législation", lvl: 2, asOf: "2026-06", src: "Code de la consommation, art. L217-3 et suivants",
      context: "Vous avez acheté un aspirateur neuf dans un magasin il y a 8 mois. Il ne s'allume plus. Le vendeur vous renvoie vers le fabricant.",
      doc: null,
      steps: [
        { q: "Qui est responsable au titre de la garantie légale de conformité ?", a: "Le vendeur", w: ["Le fabricant uniquement", "Personne après 6 mois", "Votre assurance habitation"], ex: "La garantie légale de conformité s'exerce contre le vendeur professionnel, pendant 2 ans pour un bien neuf." },
        { q: "Devez-vous prouver que le défaut existait au moment de l'achat ?", a: "Non : il est présumé exister pendant 24 mois pour un bien neuf", w: ["Oui, toujours", "Oui, après 6 mois", "Seulement si l'appareil coûte plus de 500 €"], ex: "Depuis 2022, le défaut apparu dans les 24 mois est présumé exister à la livraison. C'est au vendeur de prouver le contraire." },
        { q: "Que pouvez-vous demander en priorité ?", a: "La réparation ou le remplacement, sans frais", w: ["Uniquement un avoir", "Une indemnité forfaitaire de 100 €", "Rien, car la garantie commerciale a expiré"], ex: "Le consommateur choisit entre réparation et remplacement (sauf coût disproportionné). Une réparation sous garantie légale prolonge la garantie de 6 mois." }
      ]
    }
  ];
  W.WKA = W.WKA || {}; W.WKA.data = W.WKA.data || {};
  W.WKA.data.SITUATIONS = S;
})(typeof window !== "undefined" ? window : globalThis);
