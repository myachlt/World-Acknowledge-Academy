/* World Knowledge Academy — Jeux de données thématiques pour les générateurs (couche DONNÉES)
 * Faits stables (historiques, scientifiques). Années négatives = avant J.-C.
 */
(function (W) {
  // [année, événement, sous-catégorie, précision]
  const EVENTS = [
    [-3200, "Apparition de l'écriture cunéiforme en Mésopotamie", "Grandes civilisations", "Les premières tablettes d'Uruk servent d'abord à la comptabilité."],
    [-2560, "Achèvement de la pyramide de Khéops", "Antiquité", "Elle fut la plus haute construction humaine pendant près de 4 000 ans."],
    [-1750, "Code d'Hammurabi", "Antiquité", "Recueil de 282 lois gravées sur une stèle conservée au Louvre."],
    [-776, "Premiers Jeux olympiques antiques", "Antiquité", "Date traditionnelle, à Olympie, en l'honneur de Zeus."],
    [-753, "Fondation légendaire de Rome", "Antiquité", "Selon la tradition, par Romulus."],
    [-508, "Réformes de Clisthène et naissance de la démocratie athénienne", "Antiquité", "Les citoyens sont répartis en dix tribus."],
    [-490, "Bataille de Marathon", "Antiquité", "Victoire athénienne sur les Perses."],
    [-323, "Mort d'Alexandre le Grand", "Antiquité", "Son empire s'étendait de la Grèce à l'Indus."],
    [-221, "Unification de la Chine par Qin Shi Huang", "Grandes civilisations", "Premier empereur, connu pour son armée de terre cuite."],
    [-44, "Assassinat de Jules César", "Antiquité", "Aux ides de mars, au Sénat."],
    [-27, "Octave devient Auguste, premier empereur romain", "Antiquité", "Début du Principat."],
    [476, "Fin de l'Empire romain d'Occident", "Antiquité", "Déposition de Romulus Augustule par Odoacre."],
    [622, "Hégire : départ de Mahomet de La Mecque vers Médine", "Moyen Âge", "Point de départ du calendrier musulman."],
    [732, "Bataille de Poitiers", "Moyen Âge", "Charles Martel arrête une expédition omeyyade."],
    [800, "Couronnement de Charlemagne", "Moyen Âge", "Par le pape Léon III, à Rome."],
    [987, "Avènement d'Hugues Capet", "Moyen Âge", "Début de la dynastie capétienne."],
    [1054, "Schisme entre Rome et Constantinople", "Moyen Âge", "Séparation des Églises catholique et orthodoxe."],
    [1066, "Bataille d'Hastings", "Moyen Âge", "Guillaume le Conquérant devient roi d'Angleterre."],
    [1096, "Début de la première croisade", "Moyen Âge", "Prêchée par le pape Urbain II à Clermont en 1095."],
    [1206, "Gengis Khan proclamé chef des Mongols", "Moyen Âge", "Début de l'expansion de l'Empire mongol."],
    [1215, "Magna Carta", "Moyen Âge", "Le roi Jean sans Terre accepte de limiter son pouvoir."],
    [1347, "Arrivée de la peste noire en Europe", "Moyen Âge", "Elle tue entre un tiers et la moitié de la population européenne."],
    [1453, "Prise de Constantinople par les Ottomans", "Moyen Âge", "Fin de l'Empire byzantin."],
    [1455, "Bible de Gutenberg", "Moyen Âge", "Premier grand livre imprimé avec des caractères mobiles en Europe."],
    [1492, "Premier voyage de Christophe Colomb vers les Amériques", "Grandes civilisations", "Il atteint les Bahamas le 12 octobre."],
    [1517, "Thèses de Luther", "Révolutions", "Début de la Réforme protestante."],
    [1519, "Début du premier tour du monde (expédition Magellan)", "Grandes civilisations", "Achevé en 1522 par Elcano."],
    [1598, "Édit de Nantes", "Moyen Âge", "Henri IV accorde la liberté de culte aux protestants."],
    [1648, "Traités de Westphalie", "Révolutions", "Fin de la guerre de Trente Ans."],
    [1687, "Publication des Principia de Newton", "Révolutions", "Lois du mouvement et gravitation universelle."],
    [1776, "Déclaration d'indépendance des États-Unis", "Révolutions", "Adoptée le 4 juillet."],
    [1789, "Prise de la Bastille", "Révolutions", "Le 14 juillet, début symbolique de la Révolution française."],
    [1804, "Sacre de Napoléon Iᵉʳ", "Révolutions", "À Notre-Dame de Paris. Haïti proclame la même année son indépendance."],
    [1815, "Bataille de Waterloo", "Révolutions", "Défaite définitive de Napoléon."],
    [1848, "Printemps des peuples et abolition de l'esclavage en France", "Révolutions", "Décret du 27 avril 1848, porté par Victor Schœlcher."],
    [1865, "Fin de la guerre de Sécession et abolition de l'esclavage aux États-Unis", "Histoire contemporaine", "13ᵉ amendement."],
    [1869, "Ouverture du canal de Suez", "Histoire contemporaine", "Il relie la Méditerranée à la mer Rouge."],
    [1871, "Unification allemande", "Histoire contemporaine", "Proclamation de l'Empire allemand à Versailles."],
    [1885, "Conférence de Berlin sur le partage de l'Afrique", "Décolonisation", "Elle fixe les règles de la colonisation du continent."],
    [1905, "Loi de séparation des Églises et de l'État en France", "Histoire contemporaine", "Fondement de la laïcité française."],
    [1914, "Début de la Première Guerre mondiale", "Guerres mondiales", "Après l'attentat de Sarajevo."],
    [1917, "Révolution d'Octobre en Russie", "Révolutions", "Prise du pouvoir par les bolcheviks."],
    [1918, "Armistice de la Première Guerre mondiale", "Guerres mondiales", "Signé le 11 novembre à Rethondes."],
    [1929, "Krach de Wall Street", "Histoire contemporaine", "Début de la Grande Dépression."],
    [1939, "Début de la Seconde Guerre mondiale", "Guerres mondiales", "Invasion de la Pologne le 1ᵉʳ septembre."],
    [1944, "Débarquement de Normandie", "Guerres mondiales", "Le 6 juin, opération Overlord."],
    [1945, "Création de l'ONU", "Histoire contemporaine", "La Charte entre en vigueur le 24 octobre."],
    [1947, "Indépendance de l'Inde et du Pakistan", "Décolonisation", "Le 14 et le 15 août."],
    [1949, "Proclamation de la République populaire de Chine", "Guerre froide", "Par Mao Zedong, le 1ᵉʳ octobre."],
    [1957, "Traité de Rome et lancement de Spoutnik", "Guerre froide", "La même année, la CEE est créée et l'URSS envoie le premier satellite artificiel."],
    [1960, "« Année de l'Afrique » : 17 pays africains indépendants", "Décolonisation", "Dont 14 anciennes colonies françaises."],
    [1961, "Construction du mur de Berlin", "Guerre froide", "À partir du 13 août."],
    [1962, "Crise des missiles de Cuba", "Guerre froide", "Treize jours de tension en octobre."],
    [1963, "Discours « I Have a Dream » de Martin Luther King", "Histoire contemporaine", "Lors de la marche sur Washington."],
    [1969, "Premiers pas sur la Lune", "Histoire contemporaine", "Mission Apollo 11."],
    [1973, "Premier choc pétrolier", "Histoire contemporaine", "L'OPEP quadruple le prix du baril en quelques mois."],
    [1979, "Révolution iranienne", "Histoire contemporaine", "Fin de la monarchie du chah."],
    [1986, "Catastrophe de Tchernobyl", "Histoire contemporaine", "Explosion du réacteur n° 4, le 26 avril."],
    [1989, "Chute du mur de Berlin", "Guerre froide", "Le 9 novembre."],
    [1991, "Dissolution de l'URSS", "Guerre froide", "Le 26 décembre."],
    [1994, "Génocide des Tutsi au Rwanda", "Histoire contemporaine", "Environ 800 000 morts en cent jours."],
    [2001, "Attentats du 11 septembre", "Histoire contemporaine", "Contre le World Trade Center et le Pentagone."],
    [2002, "Mise en circulation des pièces et billets en euros", "Histoire contemporaine", "Dans 12 pays."],
    [2008, "Faillite de Lehman Brothers", "Histoire contemporaine", "Point culminant de la crise financière."],
    [2015, "Accord de Paris sur le climat", "Histoire contemporaine", "Adopté à la COP21."],
    [2020, "Sortie du Royaume-Uni de l'Union européenne", "Histoire contemporaine", "Le 31 janvier."]
  ];

  // [Z, symbole, nom, famille]
  const ELEMENTS = [
    [1, "H", "hydrogène", "non-métal"], [2, "He", "hélium", "gaz noble"], [3, "Li", "lithium", "métal alcalin"], [6, "C", "carbone", "non-métal"],
    [7, "N", "azote", "non-métal"], [8, "O", "oxygène", "non-métal"], [9, "F", "fluor", "halogène"], [10, "Ne", "néon", "gaz noble"],
    [11, "Na", "sodium", "métal alcalin"], [12, "Mg", "magnésium", "métal alcalino-terreux"], [13, "Al", "aluminium", "métal pauvre"],
    [14, "Si", "silicium", "métalloïde"], [15, "P", "phosphore", "non-métal"], [16, "S", "soufre", "non-métal"], [17, "Cl", "chlore", "halogène"],
    [18, "Ar", "argon", "gaz noble"], [19, "K", "potassium", "métal alcalin"], [20, "Ca", "calcium", "métal alcalino-terreux"],
    [26, "Fe", "fer", "métal de transition"], [27, "Co", "cobalt", "métal de transition"], [28, "Ni", "nickel", "métal de transition"],
    [29, "Cu", "cuivre", "métal de transition"], [30, "Zn", "zinc", "métal de transition"], [47, "Ag", "argent", "métal de transition"],
    [50, "Sn", "étain", "métal pauvre"], [53, "I", "iode", "halogène"], [74, "W", "tungstène", "métal de transition"],
    [78, "Pt", "platine", "métal de transition"], [79, "Au", "or", "métal de transition"], [80, "Hg", "mercure", "métal de transition"],
    [82, "Pb", "plomb", "métal pauvre"], [86, "Rn", "radon", "gaz noble"], [88, "Ra", "radium", "métal alcalino-terreux"], [92, "U", "uranium", "actinide"]
  ];
  const ELEMENT_NOTES = { W: "Du nom allemand wolfram.", Na: "Du latin natrium.", K: "Du latin kalium.", Fe: "Du latin ferrum.", Ag: "Du latin argentum.", Sn: "Du latin stannum.", Au: "Du latin aurum.", Hg: "Du grec hydrargyrum, « argent liquide ».", Pb: "Du latin plumbum.", Cu: "Du latin cuprum." };

  // [nom, rang depuis le Soleil, type, lunes connues (ordre de grandeur), particularité]
  const PLANETS = [
    ["Mercure", 1, "tellurique", "0", "La plus petite planète et la plus proche du Soleil ; une année y dure 88 jours."],
    ["Vénus", 2, "tellurique", "0", "La planète la plus chaude (environ 465 °C) à cause d'un effet de serre extrême ; elle tourne dans le sens rétrograde."],
    ["Terre", 3, "tellurique", "1", "La seule planète connue abritant la vie."],
    ["Mars", 4, "tellurique", "2", "Elle abrite Olympus Mons, le plus haut volcan connu du système solaire."],
    ["Jupiter", 5, "géante gazeuse", "plus de 90", "La plus grande planète, avec sa Grande Tache rouge."],
    ["Saturne", 6, "géante gazeuse", "plus de 140", "Célèbre pour ses anneaux ; sa densité moyenne est inférieure à celle de l'eau."],
    ["Uranus", 7, "géante de glaces", "28", "Son axe de rotation est incliné d'environ 98° : elle « roule » sur son orbite."],
    ["Neptune", 8, "géante de glaces", "16", "Les vents les plus rapides du système solaire, plus de 2 000 km/h."]
  ];

  // [grandeur, unité SI, symbole]
  const UNITS = [
    ["la force", "le newton", "N"], ["l'énergie", "le joule", "J"], ["la puissance", "le watt", "W"], ["la pression", "le pascal", "Pa"],
    ["la fréquence", "le hertz", "Hz"], ["la charge électrique", "le coulomb", "C"], ["la tension électrique", "le volt", "V"],
    ["la résistance électrique", "l'ohm", "Ω"], ["l'intensité du courant", "l'ampère", "A"], ["la température thermodynamique", "le kelvin", "K"],
    ["la quantité de matière", "la mole", "mol"], ["l'intensité lumineuse", "la candela", "cd"], ["la masse", "le kilogramme", "kg"],
    ["la radioactivité (activité)", "le becquerel", "Bq"]
  ];

  W.WKA = W.WKA || {}; W.WKA.data = W.WKA.data || {};
  Object.assign(W.WKA.data, { EVENTS, ELEMENTS, ELEMENT_NOTES, PLANETS, UNITS });
})(typeof window !== "undefined" ? window : globalThis);
