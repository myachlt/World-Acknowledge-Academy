/* World Knowledge Academy — Questions d'approfondissement : mécanismes, raisonnement, documents (couche DONNÉES)
 * doc : support à analyser. Types : text (extrait), table (tableau), chart (graphique en barres ou en courbe).
 * Les documents marqués « données d'entraînement » sont fictifs et servent uniquement à apprendre à lire un support.
 */
(function (W) {
  const B = W.WKA.data.bank;
  const Q = (cat, sub, d, q, a, w, ex, info, ctx, src, nature, asOf, doc) =>
    B.push({ cat, sub, d, q, a, w, ex, info, ctx: ctx || "", src, nature: nature || "sci", asOf: asOf || null, doc: doc || null, deep: true });

  // ---------- GÉOGRAPHIE ----------
  Q("geo", "Population et démographie", 2, "D'après le graphique, quel continent compte environ 1,5 milliard d'habitants ?", "L'Afrique", ["L'Europe", "L'Amérique latine", "L'Asie"],
    "Le graphique montre environ 4,8 milliards pour l'Asie, 1,5 pour l'Afrique, 0,74 pour l'Europe et 0,66 pour l'Amérique latine et les Caraïbes.",
    "L'Afrique est le continent dont la population croît le plus vite : elle pourrait représenter un quart de l'humanité vers 2050.", "Lire un graphique : repérer l'unité (milliards) avant de comparer les barres.", "ONU, World Population Prospects 2024", "contemp", "2024",
    { type: "chart", kind: "bar", title: "Population par grande région, 2024", unit: "milliards d'habitants", labels: ["Asie", "Afrique", "Europe", "Am. latine", "Am. du Nord", "Océanie"], series: [{ name: "Population", values: [4.8, 1.5, 0.74, 0.66, 0.38, 0.046] }], note: "Valeurs arrondies, ONU WPP 2024." });
  Q("geo", "Population et démographie", 3, "D'après le même graphique, l'Asie compte environ combien de fois plus d'habitants que l'Europe ?", "Environ 6 à 7 fois", ["Environ 2 fois", "Environ 3 fois", "Environ 15 fois"],
    "4,8 ÷ 0,74 ≈ 6,5. Il faut faire le rapport des deux valeurs, pas leur différence.",
    "L'Asie concentre environ 59 % de la population mondiale.", "Compétence : calculer un rapport à partir d'un document.", "ONU, World Population Prospects 2024", "contemp", "2024",
    { type: "chart", kind: "bar", title: "Population par grande région, 2024", unit: "milliards d'habitants", labels: ["Asie", "Afrique", "Europe", "Am. latine", "Am. du Nord", "Océanie"], series: [{ name: "Population", values: [4.8, 1.5, 0.74, 0.66, 0.38, 0.046] }], note: "Valeurs arrondies, ONU WPP 2024." });
  Q("geo", "Géographie physique", 3, "Il est 12 h à Paris en hiver (UTC+1). Quelle heure est-il à New York (UTC−5) ?", "6 h", ["7 h", "18 h", "17 h"],
    "L'écart est de 6 heures (de UTC+1 à UTC−5). New York est à l'ouest : on retire 6 heures, il est donc 6 h du matin.",
    "La Terre tourne d'environ 15° par heure, d'où des fuseaux de 15° de longitude en théorie.", "Raisonnement : à l'ouest, il est plus tôt ; à l'est, plus tard.", "Temps universel coordonné (UTC)", "sci");
  Q("geo", "Géographie physique", 4, "Pourquoi trouve-t-on de grands déserts chauds vers 20 à 30° de latitude (Sahara, désert d'Arabie, Kalahari) ?", "L'air qui s'y abaisse est sec : ce sont des zones de hautes pressions subtropicales", ["Ils sont trop éloignés de toute mer", "Ces régions reçoivent moins de soleil", "Les vents y viennent toujours des pôles"],
    "L'air chaud s'élève à l'équateur, perd son humidité en pluies, puis redescend vers les tropiques (cellule de Hadley). En descendant, il se réchauffe et s'assèche : les nuages ne se forment pas.",
    "Le désert d'Atacama ajoute à ce mécanisme un courant marin froid (Humboldt) qui stabilise l'air.", "Mécanisme : circulation atmosphérique générale.", "Météo-France ; manuels de climatologie", "sci");
  Q("geo", "Géographie physique", 3, "Qu'est-ce que la mousson en Asie du Sud ?", "Une inversion saisonnière des vents qui apporte de fortes pluies l'été", ["Une tempête tropicale isolée", "Un vent froid venu de l'Himalaya en été", "Une marée exceptionnelle"],
    "En été, le continent se réchauffe plus vite que l'océan : l'air humide de l'océan Indien est aspiré vers les terres et provoque des pluies abondantes. En hiver, le flux s'inverse.",
    "La mousson apporte en Inde environ 70 % des pluies annuelles : elle conditionne les récoltes.", "", "Météo-France ; India Meteorological Department", "sci");

  // ---------- POLITIQUE ----------
  Q("pol", "Régimes politiques", 3, "D'après cet extrait de la Constitution, que se passe-t-il si aucune motion de censure n'est adoptée ?", "Le projet de loi est considéré comme adopté", ["Le gouvernement doit démissionner", "Le texte est soumis à référendum", "Le Sénat tranche définitivement"],
    "C'est le mécanisme de l'article 49, alinéa 3 : le gouvernement engage sa responsabilité ; le texte est adopté sans vote, sauf si une motion de censure renverse le gouvernement.",
    "Depuis la révision de 2008, son usage est limité aux textes budgétaires et à un autre texte par session.", "Lire un texte juridique : repérer la condition (« sauf si ») et la conséquence.", "Constitution du 4 octobre 1958, art. 49", "hist", null,
    { type: "text", title: "Constitution française, article 49, alinéa 3 (extrait)", body: "« Le Premier ministre peut, après délibération du Conseil des ministres, engager la responsabilité du Gouvernement devant l'Assemblée nationale sur le vote d'un projet de loi de finances ou de financement de la sécurité sociale. Dans ce cas, ce projet est considéré comme adopté, sauf si une motion de censure, déposée dans les vingt-quatre heures qui suivent, est votée dans les conditions prévues à l'alinéa précédent. »" });
  Q("pol", "Régimes politiques", 2, "Quel philosophe a théorisé la séparation des pouvoirs dans « De l'esprit des lois » (1748) ?", "Montesquieu", ["Rousseau", "Voltaire", "Tocqueville"],
    "Montesquieu distingue la puissance législative, exécutive et judiciaire : « Pour qu'on ne puisse abuser du pouvoir, il faut que, par la disposition des choses, le pouvoir arrête le pouvoir. »",
    "Il s'inspire de l'observation du système anglais.", "Ce principe a influencé la Constitution américaine de 1787 et la DDHC (article 16).", "Montesquieu, De l'esprit des lois, livre XI", "hist");
  Q("pol", "Régimes politiques", 3, "Qu'appelle-t-on « cohabitation » sous la Vᵉ République ?", "Un président et un Premier ministre issus de majorités politiques opposées", ["Deux présidents simultanés", "Une alliance entre le Sénat et l'Assemblée", "Un gouvernement d'union nationale"],
    "La cohabitation survient quand l'Assemblée élue donne la majorité au camp opposé au président, qui doit nommer un Premier ministre de ce camp. Il y en a eu trois : 1986, 1993 et 1997.",
    "Le passage au quinquennat en 2000 et l'inversion du calendrier électoral visaient à rendre ces situations plus rares.", "", "Vie-publique.fr", "hist");
  Q("pol", "Organisations internationales", 4, "Une résolution recueille 13 voix pour et 2 contre au Conseil de sécurité, dont un vote contre de la Chine. Que se passe-t-il ?", "Elle est rejetée, car un membre permanent a opposé son veto", ["Elle est adoptée à la majorité", "Elle est renvoyée à l'Assemblée générale qui l'adopte", "Elle est adoptée mais non contraignante"],
    "Une décision de fond exige 9 voix sur 15 et l'absence de vote négatif d'un membre permanent. L'abstention d'un membre permanent ne bloque pas.",
    "L'URSS puis la Russie, et les États-Unis, sont les membres ayant le plus utilisé leur veto.", "Raisonnement : appliquer une règle à un cas.", "Charte des Nations unies, art. 27", "hist");
  Q("pol", "Institutions européennes", 4, "Un pays souhaite adhérer à l'Union européenne. Quelle condition fait partie des « critères de Copenhague » (1993) ?", "Des institutions stables garantissant la démocratie, l'État de droit et les droits de l'homme", ["Avoir déjà adopté l'euro", "Être membre de l'OTAN", "Avoir plus de 5 millions d'habitants"],
    "Les critères sont politiques (démocratie, État de droit, droits de l'homme, protection des minorités), économiques (économie de marché viable) et juridiques (reprise de l'acquis communautaire).",
    "L'adhésion exige ensuite l'unanimité du Conseil, l'approbation du Parlement européen et la ratification par tous les États membres.", "", "Conseil européen de Copenhague, 1993 ; TUE, art. 49", "hist");
  Q("pol", "Systèmes électoraux", 4, "Quel effet produit généralement un scrutin proportionnel par rapport à un scrutin majoritaire ?", "Une assemblée plus fidèle aux voix, mais des majorités plus difficiles à former", ["Toujours un seul parti majoritaire", "La disparition des petits partis", "Moins de partis représentés"],
    "La proportionnelle attribue les sièges en fonction des pourcentages de voix : elle représente mieux la diversité mais impose souvent des coalitions. Le scrutin majoritaire amplifie le parti arrivé en tête.",
    "La « loi de Duverger » associe le scrutin majoritaire à un tour au bipartisme.", "", "Maurice Duverger, Les partis politiques (1951)", "hist");

  // ---------- HISTOIRE ----------
  Q("hist", "Révolutions", 2, "De quel texte cet extrait est-il tiré ?", "La Déclaration des droits de l'homme et du citoyen", ["La Constitution de 1958", "La Déclaration universelle des droits de l'homme", "Le Code civil"],
    "Il s'agit de l'article 1 de la DDHC, adoptée par l'Assemblée constituante le 26 août 1789.",
    "La Déclaration universelle des droits de l'homme de 1948 commence par une formule proche : « Tous les êtres humains naissent libres et égaux en dignité et en droits. »", "Indice : « les distinctions sociales » vise la société d'ordres de l'Ancien Régime.", "DDHC, 1789", "hist", null,
    { type: "text", title: "Document historique (1789)", body: "« Article premier. Les hommes naissent et demeurent libres et égaux en droits. Les distinctions sociales ne peuvent être fondées que sur l'utilité commune. »" });
  Q("hist", "Guerres mondiales", 3, "Pourquoi l'assassinat d'un archiduc à Sarajevo a-t-il entraîné une guerre européenne en quelques semaines ?", "Le jeu des alliances a entraîné l'entrée en guerre successive des grandes puissances", ["Tous les pays européens étaient déjà en guerre", "L'archiduc était le chef de toutes les armées européennes", "Un traité imposait une guerre mondiale en cas d'attentat"],
    "L'Autriche-Hongrie attaque la Serbie, soutenue par la Russie ; l'Allemagne, alliée de Vienne, déclare la guerre à la Russie puis à la France ; l'invasion de la Belgique entraîne le Royaume-Uni.",
    "Rivalités coloniales, nationalismes et course aux armements avaient préparé le terrain.", "Mécanisme : enchaînement causal, pas cause unique.", "Britannica", "hist");
  Q("hist", "Histoire contemporaine", 4, "Pourquoi la crise de 1929, née aux États-Unis, s'est-elle propagée au reste du monde ?", "Rapatriement des capitaux américains, chute du commerce et protectionnisme", ["Parce que tous les pays utilisaient le dollar", "Parce que Wall Street contrôlait les banques centrales", "À cause d'une guerre mondiale"],
    "Les banques américaines rapatrient leurs prêts (notamment en Allemagne), le commerce mondial s'effondre et les pays relèvent leurs droits de douane (loi Smoot-Hawley en 1930), ce qui aggrave la contraction.",
    "Le commerce mondial a chuté d'environ deux tiers en valeur entre 1929 et 1934.", "Cette expérience a inspiré les règles d'après-guerre (Bretton Woods, GATT).", "Britannica ; Kindleberger, La Grande Crise mondiale", "hist");
  Q("hist", "Guerre froide", 3, "Pourquoi parle-t-on de guerre « froide » ?", "Les deux superpuissances ne se sont jamais affrontées directement, mais par crises et conflits interposés", ["Parce qu'elle s'est déroulée surtout en Sibérie", "Parce qu'elle a eu lieu en hiver", "Parce qu'aucun conflit armé n'a eu lieu dans le monde"],
    "La dissuasion nucléaire rendait un affrontement direct suicidaire. Les rivalités se sont exprimées par des guerres périphériques (Corée, Viêt Nam, Afghanistan), la course aux armements et à l'espace.",
    "L'expression est popularisée par le journaliste Walter Lippmann en 1947.", "", "Britannica", "hist");
  Q("hist", "Décolonisation", 4, "Quel facteur a fortement accéléré la décolonisation après 1945 ?", "L'affaiblissement des puissances coloniales et le soutien des États-Unis, de l'URSS et de l'ONU au droit des peuples à disposer d'eux-mêmes", ["La découverte de nouvelles colonies", "Un traité signé en 1919", "La fin de l'esclavage en 1848"],
    "Ruinées par la guerre, la France et le Royaume-Uni font face à des mouvements nationalistes renforcés, alors que les deux superpuissances et la Charte de l'ONU condamnent le colonialisme.",
    "La participation des soldats coloniaux aux deux guerres mondiales a aussi nourri les revendications.", "", "Britannica", "hist");

  // ---------- ÉCONOMIE ----------
  const inflDoc = { type: "chart", kind: "line", title: "Pays A : inflation et taux directeur", unit: "%", labels: ["An 1", "An 2", "An 3", "An 4", "An 5", "An 6"], series: [{ name: "Inflation", values: [2, 3, 8, 10, 6, 3] }, { name: "Taux directeur", values: [0.5, 0.5, 2, 4.5, 4.5, 3.5] }], note: "Données d'entraînement (fictives)." };
  Q("eco", "Banques centrales", 3, "D'après le graphique, comment la banque centrale du pays A a-t-elle réagi à la poussée d'inflation ?", "Elle a fortement relevé son taux directeur", ["Elle a baissé son taux directeur", "Elle n'a rien changé", "Elle a supprimé la monnaie"],
    "Le taux directeur passe de 0,5 % à 4,5 % entre les années 2 et 4, au moment où l'inflation grimpe à 10 %. L'inflation reflue ensuite.",
    "C'est le schéma observé en 2022-2023 dans la zone euro et aux États-Unis.", "Lire un graphique à deux courbes : comparer les dates des variations.", "Document d'entraînement", "sci", null, inflDoc);
  Q("eco", "Banques centrales", 4, "Par quel mécanisme une hausse des taux directeurs freine-t-elle l'inflation ?", "Le crédit devient plus cher, ce qui réduit la demande de consommation et d'investissement", ["Elle baisse directement les prix fixés par l'État", "Elle augmente la quantité de monnaie en circulation", "Elle oblige les entreprises à baisser leurs salaires"],
    "Les banques répercutent la hausse sur leurs prêts : ménages et entreprises empruntent moins, la demande ralentit et la pression sur les prix diminue. L'épargne devient aussi plus rémunératrice.",
    "Les effets sur l'inflation mettent en général 12 à 24 mois à se manifester pleinement.", "", "Banque de France ; BCE", "sci", null, inflDoc);
  Q("eco", "Concepts économiques", 3, "Un gel détruit une partie de la récolte de café du Brésil. Que se passe-t-il en général sur le marché mondial ?", "Le prix du café augmente, car l'offre baisse face à une demande stable", ["Le prix baisse", "Le prix ne change pas", "La demande de café double"],
    "L'offre diminue, la demande reste à peu près identique : l'équilibre se fait à un prix plus élevé. Le Brésil est le premier producteur mondial.",
    "C'est ce qui s'est produit après le gel de juillet 2021.", "Raisonnement : appliquer le modèle offre-demande.", "Notion de microéconomie", "sci");
  Q("eco", "Commerce et organisations", 3, "La monnaie d'un pays se déprécie fortement. Quel est l'effet le plus probable ?", "Ses exportations deviennent plus compétitives, ses importations plus chères", ["Ses importations deviennent moins chères", "Son inflation baisse automatiquement", "Ses exportations s'arrêtent"],
    "Les produits nationaux coûtent moins cher en devises étrangères, ce qui aide les exportateurs. À l'inverse, les produits importés (énergie, composants) coûtent plus cher, ce qui peut alimenter l'inflation.",
    "Certains pays ont volontairement dévalué leur monnaie pour relancer leurs exportations.", "", "Notion de macroéconomie", "sci");
  Q("eco", "Concepts économiques", 2, "Qu'est-ce qu'un déficit commercial ?", "Un pays importe davantage de biens et services qu'il n'en exporte", ["L'État dépense plus qu'il ne perçoit", "Une entreprise vend à perte", "La banque centrale perd de l'argent"],
    "La balance commerciale compare exportations et importations. Le déficit public, lui, concerne le budget de l'État : les deux notions sont souvent confondues.",
    "Les États-Unis ont un déficit commercial structurel depuis les années 1970.", "", "INSEE, définitions", "sci");
  Q("eco", "Concepts économiques", 4, "Quand la masse monétaire augmente beaucoup plus vite que la production, quel risque apparaît en priorité ?", "Une hausse générale des prix (inflation)", ["Une baisse durable des prix", "Une baisse du chômage garantie", "Une hausse automatique de la productivité"],
    "Selon la théorie quantitative de la monnaie, si la quantité de monnaie augmente sans hausse équivalente des biens disponibles, les prix montent. Les hyperinflations (Allemagne 1923, Zimbabwe 2008) en sont des cas extrêmes.",
    "D'autres causes existent : choc sur le prix de l'énergie, hausse des salaires non compensée par la productivité, dépréciation de la monnaie.", "Situation internationale : expliquer une forte inflation par plusieurs mécanismes.", "Milton Friedman ; Banque de France", "sci");
  Q("eco", "Commerce et organisations", 3, "Dans ce tableau, quel pays a le PIB par habitant le plus élevé ?", "Le pays C", ["Le pays A", "Le pays B", "Les trois sont égaux"],
    "PIB par habitant = PIB ÷ population. A : 2 000 ÷ 100 = 20 000 $ ; B : 900 ÷ 30 = 30 000 $ ; C : 400 ÷ 8 = 50 000 $. Le plus gros PIB (A) n'a pas le plus haut niveau de vie moyen.",
    "Le Luxembourg, petit pays, a l'un des PIB par habitant les plus élevés du monde.", "Compétence : calculer un ratio à partir d'un tableau.", "Document d'entraînement", "sci", null,
    { type: "table", title: "Trois pays fictifs", cols: ["Pays", "PIB (milliards $)", "Population (millions)"], rows: [["A", "2 000", "100"], ["B", "900", "30"], ["C", "400", "8"]], note: "Données d'entraînement (fictives)." });

  // ---------- SCIENCES ----------
  Q("sci", "Astronomie", 2, "Qu'est-ce qui explique l'existence des saisons sur Terre ?", "L'inclinaison de l'axe de rotation de la Terre (environ 23,4°)", ["La variation de la distance Terre-Soleil", "La rotation de la Lune", "L'activité solaire"],
    "Selon la période, un hémisphère reçoit les rayons du Soleil plus directement et plus longtemps. C'est pourquoi les saisons sont inversées entre hémisphères.",
    "La Terre est même au plus près du Soleil début janvier, en plein hiver boréal.", "Idée reçue fréquente : la distance n'explique pas les saisons.", "NASA", "sci");
  Q("sci", "Physique", 3, "Pourquoi le ciel est-il bleu en journée ?", "Les molécules de l'air diffusent davantage la lumière bleue que la rouge", ["Parce qu'il reflète la couleur des océans", "Parce que l'air est coloré en bleu", "Parce que le Soleil émet surtout du bleu"],
    "C'est la diffusion de Rayleigh : plus la longueur d'onde est courte, plus elle est diffusée. Au coucher du soleil, la lumière traverse plus d'atmosphère, le bleu est dispersé et il reste surtout du rouge et de l'orange.",
    "Sur Mars, les poussières donnent au contraire des couchers de soleil bleutés.", "", "NASA", "sci");
  Q("sci", "Biologie", 2, "Quelle est l'équation simplifiée de la photosynthèse ?", "Dioxyde de carbone + eau + lumière → glucose + dioxygène", ["Glucose + dioxygène → dioxyde de carbone + eau", "Azote + eau → protéines", "Dioxygène + lumière → dioxyde de carbone"],
    "Les plantes captent l'énergie lumineuse grâce à la chlorophylle pour fabriquer des sucres à partir de CO₂ et d'eau, en rejetant du dioxygène. La respiration fait l'inverse.",
    "Le phytoplancton marin produit environ la moitié de l'oxygène de la planète.", "", "Manuels de biologie", "sci");
  Q("sci", "Médecine", 3, "Comment un vaccin protège-t-il contre une maladie ?", "Il entraîne le système immunitaire à reconnaître l'agent infectieux, qui crée une mémoire immunitaire", ["Il tue directement tous les microbes présents dans le corps", "Il remplace les globules blancs", "Il agit comme un antibiotique"],
    "Le vaccin présente un antigène inoffensif (agent inactivé, fragment, ARN messager…). Le corps produit des anticorps et des cellules mémoires qui réagiront vite en cas d'infection réelle.",
    "L'immunité collective protège aussi ceux qui ne peuvent pas être vaccinés.", "", "Inserm ; OMS", "sci");
  Q("sci", "Physique", 3, "Pourquoi l'eau bout-elle à une température plus basse en haute montagne ?", "Parce que la pression atmosphérique y est plus faible", ["Parce qu'il y fait plus froid", "Parce que l'eau y est plus pure", "Parce que l'oxygène y est plus abondant"],
    "La température d'ébullition dépend de la pression : au sommet du mont Blanc (environ 4 800 m), l'eau bout vers 84 °C. La cuisson des pâtes y est plus longue.",
    "C'est le principe inverse de l'autocuiseur, qui augmente la pression pour cuire plus vite.", "", "Physique", "sci");
  Q("sci", "Astronomie", 3, "Qu'est-ce qui cause principalement les marées océaniques ?", "L'attraction gravitationnelle de la Lune (et dans une moindre mesure du Soleil)", ["Le vent", "La rotation de la Terre seule", "Les courants marins"],
    "La Lune attire différemment les côtés proche et éloigné de la Terre, ce qui crée deux renflements océaniques : d'où, en général, deux marées hautes par jour.",
    "Quand Soleil et Lune sont alignés (nouvelle et pleine lune), les marées sont plus fortes : ce sont les vives-eaux.", "", "SHOM ; NASA", "sci");
  Q("sci", "Chimie", 3, "Pourquoi la glace flotte-t-elle sur l'eau liquide ?", "La glace est moins dense que l'eau liquide", ["Elle contient de l'air piégé seulement", "Elle est plus chaude", "Elle est plus lourde mais plus large"],
    "En gelant, les molécules d'eau s'organisent en un réseau cristallin plus espacé : la glace occupe environ 9 % de volume en plus. C'est une exception parmi les substances courantes.",
    "Grâce à cela, les lacs gèlent par la surface, ce qui protège la vie aquatique en dessous.", "", "Chimie", "sci");

  // ---------- ENVIRONNEMENT ----------
  const co2 = { type: "chart", kind: "line", title: "Concentration de CO₂ dans l'atmosphère (Mauna Loa)", unit: "ppm", labels: ["1960", "1980", "2000", "2010", "2020", "2024"], series: [{ name: "CO₂", values: [317, 339, 370, 390, 414, 424] }], note: "Moyennes annuelles arrondies, NOAA." };
  Q("env", "Climat", 2, "D'après le graphique, comment évolue la concentration de CO₂ dans l'atmosphère depuis 1960 ?", "Elle augmente continûment et de plus en plus vite", ["Elle est stable", "Elle baisse depuis 2000", "Elle varie au hasard"],
    "Elle passe d'environ 317 ppm en 1960 à environ 424 ppm en 2024. La hausse est d'environ 0,8 ppm par an dans les années 1960, et de plus de 2 ppm par an aujourd'hui.",
    "Avant l'ère industrielle, la concentration était d'environ 280 ppm.", "Lire une courbe : la pente indique la vitesse de l'évolution.", "NOAA, Global Monitoring Laboratory", "contemp", "2024", co2);
  Q("env", "Climat", 3, "Par quel mécanisme les gaz à effet de serre réchauffent-ils la Terre ?", "Ils absorbent une partie du rayonnement infrarouge émis par la surface et le réémettent vers le sol", ["Ils détruisent la couche d'ozone, laissant passer plus de chaleur", "Ils reflètent la lumière du Soleil vers la Terre", "Ils produisent eux-mêmes de la chaleur"],
    "La surface chauffée par le Soleil émet des infrarouges. Le CO₂, le méthane ou la vapeur d'eau en absorbent une partie : plus il y en a, plus la chaleur est retenue.",
    "Sans effet de serre naturel, la température moyenne serait d'environ −18 °C au lieu de +15 °C.", "Idée reçue : le « trou » de la couche d'ozone est un problème distinct.", "GIEC, AR6", "sci");
  Q("env", "Océans", 4, "Pourquoi l'augmentation du CO₂ atmosphérique menace-t-elle les coraux et les coquillages ?", "L'océan absorbe du CO₂, devient plus acide et le calcaire se forme plus difficilement", ["Le CO₂ rend l'eau plus salée", "Le CO₂ bloque la lumière sous l'eau", "Le CO₂ fait baisser le niveau de la mer"],
    "En se dissolvant, le CO₂ forme de l'acide carbonique : le pH de surface a baissé d'environ 0,1 depuis l'ère préindustrielle (environ 30 % d'acidité en plus). Les organismes calcaires construisent plus difficilement leur squelette.",
    "L'océan a absorbé environ un quart du CO₂ émis par les activités humaines.", "", "GIEC ; NOAA", "sci");
  Q("env", "Biodiversité", 4, "Après la réintroduction des loups dans le parc de Yellowstone en 1995, la végétation des berges s'est en partie régénérée. Pourquoi ?", "Les loups ont réduit et déplacé les populations de cerfs qui broutaient les jeunes arbres", ["Les loups mangent des insectes nuisibles", "Les loups plantent des graines", "Le climat s'est refroidi au même moment"],
    "C'est une « cascade trophique » : un prédateur influence toute la chaîne alimentaire. On parle d'espèce clé de voûte.",
    "L'ampleur exacte de l'effet fait encore débat chez les scientifiques, d'autres facteurs ayant joué.", "Raisonnement : relier une cause à des effets indirects.", "National Park Service ; études écologiques", "sci");
  Q("env", "Énergies renouvelables", 3, "Quel est le principal défi technique d'une électricité fondée sur le solaire et l'éolien ?", "Leur production varie avec la météo : il faut du stockage, des réseaux et de la flexibilité", ["Elles émettent beaucoup de CO₂ en fonctionnement", "Elles ne fonctionnent pas en Europe", "Elles consomment de l'uranium"],
    "On parle d'énergies intermittentes ou variables. Batteries, stations de pompage, interconnexions et pilotage de la demande permettent d'équilibrer le réseau en permanence.",
    "Leur coût de production a fortement baissé : le solaire photovoltaïque a vu son coût diminuer d'environ 90 % entre 2010 et 2020.", "", "AIE ; RTE", "sci");
  const ice = { type: "chart", kind: "line", title: "Étendue minimale de la banquise arctique (septembre)", unit: "millions de km²", labels: ["1980", "1990", "2000", "2010", "2012", "2020", "2024"], series: [{ name: "Banquise", values: [7.7, 6.2, 6.3, 4.9, 3.4, 3.9, 4.3] }], note: "Valeurs arrondies, NSIDC." };
  Q("env", "Climat", 3, "D'après le graphique, quelle année présente le minimum le plus bas ?", "2012", ["1980", "2020", "2024"],
    "En septembre 2012, l'étendue minimale de la banquise est descendue à environ 3,4 millions de km², record de la série satellitaire.",
    "La tendance générale reste une baisse d'environ 12 à 13 % par décennie depuis 1979, malgré des variations d'une année à l'autre.", "Lire un graphique : distinguer la tendance de long terme des fluctuations annuelles.", "NSIDC (National Snow and Ice Data Center)", "contemp", "2024", ice);

  // ---------- CULTURES ----------
  Q("cult", "Langues", 2, "Pourquoi le français, l'espagnol, l'italien, le portugais et le roumain se ressemblent-ils ?", "Ils descendent tous du latin parlé dans l'Empire romain", ["Ils dérivent du grec ancien", "Ils ont été inventés ensemble au Moyen Âge", "Ils viennent de l'arabe"],
    "Ce sont les langues romanes, issues du latin vulgaire. Leurs différences s'expliquent par l'évolution locale et les influences (germaniques, arabes, slaves…).",
    "Le roumain est la langue romane la plus orientale, entourée de langues slaves et du hongrois.", "", "Britannica", "hist");
  Q("cult", "Religions", 3, "Quelle est la différence entre le monothéisme et le polythéisme ?", "Croyance en un dieu unique, contre croyance en plusieurs dieux", ["Religion d'un seul pays, contre religion mondiale", "Religion sans clergé, contre religion avec clergé", "Religion écrite, contre religion orale"],
    "Le judaïsme, le christianisme et l'islam sont monothéistes. Les religions grecque et romaine antiques étaient polythéistes ; l'hindouisme est souvent décrit ainsi, avec des nuances.",
    "Le bouddhisme n'est centré sur aucun dieu créateur.", "", "Britannica", "hist");
})(typeof window !== "undefined" ? window : globalThis);
