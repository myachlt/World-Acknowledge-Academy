/* World Knowledge Academy — Données politiques évolutives, organisations, fiches thématiques (couche DONNÉES)
 * Toute donnée de cette section est datée (asOf) et sourcée. L'interface affiche un avertissement
 * lorsque la date de vérification dépasse 12 mois (voir engine/freshness).
 */
(function (W) {
  // Dirigeants : état connu en juin 2026. Donnée ÉVOLUTIVE, à revérifier régulièrement.
  const LEADERS_AS_OF = "2026-06";
  const LEADERS_SOURCE = "Sites officiels des présidences et gouvernements (état connu en juin 2026)";
  // iso: [chef de l'État, chef du gouvernement (null si identique / non pertinent)]
  const LEADERS = {
    FR: ["Emmanuel Macron", "Sébastien Lecornu"],
    DE: ["Frank-Walter Steinmeier", "Friedrich Merz"],
    GB: ["Charles III", "Keir Starmer"],
    IT: ["Sergio Mattarella", "Giorgia Meloni"],
    ES: ["Felipe VI", "Pedro Sánchez"],
    BE: ["Philippe", "Bart De Wever"],
    PL: ["Karol Nawrocki", "Donald Tusk"],
    UA: ["Volodymyr Zelensky", "Ioulia Svyrydenko"],
    RU: ["Vladimir Poutine", "Mikhaïl Michoustine"],
    US: ["Donald Trump", null],
    CA: ["Charles III", "Mark Carney"],
    MX: ["Claudia Sheinbaum", null],
    BR: ["Luiz Inácio Lula da Silva", null],
    AR: ["Javier Milei", null],
    CN: ["Xi Jinping", "Li Qiang"],
    IN: ["Droupadi Murmu", "Narendra Modi"],
    JP: ["Naruhito", "Sanae Takaichi"],
    KR: ["Lee Jae-myung", null],
    TR: ["Recep Tayyip Erdoğan", null],
    SA: ["Salmane ben Abdelaziz", "Mohammed ben Salmane"],
    ZA: ["Cyril Ramaphosa", null],
    NG: ["Bola Tinubu", null],
    EG: ["Abdel Fattah al-Sissi", null],
    AU: ["Charles III", "Anthony Albanese"]
  };

  // Organisations et appartenance (codes ISO des pays présents dans le jeu de données).
  const ORGS = {
    ONU: {
      name: "Organisation des Nations unies (ONU)", short: "ONU", founded: 1945, hq: "New York",
      members: "193 États membres", asOf: "2026-06",
      summary: "Fondée le 24 octobre 1945 après l'entrée en vigueur de la Charte de San Francisco, l'ONU vise le maintien de la paix et de la sécurité internationales. Son Conseil de sécurité compte 15 membres, dont 5 permanents disposant d'un droit de veto : Chine, États-Unis, France, Royaume-Uni, Russie.",
      facts: ["Le Soudan du Sud (2011) est le dernier État admis.", "Le Saint-Siège et la Palestine sont États observateurs non membres.", "Six langues officielles : anglais, arabe, chinois, espagnol, français, russe."],
      source: "un.org"
    },
    OTAN: {
      name: "Organisation du traité de l'Atlantique Nord (OTAN)", short: "OTAN", founded: 1949, hq: "Bruxelles",
      members: "32 États membres", asOf: "2026-06",
      list: "US CA GB FR DE IT ES PT BE NL LU DK NO IS GR TR PL CZ SK HU RO BG SI HR AL ME MK EE LV LT FI SE",
      summary: "Alliance militaire créée par le traité de Washington (4 avril 1949). Son article 5 prévoit qu'une attaque contre un membre est une attaque contre tous ; il n'a été invoqué qu'une fois, après le 11 septembre 2001.",
      facts: ["La Finlande (2023) et la Suède (2024) sont les derniers membres admis.", "Le siège est à Bruxelles depuis 1967, après le retrait de la France du commandement intégré."],
      source: "nato.int"
    },
    UE: {
      name: "Union européenne (UE)", short: "UE", founded: 1993, hq: "Bruxelles (Commission, Conseil), Strasbourg (Parlement), Luxembourg (Cour de justice)",
      members: "27 États membres", asOf: "2026-06",
      list: "AT BE BG HR CY CZ DK EE FI FR DE GR HU IE IT LV LT LU MT NL PL PT RO SK SI ES SE",
      summary: "Issue des Communautés européennes (CECA 1951, CEE 1957), l'UE prend ce nom avec le traité de Maastricht (entré en vigueur en 1993). Ses principales institutions : Parlement européen (élu au suffrage universel direct), Conseil européen (chefs d'État et de gouvernement), Conseil de l'UE (ministres), Commission européenne, Cour de justice, Banque centrale européenne.",
      facts: ["Le Royaume-Uni l'a quittée le 31 janvier 2020.", "La Croatie (2013) est le dernier pays entré.", "Le Parlement européen compte 720 députés pour la législature 2024-2029."],
      source: "european-union.europa.eu"
    },
    EURO: {
      name: "Zone euro", short: "zone euro", founded: 1999, hq: "Francfort (BCE)",
      members: "21 États membres", asOf: "2026-06",
      list: "AT BE BG HR CY EE FI FR DE GR IE IT LV LT LU MT NL PT SK SI ES",
      summary: "L'euro est la monnaie scripturale depuis le 1ᵉʳ janvier 1999 et circule en pièces et billets depuis le 1ᵉʳ janvier 2002. La politique monétaire est conduite par la Banque centrale européenne, à Francfort.",
      facts: ["La Bulgarie est devenue le 21ᵉ membre le 1ᵉʳ janvier 2026.", "Monaco, le Vatican, Saint-Marin, Andorre, le Monténégro et le Kosovo utilisent l'euro sans être membres de la zone euro."],
      source: "ecb.europa.eu"
    },
    G20: {
      name: "Groupe des Vingt (G20)", short: "G20", founded: 1999, hq: "Pas de siège permanent (présidence tournante)",
      members: "19 pays + Union européenne + Union africaine", asOf: "2026-06",
      list: "AR AU BR CA CN FR DE IN ID IT JP KR MX RU SA ZA TR GB US",
      summary: "Créé en 1999 après la crise financière asiatique, le G20 réunit les principales économies mondiales. Il se réunit au niveau des chefs d'État depuis 2008.",
      facts: ["L'Union africaine en est devenue membre permanent en 2023.", "Ses membres représentent environ 85 % du PIB mondial."],
      source: "g20.org"
    },
    BRICS: {
      name: "BRICS", short: "BRICS", founded: 2009, hq: "Pas de siège permanent",
      members: "10 membres (statut de l'Arabie saoudite ambigu)", asOf: "2026-06",
      list: "BR RU IN CN ZA EG ET IR AE ID",
      summary: "Groupe né du sommet de 2009 (Brésil, Russie, Inde, Chine), rejoint par l'Afrique du Sud en 2010-2011. Il s'est élargi en 2024 à l'Égypte, l'Éthiopie, l'Iran et les Émirats arabes unis, puis à l'Indonésie en 2025.",
      facts: ["L'acronyme « BRIC » a été inventé en 2001 par l'économiste Jim O'Neill (Goldman Sachs).", "L'Arabie saoudite a été invitée en 2023 sans confirmer clairement son adhésion."],
      exclude: "SA",
      source: "Déclarations des sommets BRICS (Johannesburg 2023, Kazan 2024, Rio 2025)"
    },
    OPEP: {
      name: "Organisation des pays exportateurs de pétrole (OPEP)", short: "OPEP", founded: 1960, hq: "Vienne",
      members: "12 États membres", asOf: "2026-06",
      list: "DZ CG GA IR IQ KW LY NG SA AE VE",
      summary: "Fondée à Bagdad en 1960 par l'Arabie saoudite, l'Irak, l'Iran, le Koweït et le Venezuela, l'OPEP coordonne la politique pétrolière de ses membres. Elle s'appuie depuis 2016 sur l'alliance « OPEP+ » avec d'autres producteurs comme la Russie.",
      facts: ["L'Angola a quitté l'OPEP en janvier 2024.", "Le siège est à Vienne depuis 1965, bien que l'Autriche n'en soit pas membre."],
      source: "opec.org"
    },
    ASEAN: {
      name: "Association des nations de l'Asie du Sud-Est (ASEAN)", short: "ASEAN", founded: 1967, hq: "Jakarta",
      members: "11 États membres", asOf: "2026-06",
      list: "BN KH ID LA MY MM PH SG TH VN TL",
      summary: "Fondée en 1967 à Bangkok par l'Indonésie, la Malaisie, les Philippines, Singapour et la Thaïlande.",
      facts: ["Le Timor oriental est devenu le 11ᵉ membre en octobre 2025."],
      source: "asean.org"
    },
    UA: {
      name: "Union africaine (UA)", short: "UA", founded: 2002, hq: "Addis-Abeba",
      members: "55 États membres", asOf: "2026-06",
      summary: "Elle a succédé en 2002 à l'Organisation de l'unité africaine (OUA), créée en 1963. Plusieurs membres sont suspendus à la suite de coups d'État.",
      facts: ["Le Maroc, sorti de l'OUA en 1984, a réintégré l'UA en 2017."],
      source: "au.int"
    },
    OMC: {
      name: "Organisation mondiale du commerce (OMC)", short: "OMC", founded: 1995, hq: "Genève",
      members: "166 membres", asOf: "2026-06",
      summary: "Elle a succédé au GATT (1947) le 1ᵉʳ janvier 1995. Elle règle les différends commerciaux entre ses membres via son Organe de règlement des différends.",
      facts: ["La Chine y a adhéré en 2001, la Russie en 2012."],
      source: "wto.org"
    }
  };

  // Fiches thématiques : événements, concepts et personnalités (faits historiques, non évolutifs).
  const SHEETS = [
    { id: "ev-ww1", type: "Événement", title: "Première Guerre mondiale (1914-1918)", body: "Déclenchée après l'assassinat de l'archiduc François-Ferdinand à Sarajevo le 28 juin 1914, elle oppose la Triple-Entente (France, Royaume-Uni, Russie, rejoints par l'Italie en 1915 et les États-Unis en 1917) aux Empires centraux (Allemagne, Autriche-Hongrie, Empire ottoman, Bulgarie). L'armistice est signé le 11 novembre 1918 à Rethondes ; le traité de Versailles est signé le 28 juin 1919.", tags: ["Histoire", "Guerres mondiales"] },
    { id: "ev-ww2", type: "Événement", title: "Seconde Guerre mondiale (1939-1945)", body: "Elle commence avec l'invasion de la Pologne par l'Allemagne le 1ᵉʳ septembre 1939. En Europe, elle s'achève par la capitulation allemande (8 mai 1945) ; dans le Pacifique, par la capitulation du Japon (signée le 2 septembre 1945) après les bombardements atomiques d'Hiroshima et Nagasaki. Elle a causé entre 60 et 80 millions de morts.", tags: ["Histoire", "Guerres mondiales"] },
    { id: "ev-coldwar", type: "Période", title: "Guerre froide (1947-1991)", body: "Affrontement idéologique, politique et militaire indirect entre les États-Unis et l'URSS. Moments clés : blocus de Berlin (1948-1949), guerre de Corée (1950-1953), crise des missiles de Cuba (1962), guerre du Viêt Nam, chute du mur de Berlin (9 novembre 1989), dissolution de l'URSS (26 décembre 1991).", tags: ["Histoire", "Guerre froide"] },
    { id: "ev-revfr", type: "Événement", title: "Révolution française (1789-1799)", body: "Ouverte par la réunion des États généraux en mai 1789 et la prise de la Bastille le 14 juillet, elle abolit les privilèges (nuit du 4 août), proclame la Déclaration des droits de l'homme et du citoyen (26 août 1789), puis la République (septembre 1792). Elle se clôt avec le coup d'État du 18 Brumaire de Napoléon Bonaparte (1799).", tags: ["Histoire", "Révolutions"] },
    { id: "ev-decol", type: "Processus", title: "Décolonisation (1945-1975)", body: "Après 1945, la plupart des colonies d'Asie et d'Afrique accèdent à l'indépendance : Inde et Pakistan (1947), Indonésie (1949), Ghana (1957), « année de l'Afrique » en 1960 avec 17 indépendances, Algérie (1962), colonies portugaises (1974-1975). La conférence de Bandung (1955) marque l'émergence du tiers-monde.", tags: ["Histoire", "Décolonisation"] },
    { id: "co-pib", type: "Concept", title: "PIB et PIB par habitant", body: "Le produit intérieur brut mesure la valeur de la production de biens et services d'un pays sur une période. Le PIB par habitant divise ce total par la population. On le compare souvent en parité de pouvoir d'achat (PPA), qui corrige les écarts de prix entre pays. Ces chiffres sont des données évolutives publiées notamment par le FMI et la Banque mondiale.", tags: ["Économie"] },
    { id: "co-inflation", type: "Concept", title: "Inflation et banques centrales", body: "L'inflation est la hausse générale et durable des prix. Les banques centrales (BCE, Réserve fédérale américaine, Banque d'Angleterre, Banque du Japon…) la combattent principalement en relevant leurs taux directeurs. La BCE vise une inflation de 2 % à moyen terme.", tags: ["Économie"] },
    { id: "co-ipcc", type: "Concept", title: "Changement climatique et GIEC", body: "Le GIEC (Groupe d'experts intergouvernemental sur l'évolution du climat), créé en 1988, synthétise l'état des connaissances scientifiques. L'Accord de Paris (2015) vise à contenir le réchauffement nettement sous 2 °C par rapport à l'ère préindustrielle, en poursuivant l'effort pour le limiter à 1,5 °C.", tags: ["Environnement"] },
    { id: "pe-mandela", type: "Personnalité", title: "Nelson Mandela (1918-2013)", body: "Figure de la lutte contre l'apartheid, emprisonné 27 ans (dont 18 à Robben Island), libéré en 1990. Prix Nobel de la paix 1993 avec Frederik de Klerk, il devient en 1994 le premier président noir de l'Afrique du Sud, élu lors des premières élections multiraciales.", tags: ["Histoire", "Personnalités"] },
    { id: "pe-curie", type: "Personnalité", title: "Marie Curie (1867-1934)", body: "Physicienne et chimiste d'origine polonaise, naturalisée française. Seule personne à avoir reçu deux prix Nobel dans deux disciplines scientifiques différentes : physique (1903) et chimie (1911). Elle a découvert le polonium et le radium avec Pierre Curie.", tags: ["Sciences", "Personnalités"] }
  ];

  W.WKA = W.WKA || {};
  W.WKA.data = W.WKA.data || {};
  Object.assign(W.WKA.data, { LEADERS, LEADERS_AS_OF, LEADERS_SOURCE, ORGS, SHEETS });
})(typeof window !== "undefined" ? window : globalThis);
