/* World Knowledge Academy — Pages « Apprendre » : accueil, s'entraîner, catégories, situations, documents, révisions */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, E, U, LG, F, BY, esc, pct, icon, flag, toast, save, go, fmtTime } = UI;
  const S = () => store.s;

  function overallRating() { const r = E.KNOW.map(c => S().ratings[c]).filter(Boolean); return r.length ? r.reduce((a, b) => a + b, 0) / r.length : 0; }
  function catBars(ids) {
    return (ids || E.CATEGORIES.map(c => c.id)).map(id => { const c = E.CAT[id], x = S().stats.byCat[id] || { a: 0, c: 0 };
      return `<div class="hbar cat-${id}"><span class="row nowrap" style="gap:6px"><span class="dot catmark"></span>${esc(c.short)}</span><div class="bar"><i style="width:${x.a ? pct(x.c, x.a) : 0}%"></i></div><span class="n">${x.a ? pct(x.c, x.a) + " %" : "—"}</span></div>`; }).join("");
  }
  UI.catBars = catBars; UI.overallRating = overallRating;
  function sessionPoints(n) { return S().sessions.filter(s => s.n).slice(-n).map(s => ({ v: Math.round(s.score20 * 5), c: s.correct, n: s.n, label: new Date(s.start).toLocaleDateString("fr-FR", { day: "numeric", month: "short" }) })); }
  UI.sessionPoints = sessionPoints;

  // ---------- ACCUEIL ----------
  function wotdCard() {
    const w = F.wotd(); const inDict = F.Dict.exists(S(), { fr: w.fr, en: w.en, es: w.es });
    return `<div class="card widget"><span class="wtitle">${icon("note")} Mot du jour</span>
      <div class="row between"><h2 style="font-size:1.5rem">${esc(w.fr)}</h2><span class="chip">${esc(w.nat)}</span></div>
      <p>${esc(w.def)}</p>
      <div class="trio"><div><span>Français</span><b>${esc(w.fr)}</b></div><div><span>🇬🇧 Anglais</span><b>${esc(w.en || "—")}</b>${w.ipa ? `<small class="mono muted">${esc(w.ipa)}</small>` : ""}${w.en ? UI.sayBtn(w.en, "en-GB", "") : ""}</div><div><span>🇪🇸 Espagnol</span><b>${esc(w.es || "—")}</b>${w.es ? UI.sayBtn(w.es, "es-ES", "") : ""}</div></div>
      <p class="small"><i>« ${esc(w.exFr)} »</i></p><p class="xs muted"><b>Origine :</b> ${esc(w.origin)}</p>
      <div class="row">${inDict ? `<span class="chip pill-sage">${icon("check")} Dans votre dictionnaire</span>` : `<button class="btn sm" data-act="wotdadd">${icon("plus")} Ajouter au dictionnaire</button>`}${UI.sayBtn(w.fr, "fr-FR", "Prononcer en français")}</div></div>`;
  }
  function dykCard() {
    const d = F.dyk(); const open = app.ui.dykOpen;
    const b = d.bank;
    return `<div class="card widget cat-${d.cat}"><span class="wtitle">${icon("bulb")} Le saviez-vous ?</span>
      <span class="chip" style="justify-self:start"><span class="dot catmark"></span>${esc(E.CAT[d.cat].short)} · ${esc(d.sub)}</span>
      <p style="font-size:1.02rem">${esc(d.text)}</p>
      ${open ? `<div class="card flat stack">${b ? `<p><b>${esc(b.q)}</b></p><p>${esc(b.ex)}</p>${b.ctx ? `<p class="muted small">${esc(b.ctx)}</p>` : ""}` : d.iso ? `<p>${esc((D.PROFILES[d.iso] || {}).hist || "")}</p><a class="btn sm" href="#pays-${d.iso.toLowerCase()}">${flag(d.iso)} Ouvrir la fiche ${esc(BY[d.iso].name)}</a>` : `<p class="muted">Explorez la chronologie de cette période avec un quiz dédié.</p>`}<span class="xs muted">Source : ${esc(d.src || "")}</span></div>` : ""}
      <div class="row"><button class="btn sm" data-act="dykopen">${open ? "Refermer" : "Approfondir"}</button><button class="btn sm primary" data-act="dykquiz">${icon("target")} Transformer en question</button></div></div>`;
  }
  function dailyCard() {
    const today = U.today(), done = S().daily[today];
    return `<div class="card widget"><span class="wtitle">${icon("cal")} Défi quotidien</span>
      <h2>${done ? `Relevé : ${done.score}/${done.n}` : "25 questions, 5 univers"}</h2>
      <div class="stack" style="gap:6px">${F.DAILY_PLAN.map(p => `<div class="row between small"><span class="row nowrap" style="gap:8px"><span class="cat-${p.cats.length > 1 ? "cult" : p.cats[0]}"><span class="dot catmark"></span></span>${p.name}</span><span class="mono muted">5 questions</span></div>`).join("")}</div>
      <p class="xs muted">Le même défi pour toute la journée, renouvelé chaque jour à minuit. Niveau calé sur votre profil.</p>
      <button class="btn ${done ? "" : "sun"}" data-act="daily">${done ? "Rejouer le défi du jour" : "Relever le défi"}</button></div>`;
  }
  function gapsCard() {
    const g = F.gaps(S());
    return `<div class="card widget"><span class="wtitle">${icon("target")} Mes lacunes</span>
      ${g.weak.length ? `<p class="small muted">Détectées automatiquement à partir de vos réponses (moins de 65 % de réussite sur au moins 4 questions).</p><div class="list">${g.weak.slice(0, 4).map((w, i) => `<div class="row between cat-${w.cat}"><span style="min-width:0;flex:1"><span class="dot catmark"></span> <b>${esc(w.sub)}</b><br><span class="xs muted">${esc(E.CAT[w.cat].short)} · ${pct(w.c, w.a)} % sur ${w.a} questions</span></span><button class="btn sm" data-gap="${i}">Cibler</button></div>`).join("")}</div>`
        : `<p class="small">${S().stats.answered < 20 ? "Répondez à une vingtaine de questions : vos points faibles apparaîtront ici, avec une session ciblée pour chacun." : "Aucune lacune nette pour l'instant : bravo. Continuez à varier les domaines."}</p>`}
      ${g.untouched.length ? `<p class="xs muted">Jamais travaillé : ${g.untouched.map(id => `<button class="chip" data-catquiz="${id}" style="margin:2px">${esc(E.CAT[id].short)}</button>`).join("")}</p>` : ""}</div>`;
  }
  UI.views.accueil = function () {
    const s = S(), St = s.stats, name = s.profile.name;
    const today = s.days[U.today()] || 0, goal = s.profile.dailyGoal, streak = E.dayStreak(s);
    const due = E.dueMistakes(store).filter(m => m.isDue).length, ddue = F.Dict.due(s).length;
    const paths = F.continentPaths(s); const disc = paths.reduce((a, p) => a + p.discovered, 0), mast = paths.reduce((a, p) => a + p.mastered, 0);
    const earned = E.BADGES.filter(b => s.badges[b.id]).sort((a, b) => s.badges[b.id] - s.badges[a.id]).slice(0, 4);
    const lv = k => s.lang[k].level ? LG.lvlName(s.lang[k].level) : "À évaluer";
    root.innerHTML = `<div class="wrap">
      <div class="card hero"><div class="row between" style="align-items:flex-start;gap:18px">
        <div class="stack" style="gap:8px;max-width:560px">
          <span class="eyebrow">${new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</span>
          <h1>${name ? "Bonjour " + esc(name) + "." : "Bienvenue."}</h1>
          <p class="muted">${St.answered ? `Niveau estimé en culture générale : <b>${E.levelLabel(overallRating() || 2)}</b>. ${streak > 1 ? `Série de ${streak} jours en cours.` : "Une session par jour suffit pour progresser."}` : "Culture générale, anglais, espagnol et vie pratique : le niveau s'adapte à vos réponses dès la première session."}</p>
          <div class="row" style="margin-top:6px"><button class="btn sun lg" data-act="quick">${icon("bolt")} Quiz du jour · 10 questions</button>
          ${due ? `<button class="btn lg" data-act="review">${icon("redo")} Réviser (${due})</button>` : ""}${ddue ? `<a class="btn lg" href="#dictionnaire">${icon("note")} ${ddue} mot${ddue > 1 ? "s" : ""} à revoir</a>` : ""}</div>
        </div>
        <div class="row" style="gap:12px"><div class="ring" style="--p:${Math.min(100, pct(today, goal))}"><div>${today}/${goal}</div></div>
          <div class="stack" style="gap:0"><span class="eyebrow">Objectif du jour</span><b>${today >= goal ? "Atteint" : (goal - today) + " restantes"}</b><span class="muted small">${streak} jour${streak > 1 ? "s" : ""} d'affilée</span></div></div>
      </div></div>
      <div class="grid g2">${dailyCard()}${wotdCard()}</div>
      <div class="grid g2">${dykCard()}${gapsCard()}</div>
      <div class="grid g3">
        <a class="card link cat-en" href="#langues"><span class="wtitle">${icon("lang")} Langues</span><div class="row"><span class="emo" style="font-size:1.6rem">🇬🇧</span><b>Anglais</b><span class="chip pill-sage" style="margin-left:auto">${lv("en")}</span></div><div class="row"><span class="emo" style="font-size:1.6rem">🇪🇸</span><b>Espagnol</b><span class="chip pill-sage" style="margin-left:auto">${lv("es")}</span></div><span class="xs muted">Test de niveau, 22 types d'exercices, examens blancs, prononciation.</span></a>
        <a class="card link" href="#monde"><span class="wtitle">${icon("map")} Explorer le monde</span><b style="font-family:var(--f-display);font-size:1.4rem">${disc} / ${D.countries.length} pays découverts</b><div class="bar"><i style="width:${pct(disc, D.countries.length)}%;background:var(--sage)"></i></div><span class="small muted">${mast} maîtrisé${mast > 1 ? "s" : ""} · carte interactive, parcours par continent, comparateur.</span></a>
        <a class="card link" href="#dictionnaire"><span class="wtitle">${icon("note")} Mon carnet</span><b style="font-family:var(--f-display);font-size:1.4rem">${s.dict.length} mot${s.dict.length > 1 ? "s" : ""} · ${s.gloss.length} notion${s.gloss.length > 1 ? "s" : ""}</b><span class="small muted">${ddue} mot${ddue > 1 ? "s" : ""} à réviser aujourd'hui · ${s.dict.filter(w => (w.srs || {}).box >= 5).length} maîtrisé${s.dict.filter(w => (w.srs || {}).box >= 5).length > 1 ? "s" : ""}.</span></a>
      </div>
      <div class="grid g2">
        <div class="card stack"><div class="row between"><h2>Progression par domaine</h2><a class="chip" href="#stats">Détails</a></div>${catBars()}</div>
        <div class="card stack"><div class="row between"><h2>Évolution</h2><span class="chip">${St.bestStreak} bonnes réponses d'affilée au mieux</span></div>${UI.lineChart(sessionPoints(20))}</div>
      </div>
      ${earned.length ? `<div class="card stack"><div class="row between"><h2>Derniers badges</h2><a class="chip" href="#profil">Tous les badges</a></div><div class="badges">${earned.map(b => UI.badgeHTML(b, true)).join("")}</div></div>` : ""}
    </div>`;
  };
  UI.on("quick", () => UI.startQuiz({ mode: "dix", cats: E.KNOW, level: "adaptive", count: 10 }));
  UI.on("daily", () => UI.startQuiz(F.dailyConfig()));
  UI.on("review", () => { app.result = null; startReview(); });
  UI.on("wotdadd", () => { const w = F.wotd(); F.Dict.add(S(), { fr: w.fr, en: w.en, es: w.es, cat: w.theme || "Mot du jour", nat: w.nat, ex: w.exFr }); save(); toast(`<b>${esc(w.fr)}</b> ajouté au dictionnaire.`); UI.render(); });
  UI.on("dykopen", () => { app.ui.dykOpen = !app.ui.dykOpen; UI.views.accueil(); });
  UI.on("dykquiz", () => {
    const d = F.dyk();
    if (d.bank) { const q = E.bankToQuestion(d.bank, U.rng(Date.now())); UI.startQuiz({ mode: "dyk", fixed: [q], title: "Le saviez-vous · en question" }); }
    else if (d.iso) UI.startQuiz({ mode: "monde", iso: d.iso, cats: ["geo", "pol", "eco", "cult"], count: 5, title: "Le saviez-vous · " + BY[d.iso].name });
    else UI.startQuiz({ mode: "categorie", cats: [d.cat], sub: d.cat === "hist" ? "Chronologie" : undefined, count: 5, title: "Le saviez-vous · " + E.CAT[d.cat].short });
  });
  UI.onData("gap", v => { const g = F.gaps(S()).weak[+v]; if (g) UI.startQuiz(Object.assign({ mode: "lacune" }, g.cfg)); });
  function startReview(cats) {
    if (!Object.keys(S().mistakes).length) { toast("Aucune erreur à réviser pour l'instant. Elles s'ajoutent ici automatiquement."); return; }
    UI.startQuiz({ mode: "revision", count: 20, cats });
  }
  UI.startReview = startReview;

  // ---------- S'ENTRAÎNER ----------
  const MODES = [
    ["libre", "Mode libre", "sliders", "Choisissez domaines, niveau, nombre de questions et chronomètre."],
    ["dix", "10 questions", "ten", "Le rituel quotidien, au niveau adaptatif."],
    ["defi", "Défi quotidien", "cal", "25 questions renouvelées chaque jour : culture, géo, anglais, espagnol, pratique."],
    ["aleatoire", "Aléatoire", "shuffle", "Tous les domaines et tous les niveaux mélangés."],
    ["monde", "Mode Monde", "globe", "Continent, pays, puis thème : un parcours par pays sur la carte."],
    ["marathon", "Marathon", "infinity", "Sans limite. Trois erreurs et c'est terminé."],
    ["expert", "Expert", "star", "Uniquement les niveaux les plus difficiles."],
    ["revision", "Révision", "redo", "Vos erreurs passées, en répétition espacée."],
    ["examen", "Examen", "exam", "Temps limité, aucune correction avant la fin, note sur 20."],
    ["situations", "Situations réelles", "compass", "Fiche de paie, bail, crédit, hôtel à Londres…"],
    ["documents", "Documents", "doc", "Graphiques, tableaux, cartes, extraits de textes à analyser."],
    ["langues", "Langues", "lang", "Anglais et espagnol, du niveau A1 au C2."]
  ];
  const cfgDraft = { cats: ["mix"], level: "adaptive", count: 10, timer: 0, examCount: 20, examMin: 10 };
  UI.views.entrainer = function () {
    const m = app.ui.cfgMode;
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">S'entraîner</span><h1>Choisissez votre façon d'apprendre</h1></div>
      <div class="grid g3">${MODES.map(([id, n, ic, d]) => `<button class="modecard ${m === id ? "sel" : ""}" data-mode="${id}"><span class="ic">${icon(ic)}</span><h3>${n}</h3><p>${d}</p></button>`).join("")}</div>
      ${m === "libre" || m === "examen" ? configPanel(m) : ""}</div>`;
  };
  function configPanel(m) {
    const c = cfgDraft;
    const catChips = [["mix", "Culture générale mixte"]].concat(E.CATEGORIES.map(x => [x.id, (x.lang ? (x.id === "en" ? "🇬🇧 " : "🇪🇸 ") : "") + x.name]))
      .map(([id, n]) => `<button class="chip ${c.cats.includes(id) ? "sel" : ""}" data-cfgcat="${id}">${esc(n)}</button>`).join("");
    const lv = [["adaptive", "Adaptatif"]].concat(E.LEVELS.map((l, i) => [i + 1, (i + 1) + ". " + l]));
    return `<div class="card stack" style="gap:16px" id="cfgpanel"><h2>${m === "libre" ? "Mode libre" : "Mode examen"}</h2>
      <div class="stack"><span class="eyebrow">Domaines</span><div class="row" style="gap:6px">${catChips}</div></div>
      <div class="stack"><span class="eyebrow">Difficulté</span><div class="seg">${lv.map(([v, l]) => `<button data-cfglevel="${v}" class="${String(c.level) === String(v) ? "sel" : ""}">${l}</button>`).join("")}</div><span class="xs muted">Pour les langues, les niveaux 1 à 5 correspondent à A1 → C1 ; l'adaptatif utilise votre niveau CECRL.</span></div>
      ${m === "libre" ? `<div class="row" style="gap:24px;align-items:flex-start">
        <div class="stack"><span class="eyebrow">Nombre de questions</span><div class="seg">${[5, 10, 20, 30, 50].map(n => `<button data-cfgcount="${n}" class="${c.count === n ? "sel" : ""}">${n}</button>`).join("")}</div></div>
        <div class="stack"><span class="eyebrow">Chronomètre par question</span><div class="seg">${[[0, "Sans"], [15, "15 s"], [30, "30 s"], [60, "60 s"]].map(([n, l]) => `<button data-cfgtimer="${n}" class="${c.timer === n ? "sel" : ""}">${l}</button>`).join("")}</div></div></div>`
      : `<div class="row" style="gap:24px;align-items:flex-start">
        <div class="stack"><span class="eyebrow">Questions</span><div class="seg">${[10, 20, 40].map(n => `<button data-cfgecount="${n}" class="${c.examCount === n ? "sel" : ""}">${n}</button>`).join("")}</div></div>
        <div class="stack"><span class="eyebrow">Durée totale</span><div class="seg">${[5, 10, 20].map(n => `<button data-cfgemin="${n}" class="${c.examMin === n ? "sel" : ""}">${n} min</button>`).join("")}</div></div></div>
        <p class="muted small">Pas de correction pendant l'épreuve. Les questions non traitées à la fin du temps comptent comme fausses.</p>`}
      <div><button class="btn primary lg" data-act="startcfg">Commencer</button></div></div>`;
  }
  const cfgCats = () => cfgDraft.cats.includes("mix") || !cfgDraft.cats.length ? E.KNOW : cfgDraft.cats.slice();
  const rerenderTrain = () => { UI.views.entrainer(); };
  UI.onData("mode", id => {
    if (id === "libre" || id === "examen") { app.ui.cfgMode = id; rerenderTrain(); document.getElementById("cfgpanel").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    if (["monde", "situations", "documents", "langues"].includes(id)) return go(id);
    if (id === "defi") return UI.startQuiz(F.dailyConfig());
    if (id === "dix") return UI.startQuiz({ mode: "dix", cats: E.KNOW, level: "adaptive", count: 10 });
    if (id === "aleatoire") return UI.startQuiz({ mode: "aleatoire", cats: E.KNOW.concat(["en", "es"]), level: "adaptive", count: 15, mcqOnly: true });
    if (id === "marathon") return UI.startQuiz({ mode: "marathon", cats: E.KNOW, level: "adaptive", count: 0, lives: 3 });
    if (id === "expert") return UI.startQuiz({ mode: "expert", cats: E.KNOW, level: 5, count: 10 });
    if (id === "revision") return startReview();
  });
  UI.onData("cfgcat", id => { if (id === "mix") cfgDraft.cats = ["mix"]; else { cfgDraft.cats = cfgDraft.cats.filter(x => x !== "mix"); cfgDraft.cats = cfgDraft.cats.includes(id) ? cfgDraft.cats.filter(x => x !== id) : cfgDraft.cats.concat(id); if (!cfgDraft.cats.length) cfgDraft.cats = ["mix"]; } rerenderTrain(); });
  UI.onData("cfglevel", v => { cfgDraft.level = v === "adaptive" ? "adaptive" : +v; rerenderTrain(); });
  UI.onData("cfgcount", v => { cfgDraft.count = +v; rerenderTrain(); });
  UI.onData("cfgtimer", v => { cfgDraft.timer = +v; rerenderTrain(); });
  UI.onData("cfgecount", v => { cfgDraft.examCount = +v; rerenderTrain(); });
  UI.onData("cfgemin", v => { cfgDraft.examMin = +v; rerenderTrain(); });
  UI.on("startcfg", () => {
    const m = app.ui.cfgMode;
    if (m === "libre") UI.startQuiz({ mode: "libre", cats: cfgCats(), level: cfgDraft.level, count: cfgDraft.count, perQuestion: cfgDraft.timer });
    else UI.startQuiz({ mode: "examen", cats: cfgCats(), level: cfgDraft.level, count: cfgDraft.examCount, examSeconds: cfgDraft.examMin * 60, mcqOnly: true });
  });

  // ---------- CATÉGORIES ----------
  function availableBySub() {
    const out = {};
    E.BANK.forEach(b => { const k = b.cat + "|" + b.sub; out[k] = (out[k] || 0) + 1; });
    app.volume.gens.forEach(g => { const k = g.cat + "|" + g.sub; out[k] = (out[k] || 0) + (g.exact ? g.n : Math.min(g.n, 99999)); });
    return out;
  }
  UI.availableBySub = availableBySub;
  const CAT_ICON = { geo: "🗺️", pol: "🏛️", hist: "📜", eco: "📈", sci: "🔬", cult: "🎭", env: "🌿", prat: "🧭", en: "🇬🇧", es: "🇪🇸" };
  UI.CAT_ICON = CAT_ICON;
  UI.views.categories = function () {
    const av = availableBySub(), St = S().stats;
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Catégories</span><h1>Huit univers de culture générale, deux langues</h1>
      <p>Touchez une sous-catégorie pour 10 questions ciblées au niveau adaptatif. Les chiffres indiquent le nombre réel de questions disponibles.</p></div>
      <div class="card hero"><div class="row between"><div class="stack" style="gap:4px"><h2>Culture générale mixte</h2><p class="muted">Tous les domaines mélangés (hors langues).</p></div><button class="btn sun" data-catquiz="mix">Lancer</button></div></div>
      <div class="grid g2">${E.CATEGORIES.map(c => {
        const x = St.byCat[c.id] || { a: 0, c: 0 };
        const tot = c.subs.reduce((s, sub) => s + (av[c.id + "|" + sub] || 0), 0);
        if (c.lang) return `<a class="card link catcard cat-${c.id}" href="#langue-${c.id}"><div class="row"><span class="ic-round">${CAT_ICON[c.id]}</span><div class="stack" style="gap:2px"><h2>${esc(c.name)}</h2><span class="small muted">Niveau ${S().lang[c.id].level ? LG.lvlName(S().lang[c.id].level) : "à évaluer"} · ${c.subs.length} types d'exercices · examens blancs</span></div></div><span class="xs muted mono">${tot.toLocaleString("fr-FR")} exercices disponibles</span></a>`;
        return `<div class="card stack catcard cat-${c.id}"><div class="row between"><div class="row nowrap"><span class="ic-round">${CAT_ICON[c.id]}</span><h2>${esc(c.name)}</h2></div><button class="btn" data-catquiz="${c.id}">Lancer</button></div>
          <div class="row small" style="gap:12px"><span class="muted">${x.a ? pct(x.c, x.a) + " % de réussite sur " + x.a : "Pas encore commencé"}</span><span class="muted">· niveau ${E.levelLabel(E.ratingOf(store, c.id)).toLowerCase()}</span></div>
          <div class="bar"><i style="width:${x.a ? pct(x.c, x.a) : 0}%"></i></div>
          <div class="row" style="gap:6px">${c.subs.map(sub => { const n = av[c.id + "|" + sub] || 0; const y = St.bySub[c.id + "|" + sub]; return `<button class="chip" data-subquiz="${c.id}|${esc(sub)}" ${n ? "" : "disabled style='opacity:.45'"} title="${n.toLocaleString("fr-FR")} questions disponibles">${esc(sub)}${y ? ` · ${pct(y.c, y.a)} %` : ""}</button>`; }).join("")}</div>
          <span class="muted mono xs">${tot.toLocaleString("fr-FR")} questions disponibles${c.id === "prat" ? " · droit français, état juin 2026" : ""}</span></div>`;
      }).join("")}</div></div>`;
  };
  UI.onData("catquiz", v => UI.startQuiz({ mode: "categorie", cats: v === "mix" ? E.KNOW : [v], level: "adaptive", count: 10 }));
  UI.onData("subquiz", v => { const [cat, sub] = v.split("|"); UI.startQuiz({ mode: "categorie", cats: [cat], sub, level: "adaptive", count: 10, title: sub }); });

  // ---------- SITUATIONS ----------
  UI.views.situations = function () {
    const done = S().situations;
    const groups = [["prat", "Vie pratique"], ["eco", "Économie"], ["pol", "Politique"], ["en", "En anglais"], ["es", "En espagnol"]];
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Apprendre par situations</span><h1>Des cas concrets, pas à pas</h1>
      <p>Chaque situation part d'un document réel ou réaliste (fiche de paie, annonce, graphique, dialogue) et se résout en plusieurs étapes, avec une explication à chaque fois.</p></div>
      ${groups.map(([d, name]) => { const list = D.SITUATIONS.filter(s => s.domain === d); if (!list.length) return "";
        return `<div class="stack"><h2>${name}</h2><div class="grid g3">${list.map(s => { const r = done[s.id];
          return `<button class="modecard cat-${s.domain}" data-situ="${s.id}" style="border-top:4px solid var(--cat)"><div class="row between"><span class="chip">${esc(s.sub)}</span>${r ? `<span class="chip pill-good">${r.score}/${r.n}</span>` : `<span class="chip">${s.steps.length} étapes</span>`}</div>
            <h3>${esc(s.title)}</h3><p>${esc(s.context.slice(0, 120))}${s.context.length > 120 ? "…" : ""}</p><span class="xs muted">${s.doc ? "Document : " + { table: "tableau", text: "extrait", chart: "graphique", dialogue: "dialogue audio" }[s.doc.type] : "Mise en situation"}${s.asOf ? " · état " + U.asOfLabel(s.asOf) : ""}</span></button>`; }).join("")}</div></div>`; }).join("")}
      <p class="notice info">Idées pour la suite : déclarer ses impôts, ouvrir un compte à l'étranger, louer une voiture à Madrid, répondre à un entretien d'embauche en anglais, lire un contrat de travail. Chaque situation se rédige comme une fiche de données (voir README).</p></div>`;
  };
  UI.onData("situ", id => { const s = D.SITUATIONS.find(x => x.id === id); UI.startQuiz({ mode: "situation", situation: id, fixed: F.situationQuestions(s), title: s.title }); });

  // ---------- DOCUMENTS ----------
  UI.views.documents = function () {
    const ds = F.docStats(); const ex = E.BANK.filter(b => b.doc);
    const sample = ex[(F.dayIndex() * 3) % ex.length];
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Apprendre avec des documents</span><h1>Lire, comparer, raisonner</h1>
      <p>Des questions qui obligent à exploiter un support : tableau statistique, graphique économique, carte, extrait juridique ou historique. Certaines sont générées à partir des données (PIB, population, carte) et ne se répètent donc pas.</p></div>
      <div class="grid g3">${[["Tous les documents", E.KNOW, "doc"], ["Économie et statistiques", ["eco"], "chart"], ["Cartes", ["geo"], "map"], ["Histoire et politique", ["hist", "pol"], "book"], ["Sciences et environnement", ["sci", "env"], "bulb"], ["Droit et vie pratique", ["prat"], "scale"]]
        .map(([n, cats, ic]) => `<button class="modecard" data-docs="${cats.join(",")}"><span class="ic">${icon(ic)}</span><h3>${n}</h3><p>${cats.length > 3 ? "Mélange de tous les supports" : "10 questions sur documents"}</p></button>`).join("")}</div>
      <div class="card stack"><h2>Exemple de document du jour</h2>${UI.docHTML(sample.doc)}<p><b>${esc(sample.q)}</b></p><button class="btn" data-act="docsample">Répondre à cette question</button></div>
      <p class="xs muted">${ds.bank} documents rédigés + générateurs : ${ds.gens.join(", ")}. Types : ${ds.types.join(", ")}. À enrichir : illustrations scientifiques et articles de presse (droits de reproduction à vérifier, voir README).</p></div>`;
  };
  UI.onData("docs", v => UI.startQuiz({ mode: "documents", cats: v.split(","), docOnly: true, count: 10, level: "adaptive", title: "Documents" }));
  UI.on("docsample", () => { const ex = E.BANK.filter(b => b.doc); const b = ex[(F.dayIndex() * 3) % ex.length]; UI.startQuiz({ mode: "documents", fixed: [E.bankToQuestion(b, U.rng(Date.now()))], title: "Document du jour" }); });

  // ---------- RÉVISIONS ----------
  UI.views.revisions = function () {
    const ms = E.dueMistakes(store), due = ms.filter(m => m.isDue);
    const when = m => m.isDue ? "À revoir maintenant" : "Le " + new Date(m.due).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
    const ddue = F.Dict.due(S()).length;
    const ans = q => q.kind && q.kind !== "mcq" ? (q.accept ? q.accept[0] : "") : (q.optFlags ? BY[q.opts[q.ans]].name : q.opts[q.ans]);
    root.innerHTML = `<div class="wrap narrow"><div class="pagehead"><span class="eyebrow">Révisions</span><h1>Revoir au bon moment</h1>
      <p>Chaque erreur revient après 1, 3, 7 puis 14 jours. Quatre bonnes réponses successives la font passer au statut « acquis ». Les mots du dictionnaire suivent leur propre calendrier.</p></div>
      <div class="grid g4">${[["Erreurs à revoir", due.length], ["En attente", ms.length - due.length], ["Erreurs acquises", S().stats.mastered || 0], ["Mots à réviser", ddue]].map(([l, v]) => `<div class="card tile"><span class="v">${v}</span><span class="l">${l}</span></div>`).join("")}</div>
      <div class="row"><button class="btn primary lg" data-act="review" ${ms.length ? "" : "disabled"}>${icon("redo")} ${due.length ? `Réviser ${Math.min(20, due.length)} erreur${due.length > 1 ? "s" : ""}` : "Réviser en avance"}</button><a class="btn lg" href="#dictionnaire">${icon("note")} Réviser le vocabulaire (${ddue})</a></div>
      <div class="card">${ms.length ? `<div class="list">${ms.slice(0, 60).map(m => `<div class="row between" style="align-items:flex-start"><div style="flex:1;min-width:0"><span class="chip cat-${m.q.cat}" style="margin-bottom:4px"><span class="dot catmark"></span>${esc(UI.catLabel(m.q.cat))}</span><p>${esc(m.q.q)}${m.q.prompt ? " — " + esc(m.q.prompt) : ""}${m.q.flagPrompt ? " " + U.flag(m.q.flagPrompt) : ""}</p><p class="muted small">Réponse : ${esc(ans(m.q))}</p></div>
        <div class="stack" style="gap:4px;justify-items:end;font-size:.8rem"><span class="chip ${m.isDue ? "pill-warn" : ""}">${when(m)}</span><span class="muted">${m.wrong} erreur${m.wrong > 1 ? "s" : ""} · étape ${m.box}/4</span></div></div>`).join("")}</div>`
        : `<div class="empty">Aucune erreur enregistrée. Celles que vous ferez apparaîtront ici avec leur correction.</div>`}</div></div>`;
  };
})();
