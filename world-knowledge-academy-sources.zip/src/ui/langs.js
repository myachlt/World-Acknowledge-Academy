/* World Knowledge Academy — Langues : anglais et espagnol (niveaux CECRL, exercices, test de niveau, examens blancs, prononciation) */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, E, U, LG, F, BY, esc, pct, icon, toast, save, go, fmtTime, TTS } = UI;
  const S = () => store.s;
  const NAME = { en: "Anglais", es: "Espagnol" }, FLAG = { en: "🇬🇧", es: "🇪🇸" };
  const TYPE_DESC = {
    voc: "Mot ↔ traduction, dans les deux sens", wtr: "Écrire la traduction", match: "Relier 5 paires", img: "Image → mot, mot → image", ear: "Entendre puis traduire",
    odd: "Trouver l'intrus d'un thème", syn: "Synonymes et contraires", defs: "Définition → mot", idiom: "Expressions imagées", ff: "Pièges entre langues", scene: "Décrire une scène",
    gram: "Temps, articles, pronoms, syntaxe…", conj: "Verbes irréguliers et conjugaison", phr: "Phrasal verbs en contexte", cloze: "Textes à trous de longueurs variées",
    read: "Presse, histoire, dialogue, document professionnel…", listen: "Dialogues, annonces, interviews", tr: "Traduire des phrases", corr: "Repérer et corriger l'erreur",
    wf: "Dériver le bon mot", kwt: "Reformuler avec un mot imposé", write: "Message, courriel, essai, rapport"
  };

  // ---------- Hub ----------
  UI.views.langues = function () {
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Langues</span><h1>Anglais et espagnol, du A1 au C2</h1>
      <p>Deux parcours indépendants : niveau, exercices, statistiques et révisions propres à chaque langue. Le test de niveau est facultatif ; vous pouvez toujours choisir librement votre niveau.</p></div>
      <div class="grid g2">${["en", "es"].map(k => { const L = S().lang[k]; const bt = Object.values(L.byType); const a = bt.reduce((s, x) => s + x.a, 0), c = bt.reduce((s, x) => s + x.c, 0);
        return `<a class="card link catcard cat-${k}" href="#langue-${k}"><div class="row"><span class="ic-round">${FLAG[k]}</span><div class="stack" style="gap:2px"><h2>${NAME[k]}</h2><span class="small muted">${L.level ? "Niveau " + LG.lvlName(L.level) + (L.placed ? " (test du " + new Date(L.placed.date).toLocaleDateString("fr-FR") + ")" : " (choisi)") : "Niveau à évaluer"}</span></div></div>
          <div class="row small"><span>${a} exercice${a > 1 ? "s" : ""} · ${a ? pct(c, a) + " % de réussite" : "pas encore commencé"}</span><span class="muted">· ${L.exams.length} examen${L.exams.length > 1 ? "s" : ""} blanc${L.exams.length > 1 ? "s" : ""}</span></div>
          <span class="btn primary" style="justify-self:start">Ouvrir</span></a>`; }).join("")}</div>
      <div class="card stack"><h2>Comment c'est organisé</h2><div class="grid g4">${LG.GROUPS.map(g => `<div class="stack" style="gap:4px"><b>${g.icon} ${esc(g.name)}</b><span class="small muted">${g.subs.map(s => LG.SUBS[s]).join(", ")}</span></div>`).join("")}</div>
      <p class="small muted">Plus : test de positionnement, examens blancs inspirés de Cambridge (B1 → C2) et du DELE (B1 → C1), prononciation (accents britannique, américain, espagnol, mexicain, argentin), et un dictionnaire personnel trilingue relié aux révisions.</p></div></div>`;
  };

  // ---------- Page d'une langue ----------
  const TABS = [["ex", "Exercices"], ["test", "Test de niveau"], ["exam", "Examens blancs"], ["pron", "Prononciation"], ["prog", "Progrès"]];
  UI.views["langue-*"] = function (r) {
    const k = r.slice(7); if (!D.LANG[k]) return go("langues");
    const tab = app.ui["lt" + k] || "ex";
    root.innerHTML = `<div class="wrap cat-${k}"><div class="row between"><div class="row nowrap"><span class="ic-round">${FLAG[k]}</span><div class="pagehead"><span class="eyebrow">Langues</span><h1>${NAME[k]}</h1></div></div>
        <span class="chip pill-sage">${S().lang[k].level ? "Votre niveau : " + LG.lvlName(S().lang[k].level) : "Niveau non évalué"}</span></div>
      <div class="tabs" role="tablist">${TABS.filter(([id]) => id !== "exam" || D.LANG[k].exams.length).map(([id, l]) => `<button role="tab" aria-selected="${tab === id}" class="${tab === id ? "sel" : ""}" data-ltab="${k}|${id}">${l}</button>`).join("")}</div>
      ${({ ex: exTab, test: testTab, exam: examTab, pron: pronTab, prog: progTab })[tab](k)}</div>`;
  };
  UI.onData("ltab", v => { const [k, t] = v.split("|"); app.ui["lt" + k] = t; UI.render(); });
  const curLevel = k => app.ui["ll" + k] || S().lang[k].level || 2;
  function exTab(k) {
    const lv = curLevel(k); const subs = E.CAT[k].subs; const gens = app.volume.gens.filter(g => g.cat === k);
    const n = sub => gens.filter(g => g.sub === sub).reduce((s, g) => s + g.n, 0);
    const bt = S().lang[k].byType;
    return `<div class="card stack"><span class="eyebrow">Niveau de travail</span>
        <div class="lvlpick">${LG.CEFR.map((c, i) => `<button data-llevel="${k}|${i + 1}" class="${lv === i + 1 ? "sel" : ""}">${c}<small>${["Découverte", "Survie", "Seuil", "Avancé", "Autonome", "Maîtrise"][i]}</small></button>`).join("")}</div>
        <p class="small"><b>${LG.CEFR[lv - 1]} :</b> ${esc(LG.CEFR_DESC[lv - 1])}</p>
        <div class="row"><button class="btn primary lg" data-lmix="${k}">${icon("shuffle")} Session variée · 10 exercices ${LG.CEFR[lv - 1]}</button><button class="btn lg" data-lmix="${k}|mcq">${icon("bolt")} Session rapide (QCM)</button>
        ${S().lang[k].level !== lv ? `<button class="btn ghost" data-lsetlevel="${k}|${lv}">Définir ${LG.CEFR[lv - 1]} comme mon niveau</button>` : ""}</div></div>
      ${LG.GROUPS.map(g => `<div class="stack"><h2>${g.icon} ${esc(g.name)}</h2><div class="typegrid">${g.subs.filter(s => subs.includes(LG.SUBS[s])).map(s => { const name = LG.SUBS[s]; const x = bt[name];
        return `<button data-ltype="${k}|${esc(name)}"><span>${esc(name)}</span><small>${esc(TYPE_DESC[s])}</small><small class="mono">${x ? pct(x.c, x.a) + " % · " + x.a + " faits" : n(name) + " disponibles"}</small></button>`; }).join("")}</div></div>`).join("")}
      <div class="card flat stack"><b>Situations dans cette langue</b><div class="row">${D.SITUATIONS.filter(s => s.domain === k).map(s => `<button class="btn" data-situ="${s.id}">${icon("compass")} ${esc(s.title)}</button>`).join("")}</div>
        <span class="xs muted">Vocabulaire du quotidien et mots enregistrés : <a href="#dictionnaire">réviser mon dictionnaire</a>.</span></div>`;
  }
  UI.onData("llevel", v => { const [k, l] = v.split("|"); app.ui["ll" + k] = +l; UI.render(); });
  UI.onData("lsetlevel", v => { const [k, l] = v.split("|"); S().lang[k].level = +l; S().ratings[k] = +l; save(); toast(`Niveau ${LG.lvlName(+l)} enregistré pour l'${NAME[k].toLowerCase()}.`); UI.render(); });
  UI.onData("lmix", v => { const [k, m] = v.split("|"); UI.startQuiz({ mode: "langue", cats: [k], level: curLevel(k), count: 10, mcqOnly: m === "mcq", title: NAME[k] + " · " + LG.lvlName(curLevel(k)) }); });
  UI.onData("ltype", v => { const [k, sub] = v.split("|"); UI.startQuiz({ mode: "langue", cats: [k], sub, level: curLevel(k), count: /Compréhension|Expression écrite/.test(sub) ? 3 : /Textes/.test(sub) ? 4 : 10, title: NAME[k] + " · " + sub + " · " + LG.lvlName(curLevel(k)) }); });

  // ---------- Test de niveau ----------
  function testTab(k) {
    const p = S().lang[k].placed;
    return `<div class="card stack"><h2>Test de positionnement</h2>
      <p>14 questions de grammaire et de vocabulaire. La difficulté monte quand vous répondez juste et redescend sinon, comme dans les tests adaptatifs. Aucune correction pendant le test ; le détail s'affiche à la fin.</p>
      <p class="small muted">Durée : 5 à 8 minutes. Résultat indicatif, utile pour choisir le niveau de départ ; il ne remplace pas une certification officielle.</p>
      ${p ? `<div class="notice info">Dernier résultat : <b>${LG.lvlName(p.level)}</b> le ${new Date(p.date).toLocaleDateString("fr-FR")} (${p.correct}/${p.n}).</div>` : ""}
      <div><button class="btn primary lg" data-lplace="${k}">${p ? "Repasser le test" : "Commencer le test"}</button></div></div>`;
  }
  function PlacementSession(k) {
    const p = new LG.Placement(k);
    return { cfg: { mode: "placement", count: p.total, noFeedback: true, title: "Test de niveau · " + NAME[k], lang: k }, items: [], streak: 0, wrong: 0, correct: 0, bestStreak: 0, exhausted: false, start: Date.now(),
      next() { const q = p.next(); if (!q) return null; q.cat = k; this.items.push({ q, chosen: null }); return q; },
      answer(i, ms) { const it = this.items[this.items.length - 1]; const ok = p.answer(i); Object.assign(it, { chosen: i, correct: ok, score: ok ? 1 : 0, ms }); if (ok) { this.correct++; this.streak++; this.bestStreak = Math.max(this.bestStreak, this.streak); } else { this.wrong++; this.streak = 0; } return { correct: ok, score: ok ? 1 : 0 }; },
      finish() {
        const r = p.result(), L = S().lang[k]; L.level = r.level; L.placed = { date: Date.now(), level: r.level, correct: r.correct, n: r.n }; S().ratings[k] = r.level;
        const items = this.items.filter(i => i.chosen !== null);
        const sum = { id: U.hash("pl" + Date.now()), mode: "placement", cats: [k], start: this.start, end: Date.now(), n: items.length, correct: this.correct, bestStreak: this.bestStreak, renewed: 0, score20: items.length ? Math.round(this.correct / items.length * 200) / 10 : 0, title: this.cfg.title, items };
        S().sessions.push(sum); const earned = E.checkBadges(store, sum); save();
        return { summary: sum, earned, placement: Object.assign(r, { lang: k }) };
      } };
  }
  UI.onData("lplace", k => UI.startQuiz(null, PlacementSession(k)));
  UI.resultExtra = r => {
    if (!r.placement) return "";
    const p = r.placement;
    return `<div class="card hero stack"><span class="eyebrow">Résultat du test · ${NAME[p.lang]}</span><h1>Niveau estimé : ${p.label}</h1><p class="muted">${esc(LG.CEFR_DESC[p.level - 1])}</p>
      <div class="row">${[1, 2, 3, 4, 5, 6].map(l => { const x = p.per[l]; return `<span class="chip" style="background:rgba(255,255,255,.14);color:inherit;border-color:rgba(255,255,255,.3)">${LG.lvlName(l)} : ${x ? x.c + "/" + x.a : "—"}</span>`; }).join("")}</div>
      <div class="row"><a class="btn sun" href="#langue-${p.lang}">Commencer les exercices en ${p.label}</a></div></div>`;
  };

  // ---------- Examens blancs ----------
  function examTab(k) {
    const L = D.LANG[k], hist = S().lang[k].exams;
    return `<p class="notice info">${k === "en" ? "Épreuves <b>inspirées</b> du format Cambridge English (Reading & Use of English, Listening, Writing) : mêmes types de tâches, contenus 100 % originaux. Ce ne sont pas des sujets officiels." : "Épreuves <b>inspirées</b> du DELE (Instituto Cervantes) : compréhension de lecture, compréhension auditive, expression écrite, avec des contenus 100 % originaux. Ce ne sont pas des sujets officiels."}</p>
      <div class="grid g2">${L.exams.map(x => { const best = hist.filter(h => h.id === x.id).sort((a, b) => b.pct - a.pct)[0];
        return `<div class="card stack catcard"><div class="row between"><h2>${esc(x.name)}</h2><span class="chip pill-sage">${LG.lvlName(x.l)}</span></div>
          <p class="small muted">${x.minutes} min · ${x.parts.length} parties : ${Array.from(new Set(x.parts.map(p => p.skill))).join(", ")}</p>
          <ol class="small" style="margin:0;padding-left:18px">${x.parts.map(p => `<li>${esc(p.title || p.skill)}</li>`).join("")}</ol>
          ${best ? `<span class="chip ${best.pass ? "pill-good" : "pill-warn"}" style="justify-self:start">Meilleur : ${best.score20}/20 · ${best.pass ? "réussi" : "à retravailler"}</span>` : ""}
          <button class="btn primary" data-lexam="${k}|${x.id}">Démarrer l'examen</button></div>`; }).join("")}</div>
      <p class="xs muted">Notation : chaque trou ou question vaut 1 point, une transformation 2 points, l'expression écrite 5 points (longueur + grille d'auto-évaluation). Seuil indicatif de réussite : 60 % au total et au moins 40 % dans chaque compétence.</p>`;
  }
  UI.itemByPfx = pfx => { const m = /^e(\d+)_(\d+)$/.exec(pfx); return m && app.exam ? app.exam.x.parts[+m[1]].items[+m[2]] : null; };
  let examTick = null;
  function startExam(k, id) {
    const x = new LG.Exam(k, id); app.exam = { x, k, part: 0, left: x.def.minutes * 60, done: false };
    app.match = {}; app.sub = {}; app.ui = Object.assign({}, app.ui);
    app.returnTo = UI.route(); history.replaceState(null, "", "#jouer");
    app.custom = renderExam; app.customExit = () => { clearInterval(examTick); app.exam = null; };
    clearInterval(examTick);
    examTick = setInterval(() => { if (!app.exam || app.exam.done) return clearInterval(examTick); app.exam.left--; const t = document.getElementById("etimer"); if (t) { t.textContent = fmtClock(app.exam.left); t.classList.toggle("low", app.exam.left <= 120); } if (app.exam.left <= 0) { collectPart(); finishExam(); } }, 1000);
    UI.render();
  }
  const fmtClock = v => Math.floor(Math.max(0, v) / 60) + ":" + String(Math.max(0, v) % 60).padStart(2, "0");
  UI.onData("lexam", v => { const [k, id] = v.split("|"); startExam(k, id); });
  function collectPart() { const ex = app.exam, p = ex.x.parts[ex.part]; p.resp = p.items.map((q, i) => UI.collect(q, "e" + ex.part + "_" + i)); }
  function renderExam() {
    const ex = app.exam; if (!ex) return UI.leavePlay();
    if (ex.done) return renderExamResult();
    const p = ex.x.parts[ex.part], n = ex.x.parts.length;
    root.innerHTML = `<div class="quiz cat-${ex.k}"><div class="qhead"><button class="btn ghost icon" data-act="examquit" aria-label="Quitter l'examen">${icon("x")}</button><div class="progress"><i style="width:${ex.part / n * 100}%"></i></div><span class="mono small">Partie ${ex.part + 1}/${n}</span><span class="timer" id="etimer">${fmtClock(ex.left)}</span></div>
      <div class="row between small"><span class="muted">${esc(ex.x.def.name)}</span><span class="chip pill-sage">${esc(p.skill)}</span></div>
      <div class="card qcard"><div class="qtext">${esc(p.title)}</div>
        ${p.items.map((q, i) => `<div class="stack">${p.items.length > 1 ? `<b>${i + 1}. ${esc(q.q)}</b>` : ""}${q.kind === "input" ? `<div class="prompt"><span>${esc(q.prompt)}</span></div>` : ""}${UI.itemHTML(q, "e" + ex.part + "_" + i, { done: false, exam: true, resp: p.resp[i] })}</div>`).join("")}
        <div class="qfoot"><span class="xs muted">Pas de correction pendant l'examen. Vous pouvez revenir à la partie précédente.</span><div class="row">${ex.part ? `<button class="btn" data-act="examprev">Partie précédente</button>` : ""}<button class="btn primary lg" data-act="examnext">${ex.part === n - 1 ? "Terminer et corriger" : "Partie suivante"}</button></div></div></div></div>`;
  }
  UI.on("examnext", () => { collectPart(); const ex = app.exam; if (ex.part < ex.x.parts.length - 1) { ex.part++; renderExam(); window.scrollTo(0, 0); } else finishExam(); });
  UI.on("examprev", () => { collectPart(); app.exam.part--; renderExam(); window.scrollTo(0, 0); });
  UI.on("examquit", () => { if (app.exam && !app.exam.done && !confirmQuit()) return; clearInterval(examTick); app.exam = null; app.custom = null; UI.leavePlay(); });
  function confirmQuit() { if (app.ui.examQuitAsk) { app.ui.examQuitAsk = false; return true; } app.ui.examQuitAsk = true; toast("Touchez à nouveau la croix pour abandonner l'examen (aucune note enregistrée)."); setTimeout(() => { app.ui.examQuitAsk = false; }, 4000); return false; }
  function finishExam() {
    const ex = app.exam; clearInterval(examTick); ex.done = true; ex.score = ex.x.score(); ex.end = Date.now();
    const L = S().lang[ex.k]; L.exams.push({ id: ex.x.def.id, date: Date.now(), pct: ex.score.pct, score20: ex.score.score20, pass: ex.score.pass, by: ex.score.by });
    const day = U.today(); S().days[day] = (S().days[day] || 0) + ex.x.parts.reduce((s, p) => s + p.items.length, 0);
    const earned = E.checkBadges(store, null); save();
    earned.forEach((b, i) => setTimeout(() => toast(`Badge obtenu : <b>${esc(b.name)}</b>`), 500 + i * 1800));
    renderExamResult(); window.scrollTo(0, 0);
  }
  function renderExamResult() {
    const ex = app.exam, sc = ex.score;
    // Les réponses du lecteur s'affichent dans la correction des questions à choix.
    ex.x.parts.forEach((p, pi) => p.items.forEach((q, i) => { if (q.kind === "passage") app.sub["r" + pi + "_" + i] = p.resp[i] || []; }));
    root.innerHTML = `<div class="wrap narrow cat-${ex.k}"><div class="card stack" style="gap:16px"><span class="eyebrow">${esc(ex.x.def.name)} · résultats</span>
      <div class="score"><span class="big">${sc.score20.toLocaleString("fr-FR")}<span style="font-size:1.4rem;color:var(--muted)">/20</span></span><div class="stack" style="gap:4px"><span class="chip ${sc.pass ? "pill-good" : "pill-warn"}" style="justify-self:start">${sc.pass ? "Niveau atteint (seuil indicatif)" : "Pas encore : à retravailler"}</span><span>${sc.pts} / ${sc.max} points · ${fmtTime(ex.end - ex.x.start)}</span></div></div>
      <div class="stack"><b>Par compétence</b>${Object.entries(sc.by).map(([sk, v]) => `<div class="hbar"><span>${esc(sk)}</span><div class="bar"><i style="width:${pct(v.pts, v.max)}%;background:${v.pts / v.max >= 0.6 ? "var(--sage-deep)" : v.pts / v.max >= 0.4 ? "var(--sun)" : "var(--terra)"}"></i></div><span class="n">${pct(v.pts, v.max)} %</span></div>`).join("")}</div>
      <p class="xs muted">L'expression écrite est notée par auto-évaluation guidée : une correction fine nécessite un correcteur humain ou une IA (non branchée dans la maquette).</p>
      <div class="row"><button class="btn primary" data-lexam="${ex.k}|${ex.x.def.id}">Repasser</button><button class="btn ghost" data-act="examclose">Retour</button></div></div>
      <h2>Correction détaillée</h2>
      ${ex.x.parts.map((p, pi) => `<details class="corr" ${pi === 0 ? "open" : ""}><summary><span class="res-ic ${p.pts / p.max >= 0.6 ? "ok" : p.pts > 0 ? "mid" : "ko"}">${Math.round(p.pts)}</span><span style="flex:1"><b>${esc(p.title)}</b><br><span class="small muted">${esc(p.skill)} · ${Math.round(p.pts * 10) / 10}/${p.max} points</span></span></summary>
        <div>${p.items.map((q, i) => `<div class="stack">${q.kind === "input" ? `<div class="prompt"><span>${esc(q.prompt)}</span></div>` : ""}${UI.itemHTML(q, "r" + pi + "_" + i, { done: true, exam: false, res: p.res[i], resp: p.resp[i] })}${q.kind === "input" ? UI.inputFeedback(q, p.res[i], p.resp[i]) : ""}</div>`).join("<hr style='border:0;border-top:1px solid var(--line);width:100%'>")}</div></details>`).join("")}</div>`;
  }
  UI.on("examclose", () => { const k = app.exam ? app.exam.k : "en"; app.exam = null; app.custom = null; app.ui["lt" + k] = "exam"; history.replaceState(null, "", "#langue-" + k); UI.render(); });

  // ---------- Prononciation ----------
  function pronTab(k) {
    const L = D.LANG[k], st = S().settings;
    const voices = L.tts.map(([code, name]) => ({ code, name, ok: TTS.hasVoice(code) }));
    const accKey = k === "en" ? "accentEn" : "accentEs";
    return `<div class="card stack"><h2>Réglages de la voix</h2>
        <div class="stack"><span class="eyebrow">Accent par défaut</span><div class="seg">${voices.map(v => `<button data-accent="${accKey}|${v.code}" class="${st[accKey] === v.code ? "sel" : ""}">${esc(v.name)}${TTS.ok && !v.ok ? " *" : ""}</button>`).join("")}</div>
        ${TTS.ok ? `<span class="xs muted">* voix non installée sur cet appareil : le navigateur utilisera la voix la plus proche.</span>` : `<p class="notice">La synthèse vocale n'est pas disponible dans ce navigateur : les transcriptions phonétiques (API) restent affichées.</p>`}</div>
        <div class="stack"><span class="eyebrow">Vitesse</span><div class="seg">${[[0.7, "Lente"], [0.85, "Posée"], [1, "Normale"]].map(([r, l]) => `<button data-rate="${r}" class="${(st.rate || 1) === r ? "sel" : ""}">${l}</button>`).join("")}</div></div></div>
      <div class="card stack"><h2>${k === "en" ? "Comparer britannique et américain" : "Variantes : Espagne et Amérique latine"}</h2>
        <div class="scroll-x"><table class="data"><thead><tr><th>Mot</th>${k === "en" ? "<th>🇬🇧 Royaume-Uni</th><th>🇺🇸 États-Unis</th>" : "<th>🇪🇸 Espagne</th><th>🌎 Amérique latine</th><th>Remarque</th>"}</tr></thead><tbody>
        ${L.pron.map(p => `<tr><td><b>${esc(p[0])}</b></td><td><span class="mono">${esc(p[1])}</span> ${UI.sayBtn(k === "en" ? p[0] : p[0].split(" / ")[0], k === "en" ? "en-GB" : "es-ES", "")}</td><td><span class="mono">${esc(p[2])}</span> ${UI.sayBtn(k === "en" ? p[0] : (p[2].match(/^[a-záéíóúñ ]+$/i) ? p[2] : p[0].split(" / ")[0]), k === "en" ? "en-US" : (/Plata|Argentine/.test(p[2] + p[3]) ? "es-AR" : "es-MX"), "")}</td>${k === "es" ? `<td class="small muted">${esc(p[3])}</td>` : ""}</tr>`).join("")}</tbody></table></div>
        <span class="xs muted">Les boutons utilisent les voix exactes (${k === "en" ? "en-GB / en-US" : "es-ES / es-MX / es-AR"}) quand l'appareil les possède.</span></div>
      <div class="card stack"><h2>Écouter, répéter, s'enregistrer</h2>
        <p class="small muted">Écoutez la phrase, enregistrez-vous, puis comparez. L'enregistrement reste sur votre appareil.</p>
        <div class="list">${L.sentences.map((s, i) => `<div class="row between"><span style="flex:1;min-width:0" lang="${k}">${esc(s)}</span><div class="row">${UI.sayBtn(s, k === "en" ? "en-GB" : "es-ES", "Modèle")}${UI.sayBtn(s, k === "en" ? "en-GB" : "es-ES", "Lentement")}<button class="say" data-rec="${k}${i}">${icon("mic")}<span>S'enregistrer</span></button><span id="rec-${k}${i}"></span></div></div>`).join("")}</div>
        <p class="xs muted">L'analyse automatique de la prononciation (score, phonèmes à corriger) nécessite un service de reconnaissance vocale externe : non branché dans la maquette.</p></div>`;
  }
  UI.onData("accent", v => { const [key, code] = v.split("|"); S().settings[key] = code; save(); TTS.speak(key === "accentEn" ? "Hello, how are you today?" : "Hola, ¿qué tal estás hoy?", code, { exact: true }); UI.render(); });
  UI.onData("rate", v => { S().settings.rate = +v; save(); UI.render(); });
  const recs = {};
  UI.onData("rec", async (id, t) => {
    const out = document.getElementById("rec-" + id);
    if (recs[id] && recs[id].state === "recording") { recs[id].stop(); return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || typeof MediaRecorder === "undefined") { out.innerHTML = `<span class="xs muted">Enregistrement non pris en charge par ce navigateur.</span>`; return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream); const chunks = []; recs[id] = mr;
      mr.ondataavailable = e => chunks.push(e.data);
      mr.onstop = () => { stream.getTracks().forEach(tr => tr.stop()); const url = URL.createObjectURL(new Blob(chunks, { type: mr.mimeType || "audio/webm" })); out.innerHTML = `<audio controls src="${url}" style="height:34px;max-width:220px"></audio>`; t.querySelector("span").textContent = "Recommencer"; };
      mr.start(); t.querySelector("span").textContent = "Arrêter"; out.innerHTML = `<span class="recdot" aria-label="Enregistrement en cours"></span>`;
      setTimeout(() => { if (mr.state === "recording") mr.stop(); }, 8000);
    } catch (e) { out.innerHTML = `<span class="xs muted">Micro indisponible ici (autorisation refusée ou bloquée dans l'aperçu). Ouvrez le fichier HTML dans Chrome, Edge ou Safari pour vous enregistrer.</span>`; }
  });

  // ---------- Progrès ----------
  function progTab(k) {
    const L = S().lang[k], bt = L.byType;
    const rows = Object.values(LG.SUBS).filter(s => E.CAT[k].subs.includes(s)).map(s => ({ s, x: bt[s] }));
    const sess = S().sessions.filter(s => s.cats && s.cats.length === 1 && s.cats[0] === k).slice(-20);
    return `<div class="grid g4">${[["Niveau", L.level ? LG.lvlName(L.level) : "—"], ["Exercices faits", Object.values(bt).reduce((s, x) => s + x.a, 0)], ["Réussite", (() => { const a = Object.values(bt).reduce((s, x) => s + x.a, 0), c = Object.values(bt).reduce((s, x) => s + x.c, 0); return a ? pct(c, a) + " %" : "—"; })()], ["Examens blancs", L.exams.length]].map(([l, v]) => `<div class="card tile"><span class="v">${v}</span><span class="l">${l}</span></div>`).join("")}</div>
      <div class="grid g2"><div class="card stack"><h2>Par type d'exercice</h2>${rows.map(({ s, x }) => `<div class="hbar"><span>${esc(s)}</span><div class="bar"><i style="width:${x ? pct(x.c, x.a) : 0}%"></i></div><span class="n">${x ? pct(x.c, x.a) + " %" : "—"}</span></div>`).join("")}</div>
      <div class="stack"><div class="card stack"><h2>Évolution</h2>${UI.lineChart(sess.map(s => ({ v: Math.round(s.score20 * 5), c: s.correct, n: s.n, label: new Date(s.start).toLocaleDateString("fr-FR", { day: "numeric", month: "short" }) })))}</div>
        <div class="card stack"><h2>Examens blancs</h2>${L.exams.length ? `<div class="list">${L.exams.slice().reverse().map(x => `<div class="row between"><span>${esc((D.LANG[k].exams.find(e => e.id === x.id) || {}).name || x.id)}<br><span class="xs muted">${new Date(x.date).toLocaleDateString("fr-FR")}</span></span><span class="chip ${x.pass ? "pill-good" : "pill-warn"}">${x.score20}/20</span></div>`).join("")}</div>` : `<div class="empty">Aucun examen blanc pour l'instant.</div>`}</div></div></div>`;
  }
})();
