/* World Knowledge Academy — Moi : statistiques, profil, badges, sauvegarde. Démarre l'application. */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, E, U, LG, F, BY, esc, pct, icon, toast, save, go, fmtTime, fmtDate } = UI;
  const S = () => store.s;

  UI.views.stats = function () {
    const St = S().stats, rr = UI.overallRating();
    if (app.ui.histDetail) {
      const s = S().sessions.find(x => x.id === app.ui.histDetail);
      if (s) {
        root.innerHTML = `<div class="wrap narrow"><div><button class="btn ghost" data-act="histback" style="padding-left:0">${icon("back")} Statistiques</button></div>
          <div class="card stack"><span class="eyebrow">${esc(s.title || UI.MODE_NAMES[s.mode] || s.mode)} · ${fmtDate(s.start)}</span><h1>${s.correct}/${s.n} · ${Math.round(s.score20 * 5)} %</h1></div>
          <div class="stack">${s.items ? UI.correctionList(s.items) : `<div class="empty">Le détail des anciennes sessions n'est plus conservé (60 dernières uniquement).</div>`}</div></div>`;
        return;
      }
      app.ui.histDetail = null;
    }
    const lvRows = [1, 2, 3, 4, 5].map(d => { const x = St.byLevel[d] || { a: 0, c: 0 }; return `<div class="hbar"><span>${d}. ${E.LEVELS[d - 1]}</span><div class="bar"><i style="width:${pct(x.c, x.a)}%"></i></div><span class="n">${x.a ? pct(x.c, x.a) + " %" : "—"}</span></div>`; }).join("");
    const subTable = E.CATEGORIES.map(c => {
      const rows = c.subs.map(sub => ({ sub, x: St.bySub[c.id + "|" + sub] })).filter(o => o.x); const x = St.byCat[c.id];
      return `<tr class="cat-${c.id}"><td><b><span class="dot catmark"></span> ${esc(c.name)}</b></td><td class="n">${x ? x.a : 0}</td><td class="n">${x ? pct(x.c, x.a) + " %" : "—"}</td><td class="n">${c.lang ? (S().lang[c.id].level ? LG.lvlName(S().lang[c.id].level) : "—") : E.levelLabel(E.ratingOf(store, c.id))}</td></tr>` +
        rows.map(o => `<tr><td style="padding-left:24px" class="muted">${esc(o.sub)}</td><td class="n">${o.x.a}</td><td class="n">${pct(o.x.c, o.x.a)} %</td><td></td></tr>`).join("");
    }).join("");
    const paths = F.continentPaths(S()); const g = F.gaps(S());
    const hist = S().sessions.slice().reverse().slice(0, 40);
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Statistiques</span><h1>Votre progression</h1></div>
      <div class="grid g4">${[["Questions répondues", St.answered.toLocaleString("fr-FR")], ["Réussite", St.answered ? pct(St.correct, St.answered) + " %" : "—"], ["Sessions", S().sessions.length], ["Temps total", fmtTime(St.timeMs)], ["Meilleure série", St.bestStreak], ["Jours d'affilée", E.dayStreak(S())], ["Niveau culture générale", St.answered ? E.levelLabel(rr || 2) : "—"], ["Pays maîtrisés", paths.reduce((a, p) => a + p.mastered, 0)]].map(([l, v]) => `<div class="card tile"><span class="v">${v}</span><span class="l">${l}</span></div>`).join("")}</div>
      <div class="grid g2"><div class="card stack"><h2>Réussite par session</h2>${UI.lineChart(UI.sessionPoints(30))}</div><div class="card stack"><h2>Par domaine</h2>${UI.catBars()}</div></div>
      <div class="grid g3">
        <div class="card stack"><h2>Langues</h2>${["en", "es"].map(k => { const L = S().lang[k], bt = Object.values(L.byType), a = bt.reduce((s, x) => s + x.a, 0), c = bt.reduce((s, x) => s + x.c, 0);
          return `<a class="row between" href="#langue-${k}" style="text-decoration:none;color:inherit"><span><b>${k === "en" ? "🇬🇧 Anglais" : "🇪🇸 Espagnol"}</b><br><span class="xs muted">${a} exercices · ${a ? pct(c, a) + " %" : "—"} · ${L.exams.length} examen(s)</span></span><span class="chip pill-sage">${L.level ? LG.lvlName(L.level) : "—"}</span></a>`; }).join("")}</div>
        <div class="card stack"><h2>Monde</h2>${paths.map(p => `<div class="hbar"><span>${esc(p.name)}</span><div class="bar"><i style="width:${pct(p.mastered, p.total)}%;background:var(--m-mast)"></i></div><span class="n">${p.mastered}/${p.total}</span></div>`).join("")}</div>
        <div class="card stack"><h2>Lacunes détectées</h2>${g.weak.length ? g.weak.slice(0, 5).map((w, i) => `<div class="row between"><span class="small">${esc(w.sub)} <span class="muted">· ${pct(w.c, w.a)} %</span></span><button class="btn sm" data-gap="${i}">Cibler</button></div>`).join("") : `<p class="small muted">Aucune pour l'instant.</p>`}</div></div>
      <div class="grid g2"><div class="card stack"><h2>Par niveau de difficulté (culture générale)</h2>${lvRows}</div>
        <div class="card stack"><h2>Carnet</h2><dl class="facts"><div><dt>Mots</dt><dd>${S().dict.length}</dd></div><div><dt>Maîtrisés</dt><dd>${S().dict.filter(w => (w.srs || {}).box >= 5).length}</dd></div><div><dt>Notions</dt><dd>${S().gloss.length}</dd></div><div><dt>Erreurs acquises</dt><dd>${St.mastered || 0}</dd></div><div><dt>Situations résolues</dt><dd>${Object.keys(S().situations).length}/${D.SITUATIONS.length}</dd></div><div><dt>Défis quotidiens</dt><dd>${Object.keys(S().daily).length}</dd></div></dl></div></div>
      <div class="card stack"><h2>Par catégorie et sous-catégorie</h2><div class="scroll-x"><table class="data"><thead><tr><th>Catégorie</th><th class="n">Questions</th><th class="n">Réussite</th><th class="n">Niveau</th></tr></thead><tbody>${subTable}</tbody></table></div></div>
      <div class="card stack"><h2>Historique</h2>${hist.length ? `<div class="list">${hist.map(s => `<button class="row between" data-hist="${s.id}" style="background:none;border:0;border-top:1px solid var(--line);text-align:left;width:100%;color:inherit"><span><b>${esc(s.title || UI.MODE_NAMES[s.mode] || s.mode)}</b><br><span class="muted small">${fmtDate(s.start)} · ${fmtTime(s.end - s.start)}</span></span><span class="mono">${s.mode === "examen" ? s.score20 + "/20" : s.correct + "/" + s.n}</span></button>`).join("")}</div>` : `<div class="empty">Aucune session pour l'instant.</div>`}</div>
      <div class="card stack"><h2>Volume réel de contenu</h2>${volumeBlurb()}
        <details><summary class="small" style="cursor:pointer">Détail par générateur (${app.volume.generators})</summary><div class="scroll-x"><table class="data"><thead><tr><th>Source</th><th>Domaine</th><th class="n">Questions</th></tr></thead><tbody>
        <tr><td>Banque rédigée et vérifiée</td><td>Tous</td><td class="n">${app.volume.bank}</td></tr>
        ${app.volume.gens.map(g => `<tr><td class="mono xs">${g.id}</td><td>${esc(UI.catLabel(g.cat))} · ${esc(g.sub)}</td><td class="n">${g.exact ? g.n.toLocaleString("fr-FR") : "≈ " + g.n.toLocaleString("fr-FR") + " comb."}</td></tr>`).join("")}</tbody></table></div></details></div>
    </div>`;
  };
  function volumeBlurb() {
    const v = app.volume, lang = v.per.en.exact + v.per.es.exact;
    return `<p><b class="mono">${v.exact.toLocaleString("fr-FR")}</b> questions et exercices uniques : <b>${v.bank}</b> questions rédigées et sourcées à la main, <b>${lang.toLocaleString("fr-FR")}</b> exercices de langue, le reste produit par <b>${v.generators}</b> générateurs à partir de données vérifiées (${v.countries} pays, chronologie, éléments chimiques, PIB…).</p>
      <p class="muted small">S'y ajoutent ≈ ${(v.combos / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 0 })} millions de combinaisons (comparaisons, associations, documents chiffrés). Elles renouvellent les questions mais reposent sur les mêmes données : ce ne sont pas des faits nouveaux. Une question déjà vue n'est reproposée que lorsque le stock inédit de la sélection est épuisé.</p>`;
  }
  UI.onData("hist", id => { app.ui.histDetail = id; UI.views.stats(); window.scrollTo(0, 0); });
  UI.on("histback", () => { app.ui.histDetail = null; UI.views.stats(); });

  UI.views.profil = function () {
    const p = S().profile, th = S().settings.theme || "auto", got = E.BADGES.filter(b => S().badges[b.id]).length;
    root.innerHTML = `<div class="wrap narrow"><div class="pagehead"><span class="eyebrow">Profil</span><h1>${p.name ? esc(p.name) : "Mon profil"}</h1></div>
      <div class="card stack" style="gap:16px"><h2>Préférences</h2>
        <label class="field" for="pname">Prénom ou pseudo<input id="pname" type="text" value="${esc(p.name)}" maxlength="40" placeholder="Votre prénom"></label>
        <div class="stack"><span class="eyebrow">Objectif quotidien</span><div class="seg">${[5, 10, 20, 30, 50].map(n => `<button data-goal="${n}" class="${p.dailyGoal === n ? "sel" : ""}">${n} questions</button>`).join("")}</div></div>
        <div class="stack"><span class="eyebrow">Validation des réponses</span><div class="seg"><button data-onetap="0" class="${!p.oneTap ? "sel" : ""}">Choisir puis valider</button><button data-onetap="1" class="${p.oneTap ? "sel" : ""}">En un geste</button></div></div>
        <div class="stack"><span class="eyebrow">Apparence</span><div class="seg">${[["auto", "Automatique"], ["light", "Clair"], ["dark", "Sombre"]].map(([k, l]) => `<button data-themeset="${k}" class="${th === k ? "sel" : ""}">${l}</button>`).join("")}</div></div>
        <div class="stack"><span class="eyebrow">Niveaux de langue</span><div class="row">${["en", "es"].map(k => `<a class="chip" href="#langue-${k}">${k === "en" ? "🇬🇧 Anglais" : "🇪🇸 Espagnol"} : ${S().lang[k].level ? LG.lvlName(S().lang[k].level) : "à évaluer"}</a>`).join("")}</div></div>
      </div>
      <div class="card stack"><div class="row between"><h2>Badges</h2><span class="chip pill-brass">${got}/${E.BADGES.length}</span></div><div class="badges">${E.BADGES.map(b => UI.badgeHTML(b, !!S().badges[b.id])).join("")}</div></div>
      <div class="card stack"><h2>Sauvegarde</h2><p class="muted small">Votre progression (dont dictionnaire et glossaire) est enregistrée sur cet appareil. Copiez la sauvegarde pour la transférer, puis collez-la sur un autre appareil.</p>
        <div class="row"><button class="btn" data-act="export">Afficher et copier la sauvegarde</button><button class="btn" data-act="import">Importer une sauvegarde</button><button class="btn" data-act="exportdict">Exporter le dictionnaire (CSV)</button></div>
        <textarea id="backup" class="inp" aria-label="Sauvegarde au format JSON" placeholder="La sauvegarde apparaîtra ici, ou collez-en une pour l'importer." hidden></textarea>
        <div id="backup-act" hidden><button class="btn primary" data-act="doimport">Remplacer ma progression par cette sauvegarde</button></div></div>
      <div class="card stack"><h2>Signalements envoyés</h2>${S().reports.length ? `<div class="list">${S().reports.slice().reverse().map(r => `<div><b>${esc(r.reason)}</b> <span class="muted mono xs">ID ${esc(r.fp)} · ${fmtDate(r.ts)}</span><p class="small">${esc(r.q)}</p>${r.note ? `<p class="muted small">${esc(r.note)}</p>` : ""}</div>`).join("")}</div>` : `<p class="muted small">Aucun. Le bouton « Signaler une erreur » apparaît après chaque correction ; les signalements sont gardés ici en attendant une file de modération.</p>`}</div>
      <div class="card stack"><h2>Réinitialiser</h2>${app.ui.confirmReset ? `<p>Toute la progression, l'historique, les badges, le dictionnaire et le glossaire seront effacés de cet appareil. Cette action est définitive.</p><div class="row"><button class="btn danger" data-act="doreset">Tout effacer</button><button class="btn ghost" data-act="cancelreset">Annuler</button></div>` : `<div><button class="btn danger" data-act="reset">Effacer ma progression</button></div>`}</div>
    </div>`;
  };
  UI.onData("goal", v => { S().profile.dailyGoal = +v; save(); UI.views.profil(); });
  UI.onData("onetap", v => { S().profile.oneTap = v === "1"; save(); UI.views.profil(); });
  UI.onData("themeset", v => { UI.setTheme(v); UI.views.profil(); });
  document.addEventListener("input", e => { if (e.target.id === "pname") { S().profile.name = e.target.value.trim(); save(); } });
  UI.on("export", () => { const ta = document.getElementById("backup"); ta.hidden = false; ta.value = store.exportJSON(); ta.select(); document.getElementById("backup-act").hidden = true; if (navigator.clipboard) navigator.clipboard.writeText(ta.value).then(() => toast("Sauvegarde copiée."), () => toast("Sélectionnez le texte puis copiez-le.")); });
  UI.on("exportdict", () => {
    const q = s => '"' + String(s || "").replace(/"/g, '""') + '"';
    const csv = ["Français;Anglais;Espagnol;Catégorie;Nature;Exemple;Maîtrise"].concat(S().dict.map(w => [w.fr, w.en, w.es, w.cat, w.nat, w.ex, F.Dict.masteryLabel(F.Dict.mastery(w))].map(q).join(";"))).join("\n");
    const ta = document.getElementById("backup"); ta.hidden = false; ta.value = csv; ta.select(); document.getElementById("backup-act").hidden = true;
    if (navigator.clipboard) navigator.clipboard.writeText(csv).then(() => toast("Dictionnaire copié au format CSV (séparateur ;)."), () => toast("Sélectionnez le texte puis copiez-le."));
  });
  UI.on("import", () => { const ta = document.getElementById("backup"); ta.hidden = false; ta.value = ""; ta.focus(); document.getElementById("backup-act").hidden = false; });
  UI.on("doimport", () => { try { store.importJSON(document.getElementById("backup").value); toast("Sauvegarde importée."); UI.views.profil(); UI.renderNav(); } catch (err) { toast(esc(err.message || "Sauvegarde illisible.")); } });
  UI.on("reset", () => { app.ui.confirmReset = true; UI.views.profil(); });
  UI.on("cancelreset", () => { app.ui.confirmReset = false; UI.views.profil(); });
  UI.on("doreset", () => { store.reset(); app.ui = {}; toast("Progression effacée."); go("accueil"); });

  UI.boot();
})();
