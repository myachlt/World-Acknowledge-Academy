/* World Knowledge Academy — Mon carnet : dictionnaire trilingue personnel, révision intelligente du vocabulaire, glossaire */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, E, U, LG, F, esc, pct, icon, toast, save } = UI;
  const S = () => store.s;
  const st = () => app.ui.dict || (app.ui.dict = { q: "", lang: "", cat: "", sort: "fr", dir: "asc", edit: null, form: false, dirs: ["fr-en", "en-fr", "fr-es", "es-fr", "phrase", "ecoute", "image"], theme: "" });
  const DIRS = [["fr-en", "FR → EN"], ["en-fr", "EN → FR"], ["fr-es", "FR → ES"], ["es-fr", "ES → FR"], ["phrase", "Compléter une phrase"], ["ecoute", "Reconnaître à l'oral"], ["image", "Image"]];
  const mast = w => { const b = F.Dict.mastery(w); return `<span class="mast" title="${F.Dict.masteryLabel(b)}">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= b ? "on" : ""}"></i>`).join("")}</span>`; };
  const NATS = ["nom", "verbe", "adjectif", "adverbe", "expression", "préposition", "autre"];

  function formHTML(w) {
    w = w || {}; const cats = F.Dict.cats(S());
    return `<div class="card stack" id="dictform"><h2>${w.id ? "Modifier le mot" : "Ajouter un mot ou une expression"}</h2>
      <div class="formgrid">
        <label class="field">Français<input id="df-fr" value="${esc(w.fr || "")}" placeholder="la maison" autocomplete="off"></label>
        <label class="field">Anglais<input id="df-en" value="${esc(w.en || "")}" placeholder="house" lang="en" autocomplete="off" autocapitalize="off"></label>
        <label class="field">Espagnol<input id="df-es" value="${esc(w.es || "")}" placeholder="la casa" lang="es" autocomplete="off" autocapitalize="off"></label>
        <label class="field">Catégorie<input id="df-cat" list="df-cats" value="${esc(w.cat || "")}" placeholder="Quotidien, Professionnel, Sciences…"><datalist id="df-cats">${cats.concat(["Quotidien", "Professionnel", "Sciences", "Voyage", "Expressions"]).filter((x, i, a) => a.indexOf(x) === i).map(c => `<option value="${esc(c)}">`).join("")}</datalist></label>
        <label class="field">Nature<select id="df-nat">${NATS.map(n => `<option ${w.nat === n ? "selected" : ""}>${n}</option>`).join("")}</select></label>
        <label class="field full">Phrase d'exemple (facultatif)<input id="df-ex" value="${esc(w.ex || "")}" placeholder="I live in a house with a garden."></label>
      </div><p class="xs muted">Le français et au moins une traduction suffisent. Les expressions complètes sont acceptées (« to break the ice », « meter la pata »).</p>
      <div class="row"><button class="btn primary" data-act="dictsave" data-id="${w.id || ""}">${w.id ? "Enregistrer" : "Ajouter"}</button><button class="btn ghost" data-act="dictcancel">Annuler</button></div></div>`;
  }
  function rowsHTML(list) {
    const s = st();
    const th = (k, l) => `<th><button data-dsort="${k}" aria-label="Trier par ${l}">${l}${s.sort === k ? (s.dir === "asc" ? " ↑" : " ↓") : ""}</button></th>`;
    return `<div class="scroll-x dict table"><table class="data"><thead><tr>${th("fr", "Français")}${th("en", "Anglais")}${th("es", "Espagnol")}${th("cat", "Catégorie")}${th("mastery", "Maîtrise")}<th></th></tr></thead><tbody>
      ${list.map(w => `<tr><td><span class="w">${esc(w.fr)}</span><span class="sub">${esc(w.nat || "")}</span></td>
        <td><span class="w" lang="en">${esc(w.en || "—")}</span>${w.en ? UI.sayBtn(w.en, "en-GB", "") : ""}</td>
        <td><span class="w" lang="es">${esc(w.es || "—")}</span>${w.es ? UI.sayBtn(w.es, "es-ES", "") : ""}</td>
        <td><span class="chip">${esc(w.cat)}</span></td><td>${mast(w)}</td>
        <td><div class="row nowrap" style="gap:2px"><button class="btn ghost sm icon" data-dedit="${w.id}" aria-label="Modifier ${esc(w.fr)}">${icon("edit")}</button><button class="btn ghost sm icon" data-ddel="${w.id}" aria-label="Supprimer ${esc(w.fr)}">${icon("trash")}</button></div></td></tr>
        ${w.ex ? `<tr><td colspan="6" class="small muted" style="border-top:0;padding-top:0">« ${esc(w.ex)} »</td></tr>` : ""}`).join("")}
      </tbody></table></div>
      <div class="dictcards">${list.map(w => `<div class="dcard"><div class="tri"><div><span>Français</span><b>${esc(w.fr)}</b></div><div><span>Anglais</span><b lang="en">${esc(w.en || "—")}</b></div><div><span>Espagnol</span><b lang="es">${esc(w.es || "—")}</b></div></div>
        ${w.ex ? `<p class="small muted">« ${esc(w.ex)} »</p>` : ""}
        <div class="row between"><div class="row" style="gap:6px"><span class="chip">${esc(w.cat)}</span>${mast(w)}</div><div class="row" style="gap:4px">${w.en ? UI.sayBtn(w.en, "en-GB", "EN") : ""}${w.es ? UI.sayBtn(w.es, "es-ES", "ES") : ""}<button class="btn ghost sm icon" data-dedit="${w.id}" aria-label="Modifier">${icon("edit")}</button><button class="btn ghost sm icon" data-ddel="${w.id}" aria-label="Supprimer">${icon("trash")}</button></div></div></div>`).join("")}</div>`;
  }
  function listNow() { const s = st(); return F.Dict.list(S(), { q: s.q, lang: s.lang, cat: s.cat, sort: s.sort, dir: s.dir }); }
  UI.views.dictionnaire = function () {
    const s = st(), all = S().dict, due = F.Dict.due(S()).length, list = listNow();
    const byBox = [0, 1, 2, 3, 4, 5].map(b => all.filter(w => F.Dict.mastery(w) === b).length);
    const themes = Array.from(new Set(D.VOCAB.map(v => v.theme)));
    root.innerHTML = `<div class="wrap"><div class="row between"><div class="pagehead"><span class="eyebrow">Mon carnet</span><h1>Dictionnaire personnel</h1><p>Vos mots en français, anglais et espagnol. Ils alimentent vos révisions espacées : un mot bien su revient de plus en plus tard (1, 3, 7, 16 puis 35 jours).</p></div>
        <button class="btn primary" data-act="dictnew">${icon("plus")} Ajouter un mot</button></div>
      ${s.form ? formHTML(s.edit ? all.find(w => w.id === s.edit) : null) : ""}
      <div class="grid g4">${[["Mots", all.length], ["À réviser aujourd'hui", due], ["En cours d'apprentissage", all.length - byBox[5] - byBox[0]], ["Maîtrisés", byBox[5]]].map(([l, v]) => `<div class="card tile"><span class="v">${v}</span><span class="l">${l}</span></div>`).join("")}</div>
      <div class="card stack"><div class="row between"><h2>Révision intelligente</h2><span class="chip ${due ? "pill-terra" : "pill-sage"}">${due ? due + " à revoir" : "À jour"}</span></div>
        <div class="row" style="gap:6px">${DIRS.map(([k, l]) => `<button class="chip ${s.dirs.includes(k) ? "sel" : ""}" data-ddir="${k}">${l}</button>`).join("")}</div>
        <div class="row"><button class="btn primary" data-act="dictrev" ${all.length >= 2 ? "" : "disabled"}>${icon("redo")} ${due ? `Réviser ${Math.min(10, due)} mot${due > 1 ? "s" : ""}` : "Réviser quand même"}</button>${s.cat ? `<button class="btn" data-act="dictrevcat">Réviser seulement « ${esc(s.cat)} »</button>` : ""}</div>
        <p class="xs muted">Les mots les moins maîtrisés passent en premier. Une erreur fait reculer le mot de deux étapes.</p></div>
      <div class="card stack">
        <div class="row" style="align-items:flex-end">
          <label class="field" for="dq" style="flex:1 1 220px">Recherche instantanée<input id="dq" type="search" value="${esc(s.q)}" placeholder="Un mot dans n'importe quelle langue" autocomplete="off"></label>
          <label class="field" for="dlang">Langue<select id="dlang"><option value="">Toutes</option><option value="en" ${s.lang === "en" ? "selected" : ""}>Avec anglais</option><option value="es" ${s.lang === "es" ? "selected" : ""}>Avec espagnol</option></select></label>
          <label class="field" for="dcat">Thème<select id="dcat"><option value="">Tous</option>${F.Dict.cats(S()).map(c => `<option ${s.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
          <label class="field" for="dsort">Tri<select id="dsort">${[["fr", "A → Z (français)"], ["en", "A → Z (anglais)"], ["es", "A → Z (espagnol)"], ["mastery", "Maîtrise"], ["created", "Date d'ajout"]].map(([k, l]) => `<option value="${k}" ${s.sort === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        </div>
        <div id="dlist">${list.length ? rowsHTML(list) : `<div class="empty">${all.length ? "Aucun mot ne correspond à ces filtres." : "Votre dictionnaire est vide."}</div>`}</div>
        <span class="xs muted" id="dcount">${list.length} mot${list.length > 1 ? "s" : ""} affiché${list.length > 1 ? "s" : ""}</span></div>
      <div class="card stack"><h2>Ajouter un thème entier</h2><p class="small muted">Importez d'un coup le vocabulaire trilingue de l'application (${D.VOCAB.length} mots, A1 → C2), puis personnalisez-le.</p>
        <div class="row"><select class="inp" id="dtheme" style="max-width:260px">${themes.map(t => `<option>${esc(t)}</option>`).join("")}</select><button class="btn" data-act="dicttheme">${icon("plus")} Ajouter ce thème</button></div></div>
      <p class="xs muted">Astuce : pendant les exercices, le bouton « Ajouter au dictionnaire » enregistre le mot rencontré avec sa traduction.</p></div>`;
  };
  function refreshList() { const l = listNow(); document.getElementById("dlist").innerHTML = l.length ? rowsHTML(l) : `<div class="empty">Aucun mot ne correspond à ces filtres.</div>`; document.getElementById("dcount").textContent = `${l.length} mot${l.length > 1 ? "s" : ""} affiché${l.length > 1 ? "s" : ""}`; }
  document.addEventListener("input", e => { if (e.target.id === "dq") { st().q = e.target.value; refreshList(); } });
  document.addEventListener("change", e => {
    const id = e.target.id; if (!["dlang", "dcat", "dsort"].includes(id)) return;
    const s = st(); if (id === "dlang") s.lang = e.target.value; if (id === "dcat") s.cat = e.target.value; if (id === "dsort") { s.sort = e.target.value; s.dir = "asc"; }
    UI.views.dictionnaire();
  });
  UI.onData("dsort", k => { const s = st(); if (s.sort === k) s.dir = s.dir === "asc" ? "desc" : "asc"; else { s.sort = k; s.dir = "asc"; } refreshList(); });
  UI.onData("ddir", k => { const s = st(); s.dirs = s.dirs.includes(k) ? s.dirs.filter(x => x !== k) : s.dirs.concat(k); if (!s.dirs.length) s.dirs = [k]; UI.views.dictionnaire(); });
  UI.onData("dedit", id => { const s = st(); s.form = true; s.edit = id; UI.views.dictionnaire(); document.getElementById("dictform").scrollIntoView({ behavior: "smooth", block: "start" }); });
  UI.onData("ddel", (id, t) => {
    if (app.ui.ddelAsk !== id) { app.ui.ddelAsk = id; t.style.color = "var(--bad)"; toast("Touchez à nouveau la corbeille pour supprimer ce mot."); setTimeout(() => { app.ui.ddelAsk = null; }, 4000); return; }
    const w = S().dict.find(x => x.id === id); F.Dict.remove(S(), id); save(); app.ui.ddelAsk = null; toast(`« ${esc(w ? w.fr : "")} » supprimé.`); UI.views.dictionnaire(); UI.renderNav();
  });
  UI.on("dictnew", () => { const s = st(); s.form = true; s.edit = null; UI.views.dictionnaire(); document.getElementById("df-fr").focus(); });
  UI.on("dictcancel", () => { const s = st(); s.form = false; s.edit = null; UI.views.dictionnaire(); });
  UI.on("dictsave", t => {
    const v = id => document.getElementById(id).value; const w = { fr: v("df-fr"), en: v("df-en"), es: v("df-es"), cat: v("df-cat") || "Divers", nat: v("df-nat"), ex: v("df-ex") };
    try {
      if (t.dataset.id) { F.Dict.update(S(), t.dataset.id, w); toast("Mot modifié."); }
      else { const r = F.Dict.add(S(), w); toast(r.dup ? "Ce mot existe déjà dans votre dictionnaire." : `« ${esc(w.fr)} » ajouté.`); }
      save(); const s = st(); s.form = false; s.edit = null; UI.views.dictionnaire(); UI.renderNav();
    } catch (err) { toast(esc(err.message)); }
  });
  UI.on("dicttheme", () => {
    const th = document.getElementById("dtheme").value; let n = 0;
    D.VOCAB.filter(v => v.theme === th).forEach(v => { const r = F.Dict.add(S(), { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat }); if (!r.dup) n++; });
    save(); toast(n ? `${n} mot${n > 1 ? "s" : ""} ajouté${n > 1 ? "s" : ""} (thème ${esc(th)}).` : "Tous les mots de ce thème sont déjà dans votre dictionnaire."); UI.views.dictionnaire(); UI.renderNav();
  });
  function startDict(cat) {
    const s = st(); const qs = F.Dict.questions(S(), { n: 10, dirs: s.dirs, cat, all: !F.Dict.due(S()).length });
    if (!qs.length) { toast("Pas assez de mots compatibles avec ces exercices : ajoutez des traductions ou cochez d'autres types."); return; }
    UI.startQuiz({ mode: "dict", fixed: qs, title: "Révision du dictionnaire", dictMode: true });
  }
  UI.on("dictrev", () => startDict());
  UI.on("dictrevcat", () => startDict(st().cat));

  // ---------- Glossaire ----------
  const gs = () => app.ui.gloss || (app.ui.gloss = { q: "", cat: "", form: false, edit: null });
  UI.views.glossaire = function () {
    const s = gs(), list = F.Gloss.list(S(), { q: s.q, cat: s.cat }), cats = Array.from(new Set(S().gloss.map(g => g.cat))).sort();
    const w = s.edit ? S().gloss.find(g => g.id === s.edit) || {} : {};
    root.innerHTML = `<div class="wrap narrow"><div class="row between"><div class="pagehead"><span class="eyebrow">Mon carnet</span><h1>Glossaire personnel</h1><p>Les notions que vous voulez retenir : définition, exemple, catégorie. Ajoutez-les ici ou depuis la correction de n'importe quelle question.</p></div>
        <button class="btn primary" data-act="glnew">${icon("plus")} Nouvelle notion</button></div>
      ${s.form ? `<div class="card stack"><div class="formgrid"><label class="field">Notion<input id="gn" value="${esc(w.notion || "")}" placeholder="Ex. : inflation"></label><label class="field">Catégorie<input id="gc" value="${esc(w.cat || "")}" list="gcats" placeholder="Économie"><datalist id="gcats">${E.CATEGORIES.map(c => `<option value="${esc(c.short)}">`).join("")}</datalist></label>
        <label class="field full">Définition<textarea id="gd" rows="3">${esc(w.def || "")}</textarea></label><label class="field full">Exemple<input id="ge" value="${esc(w.ex || "")}"></label></div>
        <div class="row"><button class="btn primary" data-act="glsave">${s.edit ? "Enregistrer" : "Ajouter"}</button><button class="btn ghost" data-act="glcancel">Annuler</button></div></div>` : ""}
      <div class="row" style="align-items:flex-end"><label class="field" for="gq" style="flex:1 1 220px">Rechercher<input id="gq" type="search" value="${esc(s.q)}" placeholder="Une notion, un mot de la définition…"></label>
        <label class="field" for="gcat">Catégorie<select id="gcat"><option value="">Toutes</option>${cats.map(c => `<option ${s.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label></div>
      <div class="stack" id="glist">${glossList(list)}</div></div>`;
  };
  const glossList = list => list.length ? list.map(g => `<div class="card stack"><div class="row between"><h3>${esc(g.notion)}</h3><div class="row nowrap" style="gap:2px"><span class="chip">${esc(g.cat)}</span><button class="btn ghost sm icon" data-gedit="${g.id}" aria-label="Modifier">${icon("edit")}</button><button class="btn ghost sm icon" data-gdel="${g.id}" aria-label="Supprimer">${icon("trash")}</button></div></div><p>${esc(g.def)}</p>${g.ex ? `<p class="small muted"><b>Exemple :</b> ${esc(g.ex)}</p>` : ""}</div>`).join("")
    : `<div class="empty">${S().gloss.length ? "Aucune notion ne correspond." : "Votre glossaire est vide. Après une correction, touchez « Ajouter au glossaire » pour garder une notion."}</div>`;
  document.addEventListener("input", e => { if (e.target.id === "gq") { gs().q = e.target.value; document.getElementById("glist").innerHTML = glossList(F.Gloss.list(S(), gs())); } });
  document.addEventListener("change", e => { if (e.target.id === "gcat") { gs().cat = e.target.value; UI.views.glossaire(); } });
  UI.on("glnew", () => { Object.assign(gs(), { form: true, edit: null }); UI.views.glossaire(); });
  UI.on("glcancel", () => { Object.assign(gs(), { form: false, edit: null }); UI.views.glossaire(); });
  UI.onData("gedit", id => { Object.assign(gs(), { form: true, edit: id }); UI.views.glossaire(); });
  UI.onData("gdel", (id, t) => { if (app.ui.gdelAsk !== id) { app.ui.gdelAsk = id; t.style.color = "var(--bad)"; toast("Touchez à nouveau pour supprimer."); setTimeout(() => { app.ui.gdelAsk = null; }, 4000); return; } F.Gloss.remove(S(), id); save(); UI.views.glossaire(); });
  UI.on("glsave", () => {
    const v = id => document.getElementById(id).value; const g = { notion: v("gn"), def: v("gd"), ex: v("ge"), cat: v("gc") || "Divers" };
    try { if (gs().edit) F.Gloss.update(S(), gs().edit, g); else F.Gloss.add(S(), g); save(); Object.assign(gs(), { form: false, edit: null }); UI.views.glossaire(); toast("Glossaire mis à jour."); } catch (err) { toast(esc(err.message)); }
  });
})();
