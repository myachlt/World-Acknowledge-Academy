/* World Knowledge Academy — Interface, socle commun (couche PRÉSENTATION)
 * Navigation, routeur, synthèse vocale, documents (tableaux, graphiques, cartes), rendu des exercices,
 * déroulement d'un quiz et correction. Aucune règle métier : tout passe par WKA.engine, WKA.lang et WKA.features.
 */
(function () {
  "use strict";
  const WKA = window.WKA, { data: D, engine: E, util: U, Store, lang: LG, features: F } = WKA;
  const BY = WKA.byIso;
  const store = new Store();
  const app = { sess: null, q: null, sel: null, done: false, res: null, t0: 0, tick: null, left: 0, examLeft: 0, result: null,
    match: {}, sub: {}, report: false, gloss: false, volume: E.volume(), sheet: false, ui: {} };
  const root = document.getElementById("view");
  const UI = WKA.ui = { store, app, root, views: {}, acts: {}, attrs: {}, D, E, U, LG, F, BY };

  // ---------- Outils ----------
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const pct = (c, a) => a ? Math.round(c / a * 100) : 0;
  const fmtTime = ms => { const m = Math.round(ms / 60000); return m < 60 ? m + " min" : Math.floor(m / 60) + " h " + String(m % 60).padStart(2, "0"); };
  const fmtDate = ts => new Date(ts).toLocaleDateString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  const flag = (iso, size) => `<span class="flag" aria-hidden="true"${size ? ` style="font-size:${size}"` : ""}>${U.flag(iso)}</span>`;
  const P = (d) => d.split("|").map(x => `<path d="${x}"/>`).join("");
  const ICONS = {
    home: P("M3 11.5 12 4l9 7.5|M5.5 10v10h13V10|M10 20v-5h4v5"), play: '<circle cx="12" cy="12" r="9"/><path d="m10 8.5 5.5 3.5-5.5 3.5z"/>',
    globe: '<circle cx="12" cy="12" r="9"/>' + P("M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"),
    grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    redo: P("M20 11a8 8 0 1 0-2.3 5.7|M20 5v6h-6"), chart: P("M4 20V4|M4 20h16|m7 15 4-4 3 3 5-6"), user: '<circle cx="12" cy="8" r="4"/>' + P("M4 21a8 8 0 0 1 16 0"),
    bolt: P("M13 3 5 14h6l-1 7 8-11h-6z"), shuffle: P("M4 7h3l10 10h3M4 17h3l3-3M14 10l3-3h3|m18 5 2 2-2 2M18 15l2 2-2 2"),
    flame: P("M12 21c-4 0-6.5-2.6-6.5-6 0-4 4-6 4-10 3 2 4.5 4.5 4.5 7 1-1 1.5-2 1.5-3 2 1.5 3 4 3 6 0 3.4-2.5 6-6.5 6z"),
    star: P("m12 3 2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-2.9-5.4 2.9 1.1-6L3.2 9.4l6.1-.8z"), exam: '<rect x="5" y="3" width="14" height="18" rx="2"/>' + P("M9 8h6M9 12h6M9 16h3"),
    infinity: P("M6.5 9a3 3 0 1 0 0 6c3 0 8-6 11-6a3 3 0 1 1 0 6c-3 0-8-6-11-6z"), ten: '<circle cx="12" cy="12" r="9"/>' + P("M12 7v5l3 2"),
    sliders: P("M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12") + '<circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    medal: '<circle cx="12" cy="14" r="6"/>' + P("m9 3 3 5 3-5"), back: P("M15 5 8 12l7 7"), x: P("M6 6l12 12M18 6 6 18"), flag: P("M5 21V4M5 4h11l-2 4 2 4H5"),
    book: P("M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z|M4 19V5|M9 7h6"), chat: P("M4 5h16v11H9l-5 4z|M8 9h8M8 12h5"), map: P("M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z|M9 4v14M15 6v14"),
    scale: P("M12 4v16M5 20h14|M6 8h12|M6 8l-3 6h6zM18 8l-3 6h6z"), doc: P("M7 3h7l5 5v13H7z|M14 3v5h5|M10 13h6M10 17h6"), compass: '<circle cx="12" cy="12" r="9"/>' + P("m15.5 8.5-2 5-5 2 2-5z"),
    sound: P("M4 10v4h4l5 4V6L8 10z|M16 9a4 4 0 0 1 0 6|M18.5 6.5a7.5 7.5 0 0 1 0 11"), mic: '<rect x="9" y="3" width="6" height="11" rx="3"/>' + P("M5 11a7 7 0 0 0 14 0|M12 18v3"),
    plus: P("M12 5v14M5 12h14"), edit: P("M4 20h4L19 9l-4-4L4 16z"), trash: P("M5 7h14|M10 11v6M14 11v6|M7 7l1 13h8l1-13|M9 7V4h6v3"),
    search: '<circle cx="11" cy="11" r="6"/>' + P("m20 20-4-4"), more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>', bulb: P("M9 18h6M10 21h4|M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z"),
    cal: '<rect x="4" y="5" width="16" height="15" rx="2"/>' + P("M4 10h16M9 3v4M15 3v4"), note: P("M6 3h12v18H6z|M9 8h6M9 12h6M9 16h4"), check: P("m5 12 5 5 9-10"),
    lang: P("M4 5h9M8.5 3v2|M6 5c0 4 3 7 6 8|M11 5c0 4-3 7-6 8|M13 21l4-10 4 10M14.5 17h5")
  };
  const icon = (n, cls) => `<svg class="ico ${cls || ""}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ""}</svg>`;
  const route = () => (location.hash || "#accueil").slice(1);
  const go = h => { if (location.hash.slice(1) === h) render(); else location.hash = h; };
  function toast(html, ms) {
    document.querySelectorAll(".toast").forEach(t => t.remove());
    const t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); t.innerHTML = html; document.body.appendChild(t);
    setTimeout(() => t.remove(), ms || 3200);
  }
  const save = () => store.save();
  const catLabel = id => E.CAT[id] ? E.CAT[id].short : id;
  Object.assign(UI, { esc, pct, fmtTime, fmtDate, flag, icon, route, go, toast, save, catLabel });

  // ---------- Navigation (groupée) ----------
  const NAV = [
    { g: "Apprendre", items: [["accueil", "Accueil", "home"], ["entrainer", "S'entraîner", "play"], ["categories", "Catégories", "grid"], ["situations", "Situations réelles", "compass"], ["documents", "Apprendre avec des documents", "doc"]] },
    { g: "Langues", items: [["langue-en", "Anglais", "lang", "🇬🇧"], ["langue-es", "Espagnol", "lang", "🇪🇸"]] },
    { g: "Explorer le monde", items: [["monde", "Carte du monde", "map"], ["comparer", "Comparateur de pays", "scale"], ["fiches", "Fiches thématiques", "book"]] },
    { g: "Mon carnet", items: [["dictionnaire", "Dictionnaire", "note"], ["glossaire", "Glossaire", "bulb"], ["revisions", "Révisions", "redo"]] },
    { g: "Moi", items: [["stats", "Statistiques", "chart"], ["profil", "Profil et badges", "user"]] },
    { g: "À propos", items: [["donnees", "Données et sources", "doc"]] }
  ];
  const TABS = [["accueil", "Accueil", "home"], ["entrainer", "Jouer", "play"], ["langues", "Langues", "lang"], ["monde", "Monde", "globe"], ["plus", "Plus", "more"]];
  const SECTION = r => {
    if (r.startsWith("pays-") || r === "comparer" || r === "fiches") return "monde";
    if (r.startsWith("situation")) return "situations";
    if (r.startsWith("langue")) return r;
    return r;
  };
  function renderNav() {
    const r = app.sess ? "entrainer" : SECTION(route());
    const due = E.dueMistakes(store).filter(m => m.isDue).length, dictDue = F.Dict.due(store.s).length;
    const cnt = { revisions: due, dictionnaire: dictDue };
    document.getElementById("sidenav").innerHTML = NAV.map(gr => `<div class="grp"><span>${gr.g}</span>${gr.items.map(([id, l, ic, em]) =>
      `<a href="#${id}" ${r === id ? 'aria-current="page"' : ""}>${em ? `<span class="emo" style="font-size:1.05rem;width:20px;text-align:center">${em}</span>` : icon(ic)}<span>${l}</span>${cnt[id] ? `<span class="cnt">${cnt[id]}</span>` : ""}</a>`).join("")}</div>`).join("");
    const tabOf = r.startsWith("langue") ? "langues" : ["accueil", "entrainer", "monde"].includes(r) ? r : "plus";
    document.getElementById("tabbar").innerHTML = TABS.map(([id, l, ic]) => id === "plus"
      ? `<button data-act="sheet" ${tabOf === "plus" ? 'aria-current="page"' : ""} aria-label="Plus de rubriques">${icon(ic)}<span>${l}</span></button>`
      : `<a href="#${id}" ${tabOf === id ? 'aria-current="page"' : ""}>${icon(ic)}<span>${l}</span></a>`).join("");
    const v = app.volume;
    document.getElementById("sidefoot").innerHTML = `<span>${due ? `<b>${due}</b> erreur${due > 1 ? "s" : ""} à revoir` : "Aucune erreur en attente"} · ${dictDue} mot${dictDue > 1 ? "s" : ""} à réviser</span><span class="mono">${v.exact.toLocaleString("fr-FR")} questions uniques</span>`;
    document.getElementById("sheet").innerHTML = app.sheet ? `<div class="sheet-bg" data-act="sheet"></div><div class="sheet" role="dialog" aria-label="Toutes les rubriques">
      ${NAV.map(gr => `<div class="grp"><span>${gr.g}</span><div class="links">${gr.items.map(([id, l, ic, em]) => `<a href="#${id}" data-act="sheetgo">${em ? `<span class="emo" style="font-size:1.3rem">${em}</span>` : icon(ic)}<span>${l}</span></a>`).join("")}</div></div>`).join("")}
      <button class="btn" data-act="sheet">Fermer</button></div>` : "";
  }
  function render() {
    stopTick();
    app.sheet = false; renderNav();
    const r = route();
    if (app.custom) { app.custom(); return; }
    if (app.sess && app.q) { renderQuiz(); return; }
    if (app.result) { renderResult(); return; }
    const key = Object.keys(UI.views).find(k => k.endsWith("*") ? r.startsWith(k.slice(0, -1)) : k === r);
    (UI.views[key] || UI.views.accueil)(r);
    window.scrollTo(0, 0);
  }
  UI.render = render; UI.renderNav = renderNav;

  // ---------- Synthèse vocale ----------
  const TTS = {
    ok: typeof window.speechSynthesis !== "undefined" && typeof window.SpeechSynthesisUtterance !== "undefined",
    voices() { try { return this.ok ? speechSynthesis.getVoices() : []; } catch (e) { return []; } },
    pick(lang) { const vs = this.voices(); const l = lang.toLowerCase(); return vs.find(v => v.lang.toLowerCase().replace("_", "-") === l) || vs.find(v => v.lang.toLowerCase().startsWith(l.slice(0, 2))); },
    resolve(lang) { const s = store.s.settings; if (!lang) return "en-GB"; if (lang.startsWith("en") && lang === "en-GB") return s.accentEn || lang; if (lang.startsWith("es") && lang === "es-ES") return s.accentEs || lang; return lang; },
    speak(text, lang, opts) {
      opts = opts || {};
      if (!this.ok) { toast("La synthèse vocale n'est pas disponible dans ce navigateur. Le texte reste affiché."); return false; }
      try {
        if (!opts.queue) speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text); const L = opts.exact ? lang : this.resolve(lang); u.lang = L;
        const v = this.pick(L); if (v) u.voice = v; u.rate = (opts.rate || store.s.settings.rate || 1) * (opts.slow ? 0.7 : 1); if (opts.pitch) u.pitch = opts.pitch;
        if (opts.onend) u.onend = opts.onend;
        speechSynthesis.speak(u); return true;
      } catch (e) { toast("Lecture audio impossible ici."); return false; }
    },
    dialogue(lines, lang, rate) {
      if (!this.ok) { toast("Synthèse vocale indisponible : la transcription s'affiche à la place."); return false; }
      speechSynthesis.cancel(); const sp = Array.from(new Set(lines.map(l => l[0])));
      lines.forEach(l => this.speak(l[1], lang, { queue: true, rate, pitch: sp.indexOf(l[0]) % 2 ? 0.85 : 1.12 })); return true;
    },
    hasVoice(lang) { return !!this.pick(lang); }
  };
  if (TTS.ok) { try { speechSynthesis.onvoiceschanged = () => { }; speechSynthesis.getVoices(); } catch (e) { /* rien */ } }
  UI.TTS = TTS;
  const sayBtn = (text, lang, label, cls) => `<button class="say ${label === "" ? "ic " : ""}${cls || ""}" data-say="${esc(text)}" data-lang="${esc(lang)}" aria-label="Écouter : ${esc(text)}">${icon("sound")}${label === undefined ? "Écouter" : label}</button>`;
  UI.sayBtn = sayBtn;

  // ---------- Graphiques et documents ----------
  function lineChart(points, opt) {
    opt = opt || {};
    if (points.length < 2) return `<div class="empty">Le graphique apparaîtra après deux sessions.</div>`;
    const W = 640, H = 200, L = 34, R = 14, T = 12, B = 26;
    const x = i => L + i * (W - L - R) / (points.length - 1), y = v => T + (100 - v) * (H - T - B) / 100;
    const path = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join("");
    const area = path + `L${x(points.length - 1)},${y(0)}L${x(0)},${y(0)}Z`;
    const grid = [0, 25, 50, 75, 100].map(v => `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 6}" y="${y(v) + 4}" text-anchor="end">${v}</text>`).join("");
    const step = (W - L - R) / (points.length - 1);
    const hits = points.map((p, i) => `<rect class="hit" x="${x(i) - step / 2}" y="${T}" width="${step}" height="${H - T - B}" data-tip="${esc(p.label)} : ${p.v} % (${p.c}/${p.n})"/>`).join("");
    const last = points[points.length - 1];
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Taux de réussite des ${points.length} dernières sessions">${grid}
      <path class="area" d="${area}"/><path class="ln" d="${path}"/>${points.map((p, i) => `<circle class="pt" cx="${x(i)}" cy="${y(p.v)}" r="${i === points.length - 1 ? 5 : 3.5}"/>`).join("")}
      <text x="${x(points.length - 1)}" y="${y(last.v) - 10}" text-anchor="end" style="fill:var(--ink);font-weight:600">${last.v} %</text>
      <text x="${L}" y="${H - 6}">${esc(points[0].label)}</text><text x="${W - R}" y="${H - 6}" text-anchor="end">${esc(last.label)}</text>${hits}</svg>`;
  }
  const nf = v => (Math.abs(v) >= 100 ? Math.round(v) : Math.round(v * 100) / 100).toLocaleString("fr-FR");
  function barChart(labels, values, unit) {
    const W = 560, rowH = 30, L = 118, R = 70, H = labels.length * rowH + 10, max = Math.max(...values) || 1;
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Graphique en barres${unit ? " (" + esc(unit) + ")" : ""}">
      ${labels.map((l, i) => { const w = (W - L - R) * values[i] / max; const yy = 6 + i * rowH;
        return `<text x="${L - 8}" y="${yy + 17}" text-anchor="end" style="fill:var(--ink)">${esc(l)}</text><rect class="barr" x="${L}" y="${yy + 4}" width="${Math.max(2, w).toFixed(1)}" height="${rowH - 10}" rx="4"/><text class="vl" x="${L + w + 6}" y="${yy + 17}">${nf(values[i])}</text>`; }).join("")}</svg>`;
  }
  function seriesChart(doc) {
    const labels = doc.labels, S = doc.series, W = 560, H = 220, L = 40, R = 16, T = 14, B = 30;
    const all = S.flatMap(s => s.values); const max = Math.max(...all), min = Math.min(0, ...all);
    const x = i => L + i * (W - L - R) / Math.max(1, labels.length - 1), y = v => T + (max - v) * (H - T - B) / ((max - min) || 1);
    const cols = ["var(--accent)", "var(--terra)", "var(--sage-deep)", "var(--sun)"];
    const ticks = [0, .25, .5, .75, 1].map(f => min + (max - min) * f);
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Graphique en courbe">
      ${ticks.map(v => `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 6}" y="${y(v) + 4}" text-anchor="end">${nf(v)}</text>`).join("")}
      ${labels.map((l, i) => `<text x="${x(i)}" y="${H - 10}" text-anchor="middle">${esc(l)}</text>`).join("")}
      ${S.map((s, k) => `<path d="${s.values.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join("")}" fill="none" stroke="${cols[k % 4]}" stroke-width="2.5"/>
        ${s.values.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="3.5" fill="var(--surface)" stroke="${cols[k % 4]}" stroke-width="2"/><text class="vl" x="${x(i)}" y="${y(v) - 8}" text-anchor="middle">${nf(v)}</text>`).join("")}`).join("")}
    </svg>${S.length > 1 ? `<div class="legend">${S.map((s, k) => `<span><i style="background:${cols[k % 4]}"></i>${esc(s.name)}</span>`).join("")}</div>` : ""}`;
  }
  const M = D.MAP, OTHER = Array.isArray(M.other) ? M.other.join(" ") : M.other;
  function miniMap(iso, ctx) {
    const b = M.bbox[iso]; const dot = M.dots[iso];
    let vb = "0 0 " + M.w + " " + M.h;
    if (b || dot) {
      const [x0, y0, x1, y1] = b || [dot[0] - 4, dot[1] - 4, dot[0] + 4, dot[1] + 4];
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; const w = Math.max((x1 - x0) * (ctx || 3.2), 120), h = w * 0.55;
      vb = `${(cx - w / 2).toFixed(1)} ${(cy - h / 2).toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)}`;
    }
    return `<div class="minimap"><svg viewBox="${vb}" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Carte de situation"><rect x="-500" y="-500" width="2000" height="1500" fill="var(--sea)"/><path class="other" d="${OTHER}"/>
      ${Object.entries(M.shapes).map(([k, d]) => `<path class="c ${k === iso ? "hl" : ""}" d="${d}"/>`).join("")}
      ${dot ? `<circle cx="${dot[0]}" cy="${dot[1]}" r="${b ? 0 : 2.4}" fill="var(--terra)" stroke="var(--surface)" stroke-width=".6"/>` : ""}</svg></div>`;
  }
  function docHTML(doc, opts) {
    if (!doc) return "";
    opts = opts || {};
    const T = { table: ["Tableau statistique", "grid"], chart: ["Graphique", "chart"], text: ["Extrait de document", "doc"], dialogue: ["Dialogue", "chat"], map: ["Carte", "map"] }[doc.type] || ["Document", "doc"];
    let body = "";
    if (doc.type === "table") body = `<div class="scroll-x"><table class="data"><thead><tr>${doc.cols.map((c, i) => `<th${i ? ' class="n"' : ""}>${esc(c)}</th>`).join("")}</tr></thead><tbody>${doc.rows.map(r => `<tr>${r.map((v, i) => `<td${i ? ' class="n"' : ""}>${esc(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
    else if (doc.type === "chart") body = (doc.unit ? `<span class="xs muted">Unité : ${esc(doc.unit)}</span>` : "") + (doc.kind === "line" || doc.series.length > 1 ? seriesChart(doc) : barChart(doc.labels, doc.series[0].values, doc.unit));
    else if (doc.type === "text") body = `<blockquote>${esc(doc.body)}</blockquote>`;
    else if (doc.type === "dialogue") body = `<div class="row">${sayDialogueBtn(doc.lines, doc.lang === "en" ? "en-GB" : "es-ES")}</div><div class="passage">${doc.lines.map(l => `<div class="line"><b>${esc(l[0])}</b>${esc(l[1])}</div>`).join("")}</div>`;
    else if (doc.type === "map") body = miniMap(doc.iso, 2.6);
    return `<div class="doc"><span class="dt">${icon(T[1])} ${T[0]}</span>${doc.title && doc.type !== "map" ? `<h4>${esc(doc.title)}</h4>` : ""}${body}${doc.note ? `<span class="note">${esc(doc.note)}</span>` : ""}${doc.source ? `<span class="note">Source : ${esc(doc.source)}</span>` : ""}</div>`;
  }
  const dlgStore = [];
  function sayDialogueBtn(lines, lang, label) { dlgStore.push(lines); return `<button class="say" data-dlg="${dlgStore.length - 1}" data-lang="${lang}">${icon("sound")}${label || "Écouter le dialogue"}</button>`; }
  Object.assign(UI, { lineChart, barChart, seriesChart, miniMap, docHTML, sayDialogueBtn });

  // ---------- Rendu des items ----------
  function diffDots(q) {
    const lang = E.CAT[q.cat] && E.CAT[q.cat].lang;
    if (lang) return `<span class="chip pill-sage" title="Niveau CECRL">${LG.lvlName(q.d)}</span>`;
    return `<span class="diff" title="Difficulté ${q.d}/5 : ${E.LEVELS[q.d - 1]}">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= q.d ? "on" : ""}"></i>`).join("")}</span>`;
  }
  function natureChip(q) {
    if (q.nature === "lang") return "";
    if (q.nature === "contemp") { const stale = U.monthsSince(q.asOf) > 12; return `<span class="chip ${stale ? "pill-warn" : ""}" title="Donnée susceptible d'évoluer">${stale ? "À revérifier · " : "Donnée datée · "}${esc(U.asOfLabel(q.asOf))}</span>`; }
    return `<span class="chip">${q.nature === "hist" ? "Fait historique" : q.nature === "sci" ? "Fait établi" : "Donnée géographique"}</span>`;
  }
  function promptHTML(q) {
    let h = "";
    if (q.doc) h += docHTML(q.doc);
    if (q.flagPrompt) h += `<div class="bigflag flag" role="img" aria-label="Drapeau à identifier">${U.flag(q.flagPrompt)}</div>`;
    if (q.bigEmoji) h += `<div class="bigemo" role="img" aria-label="Image à identifier">${q.bigEmoji}</div>`;
    if (q.audioOnly) h += `<div class="stack" style="justify-items:center">${sayBtn(q.audioOnly.text, q.audioOnly.lang, "Écouter le mot", "big")}<div class="row">${sayBtn(q.audioOnly.text, q.audioOnly.lang, "Plus lentement")}</div>${!TTS.ok ? `<p class="notice">Synthèse vocale indisponible : le mot s'affiche — <b>${esc(q.audioOnly.text)}</b>.</p>` : ""}</div>`;
    if (q.prompt) h += `<div class="prompt"><span>${esc(q.prompt)}</span>${q.say && !q.sayAfter ? sayBtn(q.say.text, q.say.lang) : ""}</div>`;
    return h;
  }
  function itemHTML(q, pfx, st) {
    // st : { done, res, resp, sel, exam }
    const k = q.kind || "mcq", done = st.done;
    if (k === "mcq") {
      return `<div class="opts ${q.optFlags || q.emojiOpts ? "two" : ""}">${q.opts.map((o, i) => {
        let cls = ""; if (done && !st.exam) { if (i === q.ans) cls = "ok"; else if (i === st.sel) cls = "ko"; } else if (i === st.sel) cls = "sel";
        const lbl = q.optFlags ? `<span class="t flag" aria-label="Drapeau ${esc(BY[o] ? BY[o].name : o)}">${U.flag(o)}</span>` : q.emojiOpts ? `<span class="t emo">${esc(o)}</span>` : `<span class="t">${esc(o)}</span>`;
        const mark = done && !st.exam ? (i === q.ans ? '<span class="mark" style="color:var(--good)">Bonne réponse</span>' : i === st.sel ? '<span class="mark" style="color:var(--bad)">Votre choix</span>' : "") : "";
        return `<button class="opt ${cls}" data-opt="${i}" ${done ? "disabled" : ""}><span class="k">${"ABCD"[i]}</span>${lbl}${mark}</button>`;
      }).join("")}</div>`;
    }
    if (k === "input") {
      const v = st.resp != null ? st.resp : (q.prefill || "");
      const cls = done ? (st.res.correct ? "okg" : "kog") : "";
      return `<div class="stack">${q.long ? `<textarea class="inp ${cls}" id="${pfx}in" rows="2" ${done ? "disabled" : ""} autocomplete="off" autocapitalize="off" spellcheck="false" lang="${esc(q.lang || "")}" aria-label="Votre réponse">${esc(v)}</textarea>`
        : `<input class="inp ${cls}" id="${pfx}in" type="text" value="${esc(v)}" ${done ? "disabled" : ""} autocomplete="off" autocapitalize="off" spellcheck="false" lang="${esc(q.lang || "")}" aria-label="Votre réponse" placeholder="Votre réponse">`}
        ${q.hint && !done ? `<span class="xs muted">${esc(q.hint)}</span>` : ""}${q.lang === "es" && !done ? `<div class="row" style="gap:4px">${["á", "é", "í", "ó", "ú", "ñ", "ü", "¿", "¡"].map(c => `<button class="btn sm" data-ins="${c}" data-tgt="${pfx}in" type="button">${c}</button>`).join("")}</div>` : ""}</div>`;
    }
    if (k === "match") {
      const marks = done && st.res ? st.res.marks : null;
      return matchBlock(q, pfx, done, marks) + `${done && st.res && !st.res.correct ? `<div class="fb-block"><h4>Associations correctes</h4><p>${q.pairs.map(p => `${esc(p[0])} = <b>${esc(p[1])}</b>`).join(" · ")}</p></div>` : done ? "" : `<span class="xs muted">Touchez un mot à gauche, puis sa traduction à droite. Touchez à nouveau pour défaire.</span>`}`;
    }
    return itemHTML2(q, pfx, st);
  }
  function matchBlock(q, pfx, done, marks) {
      const m = app.match[pfx] || (app.match[pfx] = { left: null, map: {} });
      const inv = {}; Object.entries(m.map).forEach(([l, r]) => inv[r] = +l);
      return `<div class="match" data-pfx="${pfx}"><div class="col">${q.pairs.map((p, i) => `<button data-ml="${i}" data-pfx="${pfx}" class="${m.left === i ? "sel" : ""} ${m.map[i] !== undefined ? "paired" : ""} ${marks ? (marks[i] ? "ok" : "ko") : ""}" ${done ? "disabled" : ""}>${m.map[i] !== undefined ? `<span class="tag">${i + 1}</span>` : ""}${esc(p[0])}</button>`).join("")}</div>
        <div class="col">${q.rightOrder.map(j => `<button data-mr="${j}" data-pfx="${pfx}" class="${inv[j] !== undefined ? "paired" : ""} ${marks && inv[j] !== undefined ? (marks[inv[j]] ? "ok" : "ko") : ""}" ${done ? "disabled" : ""}>${inv[j] !== undefined ? `<span class="tag">${inv[j] + 1}</span>` : ""}${esc(q.pairs[j][1])}</button>`).join("")}</div></div>`;
  }
  function itemHTML2(q, pfx, st) {
    const k = q.kind || "mcq", done = st.done;
    if (k === "cloze") {
      let gi = 0; const marks = done && st.res ? st.res.marks : null; const resp = st.resp || [];
      return `${q.title && !st.exam ? `<h3>${esc(q.title)}</h3>` : ""}<div class="clozetext">${q.parts.map(p => {
        if (typeof p === "string") return esc(p);
        const i = gi++; const mk = marks ? marks[i] : null; const ok = mk === true || (mk && mk.correct); const cls = marks ? (ok ? "okg" : "kog") : "";
        const fix = marks && !ok ? `<span class="fix">→ ${esc(p.opts ? p.answer : p.accept[0])}</span>` : "";
        if (p.opts) { const order = app.ui["cz" + pfx + i] || (app.ui["cz" + pfx + i] = p.opts.slice().sort(() => Math.random() - 0.5));
          return `<span class="g">${i + 1}</span><select id="${pfx}g${i}" class="${cls}" ${done ? "disabled" : ""} aria-label="Trou ${i + 1}"><option value="">…</option>${order.map(o => `<option ${resp[i] === o ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>${fix}`; }
        return `<span class="g">${i + 1}</span><input id="${pfx}g${i}" class="${cls}" type="text" value="${esc(resp[i] || "")}" ${done ? "disabled" : ""} autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Trou ${i + 1}">${fix}`;
      }).join("")}</div>`;
    }
    if (k === "passage") {
      const sel = app.sub[pfx] || (app.sub[pfx] = []); const marks = done && st.res ? st.res.marks : null;
      const textBlock = q.audio
        ? `<div class="stack"><div class="row">${sayDialogueBtn(q.lines, q.lang, "Écouter")}<button class="say" data-dlgslow="${dlgStore.length - 1}" data-lang="${q.lang}">${icon("sound")}Plus lentement</button></div>
            ${done || !TTS.ok ? `<div class="passage">${!TTS.ok && !done ? `<p class="notice">Synthèse vocale indisponible : transcription affichée.</p>` : ""}${q.lines.map(l => `<div class="line"><b>${esc(l[0])}</b>${esc(l[1])}</div>`).join("")}</div>` : `<p class="xs muted">Transcription affichée après la correction. Vous pouvez réécouter autant que nécessaire.</p>`}</div>`
        : `<div class="passage">${q.genre ? `<span class="chip pill-terra" style="justify-self:start">${esc(q.genre)}</span>` : ""}${q.title ? `<h3>${esc(q.title)}</h3>` : ""}<p>${esc(q.text).replace(/ — /g, "<br>")}</p></div>`;
      return `${textBlock}<div>${q.subqs.map((s, i) => `<div class="subq"><b>${i + 1}. ${esc(s.q)}</b><div class="opts">${s.opts.map((o, j) => {
        let cls = ""; if (marks) { if (j === s.ans) cls = "ok"; else if (j === sel[i]) cls = "ko"; } else if (j === sel[i]) cls = "sel";
        return `<button class="opt ${cls}" data-sq="${i}|${j}" data-pfx="${pfx}" ${done ? "disabled" : ""}><span class="k">${"ABCD"[j]}</span><span class="t">${esc(o)}</span></button>`; }).join("")}</div></div>`).join("")}</div>`;
    }
    if (k === "writing") {
      const r = st.resp || {}; const words = String(r.text || "").trim().split(/\s+/).filter(Boolean).length;
      return `<div class="notice info">${esc(q.task)}</div>
        <textarea class="inp" id="${pfx}wt" rows="8" ${done ? "disabled" : ""} lang="${esc(q.lang)}" aria-label="Votre texte" placeholder="Écrivez votre texte ici (${q.min}–${q.max} mots).">${esc(r.text || "")}</textarea>
        <span class="wcount ${words >= q.min && words <= q.max * 1.15 ? "ok" : "ko"}" id="${pfx}wc" data-min="${q.min}" data-max="${q.max}">${words} mot${words > 1 ? "s" : ""} · attendu ${q.min}–${q.max}</span>
        <div class="fb-block"><h4>Grille d'auto-évaluation : cochez ce que votre texte respecte</h4><div class="checks">${q.criteria.map((c, i) => `<label><input type="checkbox" id="${pfx}ck${i}" ${(r.ticks || [])[i] ? "checked" : ""} ${done ? "disabled" : ""}>${esc(c)}</label>`).join("")}</div></div>
        ${done ? `<div class="fb-block"><h4>Texte modèle</h4><div class="model" lang="${esc(q.lang)}">${esc(q.model)}</div></div>
          <p class="xs muted">Correction automatique détaillée (grammaire, lexique, cohérence) : nécessite un service d'IA externe, non branché dans cette maquette. Ici, la note combine la longueur et votre auto-évaluation guidée.</p>` : ""}`;
    }
    return "";
  }
  function collect(q, pfx) {
    const k = q.kind || "mcq", $ = id => document.getElementById(pfx + id);
    if (k === "input") return ($("in") || {}).value || "";
    if (k === "match") { const m = app.match[pfx] || { map: {} }; return q.pairs.map((_, i) => m.map[i] !== undefined ? m.map[i] : null); }
    if (k === "cloze") return q.parts.filter(p => typeof p !== "string").map((p, i) => ($("g" + i) || {}).value || "");
    if (k === "passage") return (app.sub[pfx] || []).slice(0, q.subqs.length);
    if (k === "writing") return { text: ($("wt") || {}).value || "", ticks: q.criteria.map((_, i) => !!($("ck" + i) || {}).checked) };
    return null;
  }
  function complete(q, resp) {
    const k = q.kind || "mcq";
    if (k === "input") return String(resp).trim() ? "" : "Écrivez votre réponse avant de valider.";
    if (k === "match") return resp.every(x => x !== null) ? "" : "Associez tous les mots avant de valider.";
    if (k === "passage") return q.subqs.every((_, i) => resp[i] !== undefined && resp[i] !== null) ? "" : "Répondez à toutes les questions avant de valider.";
    if (k === "writing") return String(resp.text).trim().split(/\s+/).filter(Boolean).length >= 5 ? "" : "Écrivez au moins quelques phrases avant de valider.";
    return "";
  }
  function inputFeedback(q, res, resp) {
    if (res.correct) return `${res.accents ? `<p class="notice">Accepté, mais attention aux accents : <b>${esc(res.best)}</b>.</p>` : ""}${q.accept && q.accept.length > 1 ? `<p class="xs muted">Autres formulations acceptées : ${q.accept.filter(a => U.norm(a) !== U.norm(resp)).slice(0, 3).map(esc).join(" · ")}</p>` : ""}`;
    return `<div class="fb-block"><h4>Votre réponse comparée à la correction</h4><div class="diffline">${(res.diff || []).map(t => `<span class="${t.s}" title="${{ ok: "Correct", acc: "Accent à corriger", miss: "Manquant", extra: "En trop" }[t.s]}">${esc(t.t)}</span>`).join("") || `<span class="miss">${esc(res.best)}</span>`}</div>
      <p>Réponse attendue : <b>${esc(res.best)}</b>${res.near ? " — vous y étiez presque." : ""}</p><p class="xs muted">Vert : correct · jaune : accent · rouge : manquant · barré : en trop.</p></div>`;
  }
  Object.assign(UI, { itemHTML, collect, complete, inputFeedback, promptHTML, diffDots, natureChip });

  // ---------- Quiz ----------
  const MODE_NAMES = { libre: "Mode libre", dix: "10 questions", aleatoire: "Aléatoire", monde: "Mode Monde", marathon: "Marathon", expert: "Expert", revision: "Révision", examen: "Examen", categorie: "Catégorie",
    defi: "Défi quotidien", situation: "Situation", documents: "Documents", langue: "Langue", dict: "Révision du dictionnaire", lacune: "Lacune ciblée", placement: "Test de niveau", dyk: "Le saviez-vous" };
  UI.MODE_NAMES = MODE_NAMES;
  function startQuiz(cfg, sess) {
    app.sess = sess || new E.Session(store, cfg);
    if (cfg && cfg.mode === "aleatoire") app.sess.levelFor = function (cat) { return 1 + this.r.int(E.CAT[cat].lang ? 6 : 5); };
    app.result = null; app.custom = null; app.examLeft = (cfg && cfg.examSeconds) || 0; app.lastCfg = cfg;
    nextQuestion();
  }
  function nextQuestion() {
    app.q = app.sess.next(); app.sel = null; app.done = false; app.res = null; app.resp = null; app.report = false; app.gloss = false; app.t0 = Date.now();
    app.match = {}; app.sub = {}; app.ui = {};
    if (!app.q) return finishQuiz();
    app.left = app.sess.cfg.perQuestion || 0;
    if (location.hash !== "#jouer") { app.returnTo = route(); history.replaceState(null, "", "#jouer"); }
    render();
  }
  let tickId = null;
  function stopTick() { if (tickId) { clearInterval(tickId); tickId = null; } }
  function startTick() {
    stopTick(); const c = app.sess.cfg;
    if (!c.perQuestion && !c.examSeconds) return;
    tickId = setInterval(() => {
      if (c.examSeconds) { app.examLeft--; if (app.examLeft <= 0) { stopTick(); return finishQuiz(); } }
      if (c.perQuestion && !app.done) { app.left--; if (app.left <= 0) { validate(-1); return; } }
      const t = document.getElementById("timer");
      if (t) { const v = c.examSeconds ? app.examLeft : app.left; t.textContent = Math.floor(v / 60) + ":" + String(v % 60).padStart(2, "0"); t.classList.toggle("low", v <= (c.examSeconds ? 60 : 5)); }
    }, 1000);
  }
  UI.stopTick = stopTick;
  function renderQuiz() {
    const s = app.sess, c = s.cfg, q = app.q, exam = c.mode === "examen" || !!c.noFeedback, k = q.kind || "mcq";
    const total = c.count || 0; const prog = total ? (s.items.length - (app.done ? 0 : 1)) / total * 100 : 0;
    const timerV = c.examSeconds ? app.examLeft : c.perQuestion ? app.left : null;
    const st = { done: app.done, res: app.res, resp: app.resp, sel: app.sel, exam };
    const canValidate = k !== "mcq" || app.sel !== null;
    const cat = E.CAT[q.cat] || { short: "" };
    root.innerHTML = `<div class="quiz">
      <div class="qhead"><button class="btn ghost icon" data-act="quit" aria-label="Quitter">${icon("x")}</button>
        ${total ? `<div class="progress" role="progressbar" aria-valuenow="${Math.round(prog)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${prog}%"></i></div><span class="mono" style="font-size:.85rem">${q.n}/${total}</span>`
          : `<div style="flex:1" class="row"><span class="mono">Question ${q.n}</span>${c.lives ? `<span class="lives" aria-label="${c.lives - s.wrong} vies restantes">${"♥".repeat(Math.max(0, c.lives - s.wrong))}${"♡".repeat(s.wrong)}</span>` : ""}</div>`}
        ${timerV !== null ? `<span class="timer" id="timer">${Math.floor(timerV / 60)}:${String(timerV % 60).padStart(2, "0")}</span>` : ""}</div>
      <div class="row between small"><span class="muted">${esc(c.title || MODE_NAMES[c.mode] || "")}${c.iso && BY[c.iso] ? " · " + esc(BY[c.iso].name) : ""}</span>${s.streak >= 3 && !exam ? `<span class="streakfx">${icon("flame")} ${s.streak} d'affilée</span>` : ""}</div>
      ${q.situation && q.n === 1 ? `<div class="card flat stack"><span class="eyebrow">Situation</span><h2>${esc(q.situation)}</h2><p>${esc(q.context)}</p></div>` : ""}
      <div class="card qcard cat-${q.cat}">
        <div class="qmeta"><span class="chip"><span class="dot catmark"></span>${esc(cat.short)} · ${esc(q.topic || q.sub)}</span>${diffDots(q)}${natureChip(q)}${q.review ? '<span class="chip pill-brass">Révision</span>' : ""}${q.renewed ? '<span class="chip">Déjà vue</span>' : ""}${q.deep ? '<span class="chip pill-terra">Raisonnement</span>' : ""}</div>
        <div class="qtext">${esc(q.q)}</div>
        ${promptHTML(q)}
        ${itemHTML(q, "q", st)}
        ${app.done && !exam ? feedbackHTML(q) : ""}
        <div class="qfoot"><span class="kbd">${k === "mcq" ? "Touches 1-4 pour choisir · " : ""}Entrée pour ${app.done ? "continuer" : "valider"}</span>
          ${app.done ? `<button class="btn primary lg" data-act="next">${(c.count && s.items.length >= c.count) || (c.lives && s.wrong >= c.lives) ? "Voir les résultats" : "Continuer"}</button>`
            : `<button class="btn primary lg" data-act="validate" ${canValidate ? "" : "disabled"}>${exam ? "Valider et continuer" : "Valider"}</button>`}</div>
      </div></div>`;
    startTick();
    if (!app.done && k === "input") { const el = document.getElementById("qin"); if (el && matchMedia("(hover: hover)").matches) el.focus(); }
    if (app.done) { const f = document.querySelector(".feedback"); if (f && innerWidth < 1000) f.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
  }
  function feedbackHTML(q) {
    const res = app.res || {}, k = q.kind || "mcq";
    const ok = res.correct, mid = !ok && res.score > 0;
    const timeout = app.sel === -1;
    const ansText = k === "mcq" ? (q.optFlags ? (BY[q.opts[q.ans]] ? "le drapeau " + BY[q.opts[q.ans]].du : q.opts[q.ans]) : q.opts[q.ans]) : "";
    const scoreTxt = ["cloze", "passage"].includes(k) ? ` <small>${res.n}/${res.total} juste${res.n > 1 ? "s" : ""}</small>` : k === "match" ? ` <small>${Math.round(res.score * 5)}/5</small>` : k === "writing" ? ` <small>${res.words} mots · score ${Math.round(res.score * 100)} %</small>` : "";
    const verdict = k === "writing" ? "Texte enregistré." : ok ? "Bonne réponse." : timeout ? "Temps écoulé." : mid ? "En partie juste." : "Pas cette fois.";
    const add = q.addWord ? (F.Dict.exists(store.s, q.addWord) ? `<span class="chip pill-sage">${icon("check")} Dans votre dictionnaire</span>` : `<button class="btn sm" data-act="addword">${icon("plus")} Ajouter au dictionnaire</button>`) : "";
    return `<div class="feedback" role="status">
      <div class="verdict ${ok ? "ok" : mid ? "mid" : k === "writing" ? "mid" : "ko"}">${verdict}${k === "mcq" ? ` <small>Réponse : ${q.optFlags ? U.flag(q.opts[q.ans]) + " " : ""}${esc(ansText)}</small>` : scoreTxt}</div>
      ${k === "input" ? inputFeedback(q, res, app.resp) : ""}
      ${q.ex ? `<div class="fb-block"><h4>Explication</h4><p>${esc(q.ex)}</p></div>` : ""}
      ${q.conjTable ? `<div class="fb-block"><h4>${esc(q.conjTable.verb)} · ${esc(q.conjTable.tense.toLowerCase())}</h4><div class="conj">${q.conjTable.forms.map((f, i) => `<span>${esc(D.LANG.es.persons[i])}</span><b>${esc(f)}</b>`).join("")}</div></div>` : ""}
      ${q.info ? `<div class="fb-block"><h4>Le saviez-vous ?</h4><p>${esc(q.info)}</p></div>` : ""}
      ${q.ctx ? `<div class="fb-block"><h4>Pour aller plus loin</h4><p>${esc(q.ctx)}</p></div>` : ""}
      <div class="row">${q.say ? sayBtn(q.say.text, q.say.lang, q.sayAfter ? "Écouter la phrase" : "Réécouter") : ""}${q.audioOnly ? sayBtn(q.audioOnly.text, q.audioOnly.lang, "Réécouter : " + q.audioOnly.text) : ""}${add}
        ${q.nature !== "lang" ? `<button class="btn sm" data-act="glossform">${icon("bulb")} Ajouter au glossaire</button>` : ""}
        ${q.iso && BY[q.iso] ? `<a class="btn sm" href="#pays-${q.iso.toLowerCase()}" data-act="quit-to">${flag(q.iso)} Fiche ${esc(BY[q.iso].name)}</a>` : ""}</div>
      ${app.gloss ? glossForm(q) : ""}
      <div class="fb-src">${q.src ? `<span>Source : ${esc(q.src)}</span>` : ""}${q.asOf ? `<span>Vérifié : ${esc(U.asOfLabel(q.asOf))}</span>` : ""}<span class="mono">ID ${esc(q.fp)}</span>
        <button class="btn ghost sm" style="margin-left:auto" data-act="report">${icon("flag")} Signaler une erreur</button></div>
      ${app.report ? `<div class="stack card flat"><label class="field" for="rep-reason">Que se passe-t-il ?<select id="rep-reason"><option>La réponse est fausse</option><option>L'information est obsolète</option><option>La question est ambiguë</option><option>Faute ou formulation</option></select></label>
        <label class="field" for="rep-note">Précisions (facultatif)<textarea id="rep-note" rows="2"></textarea></label><div><button class="btn" data-act="sendreport">Envoyer le signalement</button></div></div>` : ""}
    </div>`;
  }
  function glossForm(q) {
    return `<div class="card flat stack"><b>Nouvelle notion dans votre glossaire</b>
      <div class="formgrid"><label class="field">Notion<input id="gl-n" placeholder="Ex. : PIB par habitant" value="${esc(q.topic || "")}"></label>
      <label class="field">Catégorie<input id="gl-c" value="${esc(catLabel(q.cat))}"></label><label class="field full">Définition<textarea id="gl-d" rows="3">${esc(q.ex || "")}</textarea></label>
      <label class="field full">Exemple (facultatif)<input id="gl-e" value="${esc(q.info ? q.info.slice(0, 160) : "")}"></label></div>
      <div class="row"><button class="btn primary sm" data-act="glosssave">Enregistrer</button><button class="btn ghost sm" data-act="glossform">Annuler</button></div></div>`;
  }
  function select(i) { if (app.done || !app.q) return; app.sel = i; if (store.s.profile.oneTap && app.sess.cfg.mode !== "examen") return validate(i); renderQuiz(); }
  function validate(i) {
    if (app.done || !app.q) return;
    const q = app.q, k = q.kind || "mcq";
    let resp;
    if (k === "mcq") { if (i === undefined) i = app.sel; if (i === null || i === undefined) return; app.sel = i; resp = i; }
    else if (i === -1) resp = k === "input" ? "" : k === "writing" ? { text: "", ticks: [] } : [];
    else { resp = collect(q, "q"); const msg = complete(q, resp); if (msg) { toast(msg); return; } }
    app.resp = resp;
    app.res = app.sess.answer(resp, Date.now() - app.t0);
    save();
    if (app.sess.cfg.mode === "examen" || app.sess.cfg.noFeedback) return nextQuestion();
    app.done = true; renderQuiz(); renderNav();
  }
  function finishQuiz() {
    stopTick();
    const s = app.sess; if (!s) return;
    const res = s.finish();
    if (s.cfg.mode === "examen" && s.cfg.count) { const missing = s.cfg.count - res.summary.n; if (missing > 0) { res.summary.unanswered = missing; res.summary.score20 = Math.round(res.summary.correct / s.cfg.count * 200) / 10; } }
    app.result = Object.assign(res, { exhausted: s.exhausted, cfg: s.cfg });
    app.sess = null; app.q = null; save(); render();
    (res.earned || []).forEach((b, i) => setTimeout(() => toast(`<span style="color:var(--sun)">${icon("medal")}</span><span>Badge obtenu : <b>${esc(b.name)}</b></span>`), 400 + i * 1800));
  }
  function quitQuiz() { stopTick(); if (app.sess && app.sess.items.some(i => i.chosen !== null)) { finishQuiz(); return; } app.sess = null; app.q = null; leavePlay(); }
  function leavePlay() { if (location.hash === "#jouer") history.replaceState(null, "", "#" + (app.returnTo || "accueil")); render(); }
  UI.leavePlay = leavePlay;
  Object.assign(UI, { startQuiz, nextQuestion, finishQuiz, validate, select, quitQuiz });

  // ---------- Résultats ----------
  function answerText(q) {
    const k = q.kind || "mcq";
    if (k === "mcq") return q.optFlags ? (BY[q.opts[q.ans]] || {}).name : q.opts[q.ans];
    if (k === "input") return q.accept[0];
    if (k === "match") return q.pairs.map(p => p[0] + " = " + p[1]).join(" · ");
    if (k === "cloze") return q.parts.filter(p => typeof p !== "string").map((p, i) => (i + 1) + ". " + (p.opts ? p.answer : p.accept[0])).join(" · ");
    if (k === "passage") return q.subqs.map((s, i) => (i + 1) + ". " + s.opts[s.ans]).join(" · ");
    return "Texte libre (voir le modèle)";
  }
  function yourText(it) {
    const q = it.q, k = q.kind || "mcq", c = it.chosen;
    if (c === -1) return "Temps écoulé"; if (c === null || c === undefined) return "Sans réponse";
    if (k === "mcq") return q.optFlags ? (BY[q.opts[c]] || {}).name : q.opts[c];
    if (k === "input") return c || "(vide)";
    if (k === "writing") return (c.text || "").slice(0, 120) + ((c.text || "").length > 120 ? "…" : "");
    return Math.round((it.score || 0) * 100) + " % de juste";
  }
  function correctionList(items) {
    return items.map((it, k) => {
      const q = it.q, ok = it.correct, mid = !ok && it.score > 0;
      return `<details class="corr"><summary><span class="res-ic ${ok ? "ok" : mid ? "mid" : "ko"}">${ok ? "✓" : mid ? "½" : "✗"}</span><span style="flex:1;min-width:0"><b>${k + 1}.</b> ${esc(q.q)}${q.prompt ? " — " + esc(q.prompt) : ""}${q.flagPrompt ? " " + U.flag(q.flagPrompt) : ""}${q.bigEmoji ? " " + q.bigEmoji : ""}<br>
        <span class="muted small">Réponse : ${esc(answerText(q))}${ok ? "" : " · Vous : " + esc(yourText(it))}</span></span>${diffDots(q)}</summary>
        <div class="cat-${q.cat}">${q.doc ? docHTML(q.doc) : ""}<p>${esc(q.ex)}</p>${q.info ? `<p class="muted">${esc(q.info)}</p>` : ""}${q.model ? `<div class="model">${esc(q.model)}</div>` : ""}
        <p class="xs muted">${q.src ? "Source : " + esc(q.src) : ""}${q.asOf ? " · vérifié " + esc(U.asOfLabel(q.asOf)) : ""}</p></div></details>`;
    }).join("");
  }
  UI.correctionList = correctionList;
  function badgeHTML(b, got) { return `<div class="badge ${got ? "" : "locked"}"><span class="medal">${icon("medal")}</span><b>${esc(b.name)}</b><span>${esc(b.desc)}</span></div>`; }
  UI.badgeHTML = badgeHTML;
  function renderResult() {
    const r = app.result, s = r.summary, exam = s.mode === "examen", cfg = r.cfg || {};
    const n = exam && s.unanswered ? s.n + s.unanswered : s.n;
    const p = Math.round(s.score20 * 5);
    const mention = exam ? (s.score20 >= 16 ? "Très bien" : s.score20 >= 14 ? "Bien" : s.score20 >= 12 ? "Assez bien" : s.score20 >= 10 ? "Admis" : "Non admis") : null;
    const wrong = s.items.filter(i => !i.correct).length;
    const daily = cfg.daily ? F.DAILY_PLAN.map((pl, i) => { const its = s.items.slice(F.DAILY_PLAN.slice(0, i).reduce((a, x) => a + x.n, 0)).slice(0, pl.n); return `<div class="hbar"><span>${pl.name}</span><div class="bar"><i style="width:${pct(its.filter(x => x.correct).length, its.length)}%"></i></div><span class="n">${its.filter(x => x.correct).length}/${its.length}</span></div>`; }).join("") : "";
    root.innerHTML = `<div class="wrap narrow">
      ${UI.resultExtra ? UI.resultExtra(r) : ""}
      <div class="card stack" style="gap:16px"><span class="eyebrow">${esc(cfg.title || MODE_NAMES[s.mode] || "Session")} · terminé</span>
        <div class="score"><span class="big">${exam ? s.score20.toLocaleString("fr-FR") + "<span style='font-size:1.4rem;color:var(--muted)'>/20</span>" : s.correct + "<span style='font-size:1.4rem;color:var(--muted)'>/" + n + "</span>"}</span>
          <div class="stack" style="gap:4px">${exam ? `<span class="chip ${s.score20 >= 10 ? "pill-good" : "pill-warn"}" style="justify-self:start">${mention}</span>` : ""}<span><b>${p} %</b> de réussite · ${fmtTime(s.end - s.start)} · meilleure série ${s.bestStreak}</span>
          ${s.unanswered ? `<span class="muted">${s.unanswered} question${s.unanswered > 1 ? "s" : ""} non traitée${s.unanswered > 1 ? "s" : ""}.</span>` : ""}
          ${r.exhausted ? `<span class="notice">Toutes les questions inédites de cette sélection ont été vues. Élargissez les catégories ou le niveau.</span>` : ""}
          ${s.renewed ? `<span class="muted small">${s.renewed} question${s.renewed > 1 ? "s" : ""} déjà vue${s.renewed > 1 ? "s" : ""} reproposée${s.renewed > 1 ? "s" : ""} faute de stock inédit.</span>` : ""}</div></div>
        ${daily ? `<div class="stack">${daily}<p class="xs muted">Le défi est le même pour tout le monde aujourd'hui ; un nouveau défi est proposé demain.</p></div>` : ""}
        ${r.earned && r.earned.length ? `<div class="badges">${r.earned.map(b => badgeHTML(b, true)).join("")}</div>` : ""}
        <div class="row">${cfg.daily || cfg.fixed ? "" : `<button class="btn primary" data-act="again">Rejouer</button>`}${wrong && !cfg.dictMode ? `<button class="btn" data-act="review">${icon("redo")} Réviser mes erreurs</button>` : ""}<button class="btn ghost" data-act="home">Retour à l'accueil</button></div>
      </div>
      <div class="stack"><h2>Correction complète</h2>${correctionList(s.items)}</div></div>`;
  }

  // ---------- Événements ----------
  UI.on = (name, fn) => { UI.acts[name] = fn; };
  UI.onData = (attr, fn) => { UI.attrs[attr] = fn; };
  document.addEventListener("click", e => {
    const t = e.target.closest("button, a, [data-go], path[data-iso], circle[data-iso]"); if (!t) return;
    const d = t.dataset;
    if (t.tagName === "A" && !d.act && t.getAttribute("href") === (location.hash || "#accueil")) {
      e.preventDefault(); if (app.sess && app.sess.items.some(i => i.chosen !== null)) app.sess.finish();
      app.sess = null; app.q = null; app.result = null; app.custom = null; render(); return;
    }
    if (d.say !== undefined) { TTS.speak(d.say, d.lang, { slow: /lentement/i.test(t.textContent) }); return; }
    if (d.dlg !== undefined) { TTS.dialogue(dlgStore[+d.dlg], d.lang); return; }
    if (d.dlgslow !== undefined) { TTS.dialogue(dlgStore[+d.dlgslow], d.lang, 0.72); return; }
    if (d.ins) { const el = document.getElementById(d.tgt); if (el) { const p = el.selectionStart || el.value.length; el.value = el.value.slice(0, p) + d.ins + el.value.slice(el.selectionEnd || p); el.focus(); el.setSelectionRange(p + 1, p + 1); } return; }
    if (d.opt !== undefined && app.q) return select(+d.opt);
    if (d.ml !== undefined || d.mr !== undefined) {
      const m = app.match[d.pfx] || (app.match[d.pfx] = { left: null, map: {} });
      if (d.ml !== undefined) { const i = +d.ml; if (m.map[i] !== undefined) { delete m.map[i]; m.left = null; } else m.left = m.left === i ? null : i; }
      else { const j = +d.mr; const owner = Object.keys(m.map).find(k => m.map[k] === j); if (owner !== undefined) delete m.map[owner]; else if (m.left !== null) { m.map[m.left] = j; m.left = null; } }
      const box = t.closest(".match"); const q = d.pfx === "q" ? app.q : (UI.itemByPfx && UI.itemByPfx(d.pfx)); if (box && q) box.outerHTML = matchBlock(q, d.pfx, false, null);
      return;
    }
    if (d.sq !== undefined) { const [i, j] = d.sq.split("|").map(Number); const arr = app.sub[d.pfx] || (app.sub[d.pfx] = []); arr[i] = j; t.parentElement.querySelectorAll(".opt").forEach((b, k) => b.classList.toggle("sel", k === j)); return; }
    for (const a in UI.attrs) if (d[a] !== undefined) { UI.attrs[a](d[a], t, e); return; }
    const a = d.act; if (!a) return;
    if (UI.acts[a]) { UI.acts[a](t, e); return; }
  });
  UI.on("sheet", () => { app.sheet = !app.sheet; renderNav(); });
  UI.on("sheetgo", () => { app.sheet = false; renderNav(); });
  UI.on("validate", () => validate());
  UI.on("next", () => nextQuestion());
  UI.on("quit", () => quitQuiz());
  UI.on("quit-to", (t, e) => { e.preventDefault(); const h = t.getAttribute("href"); if (app.sess) { app.sess.finish(); app.sess = null; app.q = null; stopTick(); } location.hash = h; });
  UI.on("report", () => { app.report = !app.report; renderQuiz(); });
  UI.on("sendreport", () => { const q = app.q; store.s.reports.push({ fp: q.fp, q: q.q, reason: document.getElementById("rep-reason").value, note: document.getElementById("rep-note").value, ts: Date.now() }); save(); app.report = false; renderQuiz(); toast("Merci. Le signalement est enregistré dans votre profil."); });
  UI.on("addword", () => { const w = app.q.addWord; try { const r = F.Dict.add(store.s, Object.assign({ ex: app.q.say ? app.q.say.text : "" }, w)); save(); toast(r.dup ? "Ce mot est déjà dans votre dictionnaire." : `<b>${esc(w.fr)}</b> ajouté au dictionnaire. Il reviendra dans vos révisions.`); renderQuiz(); renderNav(); } catch (err) { toast(esc(err.message)); } });
  UI.on("glossform", () => { app.gloss = !app.gloss; renderQuiz(); });
  UI.on("glosssave", () => { try { F.Gloss.add(store.s, { notion: document.getElementById("gl-n").value, def: document.getElementById("gl-d").value, ex: document.getElementById("gl-e").value, cat: document.getElementById("gl-c").value }); save(); app.gloss = false; renderQuiz(); toast("Notion ajoutée au glossaire."); } catch (err) { toast(esc(err.message)); } });
  UI.on("again", () => { const cfg = Object.assign({}, app.result.cfg); delete cfg.seed; app.result = null; startQuiz(cfg); });
  UI.on("home", () => { app.result = null; app.custom = null; go("accueil"); });
  document.addEventListener("input", e => {
    const el = e.target;
    if (el.id && /wt$/.test(el.id)) { const pfx = el.id.slice(0, -2); const c = document.getElementById(pfx + "wc"); if (c) { const n = el.value.trim().split(/\s+/).filter(Boolean).length; const min = +c.dataset.min, max = +c.dataset.max; c.textContent = `${n} mot${n > 1 ? "s" : ""} · attendu ${min}–${max}`; c.className = "wcount " + (n >= min && n <= max * 1.15 ? "ok" : "ko"); } }
    if (el.matches && el.matches("select") && app.q) { /* rien */ }
  });
  document.addEventListener("keydown", e => {
    if (!app.sess || !app.q) return;
    const inField = /input|textarea|select/i.test(e.target.tagName);
    const k = e.key.toLowerCase(), map = { "1": 0, "2": 1, "3": 2, "4": 3, a: 0, b: 1, c: 2, d: 3 };
    if (!inField && k in map && !app.done && (app.q.kind || "mcq") === "mcq") { e.preventDefault(); select(map[k]); }
    else if (k === "enter" && !(e.target.tagName === "TEXTAREA" && app.q.kind === "writing") && !e.shiftKey) { e.preventDefault(); if (app.done) nextQuestion(); else validate(); }
  });
  document.addEventListener("pointermove", e => {
    const t = e.target.closest && e.target.closest("[data-tip]"); let tip = document.querySelector(".tip");
    if (!t) { if (tip) tip.remove(); return; }
    if (!tip) { tip = document.createElement("div"); tip.className = "tip"; document.body.appendChild(tip); }
    tip.textContent = t.dataset.tip; tip.style.left = Math.max(8, Math.min(e.clientX + 12, innerWidth - tip.offsetWidth - 8)) + "px"; tip.style.top = (e.clientY - 40) + "px";
  });
  window.addEventListener("hashchange", () => {
    if (location.hash === "#jouer" && (app.sess || app.custom)) return;
    if (app.sess) { if (app.sess.items.some(i => i.chosen !== null)) app.sess.finish(); app.sess = null; app.q = null; }
    if (app.customExit) { app.customExit(); app.customExit = null; }
    app.custom = null; app.result = null; render();
  });
  // Thème
  function setTheme(t) { if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; store.s.settings.theme = t; save(); }
  UI.setTheme = setTheme;
  if (store.s.settings.theme && store.s.settings.theme !== "auto") document.documentElement.dataset.theme = store.s.settings.theme;
  UI.boot = () => { if (location.hash === "#jouer") history.replaceState(null, "", "#accueil"); render(); };
})();
