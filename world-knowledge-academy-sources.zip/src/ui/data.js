/* World Knowledge Academy — Données et sources : état des bases, sources et licences, fraîcheur, contrôle qualité,
 * et dictionnaire de référence (traductions recoupées des bases de vocabulaire). */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, U, F, esc, icon, toast, save } = UI;
  const DBX = D.DB;
  const n = v => Number(v || 0).toLocaleString("fr-FR");
  const ST = [["verified", "Vérifié", "var(--good)"], ["cross_checked", "Recoupé", "var(--sage)"], ["source_trusted", "Source de référence", "var(--petrol)"], ["editorial", "Rédigé", "var(--brass)"],
    ["auto", "Automatique", "var(--sea)"], ["estimated", "Estimé", "var(--sun)"], ["needs_review", "À revoir", "var(--warn)"], ["conflict", "Conflit", "var(--bad)"], ["stale", "Périmé", "var(--terra)"]];
  const RULES = { duplicate: "doublon", answer_contradicts_data: "réponse contredite par les données", missing_source: "source absente", stale: "donnée périmée", answer_not_in_choices: "réponse absente des propositions",
    provenance_missing: "provenance inconnue", broken_text: "texte cassé", required_fields: "champ manquant", verification_date: "date de vérification invalide" };
  const ds = () => app.ui.dbdata || (app.ui.dbdata = { q: "", lang: "en" });
  const fmtD = s => s ? new Date(s + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" }) : "—";

  function bar(status) {
    const tot = Object.values(status || {}).reduce((a, b) => a + b, 0); if (!tot) return `<span class="small muted">—</span>`;
    return `<div class="stbar" role="img" aria-label="${ST.filter(([k]) => status[k]).map(([k, l]) => `${l} ${Math.round(status[k] / tot * 100)} %`).join(", ")}">${ST.filter(([k]) => status[k]).map(([k, l, c]) => `<i style="flex:${status[k]};background:${c}" title="${l} : ${n(status[k])}"></i>`).join("")}</div>`;
  }
  function dictRows() {
    const s = ds(), q = U.norm(s.q || ""); if (q.length < 2) return `<p class="small muted">Tapez au moins deux lettres.</p>`;
    const list = (DBX.dict[s.lang] || []); const exact = [], starts = [], fr = [];
    for (const w of list) { const a = U.norm(w[0]), f = U.norm(w[3]); if (a === q || f === q) exact.push(w); else if (a.startsWith(q)) starts.push(w); else if (f.startsWith(q)) fr.push(w); if (exact.length + starts.length + fr.length > 60) break; }
    const res = exact.concat(starts, fr).slice(0, 30);
    if (!res.length) return `<p class="small muted">Aucun mot recoupé ne correspond. La base complète en contient davantage, mais seules les traductions confirmées par deux sources sont embarquées dans l'application.</p>`;
    return `<div class="stack" style="gap:6px">${res.map((w, i) => `<div class="dline"><div><b>${esc(w[0])}</b>${w[4] ? ` <span class="mono small muted">/${esc(w[4])}/</span>` : ""} <span class="small muted">${esc(w[1])}${w[7] ? " " + esc(w[7]) : ""}</span></div>
      <div>${esc(w[3])}</div><div class="row nowrap" style="gap:6px"><span class="chip">${esc(w[2] || "?")}</span><span class="chip" title="${w[6] === "v" ? "Vérifié sur l'étalon de l'application" : "Recoupé par deux sources indépendantes"}">${w[6] === "v" ? "vérifié" : "recoupé"}</span>
      <button class="btn ghost sm icon" data-dbadd="${s.lang}|${esc(w[0])}|${i}" aria-label="Ajouter « ${esc(w[0])} » à mon dictionnaire">${icon("plus")}</button></div></div>`).join("")}</div>`;
  }

  UI.views.donnees = function () {
    if (!DBX) { root.innerHTML = `<div class="wrap narrow"><div class="empty">Les bases de données n'ont pas été exportées dans cette version.</div></div>`; return; }
    const s = ds(), Q = DBX.quiz || {}, IA = DBX.in_app || {};
    const tiles = [["Lignes dans les bases", n(DBX.sqlite && DBX.sqlite.total_rows)], ["Questions validées", n((Q.accepted || 0) + (Q.imported || 0))], ["Questions des bases dans l'appli", n(IA.questions)], ["Sources documentées", DBX.sources.length]];
    root.innerHTML = `<div class="wrap">
      <div class="pagehead"><span class="eyebrow">À propos des contenus</span><h1>Données et sources</h1>
        <p>Chaque donnée de l'application vient d'une source identifiée, avec sa licence, sa date de récupération, l'année à laquelle elle se rapporte et un statut de vérification. Une donnée en conflit, à revoir ou périmée ne produit aucune question. État au ${fmtD(DBX.built_at)}.</p></div>
      <div class="grid g4">${tiles.map(([l, v]) => `<div class="card tile"><span class="v">${v}</span><span class="l">${l}</span></div>`).join("")}</div>

      <div class="card stack"><div class="row between"><h2>Les 16 bases</h2><div class="stlegend">${ST.map(([, l, c]) => `<span><i style="background:${c}"></i>${l}</span>`).join("")}</div></div>
        <div class="scroll-x"><table class="data"><thead><tr><th>Base</th><th class="n">Lignes</th><th style="min-width:180px">Vérification</th><th class="n">Périmé</th><th class="n">Signalements</th></tr></thead><tbody>
        ${DBX.bases.map(b => `<tr><td>${esc(b.label)}</td><td class="n">${n(b.rows)}</td><td>${bar(b.status)}</td><td class="n">${b.stale ? `<b style="color:var(--terra)">${n(b.stale)}</b>` : "0"}</td><td class="n" title="erreurs / avertissements / informations">${n((b.issues || {}).error)} / ${n((b.issues || {}).warn)} / ${n((b.issues || {}).info)}</td></tr>`).join("")}
        </tbody></table></div>
        <p class="small muted">« Recoupé » : deux sources indépendantes concordent. « Source de référence » : une seule source officielle (Banque mondiale, Wikidata…). « Rédigé » : contenu éditorial relu. « Estimé » : niveau de langue déduit (fréquence, mot anglais lié). Les signalements détaillés sont dans le rapport qualité.</p></div>

      <div class="grid g2">
        <div class="card stack"><h2>Contrôle des questions</h2>
          <p>${n(Q.accepted)} questions générées ou migrées ont passé toutes les règles ; ${n(Q.rejected)} ont été rejetées : ${Object.entries(Q.rejected_rules || {}).map(([k, v]) => `${RULES[k] || k} (${n(v)})`).join(", ") || "aucune"}.</p>
          <p>${n(IA.questions)} questions tirées des bases sont jouables ici : ${Object.entries(IA.by_generator || {}).map(([k, v]) => ({ stat: "statistiques datées", member: "membres d'organisations", founded: "dates de création", office: "titulaires de fonctions", nobel: "prix Nobel de la paix", border: "frontières", landlocked: "pays enclavés", imp: "lots relus" }[k] || k) + " " + n(v)).join(", ")}.</p>
          ${Object.keys(IA.withheld || {}).length ? `<p class="small muted">Retenues en attendant une vérification : ${Object.entries(IA.withheld).map(([k, v]) => `${k === "lot" ? "questions de lots non relus" : k} (${n(v)})`).join(", ")}.</p>` : ""}
          <h3>Lots importés</h3>
          ${(Q.batches || []).length ? `<ul class="small">${Q.batches.map(b => `<li><b>${esc(b.id.replace("batch:", ""))}</b> — ${esc(b.author)}, ${fmtD(b.received_at)} : ${b.accepted} acceptées, ${b.rejected} rejetées · ${b.reviewed_by ? "relu par " + esc(b.reviewed_by) : "en attente de relecture humaine"}</li>`).join("")}</ul>` : `<p class="small muted">Aucun lot importé.</p>`}</div>
        <div class="card stack"><h2>Fraîcheur</h2>
          <p>Chaque source a sa fréquence de contrôle. La synchronisation marque comme périmées les données dont la date de validité est passée (dirigeants : 60 jours ; montants et règles pratiques : 180 jours ; listes de membres : 120 jours) et relance les bases concernées.</p>
          <p>${DBX.sync ? `Dernier contrôle : ${fmtD(DBX.sync.checked_at.slice(0, 10))}. ${n(DBX.sync.stale_total)} provenance${DBX.sync.stale_total > 1 ? "s" : ""} périmée${DBX.sync.stale_total > 1 ? "s" : ""} ; sources à revérifier : ${DBX.sync.sources_due.length ? DBX.sync.sources_due.join(", ") : "aucune"}.` : "Synchronisation jamais lancée."}</p>
          <p class="small muted">Une statistique porte toujours l'année à laquelle elle se rapporte : une donnée récupérée aujourd'hui peut concerner 2023.</p></div>
      </div>

      <div class="card stack" id="dbdict"><h2>Dictionnaire de référence</h2>
        <p class="small muted">${n(IA.dict_en)} mots anglais et ${n(IA.dict_es)} mots espagnols dont la traduction est confirmée par deux sources (WordNet multilingue et Wiktionnaire) ou vérifiée. Niveaux anglais : CEFR-J et Octanove ; niveaux espagnols estimés.</p>
        <div class="row" style="align-items:flex-end"><label class="field" for="dbq" style="flex:1 1 220px">Rechercher un mot (dans la langue ou en français)<input id="dbq" type="search" value="${esc(s.q)}" placeholder="Ex. : house, casa, maison…" autocomplete="off"></label>
          <div class="seg" role="group" aria-label="Langue">${[["en", "Anglais"], ["es", "Espagnol"]].map(([k, l]) => `<button class="btn sm ${s.lang === k ? "primary" : "ghost"}" data-dblang="${k}" aria-pressed="${s.lang === k}">${l}</button>`).join("")}</div></div>
        <div id="dbres">${dictRows()}</div></div>

      <div class="card stack"><h2>Sources et licences</h2>
        <div class="scroll-x"><table class="data"><thead><tr><th>Source</th><th>Licence</th><th>Rythme de la source</th><th>Récupérée le</th><th class="n">Contrôle</th></tr></thead><tbody>
        ${DBX.sources.map(x => `<tr><td><b>${esc(x.name)}</b><br><span class="small muted">${esc(x.publisher || "")}</span></td><td class="small">${x.license_url ? `<a href="${esc(x.license_url)}" target="_blank" rel="noopener">${esc(x.license)}</a>` : esc(x.license)}</td><td class="small">${esc(x.cadence || "")}</td><td class="small">${fmtD(x.last)}</td><td class="n small">${x.every ? x.every + " j" : "—"}</td></tr>`).join("")}
        </tbody></table></div>
        <p class="small muted">Aucun contenu protégé n'est importé en masse : les textes rédigés reformulent les sources officielles, les listes de mots viennent de ressources sous licence libre, et les sources sous licence incompatible (dictionnaire de prononciation britannique sous GPL) sont écartées.</p></div>
    </div>`;
  };
  document.addEventListener("input", e => { if (e.target.id === "dbq") { ds().q = e.target.value; const r = document.getElementById("dbres"); if (r) r.innerHTML = dictRows(); } });
  UI.onData("dblang", k => { ds().lang = k; UI.views.donnees(); const i = document.getElementById("dbq"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } });
  UI.onData("dbadd", v => {
    const [lang, word] = v.split("|"); const w = (DBX.dict[lang] || []).find(x => x[0] === word); if (!w) return;
    const nat = { nom: "nom", verbe: "verbe", adjectif: "adjectif", adverbe: "adverbe" }[w[1]] || "autre";
    const r = F.Dict.add(store.s, Object.assign({ fr: w[3], cat: w[5] ? w[5][0].toUpperCase() + w[5].slice(1) : "Divers", nat }, lang === "en" ? { en: w[0] } : { es: w[0] }));
    save(); UI.renderNav(); toast(r && r.dup ? `« ${esc(w[0])} » est déjà dans votre dictionnaire.` : `« ${esc(w[0])} » ajouté à votre dictionnaire.`);
  });
})();
