/* World Knowledge Academy — Explorer le monde : carte interactive, fiches pays, parcours par continent, comparateur, fiches thématiques */
(function () {
  "use strict";
  const UI = window.WKA.ui, { store, app, root, D, E, U, LG, F, BY, esc, pct, icon, flag, toast, save, go } = UI;
  const S = () => store.s, M = D.MAP, OTHER = Array.isArray(M.other) ? M.other.join(" ") : M.other;
  const STATE_LBL = { none: "Inexploré", discovered: "Découvert", mastered: "Maîtrisé" };
  const FULL = [0, 0, M.w, M.h];
  const contBox = {};
  Object.keys(D.CONTINENTS).forEach(k => {
    const pts = D.countries.filter(c => c.cont === k).map(c => M.dots[c.iso]).filter(Boolean);
    let x0 = Math.min(...pts.map(p => p[0])), x1 = Math.max(...pts.map(p => p[0])), y0 = Math.min(...pts.map(p => p[1])), y1 = Math.max(...pts.map(p => p[1]));
    const w = (x1 - x0) * 1.3 + 40, h = (y1 - y0) * 1.3 + 30, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    const W2 = Math.max(w, h * M.w / M.h), H2 = W2 * M.h / M.w;
    contBox[k] = [cx - W2 / 2, cy - H2 / 2, W2, H2];
  });
  const mapState = () => app.ui.map || (app.ui.map = { vb: FULL.slice(), cont: "all", sel: null, tab: "pays", q: "" });

  // ---------- Carte interactive ----------
  function worldSVG(ms) {
    const st = iso => F.isoState(S(), iso);
    const small = D.countries.filter(c => !M.shapes[c.iso]);
    const grat = [];
    for (let i = 1; i < 6; i++) grat.push(`M0,${(M.h * i / 6).toFixed(1)}H${M.w}`);
    for (let i = 1; i < 12; i++) grat.push(`M${(M.w * i / 12).toFixed(1)},0V${M.h}`);
    return `<svg class="mapsvg" id="worldmap" viewBox="${ms.vb.map(v => v.toFixed(1)).join(" ")}" role="img" aria-label="Carte du monde interactive : touchez un pays">
      <rect x="-2000" y="-2000" width="5000" height="5000" fill="var(--sea)"/><path class="grat" d="${grat.join("")}"/>
      <path class="other" d="${OTHER}"/>
      ${Object.entries(M.shapes).map(([iso, d]) => BY[iso] ? `<path class="c ${st(iso)} ${ms.sel === iso ? "hl" : ""}" data-iso="${iso}" d="${d}"><title>${esc(BY[iso].name)} · ${STATE_LBL[st(iso)]}</title></path>` : "").join("")}
      ${small.map(c => { const p = M.dots[c.iso]; return `<circle class="sd ${st(c.iso)} ${ms.sel === c.iso ? "hl" : ""}" data-iso="${c.iso}" cx="${p[0]}" cy="${p[1]}" r="${Math.max(1.2, 2.6 * ms.vb[2] / M.w)}"><title>${esc(c.name)}</title></circle>`; }).join("")}
    </svg>`;
  }
  function setVB(vb) {
    const ms = mapState(); const w = U.clamp(vb[2], 60, M.w * 1.05), h = w * M.h / M.w;
    const cx = vb[0] + vb[2] / 2, cy = vb[1] + vb[3] / 2;
    ms.vb = [U.clamp(cx - w / 2, -w / 2, M.w - w / 2), U.clamp(cy - h / 2, -h / 2, M.h - h / 2), w, h];
    const svg = document.getElementById("worldmap"); if (svg) { svg.setAttribute("viewBox", ms.vb.map(v => v.toFixed(1)).join(" ")); svg.querySelectorAll("circle.sd").forEach(c => c.setAttribute("r", Math.max(1.2, 2.6 * w / M.w))); }
  }
  function bindMap() {
    const svg = document.getElementById("worldmap"); if (!svg) return;
    const ptrs = new Map(); let start = null, moved = 0, pinch = null;
    const toSvg = (dx, dy) => { const r = svg.getBoundingClientRect(), vb = mapState().vb; return [dx * vb[2] / r.width, dy * vb[3] / r.height]; };
    svg.addEventListener("pointerdown", e => { ptrs.set(e.pointerId, [e.clientX, e.clientY]); start = { x: e.clientX, y: e.clientY, vb: mapState().vb.slice() }; moved = 0; if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), vb: mapState().vb.slice() }; } });
    svg.addEventListener("pointermove", e => {
      if (!ptrs.has(e.pointerId)) return; ptrs.set(e.pointerId, [e.clientX, e.clientY]);
      if (ptrs.size === 2 && pinch) { const [a, b] = [...ptrs.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]); const f = pinch.d / d; const v = pinch.vb; setVB([v[0] + v[2] * (1 - f) / 2, v[1] + v[3] * (1 - f) / 2, v[2] * f, v[3] * f]); moved = 99; return; }
      const dx = e.clientX - start.x, dy = e.clientY - start.y; moved = Math.max(moved, Math.abs(dx) + Math.abs(dy));
      if (moved > 5) { svg.classList.add("drag"); try { svg.setPointerCapture(e.pointerId); } catch (er) { /* rien */ } const [sx, sy] = toSvg(dx, dy); setVB([start.vb[0] - sx, start.vb[1] - sy, start.vb[2], start.vb[3]]); }
    });
    const up = e => {
      ptrs.delete(e.pointerId); svg.classList.remove("drag"); if (ptrs.size < 2) pinch = null;
      if (moved <= 5 && e.type === "pointerup") { const t = document.elementFromPoint(e.clientX, e.clientY); const iso = t && t.dataset && t.dataset.iso; if (iso) selectCountry(iso); }
    };
    svg.addEventListener("pointerup", up); svg.addEventListener("pointercancel", up);
    svg.addEventListener("wheel", e => { e.preventDefault(); const r = svg.getBoundingClientRect(), vb = mapState().vb; const f = e.deltaY > 0 ? 1.18 : 1 / 1.18; const px = vb[0] + (e.clientX - r.left) / r.width * vb[2], py = vb[1] + (e.clientY - r.top) / r.height * vb[3]; setVB([px - (px - vb[0]) * f, py - (py - vb[1]) * f, vb[2] * f, vb[3] * f]); }, { passive: false });
  }
  function zoom(f) { const v = mapState().vb; setVB([v[0] + v[2] * (1 - f) / 2, v[1] + v[3] * (1 - f) / 2, v[2] * f, v[3] * f]); }
  function selectCountry(iso) {
    const ms = mapState(); ms.sel = iso;
    document.querySelectorAll("#worldmap .hl").forEach(n => n.classList.remove("hl"));
    document.querySelectorAll(`#worldmap [data-iso="${iso}"]`).forEach(n => n.classList.add("hl"));
    const p = document.getElementById("mappanel"); if (p) { p.innerHTML = panelHTML(iso); if (innerWidth < 1000) p.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
  }
  function panelHTML(iso) {
    if (!iso) return `<div class="stack"><h2>Touchez un pays</h2><p class="small muted">Faites glisser pour vous déplacer, pincez ou utilisez + et − pour zoomer. Les couleurs suivent votre maîtrise : gris inexploré, vert clair découvert, vert profond maîtrisé (au moins 3 bonnes réponses et 75 % de réussite).</p>${legend()}</div>`;
    const c = BY[iso], st = F.isoState(S(), iso), x = S().isoStats[iso] || { a: 0, c: 0 }, ec = (D.ECON || {})[iso];
    return `<div class="stack"><div class="row nowrap">${flag(iso, "3rem")}<div class="stack" style="gap:2px"><h2>${esc(c.name)}</h2><span class="small muted">${esc(D.CONTINENTS[c.cont].name)} · capitale ${esc(c.capital)}</span></div></div>
      <div class="row"><span class="chip ${st === "mastered" ? "pill-sage" : st === "discovered" ? "pill-brass" : ""}"><span class="st ${st}"></span>${STATE_LBL[st]}</span><span class="chip">${x.a ? `${x.c}/${x.a} bonnes réponses` : "Aucune question encore"}</span></div>
      <dl class="facts"><div><dt>Population</dt><dd>${esc(U.pop(c.pop))}</dd></div><div><dt>Superficie</dt><dd>${esc(U.area(c.area))}</dd></div>${ec ? `<div><dt>PIB 2024</dt><dd>${U.num(ec[0])} Md$</dd></div>` : ""}<div><dt>Monnaie</dt><dd>${esc(D.CURRENCIES[c.cur])}</dd></div></dl>
      <p class="small">${esc(c.fact)}</p>
      <div class="row"><a class="btn primary" href="#pays-${iso.toLowerCase()}">Ouvrir la fiche</a><button class="btn" data-cquiz="${iso}|all">${icon("play")} Quiz</button><button class="btn ghost" data-cmpadd="${iso}">${icon("scale")} Comparer</button></div></div>`;
  }
  const legend = () => `<div class="legend"><span><i style="background:var(--m-none)"></i>Inexploré</span><span><i style="background:var(--m-disc)"></i>Découvert</span><span><i style="background:var(--m-mast)"></i>Maîtrisé</span></div>`;
  function countryCards(list) {
    return list.length ? list.map(c => `<a class="ccard" href="#pays-${c.iso.toLowerCase()}">${flag(c.iso)}<div><div class="nm">${esc(c.name)}</div><div class="cap">${esc(c.capital)}</div></div><span class="st ${F.isoState(S(), c.iso)}" title="${STATE_LBL[F.isoState(S(), c.iso)]}"></span></a>`).join("") : `<div class="empty">Aucun pays ne correspond.</div>`;
  }
  UI.countryCards = countryCards;
  const listFor = ms => { const q = U.norm(ms.q); return D.countries.filter(c => (ms.cont === "all" || c.cont === ms.cont) && (!q || U.norm(c.name + " " + c.capital).includes(q))).sort((a, b) => a.name.localeCompare(b.name, "fr")); };
  UI.views.monde = function () {
    const ms = mapState(), paths = F.continentPaths(S());
    const tot = { d: paths.reduce((a, p) => a + p.discovered, 0), m: paths.reduce((a, p) => a + p.mastered, 0) };
    root.innerHTML = `<div class="wrap"><div class="row between"><div class="pagehead"><span class="eyebrow">Explorer le monde</span><h1>Carte du monde</h1></div>
        <div class="row"><span class="chip pill-sage">${tot.m} maîtrisés</span><span class="chip pill-brass">${tot.d} découverts</span><span class="chip">${D.countries.length} pays</span></div></div>
      <div class="seg" role="group" aria-label="Zoomer sur un continent">${[["all", "Monde"]].concat(Object.entries(D.CONTINENTS).map(([k, v]) => [k, v.name])).map(([k, l]) => `<button data-mcont="${k}" class="${ms.cont === k ? "sel" : ""}">${esc(l)}</button>`).join("")}</div>
      <div class="grid" style="grid-template-columns:minmax(0,1fr)" id="mapgrid">
        <div class="mapbox">${worldSVG(ms)}<div class="mapctl"><button data-act="mz+" aria-label="Zoomer">+</button><button data-act="mz-" aria-label="Dézoomer">−</button><button data-act="mz0" aria-label="Vue d'ensemble" style="font-size:.8rem">⤢</button></div></div>
        <div class="card" id="mappanel">${panelHTML(ms.sel)}</div>
      </div>
      <div class="tabs">${[["pays", "Tous les pays"], ["parcours", "Parcours par continent"]].map(([k, l]) => `<button class="${ms.tab === k ? "sel" : ""}" data-mtab="${k}">${l}</button>`).join("")}</div>
      ${ms.tab === "pays" ? `<label class="field" for="wsearch" style="max-width:420px">Rechercher un pays ou une capitale<input id="wsearch" type="search" value="${esc(ms.q)}" placeholder="Ex. Pérou, Canberra…" autocomplete="off"></label><div class="cgrid" id="clist">${countryCards(listFor(ms))}</div>`
        : `<div class="grid g3">${paths.map(p => `<div class="card stack"><div class="row between"><h2>${esc(p.name)}</h2><span class="chip">${p.total} pays</span></div>
          <div class="bar"><i style="width:${pct(p.mastered, p.total)}%;background:var(--m-mast)"></i></div>
          <div class="row small" style="gap:12px"><span><b>${p.mastered}</b> acquis</span><span><b>${p.discovered - p.mastered}</b> découverts</span><span class="muted"><b>${p.remaining}</b> restants</span></div>
          <div class="path">${p.steps.map((s, i) => `<div class="step ${s.mastered >= Math.ceil(s.n * 0.7) ? "done" : p.current === s ? "cur" : ""}"><span class="n">${i + 1}</span><span class="small" style="flex:1">${["Incontournables", "Très connus", "Connus", "Moins connus", "Experts"][s.tier - 1]} · ${s.mastered}/${s.n}</span>${p.current === s ? `<button class="btn sm primary" data-path="${p.id}|${s.tier}">Jouer</button>` : ""}</div>`).join("")}</div></div>`).join("")}</div>
          <p class="xs muted">Une étape est validée quand 70 % de ses pays sont maîtrisés. Les questions de l'étape portent sur ses pays : capitale, drapeau, carte, frontières, économie…</p>`}
      <p class="xs muted">Frontières : Natural Earth 1:110 M (frontières de facto, simplifiées). Les très petits États sont figurés par un point.</p></div>`;
    if (innerWidth >= 1000) document.getElementById("mapgrid").style.gridTemplateColumns = "minmax(0,2.1fr) minmax(0,1fr)";
    bindMap();
  };
  UI.on("mz+", () => zoom(1 / 1.5)); UI.on("mz-", () => zoom(1.5)); UI.on("mz0", () => { mapState().cont = "all"; setVB(FULL.slice()); document.querySelectorAll("[data-mcont]").forEach(b => b.classList.toggle("sel", b.dataset.mcont === "all")); });
  UI.onData("mcont", k => { const ms = mapState(); ms.cont = k; setVB(k === "all" ? FULL.slice() : contBox[k].slice()); document.querySelectorAll("[data-mcont]").forEach(b => b.classList.toggle("sel", b.dataset.mcont === k)); const l = document.getElementById("clist"); if (l) l.innerHTML = countryCards(listFor(ms)); });
  UI.onData("mtab", k => { mapState().tab = k; UI.views.monde(); });
  UI.onData("path", v => { const [cont, tier] = v.split("|"); const isos = D.countries.filter(c => c.cont === cont && c.tier === +tier).map(c => c.iso); UI.startQuiz({ mode: "monde", cats: ["geo", "pol", "eco"], isos, count: 10, level: "adaptive", title: "Parcours " + D.CONTINENTS[cont].name + " · étape " + tier }); });
  UI.onData("cquiz", v => { const [iso, th] = v.split("|"); const cats = th === "all" ? ["geo", "pol", "eco", "cult"] : [th]; UI.startQuiz({ mode: "monde", iso, cats, level: "adaptive", count: th === "all" ? 10 : 5, title: BY[iso].name }); });
  document.addEventListener("input", e => { if (e.target.id === "wsearch") { const ms = mapState(); ms.q = e.target.value; document.getElementById("clist").innerHTML = countryCards(listFor(ms)); } });

  // ---------- Fiche pays ----------
  const CT = [["apercu", "Aperçu"], ["geo", "Géographie"], ["hist", "Histoire"], ["pol", "Politique"], ["eco", "Économie"], ["cult", "Culture"], ["quiz", "Quiz"]];
  UI.views["pays-*"] = function (r) {
    const iso = r.slice(5).toUpperCase(), c = BY[iso]; if (!c) return go("monde");
    if (!S().discovered[iso]) { S().discovered[iso] = Date.now(); E.checkBadges(store).forEach(b => toast(`Badge obtenu : <b>${esc(b.name)}</b>`)); save(); }
    const tab = app.ui.ctab && app.ui.ctabIso === iso ? app.ui.ctab : "apercu";
    const st = F.isoState(S(), iso), P = (D.PROFILES || {})[iso], ec = (D.ECON || {})[iso], res = (D.RES || {})[iso];
    const L = D.LEADERS[iso], stale = U.monthsSince(D.LEADERS_AS_OF) > 12;
    const orgs = F.compare([iso])[0].orgs;
    const row = (t, v, note) => `<div><dt>${t}</dt><dd>${v}${note ? `<br><small>${note}</small>` : ""}</dd></div>`;
    const nbs = c.borders.filter(b => BY[b]);
    const noProfile = `<p class="notice info">Fiche détaillée rédigée pour ${Object.keys(D.PROFILES || {}).length} pays dans la maquette ; celle-ci reste à écrire (voir README). Les données chiffrées ci-dessous sont, elles, disponibles pour tous les pays.</p>`;
    const body = {
      apercu: `<p style="font-size:1.05rem">${esc(c.fact)}</p><div class="grid g2"><dl class="facts">${row("Capitale", esc(c.capital), c.capitalNote ? esc(c.capitalNote) : "")}${row("Population", "≈ " + esc(U.pop(c.pop)), "ONU 2024 · donnée évolutive")}${row("Superficie", esc(U.area(c.area)))}${row("Langue" + (c.langs.length > 1 ? "s officielles" : " officielle"), esc(c.langs.map(l => D.LANGUAGES[l]).join(", ")))}${row("Monnaie", esc(D.CURRENCIES[c.cur]))}${row("Régime", esc(D.GOV[c.gov]))}</dl>${UI.miniMap(iso, 4)}</div>`,
      geo: `<div class="grid g2"><dl class="facts">${row("Continent", esc(D.CONTINENTS[c.cont].name) + (c.trans ? " (transcontinental)" : ""))}${row("Coordonnées de la capitale", `<span class="coords">${Math.abs(c.lat)}° ${c.lat >= 0 ? "N" : "S"} · ${Math.abs(c.lon)}° ${c.lon >= 0 ? "E" : "O"}</span>`)}${row("Superficie", esc(U.area(c.area)), esc(D.META.areaSource))}${row("Densité", esc(U.density(c.density)))}${row("Accès à la mer", c.landlocked ? "Non, pays enclavé" : "Oui")}${res ? row("Ressources naturelles", esc(res)) : ""}</dl>${UI.miniMap(iso, 2.4)}</div>
        <h3>Voisins terrestres</h3>${nbs.length ? `<div class="cgrid">${countryCards(nbs.map(b => BY[b]))}</div>` : `<p class="muted">${esc(c.name)} n'a pas de frontière terrestre avec un pays de la base.</p>`}`,
      hist: P && P.hist ? `<p>${esc(P.hist)}</p>` : noProfile,
      pol: `<dl class="facts">${row("Régime politique", esc(D.GOV[c.gov]), "Classification simplifiée · état " + esc(U.asOfLabel(D.META.verifiedAt)))}${L ? row("Chef de l'État", esc(L[0]), (stale ? "⚠ À revérifier · " : "") + "état " + esc(U.asOfLabel(D.LEADERS_AS_OF))) : ""}${L && L[1] ? row("Chef du gouvernement", esc(L[1]), (stale ? "⚠ À revérifier · " : "") + "état " + esc(U.asOfLabel(D.LEADERS_AS_OF))) : ""}${row("Organisations", orgs.length ? esc(orgs.join(" · ")) : "—", "ONU, UE, OTAN, G20, BRICS, OPEP, ASEAN, UA, zone euro, OMC")}</dl>${P && P.pol ? `<p>${esc(P.pol)}</p>` : ""}`,
      eco: `<dl class="facts">${ec ? row("PIB nominal 2024", U.num(ec[0]) + " Md$", D.ECON_META.gdpSource) + row("PIB par habitant", "≈ " + U.num(Math.round(ec[0] * 1000 / c.pop / 100) * 100) + " $", "Calculé : PIB ÷ population") + row("Espérance de vie", String(ec[1]).replace(".", ",") + " ans", D.ECON_META.lifeSource) : row("PIB", "Non renseigné dans la maquette", "Données FMI disponibles pour " + Object.keys(D.ECON).length + " pays")}${row("Monnaie", esc(D.CURRENCIES[c.cur]))}${res ? row("Ressources", esc(res)) : ""}</dl>${P && P.eco ? `<p>${esc(P.eco)}</p>` : noProfile}`,
      cult: `<dl class="facts">${row("Langues officielles", esc(c.langs.map(l => D.LANGUAGES[l]).join(", ")))}</dl>${P && P.cult ? `<p>${esc(P.cult)}</p>` : noProfile}<p class="muted small">${esc(c.fact)}</p>`,
      quiz: `<p>Questions générées à partir des données de ce pays : capitale, drapeau, carte, frontières, population, monnaie, régime, organisations…</p><div class="row"><button class="btn primary" data-cquiz="${iso}|all">Tous les thèmes</button>${E.countryThemes(iso).map(t => `<button class="btn" data-cquiz="${iso}|${t.id}">${t.name}</button>`).join("")}</div>`
    }[tab];
    root.innerHTML = `<div class="wrap narrow"><div><a class="btn ghost" href="#monde" style="padding-left:0">${icon("back")} Carte du monde</a></div>
      <div class="card stack"><div class="row nowrap" style="gap:16px">${flag(iso, "4.2rem")}<div class="stack" style="gap:4px"><span class="eyebrow">${esc(D.CONTINENTS[c.cont].name)}</span><h1>${esc(c.name)}</h1><div class="row"><span class="chip"><span class="st ${st}"></span>${STATE_LBL[st]}</span><button class="chip" data-cmpadd="${iso}">${icon("scale")} Comparer</button></div></div></div></div>
      <div class="tabs">${CT.map(([k, l]) => `<button class="${tab === k ? "sel" : ""}" data-ctab="${iso}|${k}">${l}</button>`).join("")}</div>
      <div class="card stack">${body}</div>
      <p class="xs muted">Sources : ${esc(D.META.populationSource)} ; ${esc(D.META.politicalSource)}. ${esc(D.META.verifiedNote || "")}</p></div>`;
  };
  UI.onData("ctab", v => { const [iso, k] = v.split("|"); app.ui.ctab = k; app.ui.ctabIso = iso; UI.render(); });

  // ---------- Comparateur ----------
  const ROWS = [
    ["Continent", c => c.cont], ["Capitale", c => c.capital], ["Population", c => c.pop, U.pop, "max"], ["Superficie", c => c.area, U.area, "max"], ["Densité", c => c.density, U.density, "max"],
    ["PIB 2024", c => c.gdp, v => U.num(v) + " Md$", "max"], ["PIB par habitant", c => c.gdppc, v => U.num(Math.round(v / 100) * 100) + " $", "max"], ["Espérance de vie", c => c.life, v => String(v).replace(".", ",") + " ans", "max"],
    ["Monnaie", c => c.currency], ["Régime politique", c => c.gov], ["Langues officielles", c => c.langs], ["Ressources naturelles", c => c.res || "—"], ["Accès à la mer", c => c.landlocked ? "Non (enclavé)" : "Oui"], ["Organisations", c => c.orgs.join(", ")]
  ];
  const cmpList = () => app.ui.cmp || (app.ui.cmp = ["FR", "DE", "ES"]);
  UI.views.comparer = function () {
    const list = cmpList(), rows = F.compare(list), chartKey = app.ui.cmpChart || 5;
    const num = ROWS.map((r, i) => [r, i]).filter(([r]) => r[3]);
    const [cr] = ROWS[chartKey]; const vals = rows.map(c => ROWS[chartKey][1](c));
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Explorer le monde</span><h1>Comparateur de pays</h1><p>Jusqu'à 4 pays côte à côte. La meilleure valeur de chaque indicateur chiffré est surlignée.</p></div>
      <div class="card stack"><div class="row">${list.map(i => `<span class="chip">${flag(i)} ${esc(BY[i].name)} <button class="btn ghost sm icon" data-cmprm="${i}" aria-label="Retirer ${esc(BY[i].name)}" style="min-height:22px;width:22px">${icon("x")}</button></span>`).join("")}</div>
        ${list.length < 4 ? `<label class="field" for="cmpq" style="max-width:420px">Ajouter un pays<input id="cmpq" type="search" placeholder="Tapez un nom de pays" autocomplete="off"></label><div class="row" id="cmpres"></div>` : `<span class="xs muted">4 pays au maximum : retirez-en un pour en ajouter un autre.</span>`}</div>
      ${rows.length ? `<div class="card"><div class="scroll-x"><table class="data"><thead><tr><th>Indicateur</th>${rows.map(c => `<th>${flag(c.iso)} ${esc(c.name)}</th>`).join("")}</tr></thead><tbody>
        ${ROWS.map(([lbl, get, fmt, best]) => { const v = rows.map(get); const bi = best ? v.indexOf(Math.max(...v.filter(x => x != null))) : -1;
          return `<tr><td class="muted">${lbl}</td>${v.map((x, i) => `<td class="${i === bi && rows.length > 1 ? "hl" : ""}">${x == null ? "<span class='muted'>n.d.</span>" : esc(fmt ? fmt(x) : x)}</td>`).join("")}</tr>`; }).join("")}</tbody></table></div>
        <p class="xs muted">Sources : ONU WPP 2024 (population), FMI avril 2025 (PIB 2024), Banque mondiale (espérance de vie 2023). « n.d. » : donnée non chargée dans la maquette. Indicateurs sociaux à ajouter : IDH, Gini, taux de chômage (voir README).</p></div>
      <div class="card stack"><div class="row between"><h2>Graphique : ${esc(cr)}</h2><div class="seg">${num.map(([r, i]) => `<button data-cmpchart="${i}" class="${chartKey === i ? "sel" : ""}">${esc(r[0])}</button>`).join("")}</div></div>
        ${vals.every(v => v != null) ? UI.barChart(rows.map(c => c.name), vals, "") : `<p class="muted">Donnée manquante pour au moins un pays.</p>`}</div>` : ""}
      <div class="row"><button class="btn" data-act="cmpquiz" ${rows.length >= 2 ? "" : "disabled"}>${icon("play")} Quiz sur ces pays</button></div></div>`;
  };
  UI.onData("cmprm", i => { app.ui.cmp = cmpList().filter(x => x !== i); UI.views.comparer(); });
  UI.onData("cmpadd", i => { const l = cmpList(); if (!l.includes(i)) { if (l.length >= 4) l.shift(); l.push(i); } toast(`${esc(BY[i].name)} ajouté au comparateur.`); go("comparer"); });
  UI.onData("cmppick", i => { const l = cmpList(); if (!l.includes(i) && l.length < 4) l.push(i); UI.views.comparer(); });
  UI.onData("cmpchart", i => { app.ui.cmpChart = +i; UI.views.comparer(); });
  UI.on("cmpquiz", () => UI.startQuiz({ mode: "monde", cats: ["geo", "pol", "eco"], isos: cmpList(), count: 10, level: "adaptive", title: "Comparateur · " + cmpList().map(i => BY[i].name).join(", ") }));
  document.addEventListener("input", e => {
    if (e.target.id !== "cmpq") return; const q = U.norm(e.target.value);
    document.getElementById("cmpres").innerHTML = q ? D.countries.filter(c => U.norm(c.name).includes(q) && !cmpList().includes(c.iso)).slice(0, 8).map(c => `<button class="chip" data-cmppick="${c.iso}">${flag(c.iso)} ${esc(c.name)}</button>`).join("") : "";
  });

  // ---------- Fiches thématiques ----------
  UI.views.fiches = function () {
    root.innerHTML = `<div class="wrap"><div class="pagehead"><span class="eyebrow">Explorer le monde</span><h1>Fiches thématiques</h1></div>
      <h2>Organisations internationales</h2><div class="grid g2">${Object.values(D.ORGS).map(o => `<div class="card stack">
        <div class="row between"><h3>${esc(o.name)}</h3><span class="chip">${o.founded}</span></div>
        <p class="muted small">Siège : ${esc(o.hq)} · ${esc(o.members)} <span class="chip ${U.monthsSince(o.asOf) > 12 ? "pill-warn" : ""}" style="font-size:.7rem">état ${esc(U.asOfLabel(o.asOf))}</span></p>
        <p style="font-size:.95rem">${esc(o.summary)}</p><ul style="margin:0;padding-left:18px;font-size:.9rem">${o.facts.map(f => `<li>${esc(f)}</li>`).join("")}</ul>
        ${o.list ? `<div class="row" style="gap:4px">${o.list.split(" ").filter(i => BY[i]).map(i => `<a href="#pays-${i.toLowerCase()}" title="${esc(BY[i].name)}" style="text-decoration:none;font-size:1.2rem">${flag(i)}</a>`).join("")}</div>` : ""}
        <span class="xs muted">Source : ${esc(o.source)}</span></div>`).join("")}</div>
      <div><button class="btn primary" data-subquiz="pol|Organisations internationales">Quiz sur les organisations internationales</button></div>
      <h2>Événements, concepts et personnalités</h2><div class="grid g2">${D.SHEETS.map(s => `<div class="card stack"><span class="eyebrow">${esc(s.type)}</span><h3>${esc(s.title)}</h3><p style="font-size:.95rem">${esc(s.body)}</p><div class="row" style="gap:6px">${s.tags.map(t => `<span class="chip">${esc(t)}</span>`).join("")}</div></div>`).join("")}</div></div>`;
  };
})();
