/* World Knowledge Academy — Moteur de sessions (couche LOGIQUE)
 * Sélection des questions, anti-répétition, difficulté adaptative, répétition espacée, badges, volume réel.
 * Aucune dépendance à l'interface : utilisable tel quel côté serveur ou dans une application mobile.
 */
(function (W) {
  const D = W.WKA.data, U = W.WKA.util, G = W.WKA.generators, BY = W.WKA.byIso, LG = W.WKA.lang;

  const CATEGORIES = [
    { id: "geo", name: "Géographie", short: "Géo", hue: "geo", subs: ["Pays et capitales", "Drapeaux", "Continents et régions", "Géographie physique", "Frontières", "Population et démographie", "Superficie et densité", "Grandes villes", "Territoires et dépendances"] },
    { id: "pol", name: "Politique et géopolitique", short: "Politique", hue: "pol", subs: ["Régimes politiques", "Chefs d'État et de gouvernement", "Organisations internationales", "Institutions européennes", "Systèmes électoraux", "Conflits et traités", "Grandes puissances"] },
    { id: "hist", name: "Histoire", short: "Histoire", hue: "hist", subs: ["Grandes civilisations", "Antiquité", "Moyen Âge", "Révolutions", "Guerres mondiales", "Guerre froide", "Décolonisation", "Histoire contemporaine", "Grandes personnalités", "Chronologie"] },
    { id: "eco", name: "Économie et finance", short: "Économie", hue: "eco", subs: ["Monnaies", "Banques centrales", "Commerce et organisations", "Matières premières", "Concepts économiques", "Entreprises"] },
    { id: "sci", name: "Sciences et technologies", short: "Sciences", hue: "sci", subs: ["Physique", "Chimie", "Biologie", "Astronomie", "Médecine", "Technologies et IA", "Énergie"] },
    { id: "cult", name: "Cultures et sociétés", short: "Cultures", hue: "cult", subs: ["Langues", "Religions", "Gastronomie", "Patrimoine", "Arts et littérature", "Personnalités", "Festivals et événements"] },
    { id: "env", name: "Environnement et monde", short: "Environnement", hue: "env", subs: ["Biodiversité", "Climat", "Océans", "Géologie", "Énergies renouvelables", "Espèces animales", "Ressources naturelles"] },
    { id: "prat", name: "Vie pratique et quotidienne", short: "Vie pratique", hue: "prat", subs: ["Droit et législation", "Finance personnelle", "Vie professionnelle", "Vie quotidienne", "Santé et prévention", "Culture numérique"] },
    { id: "en", name: "Anglais", short: "Anglais", hue: "en", lang: true, flag: "GB", subs: Object.values(LG.SUBS) },
    { id: "es", name: "Espagnol", short: "Espagnol", hue: "es", lang: true, flag: "ES", subs: Object.values(LG.SUBS).filter(x => x !== LG.SUBS.phr) }
  ];
  const KNOW = CATEGORIES.filter(c => !c.lang).map(c => c.id); // catégories de culture générale (hors langues)
  const CAT = Object.fromEntries(CATEGORIES.map(c => [c.id, c]));
  const LEVELS = ["Débutant", "Intermédiaire", "Avancé", "Expert", "Expert international"];

  // ---- Indexation de la banque rédigée : identifiant + empreinte de contenu ----
  const BANK = D.bank.map(b => {
    const ck = U.contentKey(b.q, b.a);
    return Object.assign({}, b, { fp: U.hash("bank|" + ck), concept: "bank|" + ck, gen: "bank" });
  });
  function bankToQuestion(b, r) {
    const opts = r.shuffle([b.a].concat(b.w));
    return { gen: "bank", cat: b.cat, sub: b.sub, d: b.d, q: b.q, opts, ans: opts.indexOf(b.a), ex: b.ex, info: b.info, ctx: b.ctx,
      src: b.src, asOf: b.asOf, nature: b.nature, fp: b.fp, concept: b.concept, iso: null, flagPrompt: null, optFlags: false, doc: b.doc || null, deep: !!b.deep };
  }

  // ---- Volume réel disponible ----
  function volume() {
    const per = {}; CATEGORIES.forEach(c => per[c.id] = { exact: 0, combos: 0, bank: 0 });
    BANK.forEach(b => { per[b.cat].exact++; per[b.cat].bank++; });
    const gens = G.map(g => { const s = g.space(); if (s.exact) per[g.cat].exact += s.n; else per[g.cat].combos += s.n; return { id: g.id, cat: g.cat, sub: g.sub, ...s }; });
    const exact = Object.values(per).reduce((s, x) => s + x.exact, 0);
    const combos = Object.values(per).reduce((s, x) => s + x.combos, 0);
    return { per, gens, exact, combos, bank: BANK.length, countries: D.countries.length, generators: G.length };
  }

  // ---- Niveau adaptatif (type Elo simplifié) ----
  function expected(rating, d) { return 1 / (1 + Math.exp(-(rating - d) * 1.3)); }
  function ratingOf(store, cat) {
    if (CAT[cat] && CAT[cat].lang) { const l = (store.s.lang[cat] || {}).level; return store.s.ratings[cat] || l || 2; }
    return store.s.ratings[cat] || 2;
  }
  function levelLabel(r) { return LEVELS[U.clamp(Math.round(r), 1, 5) - 1]; }

  // ---- Répétition espacée : 1, 3, 7, 14 jours puis acquis ----
  const INTERVALS = [0, 1, 3, 7, 14];
  const DAY = 86400000;
  function dueMistakes(store, now) {
    now = now || Date.now();
    return Object.entries(store.s.mistakes).map(([fp, m]) => Object.assign({ fp }, m)).sort((a, b) => a.due - b.due).map(m => Object.assign(m, { isDue: m.due <= now }));
  }

  // ---- Session ----
  function Session(store, cfg) {
    this.store = store;
    this.cfg = Object.assign({ mode: "libre", cats: KNOW.slice(), level: "adaptive", count: 10, lives: 0, examSeconds: 0, perQuestion: 0 }, cfg);
    this.seed = this.cfg.seed || ((Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0);
    this.r = U.rng(this.seed);
    this.items = []; this.fps = new Set(); this.concepts = new Set();
    this.correct = 0; this.wrong = 0; this.streak = 0; this.bestStreak = 0;
    this.start = Date.now(); this.renewed = 0; this.exhausted = false;
    this.recent = new Set(store.s.recent.slice(-120));
    if (this.cfg.mode === "revision") {
      this.queue = dueMistakes(store).filter(m => !this.cfg.cats || !cfg || !cfg.cats || this.cfg.cats.includes(m.q.cat)).slice(0, this.cfg.count || 20).map(m => m.q);
      this.cfg.count = this.queue.length;
    }
    if (this.cfg.fixed) { this.queue = this.cfg.fixed; this.cfg.count = this.queue.length; }
    if (this.cfg.plan) this.cfg.count = this.cfg.plan.reduce((s, p) => s + p.n, 0);
  }
  Session.prototype.levelFor = function (cat) {
    const c = this.cfg;
    const isLang = CAT[cat] && CAT[cat].lang, top = isLang ? 6 : 5;
    if (c.mode === "expert") return isLang ? 5 + (this.r() < 0.5 ? 0 : 1) : (this.r() < 0.5 ? 4 : 5);
    if (c.level !== "adaptive") return U.clamp(c.level, 1, top);
    if (c.daily) return isLang ? (this.store.s.lang[cat].level || 2) : 1 + (this.items.length % 5);
    const rt = ratingOf(this.store, cat);
    const jitter = this.r(); // 70 % au niveau estimé, 15 % au-dessus (défi), 15 % en dessous (consolidation)
    return U.clamp(Math.round(rt) + (jitter < 0.15 ? -1 : jitter > 0.85 ? 1 : 0), 1, top);
  };
  Session.prototype._try = function (cat, level, stage) {
    const r = this.r, c = this.cfg, seen = this.store.s.seen;
    const isLang = CAT[cat] && CAT[cat].lang;
    const tol = isLang || c.mode === "expert" || c.level === "adaptive" ? 1 : 0;
    const subOk = s => (!c.sub || s === c.sub) && (!c.subs || c.subs.includes(s));
    const gens = G.filter(g => g.cat === cat && subOk(g.sub) && (!c.docOnly || g.doc) && (!c.noAudio || !/_ear$|_listen$/.test(g.id)) && (!c.mcqOnly || !/_(wtr|match|cloze|read|listen|tr|corr|wf|kwt|write)$/.test(g.id) || g.id.endsWith("_conj")));
    const iso = c.iso || (c.isos ? r.pick(c.isos) : null);
    const bank = iso ? [] : BANK.filter(b => b.cat === cat && subOk(b.sub) && (!c.docOnly || b.doc) && Math.abs(b.d - level) <= tol && !this.fps.has(b.fp) && (stage >= 3 || !seen[b.fp]));
    let q = null;
    const pBank = bank.length ? (c.docOnly ? 0.6 : cat === "geo" || cat === "pol" ? 0.35 : cat === "eco" || cat === "hist" ? 0.55 : cat === "sci" ? 0.7 : 0.9) : 0;
    if (r() < pBank || !gens.length) {
      if (!bank.length) return null;
      const exact = bank.filter(b => b.d === level);
      q = bankToQuestion(r.pick(exact.length && r() < 0.7 ? exact : bank), r);
    } else {
      const tot = gens.reduce((s, g) => s + g.weight, 0); let x = r() * tot; let g = gens[0];
      for (const gg of gens) { x -= gg.weight; if (x <= 0) { g = gg; break; } }
      q = g.make(r, level, { iso });
      if (q && c.mcqOnly && q.kind && q.kind !== "mcq") return null;
    }
    if (!q) return null;
    if (this.fps.has(q.fp) || this.concepts.has(q.concept)) return null;
    if (stage < 3 && seen[q.fp]) return null;
    if (stage < 2 && this.recent.has(q.concept)) return null;
    if (c.mode === "expert" && q.d < 4 && stage < 3) return null;
    if (!iso && stage < 2 && Math.abs(q.d - level) > tol) return null;
    if (stage >= 3 && seen[q.fp]) q.renewed = true;
    return q;
  };
  Session.prototype.next = function () {
    const c = this.cfg;
    if (c.count && this.items.length >= c.count) return null;
    if (c.lives && this.wrong >= c.lives) return null;
    if (this.queue) {
      const m = this.queue[this.items.length]; if (!m) return null;
      const q = Object.assign({}, m, { review: c.mode === "revision" });
      return this._push(q);
    }
    let cats = c.cats.length ? c.cats : KNOW;
    if (c.plan) { let k = this.items.length; for (const p of c.plan) { if (k < p.n) { cats = p.cats; break; } k -= p.n; } }
    for (let stage = c.daily ? 3 : 1; stage <= 3; stage++) {
      for (let t = 0; t < 70; t++) {
        const cat = this.r.pick(cats);
        const q = this._try(cat, this.levelFor(cat), stage);
        if (q) { if (q.renewed) this.renewed++; return this._push(q); }
      }
    }
    this.exhausted = true;
    return null;
  };
  Session.prototype._push = function (q) {
    q.n = this.items.length + 1;
    this.fps.add(q.fp); this.concepts.add(q.concept);
    this.items.push({ q, chosen: null, correct: null, ms: 0 });
    return q;
  };
  Session.prototype.answer = function (choice, ms) {
    const it = this.items[this.items.length - 1];
    if (!it || it.chosen !== null) return null;
    const q = it.q, st = this.store.s, now = Date.now();
    const res = LG.check(q, choice);
    it.chosen = choice; it.ms = ms || 0; it.correct = res.correct; it.score = res.score; it.res = res;
    const ok = it.correct;
    if (ok) { this.correct++; this.streak++; this.bestStreak = Math.max(this.bestStreak, this.streak); } else { this.wrong++; this.streak = 0; }
    // Statistiques globales
    const S = st.stats; S.answered++; if (ok) S.correct++; S.timeMs += it.ms;
    S.curStreak = ok ? S.curStreak + 1 : 0; S.bestStreak = Math.max(S.bestStreak, S.curStreak);
    const bump = (o, k) => { o[k] = o[k] || { a: 0, c: 0 }; o[k].a++; if (ok) o[k].c++; };
    bump(S.byCat, q.cat); bump(S.bySub, q.cat + "|" + q.sub); bump(S.byLevel, q.d);
    const day = U.today(); st.days[day] = (st.days[day] || 0) + 1;
    st.seen[q.fp] = now; st.recent.push(q.concept); if (st.recent.length > 150) st.recent = st.recent.slice(-150);
    // Par pays (coloration de la carte) et par langue
    [q.iso].filter(Boolean).forEach(i => { const x = st.isoStats[i] = st.isoStats[i] || { a: 0, c: 0 }; x.a++; if (ok) x.c++; });
    const isLang = CAT[q.cat] && CAT[q.cat].lang;
    if (isLang) { const lg = st.lang[q.cat]; lg.byType[q.sub] = lg.byType[q.sub] || { a: 0, c: 0 }; lg.byType[q.sub].a++; if (ok) lg.byType[q.sub].c++; lg.last = now; }
    if (q.dictId) dictReview(st, q.dictId, ok, now);
    // Niveau adaptatif
    if (!q.dictId && !this.cfg.fixed) { const rt = ratingOf(this.store, q.cat); st.ratings[q.cat] = U.clamp(rt + 0.35 * ((ok ? 1 : 0) - expected(rt, q.d)), 1, isLang ? 6 : 5); }
    // Répétition espacée
    const snap = Object.assign({}, q); delete snap.review; delete snap.n; delete snap.renewed;
    if (q.dictId || q.kind === "writing") { /* révisé via le dictionnaire / auto-évalué : pas de file d'erreurs */ }
    else if (!ok) st.mistakes[q.fp] = { q: snap, box: 0, due: now, wrong: ((st.mistakes[q.fp] || {}).wrong || 0) + 1, last: now };
    else if (st.mistakes[q.fp]) {
      const m = st.mistakes[q.fp]; m.box++;
      if (m.box >= INTERVALS.length) { delete st.mistakes[q.fp]; S.mastered = (S.mastered || 0) + 1; }
      else m.due = now + INTERVALS[m.box] * DAY;
    }
    if (ok && q.iso) st.discovered[q.iso] = st.discovered[q.iso] || now;
    return Object.assign({ answer: q.ans }, res, { correct: ok });
  };
  Session.prototype.finish = function () {
    const st = this.store.s;
    const answered = this.items.filter(i => i.chosen !== null);
    const sum = {
      id: U.hash(String(this.seed) + this.start), mode: this.cfg.mode, cats: this.cfg.cats, level: this.cfg.level, iso: this.cfg.iso || null,
      start: this.start, end: Date.now(), n: answered.length, correct: this.correct, bestStreak: this.bestStreak, renewed: this.renewed,
      score20: answered.length ? Math.round(answered.reduce((s, i) => s + (i.score || 0), 0) / answered.length * 200) / 10 : 0,
      title: this.cfg.title || null, daily: this.cfg.daily || null,
      items: answered.map(i => ({ q: i.q, chosen: i.chosen, correct: i.correct, ms: i.ms, score: i.score }))
    };
    if (answered.length) st.sessions.push(sum);
    if (this.cfg.daily && answered.length) st.daily[this.cfg.daily] = { score: this.correct, n: answered.length, at: Date.now() };
    if (this.cfg.situation && answered.length) st.situations[this.cfg.situation] = { score: this.correct, n: answered.length, at: Date.now() };
    const earned = checkBadges(this.store, sum);
    this.store.save();
    return { summary: sum, earned };
  };

  // ---- Badges ----
  const BADGES = [
    { id: "first", name: "Premier voyage", desc: "Terminer une première session.", test: (s) => s.sessions.length >= 1 },
    { id: "q100", name: "Centurion", desc: "Répondre à 100 questions.", test: (s) => s.stats.answered >= 100 },
    { id: "q500", name: "Globe-trotter", desc: "Répondre à 500 questions.", test: (s) => s.stats.answered >= 500 },
    { id: "q1000", name: "Encyclopédiste", desc: "Répondre à 1 000 questions.", test: (s) => s.stats.answered >= 1000 },
    { id: "streak10", name: "Série de 10", desc: "10 bonnes réponses consécutives.", test: (s) => s.stats.bestStreak >= 10 },
    { id: "streak25", name: "Série de 25", desc: "25 bonnes réponses consécutives.", test: (s) => s.stats.bestStreak >= 25 },
    { id: "exam16", name: "Mention très bien", desc: "Obtenir au moins 16/20 en mode Examen.", test: (s, last) => last && last.mode === "examen" && last.n >= 10 && last.score20 >= 16 },
    { id: "marathon30", name: "Marathonien", desc: "30 bonnes réponses dans un marathon.", test: (s, last) => last && last.mode === "marathon" && last.correct >= 30 },
    { id: "review10", name: "Mémoire d'éléphant", desc: "Faire passer 10 erreurs au statut « acquis » en révision.", test: (s) => (s.stats.mastered || 0) >= 10 },
    { id: "days7", name: "Rituel", desc: "S'entraîner 7 jours d'affilée.", test: (s) => dayStreak(s) >= 7 },
    { id: "placed", name: "Boussole", desc: "Passer un test de niveau en langue.", test: (s) => !!(s.lang.en.placed || s.lang.es.placed) },
    { id: "bilingual", name: "Trilingue", desc: "Atteindre le niveau B2 en anglais ET en espagnol.", test: (s) => (s.lang.en.level || 0) >= 4 && (s.lang.es.level || 0) >= 4 },
    { id: "exam_ok", name: "Prêt pour l'examen", desc: "Réussir un examen blanc de langue (60 % et toutes les compétences au-dessus de 40 %).", test: (s) => ["en", "es"].some(k => s.lang[k].exams.some(e => e.pass)) },
    { id: "dict20", name: "Lexicographe", desc: "Enregistrer 20 mots dans son dictionnaire.", test: (s) => s.dict.length >= 20 },
    { id: "dictm10", name: "Vocabulaire ancré", desc: "Faire passer 10 mots du dictionnaire au statut « maîtrisé ».", test: (s) => s.dict.filter(w => (w.srs || {}).box >= 4).length >= 10 },
    { id: "daily", name: "Défi relevé", desc: "Terminer un défi quotidien.", test: (s) => Object.keys(s.daily).length >= 1 },
    { id: "situ5", name: "Débrouillard", desc: "Résoudre 5 situations de la vie réelle.", test: (s) => Object.keys(s.situations).length >= 5 },
    { id: "map50", name: "Cartographe", desc: "Maîtriser 50 pays sur la carte.", test: (s) => Object.values(s.isoStats).filter(x => x.c >= 3 && x.c / x.a >= 0.75).length >= 50 }
  ].concat(CATEGORIES.map(c => ({ id: "master_" + c.id, name: "Maîtrise : " + c.short, desc: `Au moins 80 % de réussite sur 30 questions ou plus en ${c.name}.`, test: (s) => { const x = s.stats.byCat[c.id]; return x && x.a >= 30 && x.c / x.a >= 0.8; } })))
    .concat(Object.entries(D.CONTINENTS).map(([k, v]) => ({ id: "cont_" + k, name: "Explorateur : " + v.name, desc: `Découvrir tous les pays ${v.du} (fiche consultée ou bonne réponse).`, test: (s) => D.countries.filter(c => c.cont === k).every(c => s.discovered[c.iso]) })));
  function checkBadges(store, last) {
    const s = store.s, out = [];
    BADGES.forEach(b => { if (!s.badges[b.id] && b.test(s, last)) { s.badges[b.id] = Date.now(); out.push(b); } });
    return out;
  }
  function dayStreak(s) {
    let n = 0; const d = new Date();
    if (!s.days[U.today()]) d.setDate(d.getDate() - 1);
    for (;;) { const k = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); if (s.days[k]) { n++; d.setDate(d.getDate() - 1); } else break; }
    return n;
  }

  // ---- Questions disponibles pour un pays (mode Monde) ----
  function countryThemes(iso) {
    const themes = { geo: "Géographie", pol: "Politique", eco: "Économie", cult: "Culture" };
    return Object.entries(themes).filter(([k]) => G.some(g => g.cat === k)).map(([id, name]) => ({ id, name }));
  }

  // ---- Dictionnaire personnel : répétition espacée par mot (boîtes de Leitner) ----
  const DICT_INT = [0, 1, 3, 7, 16, 35];
  function dictReview(st, id, ok, now) {
    const w = st.dict.find(x => x.id === id); if (!w) return;
    const s = w.srs = w.srs || { box: 0, due: 0, a: 0, c: 0 };
    s.a++; if (ok) s.c++;
    s.box = ok ? Math.min(5, s.box + 1) : Math.max(0, s.box - 2);
    s.due = now + DICT_INT[s.box] * DAY; s.last = now;
  }

  W.WKA.engine = { KNOW, DICT_INT, dictReview, bankToQuestion, CATEGORIES, CAT, LEVELS, BANK, BADGES, volume, Session, dueMistakes, ratingOf, levelLabel, dayStreak, checkBadges, countryThemes, expected };
})(typeof window !== "undefined" ? window : globalThis);
