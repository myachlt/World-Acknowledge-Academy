/* World Knowledge Academy — Utilitaires du moteur : hasard reproductible, empreintes, formats */
(function (W) {
  const U = {};

  // Générateur pseudo-aléatoire reproductible (mulberry32) : une graine = une session rejouable.
  U.rng = function (seed) {
    let a = seed >>> 0;
    const r = function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    r.int = n => Math.floor(r() * n);
    r.pick = arr => arr[Math.floor(r() * arr.length)];
    r.shuffle = arr => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    r.sample = (arr, n) => r.shuffle(arr).slice(0, n);
    return r;
  };

  // Hachage FNV-1a 32 bits, rendu en base 36 : identifiant court et stable.
  U.hash = function (str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(36);
  };

  // Normalisation : minuscules, sans accents ni ponctuation.
  U.norm = s => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
    .replace(/[’']/g, " ").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

  const STOP = new Set("le la les l de du des d un une a au aux en et est sont quel quelle quels quelles qui que quoi dans sur par pour avec ce cette ces se sa son ses lequel laquelle lesquels pays monde il elle on y ne pas plus moins comment appelle appelee t".split(" "));

  // Empreinte de CONTENU : indépendante de l'ordre des mots et des mots-outils.
  // Deux formulations qui testent le même fait avec la même réponse produisent la même empreinte.
  U.contentKey = function (question, answer) {
    const toks = U.norm(question).split(" ").filter(t => t.length > 2 && !STOP.has(t));
    const uniq = Array.from(new Set(toks)).sort();
    return U.hash(uniq.join(" ") + "=>" + U.norm(answer));
  };

  // Similarité de Jaccard entre deux questions (détection des quasi-doublons).
  U.similarity = function (a, b) {
    const A = new Set(U.norm(a).split(" ").filter(t => t.length > 2 && !STOP.has(t)));
    const B = new Set(U.norm(b).split(" ").filter(t => t.length > 2 && !STOP.has(t)));
    if (!A.size || !B.size) return 0;
    let inter = 0; A.forEach(t => { if (B.has(t)) inter++; });
    return inter / (A.size + B.size - inter);
  };

  U.flag = iso => iso.toUpperCase().replace(/./g, c => String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 65));

  const nf = new Intl.NumberFormat("fr-FR");
  U.num = n => nf.format(n);
  U.pop = function (m) { // m en millions
    if (m >= 1000) return (Math.round(m / 10) / 100).toLocaleString("fr-FR") + " milliard" + (m >= 2000 ? "s" : "");
    if (m >= 10) return Math.round(m).toLocaleString("fr-FR") + " millions";
    if (m >= 1) return (Math.round(m * 10) / 10).toLocaleString("fr-FR") + " million" + (m >= 2 ? "s" : "");
    const v = m * 1e6;
    const r = v >= 100000 ? Math.round(v / 10000) * 10000 : v >= 10000 ? Math.round(v / 1000) * 1000 : Math.round(v / 100) * 100;
    return nf.format(r) + " habitants";
  };
  U.area = function (a) {
    if (a < 10) return a.toLocaleString("fr-FR") + " km²";
    const r = a >= 100000 ? Math.round(a / 1000) * 1000 : a >= 1000 ? Math.round(a / 100) * 100 : Math.round(a);
    return nf.format(r) + " km²";
  };
  U.density = d => (d >= 100 ? nf.format(Math.round(d)) : (Math.round(d * 10) / 10).toLocaleString("fr-FR")) + " hab./km²";
  U.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  U.today = () => { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };

  // Ancienneté (en mois) d'une donnée datée "AAAA-MM" ou "AAAA".
  U.monthsSince = function (asOf, now) {
    if (!asOf) return 0;
    const [y, m] = String(asOf).split("-").map(Number);
    const n = now || new Date();
    return (n.getFullYear() - y) * 12 + (n.getMonth() + 1 - (m || 6));
  };
  U.asOfLabel = function (asOf) {
    if (!asOf) return "";
    const mois = ["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre"];
    const [y, m] = String(asOf).split("-").map(Number);
    return m ? mois[m - 1] + " " + y : String(y);
  };

  W.WKA = W.WKA || {};
  W.WKA.util = U;
})(typeof window !== "undefined" ? window : globalThis);
