/* World Knowledge Academy — Persistance (couche DONNÉES UTILISATEUR)
 * Un adaptateur unique (load/save) : aujourd'hui localStorage, demain une API ou une base distante
 * sans toucher au moteur ni à l'interface. Une clé par profil permet plusieurs utilisateurs.
 */
(function (W) {
  const KEY = "wka:v1:";
  const mem = {};
  const LocalAdapter = {
    load(id) { try { const s = W.localStorage.getItem(KEY + id); return s ? JSON.parse(s) : (mem[id] || null); } catch (e) { return mem[id] || null; } },
    save(id, v) { mem[id] = v; try { W.localStorage.setItem(KEY + id, JSON.stringify(v)); return true; } catch (e) { return false; } },
    remove(id) { delete mem[id]; try { W.localStorage.removeItem(KEY + id); } catch (e) { /* stockage indisponible */ } }
  };

  const fresh = () => ({
    v: 1,
    profile: { name: "", dailyGoal: 10, oneTap: false, timer: 0, createdAt: Date.now() },
    stats: { answered: 0, correct: 0, timeMs: 0, bestStreak: 0, curStreak: 0, byCat: {}, bySub: {}, byLevel: {} },
    sessions: [],      // résumés + détail des 60 dernières sessions
    seen: {},          // empreinte -> horodatage de dernière présentation
    recent: [],        // derniers concepts vus (anti-similarité entre sessions)
    mistakes: {},      // empreinte -> { q, box, due, wrong }
    ratings: {},       // catégorie -> niveau estimé (1-5, décimal)
    badges: {},        // id -> horodatage d'obtention
    days: {},          // AAAA-MM-JJ -> nombre de réponses
    discovered: {},    // iso -> horodatage (fiche consultée ou bonne réponse)
    reports: [],       // signalements d'erreurs
    // v0.2
    lang: { en: freshLang(), es: freshLang() }, // niveau CECRL, test de niveau, examens, réussite par type d'exercice
    dict: [],          // dictionnaire personnel : { id, fr, en, es, cat, nat, ex, created, srs }
    gloss: [],         // glossaire personnel : { id, notion, def, ex, cat, created }
    isoStats: {},      // iso -> { a, c } : maîtrise par pays (coloration de la carte)
    daily: {},         // AAAA-MM-JJ -> résultat du défi quotidien
    situations: {},    // id -> meilleur résultat
    dykSeen: {},       // « Le saviez-vous » déjà approfondis
    settings: { accentEn: "en-GB", accentEs: "es-ES", rate: 1, theme: "auto" }
  });
  function freshLang() { return { level: null, placed: null, exams: [], byType: {}, last: 0 }; }

  // Exemples fournis dans le cahier des charges : le dictionnaire n'est jamais vide au premier lancement.
  function seedDict() {
    const now = Date.now();
    return [["la maison", "house", "la casa", "Quotidien", "nom", "J'habite dans une maison avec un jardin. / I live in a house with a garden."],
      ["le travail", "work", "el trabajo", "Professionnel", "nom", "Je vais au travail à vélo. / I cycle to work."],
      ["l'environnement", "environment", "el medio ambiente", "Sciences", "nom", "Il faut protéger l'environnement. / We must protect the environment."]]
      .map((w, i) => ({ id: "d" + now.toString(36) + i, fr: w[0], en: w[1], es: w[2], cat: w[3], nat: w[4], ex: w[5], created: now - (3 - i) * 1000, srs: { box: 0, due: 0, a: 0, c: 0 } }));
  }
  function Store(adapter, id) {
    this.adapter = adapter || LocalAdapter;
    this.id = id || "default";
    const loaded = this.adapter.load(this.id);
    this.s = Object.assign(fresh(), loaded || {});
    this.s.profile = Object.assign(fresh().profile, this.s.profile || {});
    this.s.stats = Object.assign(fresh().stats, this.s.stats || {});
    const f = fresh();
    this.s.lang = Object.assign(f.lang, this.s.lang || {});
    ["en", "es"].forEach(k => { this.s.lang[k] = Object.assign(freshLang(), this.s.lang[k] || {}); });
    this.s.settings = Object.assign(f.settings, this.s.settings || {});
    if (!loaded || !loaded.dict) this.s.dict = seedDict();
  }
  Store.prototype.save = function () {
    if (this.s.sessions.length > 60) {
      this.s.sessions.slice(0, this.s.sessions.length - 60).forEach(x => { delete x.items; });
      if (this.s.sessions.length > 400) this.s.sessions = this.s.sessions.slice(-400);
    }
    const seenKeys = Object.keys(this.s.seen);
    if (seenKeys.length > 20000) seenKeys.sort((a, b) => this.s.seen[a] - this.s.seen[b]).slice(0, seenKeys.length - 20000).forEach(k => delete this.s.seen[k]);
    return this.adapter.save(this.id, this.s);
  };
  Store.prototype.reset = function () { this.s = fresh(); this.s.dict = seedDict(); this.adapter.remove(this.id); };
  Store.prototype.exportJSON = function () { return JSON.stringify(this.s); };
  Store.prototype.importJSON = function (txt) {
    const v = JSON.parse(txt);
    if (!v || v.v !== 1 || !v.stats) throw new Error("Ce fichier n'est pas une sauvegarde World Knowledge Academy.");
    this.s = Object.assign(fresh(), v);
    ["en", "es"].forEach(k => { this.s.lang[k] = Object.assign(freshLang(), (v.lang || {})[k] || {}); });
    this.save();
  };

  W.WKA = W.WKA || {};
  W.WKA.Store = Store;
  W.WKA.LocalAdapter = LocalAdapter;
})(typeof window !== "undefined" ? window : globalThis);
