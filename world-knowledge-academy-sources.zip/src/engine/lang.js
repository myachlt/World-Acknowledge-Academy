/* World Knowledge Academy — Moteur des langues (couche LOGIQUE)
 * Anglais et espagnol : générateurs d'exercices par type et par niveau CECRL (1=A1 … 6=C2),
 * correction tolérante des réponses saisies, test de positionnement, examens blancs par compétence.
 * Types d'items : mcq (choix), input (saisie), match (associations), cloze (texte à trous),
 * passage (lecture / écoute + questions), writing (expression écrite, auto-évaluation guidée).
 */
(function (W) {
  const D = W.WKA.data, U = W.WKA.util, G = W.WKA.generators;
  const LANG = D.LANG, V = D.VOCAB;
  const CEFR = ["A1", "A2", "B1", "B2", "C1", "C2"];
  const CEFR_DESC = [
    "Comprendre et utiliser des expressions familières et quotidiennes.",
    "Communiquer lors de tâches simples et habituelles.",
    "Se débrouiller en voyage, raconter un événement, donner son avis simplement.",
    "Comprendre l'essentiel de sujets complexes, argumenter avec aisance.",
    "S'exprimer spontanément et couramment, comprendre des textes longs et exigeants.",
    "Comprendre pratiquement tout, nuancer finement le sens."
  ];
  const lvlName = l => CEFR[U.clamp(l, 1, 6) - 1];

  // ---------- Correction tolérante ----------
  const clean = s => String(s || "").replace(/[’`´]/g, "'").replace(/[“”«»]/g, '"').replace(/\s+/g, " ").trim().replace(/^[¿¡"]+|[.!?"…]+$/g, "").trim().toLowerCase();
  const noAcc = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "");
  const toks = s => clean(s).replace(/[,;:()]/g, " ").split(" ").filter(Boolean);
  function diff(user, target) { // alignement mot à mot (plus longue sous-séquence commune)
    const a = toks(user), b = toks(target), n = a.length, m = b.length;
    const L = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = noAcc(a[i]) === noAcc(b[j]) ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    const out = []; let i = 0, j = 0;
    while (i < n && j < m) { if (noAcc(a[i]) === noAcc(b[j])) { out.push({ t: b[j], s: a[i] === b[j] ? "ok" : "acc" }); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) { out.push({ t: a[i], s: "extra" }); i++; } else { out.push({ t: b[j], s: "miss" }); j++; } }
    while (i < n) out.push({ t: a[i++], s: "extra" }); while (j < m) out.push({ t: b[j++], s: "miss" });
    return { tokens: out, sim: m ? L[0][0] / Math.max(n, m) : 0 };
  }
  function checkText(resp, accept) {
    const r = clean(resp);
    if (!r) return { correct: false, score: 0, empty: true, best: accept[0] };
    for (const a of accept) if (clean(a) === r) return { correct: true, score: 1, best: a };
    for (const a of accept) if (noAcc(clean(a)) === noAcc(r)) return { correct: true, score: 1, best: a, accents: true };
    let best = accept[0], bd = null;
    accept.forEach(a => { const d = diff(resp, a); if (!bd || d.sim > bd.sim) { bd = d; best = a; } });
    return { correct: false, score: 0, best, diff: bd.tokens, near: bd.sim >= 0.75 };
  }
  function parseCloze(text) {
    const parts = []; const re = /\{\{(.+?)\}\}/g; let last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) parts.push(text.slice(last, m.index));
      const body = m[1];
      if (body[0] === "=") parts.push({ accept: body.slice(1).split("/") });
      else { const o = body.split("|"); parts.push({ answer: o[0], opts: o }); }
      last = re.lastIndex;
    }
    if (last < text.length) parts.push(text.slice(last));
    return parts;
  }
  const gaps = q => q.parts.filter(p => typeof p !== "string");
  // Vérifie une réponse, quel que soit le type d'item. resp : index (mcq), texte (input), tableaux (autres).
  function check(q, resp) {
    const k = q.kind || "mcq";
    if (k === "mcq") return { correct: resp === q.ans, score: resp === q.ans ? 1 : 0 };
    if (k === "input") return checkText(resp, q.accept);
    if (k === "match") { const ok = q.pairs.map((p, i) => resp && resp[i] === i); const n = ok.filter(Boolean).length; return { correct: n === q.pairs.length, score: n / q.pairs.length, marks: ok }; }
    if (k === "cloze") {
      const g = gaps(q); const marks = g.map((p, i) => p.opts ? (resp && resp[i]) === p.answer : checkText(resp && resp[i], p.accept));
      const n = marks.filter(x => x === true || (x && x.correct)).length;
      return { correct: n === g.length, score: n / g.length, marks, n, total: g.length };
    }
    if (k === "passage") { const marks = q.subqs.map((s, i) => resp && resp[i] === s.ans); const n = marks.filter(Boolean).length; return { correct: n >= Math.ceil(q.subqs.length * 0.67), score: n / q.subqs.length, marks, n, total: q.subqs.length }; }
    if (k === "writing") {
      const words = String((resp && resp.text) || "").trim().split(/\s+/).filter(Boolean).length;
      const ticks = (resp && resp.ticks || []).filter(Boolean).length;
      const lenOk = words >= q.min && words <= q.max * 1.15;
      const score = (ticks + (lenOk ? 1 : 0)) / (q.criteria.length + 1);
      return { correct: score >= 0.6, score, words, lenOk, selfAssessed: true };
    }
    return { correct: false, score: 0 };
  }

  // ---------- Générateurs ----------
  const SUBS = {
    voc: "Vocabulaire", wtr: "Traduction de mots", match: "Associations", img: "Images", ear: "Écoute de mots", odd: "Intrus",
    syn: "Synonymes et antonymes", defs: "Définitions", idiom: "Expressions idiomatiques", ff: "Faux amis", scene: "Scènes",
    gram: "Grammaire", conj: "Conjugaison", phr: "Verbes à particule", cloze: "Textes à trous", read: "Compréhension écrite",
    listen: "Compréhension orale", tr: "Traduction de phrases", corr: "Correction d'erreurs", wf: "Formation de mots", kwt: "Transformations", write: "Expression écrite"
  };
  const GROUPS = [
    { id: "lex", name: "Vocabulaire et images", icon: "📚", subs: ["voc", "wtr", "match", "img", "ear", "odd", "syn", "defs", "idiom", "ff", "scene"] },
    { id: "gram", name: "Grammaire et conjugaison", icon: "🧩", subs: ["gram", "conj", "phr"] },
    { id: "comp", name: "Textes et compréhension", icon: "📰", subs: ["cloze", "read", "listen"] },
    { id: "expr", name: "Expression et traduction", icon: "✍️", subs: ["tr", "corr", "wf", "kwt", "write"] }
  ];
  const near = (arr, level, key) => { // contenus du niveau demandé, sinon du niveau le plus proche en dessous puis au-dessus
    const lv = x => (key ? x[key] : x.l);
    const widen = p => { if (p.length >= 3) return p; const w = arr.filter(x => Math.abs(lv(x) - level) <= 1); return w.length > p.length ? w : p; }; // peu de textes : on ouvre aux niveaux voisins
    for (let d = 0; d <= 5; d++) { const p = arr.filter(x => lv(x) === level - d); if (p.length) return widen(p); }
    for (let d = 1; d <= 5; d++) { const p = arr.filter(x => lv(x) === level + d); if (p.length) return widen(p); }
    return arr;
  };
  const vocPool = (level, pred) => { const p = V.filter(v => v.lvl <= level && v.lvl >= level - 2 && (!pred || pred(v))); return p.length >= 8 ? p : V.filter(v => v.lvl <= Math.max(level, 2) && (!pred || pred(v))); };
  const ttsOf = code => code === "en" ? "en-GB" : "es-ES";
  const bare = s => s.replace(/^(le |la |les |l'|el |los |las |to )/i, "");

  function mcq(r, o) {
    const opts = r.shuffle([o.answer].concat(o.wrong));
    if (new Set(opts.map(x => U.norm(x))).size !== opts.length) return null;
    return Object.assign({ kind: "mcq", opts, ans: opts.indexOf(o.answer), nature: "lang", src: o.src || "Contenu original World Knowledge Academy", info: "", ctx: "" }, o, { fp: U.hash(o.fpKey), answer: undefined, wrong: undefined });
  }
  function item(o) { return Object.assign({ nature: "lang", src: "Contenu original World Knowledge Academy", info: "", ctx: "", ex: "" }, o, { fp: U.hash(o.fpKey) }); }

  function defLang(code) {
    const L = LANG[code], T = code, tts = ttsOf(code), other = code === "en" ? "es" : "en";
    const nm = code === "en" ? "anglais" : "espagnol";
    const def = (key, weight, make, space) => G.push({ id: code + "_" + key, cat: code, sub: SUBS[key], weight, bump: 0, lang: true, make, space });
    const wordOf = v => v[T];

    def("voc", 3, function (r, level) {
      const pool = vocPool(level); const v = r.pick(pool);
      const same = pool.filter(x => x !== v && x.nat === v.nat && U.norm(x[T]) !== U.norm(v[T]));
      const dist = r.sample(same.filter(x => x.theme === v.theme).concat(r.shuffle(same)).filter((x, i, a) => a.indexOf(x) === i), 3);
      if (dist.length < 3) return null;
      const toTarget = r() < 0.5;
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: v.lvl, q: toTarget ? `Comment dit-on en ${nm} :` : `Que signifie ce mot ${code === "en" ? "anglais" : "espagnol"} ?`,
        prompt: toTarget ? v.fr : v[T], say: toTarget ? null : { text: bare(v[T]) === v[T] ? v[T] : v[T], lang: tts },
        answer: toTarget ? v[T] : v.fr, wrong: dist.map(x => toTarget ? x[T] : x.fr),
        ex: `${v.fr} = ${v[T]}${code === "en" && v.ipa ? " " + v.ipa : ""} (${v.nat}, thème ${v.theme.toLowerCase()}). En ${code === "en" ? "espagnol" : "anglais"} : ${v[other]}.`,
        addWord: { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat }, img: v.img || null,
        fpKey: `${T}voc|${v.id}|${toTarget}`, concept: `${T}w|${v.id}` });
    }, () => ({ n: V.length * 2, exact: true }));

    def("wtr", 1.6, function (r, level) {
      const v = r.pick(vocPool(level)); const toTarget = r() < 0.65;
      const acc = toTarget ? [v[T], bare(v[T])] : [v.fr, bare(v.fr)];
      return item({ kind: "input", gen: this.id, cat: T, sub: this.sub, d: v.lvl, q: toTarget ? `Écrivez en ${nm} :` : "Écrivez en français :",
        prompt: toTarget ? v.fr : v[T], say: toTarget ? null : { text: v[T], lang: tts }, accept: Array.from(new Set(acc)), lang: toTarget ? T : "fr",
        hint: toTarget && code === "es" ? "L'article (el / la) est accepté mais pas obligatoire." : (toTarget ? "« to » devant un verbe est facultatif." : "L'article est facultatif."),
        ex: `${v.fr} = ${v[T]}${code === "en" && v.ipa ? " " + v.ipa : ""}.`, addWord: { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat },
        fpKey: `${T}wtr|${v.id}|${toTarget}`, concept: `${T}w|${v.id}` });
    }, () => ({ n: V.length * 2, exact: true }));

    def("match", 1.2, function (r, level) {
      const pool = vocPool(level); const set = r.sample(pool, 5);
      if (new Set(set.map(v => U.norm(v[T]))).size < 5) return null;
      return item({ kind: "match", gen: this.id, cat: T, sub: this.sub, d: Math.max(...set.map(v => v.lvl)), q: `Associez chaque mot français à sa traduction en ${nm}.`,
        pairs: set.map(v => [v.fr, v[T]]), rightOrder: r.shuffle([0, 1, 2, 3, 4]), lang: tts,
        ex: set.map(v => `${v.fr} = ${v[T]}`).join(" · "), fpKey: `${T}match|` + set.map(v => v.id).sort().join(","), concept: `${T}match|` + set.map(v => v.id).sort().join(",") });
    }, () => ({ n: 50000, exact: false, facts: V.length }));

    def("img", 1.6, function (r, level) {
      const pool = vocPool(Math.max(level, 2), v => v.img); const v = r.pick(pool);
      const dist = r.sample(pool.filter(x => x !== v && x.img !== v.img), 3); if (dist.length < 3) return null;
      if (r() < 0.6) return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: v.lvl, q: `Quel mot ${code === "en" ? "anglais" : "espagnol"} correspond à cette image ?`, bigEmoji: v.img,
        answer: v[T], wrong: dist.map(x => x[T]), ex: `${v.img} ${v[T]} = ${v.fr}.`, addWord: { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat },
        fpKey: `${T}img|${v.id}`, concept: `${T}w|${v.id}` });
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: v.lvl, q: "Quelle image correspond à ce mot ?", prompt: v[T], say: { text: v[T], lang: tts }, emojiOpts: true,
        answer: v.img, wrong: dist.map(x => x.img), ex: `${v[T]} = ${v.fr} ${v.img}.`, addWord: { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat },
        fpKey: `${T}imgr|${v.id}`, concept: `${T}w|${v.id}` });
    }, () => ({ n: V.filter(v => v.img).length * 2, exact: true }));

    def("ear", 1.1, function (r, level) {
      const pool = vocPool(level); const v = r.pick(pool);
      const dist = r.sample(pool.filter(x => x !== v && x.nat === v.nat), 3); if (dist.length < 3) return null;
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: v.lvl, q: "Écoutez le mot, puis choisissez sa traduction.", audioOnly: { text: v[T], lang: tts },
        answer: v.fr, wrong: dist.map(x => x.fr), ex: `Vous avez entendu « ${v[T]} »${code === "en" && v.ipa ? " " + v.ipa : ""} = ${v.fr}.`,
        addWord: { fr: v.fr, en: v.en, es: v.es, cat: v.theme, nat: v.nat }, needsAudio: true,
        fpKey: `${T}ear|${v.id}`, concept: `${T}ear|${v.id}` });
    }, () => ({ n: V.length, exact: true }));

    def("odd", 1, function (r, level) {
      const pool = vocPool(Math.max(level, 2)); const themes = Array.from(new Set(pool.map(v => v.theme)));
      for (let k = 0; k < 10; k++) {
        const th = r.pick(themes); const inT = pool.filter(v => v.theme === th); if (inT.length < 3) continue;
        const three = r.sample(inT, 3); const odd = r.pick(pool.filter(v => v.theme !== th));
        return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: Math.max(...three.map(v => v.lvl), odd.lvl), q: "Quel mot est l'intrus ?",
          answer: odd[T], wrong: three.map(v => v[T]),
          ex: `${three.map(v => `${v[T]} (${v.fr})`).join(", ")} relèvent du thème « ${th} » ; ${odd[T]} (${odd.fr}) appartient au thème « ${odd.theme} ».`,
          fpKey: `${T}odd|${three.map(v => v.id).sort().join(",")}|${odd.id}`, concept: `${T}odd|${odd.id}` });
      }
      return null;
    }, () => ({ n: 20000, exact: false, facts: V.length }));

    def("syn", 1.2, function (r, level) {
      const isSyn = r() < 0.5; const list = isSyn ? L.synonyms : L.antonyms;
      const pool = near(list, level, 2); const p = r.pick(pool); const flip = r() < 0.5;
      const word = flip ? p[1] : p[0], ans = flip ? p[0] : p[1];
      const wrong = r.sample(list.filter(x => x !== p).map(x => r() < 0.5 ? x[0] : x[1]).filter(x => x !== ans && x !== word), 3);
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[2], q: isSyn ? "Quel est le SYNONYME de ce mot ?" : "Quel est le CONTRAIRE de ce mot ?", prompt: word, say: { text: word, lang: tts },
        answer: ans, wrong, ex: `${word} ${isSyn ? "≈" : "≠"} ${ans}.`, fpKey: `${T}syn|${word}|${ans}`, concept: `${T}syn|${p[0]}` });
    }, () => ({ n: (L.synonyms.length + L.antonyms.length) * 2, exact: true }));

    def("defs", 1, function (r, level) {
      const p = r.pick(near(L.definitions, level, 2));
      const wrong = r.sample(L.definitions.filter(x => x !== p), 3).map(x => x[0]);
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[2], q: "Quel mot correspond à cette définition ?", prompt: "« " + p[1] + " »", say: { text: p[1], lang: tts },
        answer: p[0], wrong, ex: `${p[0]} : ${p[1]}.`, fpKey: `${T}def|${p[0]}`, concept: `${T}def|${p[0]}` });
    }, () => ({ n: L.definitions.length, exact: true }));

    def("idiom", 1, function (r, level) {
      const p = r.pick(near(L.idioms, level, 2));
      const wrong = r.sample(L.idioms.filter(x => x !== p), 3).map(x => x[1]);
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[2], q: "Que signifie cette expression ?", prompt: p[0], say: { text: p[0], lang: tts },
        answer: p[1], wrong, ex: `« ${p[0]} » ≈ « ${p[1]} ». Une expression idiomatique ne se traduit pas mot à mot.`,
        addWord: { fr: p[1], en: code === "en" ? p[0] : "", es: code === "es" ? p[0] : "", cat: "Expressions", nat: "expression" },
        fpKey: `${T}idiom|${p[0]}`, concept: `${T}idiom|${p[0]}` });
    }, () => ({ n: L.idioms.length, exact: true }));

    def("ff", 1, function (r, level) {
      const p = r.pick(near(L.falseFriends, level, 3));
      const others = r.sample(L.falseFriends.filter(x => x !== p), 2).map(x => x[1]);
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[3], q: `Faux ami : que signifie « ${p[0]} » en ${nm} ?`, prompt: p[0], say: { text: p[0], lang: tts },
        answer: p[1], wrong: [p[2]].concat(others), ex: `« ${p[0]} » signifie « ${p[1]} », et non « ${p[2]} ».`,
        addWord: { fr: p[1], en: code === "en" ? p[0] : "", es: code === "es" ? p[0] : "", cat: "Faux amis", nat: "mot" },
        fpKey: `${T}ff|${p[0]}`, concept: `${T}ff|${p[0]}` });
    }, () => ({ n: L.falseFriends.length, exact: true }));

    def("scene", 1, function (r, level) {
      const p = r.pick(near(L.scenes, level, 3));
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[3], q: "Quelle phrase décrit le mieux la scène ?", bigEmoji: p[0],
        answer: p[1], wrong: p[2], ex: `${p[0]} : « ${p[1]} »`, say: { text: p[1], lang: tts }, sayAfter: true,
        fpKey: `${T}scene|${p[0]}`, concept: `${T}scene|${p[0]}` });
    }, () => ({ n: L.scenes.length, exact: true }));

    def("gram", 3, function (r, level) {
      const g = r.pick(near(L.grammar, level));
      return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: g.l, topic: g.sub, q: `${g.sub} — complétez :`, prompt: g.q,
        answer: g.a, wrong: g.w, ex: g.ex, sayAfter: true, say: { text: g.q.replace(/_{2,}/, g.a), lang: tts },
        fpKey: `${T}gram|${g.q}`, concept: `${T}gram|${g.q}` });
    }, () => ({ n: L.grammar.length, exact: true }));

    if (code === "en") {
      def("conj", 2, function (r, level) {
        const v = r.pick(L.irregular); const form = r.int(2) + 1; const fname = form === 1 ? "prétérit (past simple)" : "participe passé (past participle)";
        const acc = v[form].split("/");
        if (r() < 0.5 || level <= 2) {
          const wrong = Array.from(new Set([v[0] + "ed", form === 1 ? v[2] : v[1], v[0]].filter(x => !acc.includes(x)))).slice(0, 3);
          if (wrong.length < 3) wrong.push(v[0] + "s");
          return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: Math.max(2, Math.min(level, 4)), q: `Quel est le ${fname} de « ${v[0]} » (${v[3]}) ?`,
            answer: v[form], wrong: wrong.slice(0, 3), ex: `${v[0]} → ${v[1]} → ${v[2]} (${v[3]}).`, say: { text: `${v[0]}, ${v[1].replace("/", ", ")}, ${v[2]}`, lang: tts }, sayAfter: true,
            fpKey: `enirr|${v[0]}|${form}|m`, concept: `enirr|${v[0]}|${form}` });
        }
        return item({ kind: "input", gen: this.id, cat: T, sub: this.sub, d: Math.max(2, Math.min(level, 4)), q: `Écrivez le ${fname} de :`, prompt: `${v[0]} (${v[3]})`,
          accept: acc.concat([v[form]]), lang: "en", ex: `${v[0]} → ${v[1]} → ${v[2]}.`, say: { text: `${v[0]}, ${v[1].replace("/", ", ")}, ${v[2]}`, lang: tts }, sayAfter: true,
          fpKey: `enirr|${v[0]}|${form}|i`, concept: `enirr|${v[0]}|${form}` });
      }, () => ({ n: L.irregular.length * 4, exact: true }));
      def("phr", 1.2, function (r, level) {
        const p = r.pick(near(L.phrasal, level, 3));
        const wrong = r.sample(L.phrasal.filter(x => x !== p), 3).map(x => x[1]);
        return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: p[3], q: "Que signifie ce verbe à particule dans la phrase ?", prompt: p[2].replace(new RegExp("\\b(" + p[0].split(" ")[0] + "\\w*)", "i"), "$1"), say: { text: p[2], lang: tts },
          answer: p[1], wrong, ex: `« ${p[0]} » = ${p[1]}. Exemple : ${p[2]}`, addWord: { fr: p[1], en: p[0], es: "", cat: "Verbes à particule", nat: "verbe" },
          fpKey: `enphr|${p[0]}`, concept: `enphr|${p[0]}` });
      }, () => ({ n: L.phrasal.length, exact: true }));
    } else {
      def("conj", 2, function (r, level) {
        const pool = near(L.conj, level, 4); const v = r.pick(pool);
        const tenses = Object.keys(v[3]).filter(t => level >= 3 || !/Subjonctif/.test(t)); const t = r.pick(tenses); const pi = r.int(6);
        const ans = v[3][t][pi]; const person = L.persons[pi];
        if (r() < 0.55) {
          const cand = Array.from(new Set(v[3][t].concat(...Object.values(v[3]).map(f => [f[pi]])))).filter(x => x !== ans);
          const wrong = r.sample(cand, 3); if (wrong.length < 3) return null;
          return mcq(r, { gen: this.id, cat: T, sub: this.sub, d: Math.max(v[4], /Subjonctif/.test(t) ? 3 : 1), q: `Conjuguez « ${v[0]} » (${v[1]}) — ${t.toLowerCase()}, ${person} :`,
            answer: ans, wrong, ex: `${v[0]}, ${t.toLowerCase()} : ${v[3][t].map((f, i) => `${L.persons[i]} ${f}`).join(", ")}. (${v[2]})`, conjTable: { verb: v[0], tense: t, forms: v[3][t] },
            fpKey: `esconj|${v[0]}|${t}|${pi}|m`, concept: `esconj|${v[0]}|${t}|${pi}` });
        }
        return item({ kind: "input", gen: this.id, cat: T, sub: this.sub, d: Math.max(v[4], /Subjonctif/.test(t) ? 3 : 1), q: `Conjuguez « ${v[0]} » (${v[1]}) — ${t.toLowerCase()} :`, prompt: `${person} …`,
          accept: [ans], lang: "es", ex: `${v[0]}, ${t.toLowerCase()} : ${v[3][t].map((f, i) => `${L.persons[i]} ${f}`).join(", ")}.`, conjTable: { verb: v[0], tense: t, forms: v[3][t] },
          hint: "Les accents comptent (une réponse sans accent est acceptée mais signalée).",
          fpKey: `esconj|${v[0]}|${t}|${pi}|i`, concept: `esconj|${v[0]}|${t}|${pi}` });
      }, () => ({ n: L.conj.reduce((s, v) => s + Object.keys(v[3]).length * 6 * 2, 0), exact: true }));
    }

    def("cloze", 1.4, function (r, level) {
      const c = r.pick(near(L.cloze, level));
      return item({ kind: "cloze", gen: this.id, cat: T, sub: this.sub, d: c.l, q: "Complétez le texte.", title: c.title, parts: parseCloze(c.text), lang: tts,
        ex: "Texte complet : " + c.text.replace(/\{\{=?([^|}/]+)[^}]*\}\}/g, "$1"), fpKey: `${T}cloze|${c.title}`, concept: `${T}cloze|${c.title}` });
    }, () => ({ n: L.cloze.length, exact: true }));

    def("read", 1.3, function (r, level) {
      const t = r.pick(near(L.reading, level));
      return item({ kind: "passage", gen: this.id, cat: T, sub: this.sub, d: t.l, q: "Lisez le document, puis répondez aux questions.", title: t.title, genre: t.genre, text: t.text, lang: tts,
        subqs: t.qs.map(s => { const opts = r.shuffle([s[1]].concat(s[2])); return { q: s[0], opts, ans: opts.indexOf(s[1]) }; }),
        ex: "Relisez le passage qui justifie chaque réponse : la bonne option reformule le texte, les autres déforment un détail.", fpKey: `${T}read|${t.title}`, concept: `${T}read|${t.title}` });
    }, () => ({ n: L.reading.length, exact: true }));

    def("listen", 1.3, function (r, level) {
      const t = r.pick(near(L.listening, level));
      return item({ kind: "passage", audio: true, gen: this.id, cat: T, sub: this.sub, d: t.l, q: "Écoutez l'enregistrement (synthèse vocale), puis répondez.", title: t.title, lines: t.lines, lang: tts,
        subqs: t.qs.map(s => { const opts = r.shuffle([s[1]].concat(s[2])); return { q: s[0], opts, ans: opts.indexOf(s[1]) }; }),
        ex: "La transcription s'affiche après la correction. Astuce : lisez les questions AVANT d'écouter.", fpKey: `${T}listen|${t.title}`, concept: `${T}listen|${t.title}` });
    }, () => ({ n: L.listening.length, exact: true }));

    def("tr", 1.3, function (r, level) {
      const t = r.pick(near(L.translations, level));
      return item({ kind: "input", long: true, gen: this.id, cat: T, sub: this.sub, d: t.l, q: `Traduisez en ${nm} :`, prompt: t.fr, accept: t.accept, lang: code,
        ex: (t.note ? t.note + " " : "") + "Traductions acceptées : " + t.accept.slice(0, 3).join(" / "), say: { text: t.accept[0], lang: tts }, sayAfter: true,
        fpKey: `${T}tr|${t.fr}`, concept: `${T}tr|${t.fr}` });
    }, () => ({ n: L.translations.length, exact: true }));

    def("corr", 1.1, function (r, level) {
      const t = r.pick(near(L.corrections, level));
      return item({ kind: "input", long: true, gen: this.id, cat: T, sub: this.sub, d: t.l, q: "Cette phrase contient une erreur. Réécrivez-la correctement :", prompt: t.wrong, accept: t.accept, lang: code, prefill: t.wrong,
        ex: t.note + " Correction : " + t.accept[0], fpKey: `${T}corr|${t.wrong}`, concept: `${T}corr|${t.wrong}` });
    }, () => ({ n: L.corrections.length, exact: true }));

    def("wf", 1, function (r, level) {
      const t = r.pick(near(L.wordFormation, level));
      return item({ kind: "input", gen: this.id, cat: T, sub: this.sub, d: t.l, q: `Formation de mots : complétez avec un mot formé à partir de ${t.stem}.`, prompt: t.s, accept: t.accept, lang: code,
        ex: `${t.stem} → ${t.accept[0]}. Repérez la nature du mot attendu (nom, adjectif, adverbe) et le sens (positif, négatif).`, fpKey: `${T}wf|${t.s}`, concept: `${T}wf|${t.s}` });
    }, () => ({ n: L.wordFormation.length, exact: true }));

    def("kwt", 0.9, function (r, level) {
      const t = r.pick(near(L.kwt, level));
      return item({ kind: "input", gen: this.id, cat: T, sub: this.sub, d: t.l, q: `Transformation : complétez la 2ᵉ phrase pour qu'elle ait le même sens, en utilisant le mot ${t.key} (2 à 5 mots).`,
        prompt: t.s1 + "\n→ " + t.s2, accept: t.accept, lang: code, ex: `Réponse : ${t.accept[0]}.`, fpKey: `${T}kwt|${t.s1}`, concept: `${T}kwt|${t.s1}` });
    }, () => ({ n: L.kwt.length, exact: true }));

    def("write", 0.6, function (r, level) {
      const t = r.pick(near(L.writing, level));
      return item({ kind: "writing", gen: this.id, cat: T, sub: this.sub, d: t.l, q: t.type, task: t.task, min: t.min, max: t.max, criteria: t.criteria, model: t.model, lang: code,
        ex: "Comparez votre texte au modèle, critère par critère.", fpKey: `${T}write|${t.task}`, concept: `${T}write|${t.task}` });
    }, () => ({ n: L.writing.length, exact: true }));
  }
  defLang("en"); defLang("es");

  // ---------- Test de positionnement (méthode en escalier) ----------
  function Placement(code, seed) {
    this.code = code; this.r = U.rng(seed || Date.now()); this.level = 3; this.n = 0; this.total = 14; this.hist = []; this.used = new Set();
  }
  Placement.prototype.next = function () {
    if (this.n >= this.total) return null;
    const kinds = ["gram", "gram", "voc", "defs", "syn", "gram", "conj", "idiom"];
    for (let t = 0; t < 40; t++) {
      const k = kinds[this.r.int(kinds.length)]; const g = G.find(x => x.id === this.code + "_" + k); if (!g) continue;
      const q = g.make(this.r, this.level, {}); if (!q || q.kind !== "mcq" || this.used.has(q.fp)) continue;
      if (Math.abs(q.d - this.level) > 1) continue;
      this.used.add(q.fp); q.d = this.level; q.n = this.n + 1; this.cur = q; return q;
    }
    return null;
  };
  Placement.prototype.answer = function (i) {
    const ok = i === this.cur.ans; this.hist.push({ l: this.level, ok, q: this.cur, chosen: i }); this.n++;
    this.level = U.clamp(this.level + (ok ? 1 : -1), 1, 6);
    return ok;
  };
  Placement.prototype.result = function () {
    // Niveau retenu : le plus haut niveau où au moins 2 réponses sur 3 sont justes (sur au moins 2 questions).
    const per = {}; this.hist.forEach(h => { per[h.l] = per[h.l] || { a: 0, c: 0 }; per[h.l].a++; if (h.ok) per[h.l].c++; });
    let lvl = 1; for (let l = 1; l <= 6; l++) { const p = per[l]; if (p && p.a >= 2 && p.c / p.a >= 0.66) lvl = l; else if (p && p.a >= 1 && p.c / p.a >= 0.66 && l === lvl + 1) lvl = l; }
    const last = this.hist.slice(-6); const avg = Math.round(last.reduce((s, h) => s + h.l, 0) / Math.max(1, last.length));
    const level = U.clamp(Math.round((lvl + avg) / 2), 1, 6);
    return { level, label: lvlName(level), per, correct: this.hist.filter(h => h.ok).length, n: this.hist.length };
  };

  // ---------- Examens blancs ----------
  function Exam(code, id, seed) {
    const L = LANG[code]; const ex = L.exams.find(e => e.id === id); const r = U.rng(seed || Date.now());
    this.code = code; this.def = ex; this.start = Date.now();
    this.parts = ex.parts.map((p, pi) => {
      let items = [];
      if (p.type === "mcloze" || p.type === "ocloze") items = [{ kind: "cloze", q: p.title, title: p.title, parts: parseCloze(p.text), fp: "x" + pi }];
      else if (p.type === "wf") items = p.items.filter(i => L.wordFormation[i]).map(i => { const t = L.wordFormation[i]; return { kind: "input", q: `Mot à former à partir de ${t.stem}`, prompt: t.s, accept: t.accept, lang: code, ex: t.accept[0] }; });
      else if (p.type === "kwt") items = p.items.filter(i => L.kwt[i]).map(i => { const t = L.kwt[i]; return { kind: "input", q: `Mot imposé : ${t.key}`, prompt: t.s1 + "\n→ " + t.s2, accept: t.accept, lang: code, ex: t.accept[0] }; });
      else if (p.type === "reading") { const t = L.reading[p.ref]; items = [{ kind: "passage", q: t.title, title: t.title, genre: t.genre, text: t.text, subqs: t.qs.map(s => { const o = r.shuffle([s[1]].concat(s[2])); return { q: s[0], opts: o, ans: o.indexOf(s[1]) }; }) }]; }
      else if (p.type === "listening") { const t = L.listening[p.ref]; items = [{ kind: "passage", audio: true, lang: ttsOf(code), q: t.title, title: t.title, lines: t.lines, subqs: t.qs.map(s => { const o = r.shuffle([s[1]].concat(s[2])); return { q: s[0], opts: o, ans: o.indexOf(s[1]) }; }) }]; }
      else if (p.type === "writing") { const t = L.writing[p.ref]; items = [{ kind: "writing", q: t.type, task: t.task, min: t.min, max: t.max, criteria: t.criteria, model: t.model, lang: code }]; }
      return { title: p.title || p.skill, skill: p.skill, type: p.type, items, resp: items.map(() => null), done: false };
    });
  }
  const weightOf = (q) => q.kind === "cloze" ? gaps(q).length : q.kind === "passage" ? q.subqs.length : q.kind === "writing" ? 5 : q.kind === "input" && /Mot imposé/.test(q.q) ? 2 : 1;
  Exam.prototype.score = function () {
    const by = {}; let pts = 0, max = 0;
    this.parts.forEach(p => {
      p.res = p.items.map((q, i) => check(q, p.resp[i]));
      p.pts = p.items.reduce((s, q, i) => s + p.res[i].score * weightOf(q), 0); p.max = p.items.reduce((s, q) => s + weightOf(q), 0);
      by[p.skill] = by[p.skill] || { pts: 0, max: 0 }; by[p.skill].pts += p.pts; by[p.skill].max += p.max; pts += p.pts; max += p.max;
    });
    const pct = max ? pts / max : 0;
    const minSkill = Math.min(...Object.values(by).map(s => s.max ? s.pts / s.max : 1));
    return { by, pts: Math.round(pts * 10) / 10, max, pct, score20: Math.round(pct * 200) / 10, pass: pct >= 0.6 && minSkill >= 0.4, minSkill };
  };

  W.WKA.lang = { CEFR, CEFR_DESC, lvlName, SUBS, GROUPS, check, checkText, parseCloze, diff, Placement, Exam, ttsOf, clean };
})(typeof window !== "undefined" ? window : globalThis);
