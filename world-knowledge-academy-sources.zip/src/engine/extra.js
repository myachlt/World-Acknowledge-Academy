/* World Knowledge Academy — Générateurs d'approfondissement (couche LOGIQUE)
 * Chronologie, sciences, économie sur documents, carte, ressources. S'ajoutent à la liste WKA.generators.
 * Les questions « doc » embarquent leur support (tableau, graphique, carte) : le joueur doit LIRE et RAISONNER.
 */
(function (W) {
  const D = W.WKA.data, U = W.WKA.util, G = W.WKA.generators, BY = W.WKA.byIso;
  const C = D.countries;

  function build(r, o) {
    const opts = r.shuffle([o.answer].concat(o.wrong));
    if (new Set(opts.map(x => U.norm(x))).size !== opts.length) return null;
    return {
      gen: o.gen, cat: o.cat, sub: o.sub, d: U.clamp(o.d, 1, 5), q: o.q, opts, ans: opts.indexOf(o.answer),
      ex: o.ex, info: o.info || "", ctx: o.ctx || "", src: o.src || "", asOf: o.asOf || null,
      nature: o.nature || "sci", fp: U.hash(o.fpKey), concept: o.concept, iso: o.iso || null,
      flagPrompt: null, optFlags: false, isos: o.isos || null, doc: o.doc || null, deep: !!o.doc
    };
  }
  const def = g => { G.push(Object.assign({ weight: 1, bump: 0 }, g)); };
  const yr = y => y < 0 ? `${-y} av. J.-C.` : String(y);
  const century = y => { if (y < 0) { const c = Math.ceil(-y / 100); return `${roman(c)}ᵉ siècle av. J.-C.`; } const c = Math.ceil(y / 100); return `${roman(c)}ᵉ siècle`; };
  function roman(n) { const m = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]; let s = ""; for (const [v, l] of m) while (n >= v) { s += l; n -= v; } return s; }

  // ---------- HISTOIRE : chronologie ----------
  const EV = D.EVENTS;
  def({
    id: "chrono", cat: "hist", sub: "Chronologie", weight: 2.2,
    make(r, level) {
      // Plus le niveau est élevé, plus les événements sont proches dans le temps.
      const gap = [0, 400, 150, 60, 25, 8][level];
      for (let k = 0; k < 30; k++) {
        const set = r.sample(EV, 4).sort((a, b) => a[0] - b[0]);
        let minGap = Infinity; for (let i = 1; i < 4; i++) minGap = Math.min(minGap, set[i][0] - set[i - 1][0]);
        if (minGap < gap || (level <= 2 && minGap < 30)) continue;
        if (level >= 4 && set[3][0] - set[0][0] > 600) continue;
        const first = set[0], ask = r() < 0.5 ? "first" : "last", ans = ask === "first" ? first : set[3];
        return build(r, { gen: this.id, cat: "hist", sub: ans[2], d: level,
          q: ask === "first" ? "Lequel de ces événements a eu lieu EN PREMIER ?" : "Lequel de ces événements est le PLUS RÉCENT ?",
          answer: ans[1], wrong: set.filter(x => x !== ans).map(x => x[1]),
          ex: "Ordre chronologique : " + set.map(x => `${x[1]} (${yr(x[0])})`).join(" → ") + ".",
          info: ans[3], ctx: "Méthode : situer chaque événement dans son siècle avant de comparer.",
          src: "Chronologies historiques de référence", nature: "hist",
          fpKey: "chrono|" + ask + "|" + set.map(x => x[0]).join(","), concept: "chrono|" + ans[1] });
      }
      return null;
    },
    space: () => ({ n: Math.round(EV.length * (EV.length - 1) * (EV.length - 2) * (EV.length - 3) / 24 * 0.6), exact: false, facts: EV.length })
  });
  def({
    id: "event_date", cat: "hist", sub: "Chronologie", weight: 1.4,
    make(r, level) {
      const e = r.pick(EV);
      const byCentury = level <= 2;
      if (byCentury) {
        const c = century(e[0]);
        const near = [-300, -100, 100, 200, 300, -200].map(d => century(e[0] + d)).filter(x => x !== c);
        const wrong = Array.from(new Set(near)).slice(0, 3); if (wrong.length < 3) return null;
        return build(r, { gen: this.id, cat: "hist", sub: e[2], d: 1 + (Math.abs(e[0]) < 1000 && e[0] < 1500 ? 1 : 0),
          q: `En quel siècle se situe cet événement : ${e[1]} ?`, answer: c, wrong,
          ex: `${e[1]} : ${yr(e[0])}, donc ${c}. Rappel : l'an 1850 appartient au XIXᵉ siècle (on ajoute 1 aux centaines).`, info: e[3],
          src: "Chronologies historiques de référence", nature: "hist", fpKey: "evc|" + e[0] + e[1], concept: "evdate|" + e[1] });
      }
      const span = level >= 5 ? [1, 2, 3, -1, -2, -3] : level === 4 ? [5, 10, -5, -10, 3, -3] : [20, 50, -20, -50, 30, -30];
      const wrong = r.sample(span, 3).map(d => yr(e[0] + d));
      return build(r, { gen: this.id, cat: "hist", sub: e[2], d: level,
        q: `En quelle année : ${e[1]} ?`, answer: yr(e[0]), wrong,
        ex: `${e[1]} : ${yr(e[0])}.`, info: e[3], src: "Chronologies historiques de référence", nature: "hist",
        fpKey: "evy|" + e[0] + e[1] + level, concept: "evdate|" + e[1] });
    },
    space: () => ({ n: EV.length * 2, exact: true })
  });

  // ---------- SCIENCES : éléments, planètes, unités ----------
  const EL = D.ELEMENTS;
  def({
    id: "element", cat: "sci", sub: "Chimie", weight: 1.3,
    make(r, level) {
      const pool = EL.filter(e => level <= 2 ? e[0] <= 30 : true);
      const e = r.pick(pool), mode = r.int(3);
      const others = r.sample(EL.filter(x => x !== e), 3);
      const note = D.ELEMENT_NOTES[e[1]] || "";
      if (mode === 0) return build(r, { gen: this.id, cat: "sci", sub: "Chimie", d: note ? Math.max(level, 3) : Math.min(level, 3),
        q: `Quel est le symbole chimique de l'élément « ${e[2]} » ?`, answer: e[1], wrong: others.map(x => x[1]),
        ex: `${e[2][0].toUpperCase() + e[2].slice(1)} : symbole ${e[1]}, numéro atomique ${e[0]}. ${note}`.trim(), info: `Famille : ${e[3]}.`,
        src: "IUPAC, tableau périodique", nature: "sci", fpKey: "els|" + e[1], concept: "el|" + e[1] });
      if (mode === 1) return build(r, { gen: this.id, cat: "sci", sub: "Chimie", d: Math.min(5, level + 1),
        q: `Quel élément porte le numéro atomique ${e[0]} ?`, answer: e[2], wrong: others.map(x => x[2]),
        ex: `Le numéro atomique ${e[0]} correspond au ${e[2]} (${e[1]}) : son noyau compte ${e[0]} protons.`, info: `Famille : ${e[3]}.`,
        src: "IUPAC, tableau périodique", nature: "sci", fpKey: "eln|" + e[1], concept: "elz|" + e[1] });
      const fams = Array.from(new Set(EL.map(x => x[3]))).filter(f => f !== e[3]);
      if (fams.length < 3) return null;
      return build(r, { gen: this.id, cat: "sci", sub: "Chimie", d: Math.min(5, level + 1),
        q: `À quelle famille appartient le ${e[2]} (${e[1]}) ?`, answer: e[3], wrong: r.sample(fams, 3),
        ex: `Le ${e[2]} est un ${e[3]}. La famille dépend de la colonne du tableau périodique, donc des électrons de valence.`, info: note,
        src: "IUPAC, tableau périodique", nature: "sci", fpKey: "elf|" + e[1], concept: "elf|" + e[1] });
    },
    space: () => ({ n: EL.length * 3, exact: true })
  });
  const PL = D.PLANETS;
  def({
    id: "planet", cat: "sci", sub: "Astronomie", weight: 0.8,
    make(r, level) {
      const p = r.pick(PL);
      if (r() < 0.5) {
        const wrong = r.sample(PL.filter(x => x !== p), 3).map(x => x[0]);
        return build(r, { gen: this.id, cat: "sci", sub: "Astronomie", d: Math.min(level, 3),
          q: `Quelle planète correspond à cette description : « ${p[4]} »`.replace(p[0], "cette planète"), answer: p[0], wrong,
          ex: `Il s'agit de ${p[0]}, ${p[1]}ᵉ planète du système solaire (planète ${p[2]}).`, info: `Satellites naturels connus : ${p[3]}.`,
          src: "NASA, Solar System Exploration", nature: "sci", fpKey: "pld|" + p[0], concept: "pl|" + p[0] });
      }
      const wrong = ["1", "2", "3", "4", "5", "6", "7", "8"].filter(x => x !== String(p[1]));
      return build(r, { gen: this.id, cat: "sci", sub: "Astronomie", d: Math.min(level, 2),
        q: `Quel est le rang de ${p[0]} en partant du Soleil ?`, answer: String(p[1]) + "ᵉ", wrong: r.sample(wrong.filter(x => Math.abs(+x - p[1]) <= 3), 3).map(x => x + "ᵉ"),
        ex: "Ordre : Mercure, Vénus, Terre, Mars, Jupiter, Saturne, Uranus, Neptune.", info: p[4],
        src: "NASA, Solar System Exploration", nature: "sci", fpKey: "plr|" + p[0], concept: "plr|" + p[0] });
    },
    space: () => ({ n: PL.length * 2, exact: true })
  });
  const UN = D.UNITS;
  def({
    id: "unit", cat: "sci", sub: "Physique", weight: 0.9,
    make(r, level) {
      const u = r.pick(UN); const others = r.sample(UN.filter(x => x !== u), 3);
      if (level <= 2 || r() < 0.5) return build(r, { gen: this.id, cat: "sci", sub: "Physique", d: Math.max(2, Math.min(level, 3)),
        q: `Quelle est l'unité du Système international pour ${u[0]} ?`, answer: u[1], wrong: others.map(x => x[1]),
        ex: `${u[0][0].toUpperCase() + u[0].slice(1)} se mesure en ${u[1].replace(/^(le |l')/, "")} (symbole ${u[2]}).`,
        src: "BIPM, Le Système international d'unités (9ᵉ éd.)", nature: "sci", fpKey: "un|" + u[2], concept: "un|" + u[2] });
      return build(r, { gen: this.id, cat: "sci", sub: "Physique", d: 4,
        q: `Quelle grandeur se mesure avec l'unité de symbole « ${u[2]} » ?`, answer: u[0], wrong: others.map(x => x[0]),
        ex: `${u[2]} est le symbole ${u[1].startsWith("l'") ? "de " + u[1] : "du " + u[1].replace(/^le /, "")}, unité de ${u[0].replace(/^(la |le |l')/, "")}.`,
        src: "BIPM, Le Système international d'unités (9ᵉ éd.)", nature: "sci", fpKey: "uns|" + u[2], concept: "uns|" + u[2] });
    },
    space: () => ({ n: UN.length * 2, exact: true })
  });

  // ---------- ÉCONOMIE : lecture de documents ----------
  const E = D.ECON, EM = D.ECON_META;
  const econ = C.filter(c => E[c.iso]);
  const gdpPc = c => E[c.iso][0] * 1000 / c.pop; // dollars par habitant
  const fmtGdp = v => v >= 1000 ? (Math.round(v / 100) / 10).toLocaleString("fr-FR") + " billion $" : U.num(Math.round(v)) + " Md$";
  const fmtPc = v => U.num(Math.round(v / 100) * 100) + " $";
  def({
    id: "gdp_doc", cat: "eco", sub: "Concepts économiques", weight: 1.6, doc: true,
    make(r, level) {
      for (let k = 0; k < 30; k++) {
        const set = r.sample(econ.filter(c => level <= 2 ? c.tier <= 2 : true), 4);
        const byPc = set.slice().sort((a, b) => gdpPc(b) - gdpPc(a));
        const byGdp = set.slice().sort((a, b) => E[b.iso][0] - E[a.iso][0]);
        if (gdpPc(byPc[0]) / gdpPc(byPc[1]) < 1.2) continue;
        if (level >= 3 && byPc[0] === byGdp[0]) continue; // le piège : le plus gros PIB n'est pas le plus riche par habitant
        const w = byPc[0];
        return build(r, { gen: this.id, cat: "eco", sub: "Concepts économiques", d: U.clamp(level, 2, 5),
          q: "D'après le tableau, quel pays a le PIB PAR HABITANT le plus élevé ?", answer: w.name, wrong: set.filter(x => x !== w).map(x => x.name),
          ex: "PIB par habitant = PIB ÷ population. " + byPc.map(c => `${c.name} : ${fmtGdp(E[c.iso][0])} ÷ ${U.pop(c.pop)} ≈ ${fmtPc(gdpPc(c))}`).join(" ; ") + ".",
          info: "Le PIB mesure la taille d'une économie ; le PIB par habitant approche le niveau de vie moyen, sans dire comment la richesse est répartie.",
          ctx: byPc[0] !== byGdp[0] ? `Piège : ${byGdp[0].name} a le PIB total le plus élevé, mais sa population est bien plus nombreuse.` : "",
          src: EM.gdpSource + " ; ONU WPP 2024", asOf: "2024", nature: "contemp", iso: w.iso, isos: set.map(c => c.iso),
          doc: { type: "table", title: "PIB et population, 2024", cols: ["Pays", "PIB (dollars courants)", "Population"], rows: set.map(c => [c.name, fmtGdp(E[c.iso][0]), U.pop(c.pop)]), note: "Valeurs arrondies. Sources : FMI (avril 2025), ONU (2024)." },
          fpKey: "gdpdoc|" + set.map(c => c.iso).sort().join(","), concept: "gdppc|" + w.iso });
      }
      return null;
    },
    space: () => ({ n: Math.round(econ.length * (econ.length - 1) * (econ.length - 2) * (econ.length - 3) / 24 * 0.3), exact: false, facts: econ.length })
  });
  def({
    id: "gdp_chart", cat: "eco", sub: "Concepts économiques", weight: 1.2, doc: true,
    make(r, level) {
      const set = r.sample(econ.filter(c => c.tier <= Math.max(2, level)), 5);
      if (set.length < 5) return null;
      const sorted = set.slice().sort((a, b) => E[b.iso][0] - E[a.iso][0]);
      const ask = level >= 3 ? "ratio" : "rank";
      if (ask === "ratio") {
        const a = sorted[0], b = sorted[sorted.length - 1]; const ratio = E[a.iso][0] / E[b.iso][0];
        if (ratio < 2) return null;
        const rr = Math.round(ratio); const opts = [rr, Math.max(1, Math.round(rr / 3)), rr * 3, rr + Math.max(2, Math.round(rr / 2))];
        if (new Set(opts).size < 4) return null;
        return build(r, { gen: this.id, cat: "eco", sub: "Concepts économiques", d: Math.min(5, level + 1),
          q: `D'après le graphique, le PIB de ${a.name} est environ combien de fois celui de ${b.name} ?`, answer: `Environ ${rr} fois`, wrong: opts.slice(1).map(x => `Environ ${x} fois`),
          ex: `${fmtGdp(E[a.iso][0])} ÷ ${fmtGdp(E[b.iso][0])} ≈ ${ratio.toFixed(1).replace(".", ",")}. On calcule un rapport (division), pas une différence.`,
          src: EM.gdpSource, asOf: "2024", nature: "contemp", isos: set.map(c => c.iso),
          doc: { type: "chart", kind: "bar", title: "PIB nominal 2024", unit: "milliards de dollars", labels: sorted.map(c => c.name), series: [{ name: "PIB", values: sorted.map(c => E[c.iso][0]) }], note: "FMI, avril 2025, arrondi." },
          fpKey: "gdpch|" + set.map(c => c.iso).sort().join(","), concept: "gdpratio|" + a.iso + b.iso });
      }
      const k = r.int(3) + 1, target = sorted[k];
      return build(r, { gen: this.id, cat: "eco", sub: "Concepts économiques", d: 2,
        q: `D'après le graphique, quel pays a le ${k + 1}ᵉ PIB le plus élevé ?`, answer: target.name, wrong: r.sample(set.filter(x => x !== target), 3).map(x => x.name),
        ex: "Classement : " + sorted.map((c, i) => `${i + 1}. ${c.name} (${fmtGdp(E[c.iso][0])})`).join(", ") + ".",
        src: EM.gdpSource, asOf: "2024", nature: "contemp", isos: set.map(c => c.iso),
        doc: { type: "chart", kind: "bar", title: "PIB nominal 2024", unit: "milliards de dollars", labels: r.shuffle(set).map(c => c.name), series: null, _iso: null, note: "FMI, avril 2025, arrondi." },
        fpKey: "gdprk|" + set.map(c => c.iso).sort().join(",") + k, concept: "gdprk|" + target.iso });
    },
    space: () => ({ n: 200000, exact: false, facts: econ.length })
  });
  // Les valeurs du graphique doivent suivre l'ordre des étiquettes mélangées.
  const gc = G[G.length - 1], mk = gc.make;
  gc.make = function (r, level, o) {
    const q = mk.call(this, r, level, o); if (!q || !q.doc || q.doc.series) return q;
    q.doc.series = [{ name: "PIB", values: q.doc.labels.map(n => E[C.find(c => c.name === n).iso][0]) }];
    return q;
  };
  def({
    id: "life_cmp", cat: "eco", sub: "Concepts économiques", weight: 0.8,
    make(r, level) {
      for (let k = 0; k < 25; k++) {
        const set = r.sample(econ, 4); const s = set.slice().sort((a, b) => E[b.iso][1] - E[a.iso][1]);
        if (E[s[0].iso][1] - E[s[1].iso][1] < 3) continue;
        return build(r, { gen: this.id, cat: "eco", sub: "Concepts économiques", d: U.clamp(level, 2, 5),
          q: "Lequel de ces pays a l'espérance de vie à la naissance la plus élevée ?", answer: s[0].name, wrong: s.slice(1).map(x => x.name),
          ex: s.map(c => `${c.name} : ${String(E[c.iso][1]).replace(".", ",")} ans`).join(" ; ") + ".",
          info: "L'espérance de vie dépend du système de santé, de la mortalité infantile, de l'alimentation et des conditions de vie ; elle n'est pas strictement liée au PIB.",
          ctx: "Écart minimal de 3 ans entre les deux premiers pour que la réponse reste stable d'une année à l'autre.",
          src: EM.lifeSource, asOf: "2023", nature: "contemp", iso: s[0].iso, isos: set.map(c => c.iso),
          fpKey: "life|" + set.map(c => c.iso).sort().join(","), concept: "life|" + s[0].iso });
      }
      return null;
    },
    space: () => ({ n: 300000, exact: false, facts: econ.length })
  });
  const RES = D.RES; const resIsos = Object.keys(RES).filter(i => BY[i]);
  def({
    id: "resources", cat: "eco", sub: "Matières premières", weight: 1,
    make(r, level) {
      const iso = r.pick(resIsos), c = BY[iso];
      const others = r.sample(resIsos.filter(i => i !== iso), 3).map(i => BY[i]);
      return build(r, { gen: this.id, cat: "eco", sub: "Matières premières", d: U.clamp(c.tier + 1, 2, 5),
        q: `Quel pays est particulièrement riche en : ${RES[iso].toLowerCase()} ?`, answer: c.name, wrong: others.map(x => x.name),
        ex: `${c.name} : ${RES[iso]}. ` + others.map(x => `${x.name} : ${RES[x.iso].toLowerCase()}`).join(" ; ") + ".",
        info: "Une économie très dépendante d'une matière première est vulnérable aux variations de son prix : on parle parfois de « malédiction des ressources ».",
        src: "USGS Mineral Commodity Summaries ; AIE", asOf: "2025", nature: "contemp", iso, fpKey: "res|" + iso, concept: "res|" + iso });
    },
    space: () => ({ n: resIsos.length, exact: true })
  });

  // ---------- GÉOGRAPHIE : carte ----------
  const SH = D.MAP ? D.MAP.shapes : {};
  const mapIsos = C.filter(c => SH[c.iso] && c.area >= 20000);
  def({
    id: "map_locate", cat: "geo", sub: "Continents et régions", weight: 1.8, doc: true,
    make(r, level, o) {
      const c = o && o.iso ? BY[o.iso] : r.pick(mapIsos.filter(x => Math.abs(x.tier - level) <= 1));
      if (!c || !SH[c.iso]) return null;
      const near = mapIsos.filter(x => x !== c && x.cont === c.cont);
      const others = (level >= 3 && near.length >= 3 ? r.sample(near, 3) : r.sample(mapIsos.filter(x => x !== c), 3));
      return build(r, { gen: this.id, cat: "geo", sub: "Continents et régions", d: U.clamp(c.tier + (level >= 3 ? 1 : 0), 1, 5),
        q: "Quel pays est mis en évidence sur la carte ?", answer: c.name, wrong: others.map(x => x.name),
        ex: `Il s'agit ${c.du}, capitale ${c.capital}. ` + (c.borders.length ? `Pays voisins : ${c.borders.filter(b => BY[b]).map(b => BY[b].name).slice(0, 6).join(", ")}.` : "C'est un pays insulaire ou sans frontière terrestre."),
        info: c.fact, src: "Natural Earth (frontières de facto, échelle 1:110 M)", nature: "geo", iso: c.iso,
        doc: { type: "map", iso: c.iso, title: "Localiser un pays" },
        fpKey: "map|" + c.iso, concept: "map|" + c.iso });
    },
    space: () => ({ n: mapIsos.length, exact: true })
  });
})(typeof window !== "undefined" ? window : globalThis);
