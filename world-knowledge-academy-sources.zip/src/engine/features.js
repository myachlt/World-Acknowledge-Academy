/* World Knowledge Academy — Fonctions transverses (couche LOGIQUE)
 * Dictionnaire et glossaire personnels, révisions espacées du vocabulaire, Le saviez-vous, Mot du jour,
 * Défi quotidien, Mes lacunes, maîtrise de la carte, parcours par continent, comparateur de pays, situations.
 */
(function (W) {
  const D = W.WKA.data, U = W.WKA.util, E = W.WKA.engine, BY = W.WKA.byIso, LG = W.WKA.lang;
  const DAY = 86400000;
  const dayIndex = (date) => Math.floor(new Date((date || U.today()) + "T12:00:00").getTime() / DAY);
  const uid = () => "d" + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);

  // ---------- Dictionnaire personnel ----------
  const Dict = {
    list(st, o) {
      o = o || {}; const q = U.norm(o.q || "");
      let a = st.dict.filter(w => (!o.cat || w.cat === o.cat) && (!o.lang || (w[o.lang] || "").trim()) &&
        (!q || U.norm([w.fr, w.en, w.es, w.cat, w.ex || ""].join(" ")).includes(q)));
      const key = o.sort || "fr"; const dir = o.dir === "desc" ? -1 : 1;
      const k = w => key === "mastery" ? Dict.mastery(w) : key === "created" ? w.created : U.norm(String(w[key] || "").replace(/^(le |la |les |l'|el |los |las |to )/i, ""));
      a.sort((x, y) => (k(x) > k(y) ? 1 : k(x) < k(y) ? -1 : 0) * dir);
      return a;
    },
    cats(st) { return Array.from(new Set(st.dict.map(w => w.cat).filter(Boolean))).sort((a, b) => a.localeCompare(b, "fr")); },
    exists(st, w) { return st.dict.find(x => U.norm(x.fr) === U.norm(w.fr) && (!w.en || U.norm(x.en) === U.norm(w.en)) && (!w.es || U.norm(x.es) === U.norm(w.es))); },
    add(st, w) {
      const ex = Dict.exists(st, w); if (ex) return { entry: ex, dup: true };
      const e = { id: uid(), fr: (w.fr || "").trim(), en: (w.en || "").trim(), es: (w.es || "").trim(), cat: (w.cat || "Divers").trim(), nat: (w.nat || "").trim(), ex: (w.ex || "").trim(), created: Date.now(), srs: { box: 0, due: 0, a: 0, c: 0 } };
      if (!e.fr || (!e.en && !e.es)) throw new Error("Indiquez le mot français et au moins une traduction.");
      st.dict.push(e); return { entry: e, dup: false };
    },
    update(st, id, w) { const e = st.dict.find(x => x.id === id); if (!e) return null; ["fr", "en", "es", "cat", "nat", "ex"].forEach(k => { if (w[k] !== undefined) e[k] = String(w[k]).trim(); }); return e; },
    remove(st, id) { st.dict = st.dict.filter(x => x.id !== id); },
    // 0 = nouveau … 5 = maîtrisé
    mastery(w) { return (w.srs || {}).box || 0; },
    masteryLabel(b) { return ["Nouveau", "Découvert", "En cours", "Bien connu", "Presque acquis", "Maîtrisé"][b] || "Nouveau"; },
    due(st, now) { now = now || Date.now(); return st.dict.filter(w => ((w.srs || {}).due || 0) <= now); },
    // Questions de révision tirées du dictionnaire. dirs : fr-en, en-fr, fr-es, es-fr, phrase, ecoute, image
    questions(st, o) {
      o = o || {}; const r = U.rng(o.seed || Date.now()); const now = Date.now();
      let pool = st.dict.filter(w => !o.cat || w.cat === o.cat);
      const due = pool.filter(w => ((w.srs || {}).due || 0) <= now);
      const pick = r.shuffle(due.length >= 3 || o.all ? (o.all ? pool : due) : pool).sort((a, b) => ((a.srs || {}).box || 0) - ((b.srs || {}).box || 0)).slice(0, o.n || 10);
      const out = [];
      pick.forEach((w, i) => {
        const dirs = (o.dirs && o.dirs.length ? o.dirs : ["fr-en", "en-fr", "fr-es", "es-fr", "phrase", "ecoute", "image"]).filter(d =>
          (d.includes("en") ? w.en : true) && (d.includes("es") ? w.es : true) && (d !== "phrase" || (w.ex && sentenceHole(w))) && (d !== "image" || imgOf(w)) && (d !== "ecoute" || w.en || w.es));
        if (!dirs.length) return;
        const d = dirs[r.int(dirs.length)];
        const q = makeDictQ(r, st, w, d); if (q) out.push(q);
      });
      return out;
    }
  };
  function imgOf(w) { const v = D.VOCAB.find(v => U.norm(v.fr) === U.norm(w.fr) || (w.en && U.norm(v.en) === U.norm(w.en))); return v && v.img; }
  function sentenceHole(w) {
    const cands = [w.en, w.es, w.fr].filter(Boolean).map(x => x.replace(/^(le |la |les |l'|el |los |las |to )/i, ""));
    for (const c of cands) { const re = new RegExp("\\b" + c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i"); if (re.test(w.ex)) return { word: c, text: w.ex.replace(re, "_____") }; }
    return null;
  }
  function distract(r, st, w, key, n) {
    const fromDict = st.dict.filter(x => x !== w && x[key] && U.norm(x[key]) !== U.norm(w[key])).map(x => x[key]);
    const fromVoc = D.VOCAB.filter(v => v[key] && U.norm(v[key]) !== U.norm(w[key])).map(v => v[key]);
    return r.shuffle(Array.from(new Set(r.shuffle(fromDict).slice(0, 6).concat(r.sample(fromVoc, 8))))).slice(0, n);
  }
  function makeDictQ(r, st, w, d) {
    const base = { gen: "dict", cat: d.includes("es") ? "es" : d.includes("en") ? "en" : (w.en ? "en" : "es"), sub: "Mon dictionnaire", d: 2, dictId: w.id, nature: "lang", src: "Votre dictionnaire personnel", info: w.ex || "", ctx: "", fp: U.hash("dict|" + w.id + "|" + d), concept: "dict|" + w.id };
    const mk = (q, prompt, ans, key, extra) => { const wrong = distract(r, st, w, key, 3); if (wrong.length < 3) return null; const opts = r.shuffle([ans].concat(wrong)); return Object.assign({}, base, { kind: "mcq", q, prompt, opts, ans: opts.indexOf(ans), ex: `${w.fr} · ${w.en || "—"} · ${w.es || "—"}${w.nat ? " (" + w.nat + ")" : ""}.` }, extra || {}); };
    const tts = k => k === "en" ? "en-GB" : "es-ES";
    if (d === "fr-en") return r() < 0.5 ? mk("Traduisez en anglais :", w.fr, w.en, "en") : Object.assign({}, base, { kind: "input", q: "Écrivez en anglais :", prompt: w.fr, accept: [w.en, w.en.replace(/^to /i, "")], lang: "en", ex: `${w.fr} = ${w.en}.`, say: { text: w.en, lang: "en-GB" }, sayAfter: true });
    if (d === "en-fr") return mk("Que signifie ce mot anglais ?", w.en, w.fr, "fr", { say: { text: w.en, lang: tts("en") } });
    if (d === "fr-es") return r() < 0.5 ? mk("Traduisez en espagnol :", w.fr, w.es, "es") : Object.assign({}, base, { kind: "input", q: "Écrivez en espagnol :", prompt: w.fr, accept: [w.es, w.es.replace(/^(el |la |los |las )/i, "")], lang: "es", ex: `${w.fr} = ${w.es}.`, say: { text: w.es, lang: "es-ES" }, sayAfter: true });
    if (d === "es-fr") return mk("Que signifie ce mot espagnol ?", w.es, w.fr, "fr", { say: { text: w.es, lang: tts("es") } });
    if (d === "phrase") { const h = sentenceHole(w); return Object.assign({}, base, { kind: "input", q: "Complétez la phrase avec le mot de votre dictionnaire :", prompt: h.text, accept: [h.word], lang: "fr", ex: w.ex }); }
    if (d === "ecoute") { const k = w.en ? "en" : "es"; return mk("Écoutez, puis choisissez la traduction.", null, w.fr, "fr", { audioOnly: { text: w[k], lang: tts(k) }, needsAudio: true }); }
    if (d === "image") { const k = w.en ? "en" : "es"; return mk("Quel mot correspond à l'image ?", null, w[k], k, { bigEmoji: imgOf(w) }); }
    return null;
  }

  // ---------- Glossaire personnel ----------
  const Gloss = {
    list(st, o) { o = o || {}; const q = U.norm(o.q || ""); return st.gloss.filter(g => (!o.cat || g.cat === o.cat) && (!q || U.norm([g.notion, g.def, g.ex, g.cat].join(" ")).includes(q))).sort((a, b) => a.notion.localeCompare(b.notion, "fr")); },
    add(st, g) { if (!g.notion || !g.def) throw new Error("Indiquez la notion et sa définition."); const e = { id: uid(), notion: g.notion.trim(), def: g.def.trim(), ex: (g.ex || "").trim(), cat: g.cat || "Divers", created: Date.now() }; st.gloss.push(e); return e; },
    update(st, id, g) { const e = st.gloss.find(x => x.id === id); if (e) Object.assign(e, g); return e; },
    remove(st, id) { st.gloss = st.gloss.filter(x => x.id !== id); }
  };

  // ---------- Le saviez-vous ? ----------
  const DYK = (() => {
    const out = [];
    E.BANK.forEach(b => { if (b.info && b.info.length > 60 && !b.doc && !b.pi) out.push({ text: b.info, cat: b.cat, sub: b.sub, src: b.src, bank: b }); });
    Object.entries(D.PROFILES || {}).forEach(([iso, p]) => { if (BY[iso] && p.cult) out.push({ text: p.cult, cat: "cult", sub: BY[iso].name, src: "Fiche pays", iso }); });
    D.EVENTS.forEach(e => out.push({ text: `${e[1]} (${e[0] < 0 ? -e[0] + " av. J.-C." : e[0]}) : ${e[3]}`, cat: "hist", sub: e[2], src: "Chronologie" }));
    return out;
  })();
  function dyk(date) {
    // On alterne les domaines d'un jour à l'autre.
    const i = dayIndex(date); const cats = E.KNOW; const cat = cats[i % cats.length];
    const pool = DYK.filter(x => x.cat === cat); const p = pool.length ? pool : DYK;
    return p[(i * 7919) % p.length];
  }

  // ---------- Mot du jour ----------
  function wotd(date) {
    const i = dayIndex(date); const w = D.WOTD[i % D.WOTD.length];
    const v = D.VOCAB.find(x => x.fr === w[0]) || {};
    return { fr: w[0], def: w[1], exFr: w[2], origin: w[3], en: v.en || "", es: v.es || "", ipa: v.ipa || "", nat: v.nat || "nom", theme: v.theme || "", img: v.img || "" };
  }

  // ---------- Défi quotidien ----------
  const DAILY_PLAN = [
    { id: "cult", name: "Culture générale", cats: ["hist", "cult", "sci", "env", "eco", "pol"], n: 5 },
    { id: "geo", name: "Géographie", cats: ["geo"], n: 5 },
    { id: "en", name: "Anglais", cats: ["en"], n: 5 },
    { id: "es", name: "Espagnol", cats: ["es"], n: 5 },
    { id: "prat", name: "Vie pratique", cats: ["prat"], n: 5 }
  ];
  function dailyConfig(date) {
    date = date || U.today();
    return { mode: "defi", daily: date, seed: (dayIndex(date) * 2654435761) >>> 0, plan: DAILY_PLAN.map(p => ({ cats: p.cats, n: p.n })), level: "adaptive", mcqOnly: true, noAudio: true, title: "Défi du " + new Date(date + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "long" }) };
  }

  // ---------- Mes lacunes ----------
  function gaps(st) {
    const out = [];
    Object.entries(st.stats.bySub).forEach(([k, v]) => {
      const [cat, sub] = k.split("|"); if (!E.CAT[cat] || v.a < 4) return;
      const rate = v.c / v.a; if (rate < 0.65) out.push({ cat, sub, a: v.a, c: v.c, rate, cfg: { mode: "libre", cats: [cat], sub, count: 10, level: "adaptive", title: "Cibler : " + sub } });
    });
    ["en", "es"].forEach(code => Object.entries(st.lang[code].byType).forEach(([sub, v]) => {
      if (v.a < 4 || out.some(o => o.cat === code && o.sub === sub)) return; const rate = v.c / v.a;
      if (rate < 0.65) out.push({ cat: code, sub, a: v.a, c: v.c, rate, cfg: { mode: "libre", cats: [code], sub, count: 10, level: "adaptive", title: "Cibler : " + sub } });
    }));
    out.sort((a, b) => a.rate - b.rate || b.a - a.a);
    // Domaines jamais travaillés : on les signale aussi (lacune « inconnue »).
    const untouched = E.CATEGORIES.filter(c => !(st.stats.byCat[c.id] || {}).a).map(c => c.id);
    return { weak: out.slice(0, 8), untouched };
  }

  // ---------- Carte : maîtrise par pays ----------
  function isoState(st, iso) {
    const x = st.isoStats[iso];
    if (x && x.c >= 3 && x.c / x.a >= 0.75) return "mastered";
    if (st.discovered[iso] || (x && x.a)) return "discovered";
    return "none";
  }
  function continentPaths(st) {
    return Object.entries(D.CONTINENTS).map(([k, v]) => {
      const cs = D.countries.filter(c => c.cont === k);
      const states = cs.map(c => isoState(st, c.iso));
      const mastered = states.filter(s => s === "mastered").length, discovered = states.filter(s => s !== "none").length;
      // Étapes : les pays les plus connus d'abord (rang de notoriété), par paliers.
      const steps = [1, 2, 3, 4, 5].map(t => ({ tier: t, isos: cs.filter(c => c.tier === t).map(c => c.iso) })).filter(s => s.isos.length);
      const stepState = steps.map(s => ({ tier: s.tier, n: s.isos.length, mastered: s.isos.filter(i => isoState(st, i) === "mastered").length, isos: s.isos }));
      const current = stepState.find(s => s.mastered < Math.ceil(s.n * 0.7)) || stepState[stepState.length - 1];
      return { id: k, name: v.name, du: v.du, total: cs.length, mastered, discovered, remaining: cs.length - discovered, steps: stepState, current };
    });
  }

  // ---------- Comparateur ----------
  const ORG_KEYS = ["ONU", "UE", "OTAN", "G20", "BRICS", "OPEP", "ASEAN", "UA", "EURO", "OMC"];
  function compare(isos) {
    const E2 = D.ECON || {};
    return isos.map(i => BY[i]).filter(Boolean).map(c => {
      const ec = E2[c.iso];
      return {
        iso: c.iso, name: c.name, flag: U.flag(c.iso), capital: c.capital, cont: D.CONTINENTS[c.cont].name,
        pop: c.pop, area: c.area, density: c.density, gdp: ec ? ec[0] : null, gdppc: ec ? ec[0] * 1000 / c.pop : null, life: ec ? ec[1] : null,
        currency: D.CURRENCIES[c.cur] || c.cur, gov: D.GOV[c.gov] || c.gov,
        langs: c.langs.map(l => D.LANGUAGES[l] || l).join(", "), res: (D.RES || {})[c.iso] || "", landlocked: c.landlocked,
        orgs: ORG_KEYS.filter(k => D.ORGS[k] && (k === "ONU" || (D.ORGS[k].list || "").split(" ").includes(c.iso)))
      };
    });
  }

  // ---------- Situations ----------
  function situationQuestions(s, seed) {
    const r = U.rng(seed || Date.now());
    return s.steps.map((st, i) => {
      const opts = r.shuffle([st.a].concat(st.w));
      return { kind: "mcq", gen: "situation", cat: s.domain, sub: s.sub, d: s.lvl, q: st.q, opts, ans: opts.indexOf(st.a), ex: st.ex, info: st.info || "", ctx: i === 0 ? s.context : "",
        src: s.src, asOf: s.asOf, nature: s.asOf ? "contemp" : "sci", fp: U.hash("sit|" + s.id + "|" + i), concept: "sit|" + s.id + "|" + i, doc: s.doc, situation: s.title, context: s.context };
    });
  }

  // ---------- Documents disponibles ----------
  function docStats() {
    const bank = E.BANK.filter(b => b.doc).length; const gens = W.WKA.generators.filter(g => g.doc).map(g => g.id);
    return { bank, gens, types: ["Tableaux statistiques", "Graphiques économiques", "Extraits juridiques", "Documents historiques", "Cartes"] };
  }

  W.WKA.features = { Dict, Gloss, DYK, dyk, wotd, DAILY_PLAN, dailyConfig, gaps, isoState, continentPaths, compare, ORG_KEYS, situationQuestions, docStats, dayIndex };
})(typeof window !== "undefined" ? window : globalThis);
