/* World Knowledge Academy — Générateurs paramétriques (couche LOGIQUE)
 * Chaque générateur fabrique des questions à partir des données vérifiées.
 * Il fournit :
 *   - make(r, level, opts) : une question, ou null s'il ne peut pas en produire au niveau demandé
 *   - space()              : le nombre RÉEL de questions distinctes qu'il peut produire
 * Chaque question porte :
 *   - fp      : empreinte du contenu exact (même fait, même sens de question)
 *   - concept : fait testé (sert à espacer « capitale de X » et « X est la capitale de… »)
 */
(function (W) {
  const D = W.WKA.data, U = W.WKA.util;
  const C = D.countries;
  const BY = Object.fromEntries(C.map(c => [c.iso, c]));
  const META = D.META;
  const CONT = D.CONTINENTS;

  const FLAG_LOOKALIKES = [["ID", "MC", "PL"], ["RO", "TD"], ["NL", "LU"], ["IE", "CI", "IT"], ["AU", "NZ"], ["NO", "IS"],
    ["SN", "ML", "GN", "CM"], ["CO", "EC", "VE"], ["SI", "SK", "RU"], ["HN", "NI", "SV"], ["QA", "BH"], ["JO", "SY", "IQ", "EG"]];
  const lookalikesOf = iso => {
    const g = FLAG_LOOKALIKES.find(g => g.includes(iso));
    return g ? g.filter(x => x !== iso && BY[x]) : [];
  };

  // Le niveau souhaité (1-5) correspond à la notoriété des pays interrogés.
  function pickCountry(r, target, pred, focus) {
    if (focus) { const c = BY[focus]; return c && pred(c) ? c : null; }
    const t = U.clamp(Math.round(target), 1, 5);
    let pool = C.filter(c => c.tier === t && pred(c));
    if (pool.length < 3) pool = C.filter(c => Math.abs(c.tier - t) <= 1 && pred(c));
    return pool.length ? r.pick(pool) : null;
  }
  // Distracteurs : à niveau élevé, on privilégie la même région (plus difficile à départager).
  function pickOthers(r, pool, n, near, level) {
    const preferNear = level >= 3 || r() < 0.35;
    const a = preferNear ? r.shuffle(pool.filter(near)) : [];
    const b = r.shuffle(pool.filter(x => !a.includes(x)));
    const out = a.slice(0, n);
    for (const x of b) { if (out.length >= n) break; out.push(x); }
    return out.length === n ? out : null;
  }
  const diffOf = (tier, bump) => U.clamp(Math.round(tier + bump), 1, 5);
  const popSrc = { src: META.populationSource, asOf: "2024", nature: "contemp" };
  const polSrc = { src: META.politicalSource, asOf: META.verifiedAt, nature: "contemp" };
  const contName = c => CONT[c.cont].name;
  const sameNameCapital = c => U.norm(c.capital).includes(U.norm(c.name)) || U.norm(c.name).includes(U.norm(c.capital));
  const nbNames = c => c.borders.filter(b => BY[b]).map(b => BY[b].name);

  // Construit l'objet question final (ordre des options mélangé).
  function build(r, o) {
    const opts = r.shuffle([o.answer].concat(o.wrong));
    const uniq = new Set(opts.map(x => U.norm(x)));
    if (uniq.size !== 4) return null; // garde-fou : jamais deux options identiques
    return {
      gen: o.gen, cat: o.cat, sub: o.sub, d: o.d, q: o.q, opts, ans: opts.indexOf(o.answer),
      ex: o.ex, info: o.info || "", ctx: o.ctx || "", src: o.src || "", asOf: o.asOf || null,
      nature: o.nature || "geo", fp: U.hash(o.fpKey), concept: o.concept, iso: o.iso || null,
      flagPrompt: o.flagPrompt || null, optFlags: !!o.optFlags, isos: o.isos || null
    };
  }

  const G = [];
  const def = g => { g.weight = g.weight || 1; G.push(g); };

  // ---------- GÉOGRAPHIE : capitales ----------
  const capOk = c => !D.CAPITAL_SKIP.includes(c.iso) && !sameNameCapital(c);
  def({
    id: "capital", cat: "geo", sub: "Pays et capitales", bump: 0, weight: 2,
    make(r, level, o) {
      const c = pickCountry(r, level, capOk, o.iso); if (!c) return null;
      const others = pickOthers(r, C.filter(x => x !== c && capOk(x)), 3, x => x.cont === c.cont, level); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 0), iso: c.iso,
        q: `Quelle est la capitale ${c.du} ?`, answer: c.capital, wrong: others.map(x => x.capital),
        ex: `${c.capital} est la capitale ${c.du}. ${c.capitalNote || ""}`.trim(), info: c.fact,
        ctx: `Les autres propositions sont les capitales ${others.map(x => x.du).join(", ")}.`,
        src: META.politicalSource, nature: "geo", fpKey: "cap>" + c.iso, concept: "capital|" + c.iso });
    },
    space: () => ({ n: C.filter(capOk).length, exact: true })
  });
  def({
    id: "capital_rev", cat: "geo", sub: "Pays et capitales", bump: 0.5, weight: 1.5,
    make(r, level, o) {
      const c = pickCountry(r, level - 0.5, capOk, o.iso); if (!c) return null;
      const others = pickOthers(r, C.filter(x => x !== c), 3, x => x.cont === c.cont, level); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 0.5), iso: c.iso,
        q: `${c.capital} est la capitale de quel pays ?`, answer: c.name, wrong: others.map(x => x.name),
        ex: `${c.capital} est la capitale ${c.du} (${contName(c)}). ${c.capitalNote || ""}`.trim(), info: c.fact,
        src: META.politicalSource, nature: "geo", fpKey: "cap<" + c.iso, concept: "capital|" + c.iso });
    },
    space: () => ({ n: C.filter(capOk).length, exact: true })
  });

  // ---------- GÉOGRAPHIE : drapeaux ----------
  def({
    id: "flag", cat: "geo", sub: "Drapeaux", bump: 0, weight: 1.5,
    make(r, level, o) {
      const c = pickCountry(r, level, () => true, o.iso); if (!c) return null;
      const look = level >= 3 ? lookalikesOf(c.iso).map(i => BY[i]) : [];
      const rest = pickOthers(r, C.filter(x => x !== c && !look.includes(x)), 3 - Math.min(3, look.length), x => x.cont === c.cont, level);
      if (!rest) return null;
      const others = look.slice(0, 3).concat(rest).slice(0, 3);
      const la = lookalikesOf(c.iso).map(i => BY[i].name);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, look.length ? 1 : 0), iso: c.iso,
        q: "À quel pays appartient ce drapeau ?", flagPrompt: c.iso, answer: c.name, wrong: others.map(x => x.name),
        ex: `Ce drapeau est celui ${c.du}, dont la capitale est ${c.capital}.`,
        info: la.length ? `Attention aux confusions : il ressemble au drapeau ${lookalikesOf(c.iso).map(i => BY[i].du).join(" et ")}.` : c.fact,
        nature: "geo", fpKey: "flag>" + c.iso, concept: "flag|" + c.iso });
    },
    space: () => ({ n: C.length, exact: true })
  });
  def({
    id: "flag_rev", cat: "geo", sub: "Drapeaux", bump: 0.5,
    make(r, level, o) {
      const c = pickCountry(r, level - 0.5, () => true, o.iso); if (!c) return null;
      const look = level >= 3 ? lookalikesOf(c.iso).map(i => BY[i]) : [];
      const rest = pickOthers(r, C.filter(x => x !== c && !look.includes(x)), 3 - Math.min(3, look.length), x => x.cont === c.cont, level);
      if (!rest) return null;
      const others = look.slice(0, 3).concat(rest).slice(0, 3);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, look.length ? 1.5 : 0.5), iso: c.iso,
        q: `Quel est le drapeau ${c.du} ?`, answer: c.iso, wrong: others.map(x => x.iso), optFlags: true,
        ex: `Le bon drapeau est celui ${c.du}. Les autres sont ceux ${others.map(x => x.du).join(", ")}.`, info: c.fact,
        nature: "geo", fpKey: "flag<" + c.iso, concept: "flag|" + c.iso });
    },
    space: () => ({ n: C.length, exact: true })
  });

  // ---------- GÉOGRAPHIE : continents ----------
  def({
    id: "continent", cat: "geo", sub: "Continents et régions", bump: -1,
    make(r, level, o) {
      const c = pickCountry(r, level + 1, x => !x.trans, o.iso); if (!c) return null;
      const wrong = r.sample(Object.keys(CONT).filter(k => k !== c.cont), 3).map(k => CONT[k].name);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, -1), iso: c.iso,
        q: `Sur quel continent se trouve ${c.name} ?`, answer: contName(c), wrong,
        ex: `${c.name} se trouve en ${contName(c)}. Capitale : ${c.capital}.`,
        info: c.fact, nature: "geo", fpKey: "cont>" + c.iso, concept: "cont|" + c.iso });
    },
    space: () => ({ n: C.filter(x => !x.trans).length, exact: true })
  });

  // ---------- GÉOGRAPHIE : frontières ----------
  const hasNb = c => c.borders.some(b => BY[b]);
  def({
    id: "border", cat: "geo", sub: "Frontières", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, hasNb, o.iso); if (!c) return null;
      const nb = BY[r.pick(c.borders.filter(b => BY[b]))];
      const pool = C.filter(x => x !== c && !c.borders.includes(x.iso));
      const others = pickOthers(r, pool, 3, x => x.cont === c.cont, Math.max(level, 3)); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Lequel de ces pays partage une frontière terrestre avec ${c.name} ?`, answer: nb.name, wrong: others.map(x => x.name),
        ex: `${c.name} a des frontières terrestres avec : ${nbNames(c).join(", ")}.`,
        info: c.fact, ctx: "Liste établie à partir des pays présents dans la base de démonstration.",
        nature: "geo", fpKey: "brd|" + c.iso + "|" + nb.iso, concept: "brd|" + [c.iso, nb.iso].sort().join("-") });
    },
    space: () => { const s = new Set(); C.forEach(c => c.borders.forEach(b => { if (BY[b]) s.add(c.iso + b); })); return { n: s.size, exact: true }; }
  });
  def({
    id: "not_border", cat: "geo", sub: "Frontières", bump: 1.5,
    make(r, level, o) {
      const ok = c => c.borders.filter(b => BY[b]).length >= 3;
      const c = pickCountry(r, level - 1.5, ok, o.iso); if (!c) return null;
      const nbs = r.sample(c.borders.filter(b => BY[b]), 3).map(b => BY[b]);
      const pool = C.filter(x => x !== c && !c.borders.includes(x.iso) && x.cont === c.cont);
      if (!pool.length) return null;
      const odd = r.pick(pool);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1.5), iso: c.iso,
        q: `Lequel de ces pays n'a PAS de frontière terrestre avec ${c.name} ?`, answer: odd.name, wrong: nbs.map(x => x.name),
        ex: `${odd.name} ne touche pas ${c.name}. Ses voisins sont : ${nbNames(c).join(", ")}.`, info: c.fact,
        nature: "geo", fpKey: "nbrd|" + c.iso + "|" + odd.iso, concept: "nbrd|" + c.iso });
    },
    space: () => ({ n: C.filter(c => c.borders.filter(b => BY[b]).length >= 3).reduce((s, c) => s + C.filter(x => x !== c && x.cont === c.cont && !c.borders.includes(x.iso)).length, 0), exact: true })
  });
  def({
    id: "landlocked", cat: "geo", sub: "Géographie physique", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => x.landlocked, o.iso); if (!c) return null;
      const others = pickOthers(r, C.filter(x => !x.landlocked && x.area > 1000), 3, x => x.cont === c.cont, level); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: "Lequel de ces pays n'a aucun accès à la mer ?", answer: c.name, wrong: others.map(x => x.name),
        ex: `${c.name} est un pays enclavé : il n'a pas de façade maritime${["KZ", "TM", "AZ"].includes(c.iso) ? " ouverte sur l'océan (la Caspienne est une mer fermée)" : ""}. Ses voisins : ${nbNames(c).join(", ") || "—"}.`,
        info: c.fact, nature: "geo", fpKey: "land|" + c.iso, concept: "land|" + c.iso });
    },
    space: () => ({ n: C.filter(x => x.landlocked).length, exact: true })
  });

  // ---------- GÉOGRAPHIE : comparaisons chiffrées (combinatoires) ----------
  function comparison(id, sub, key, fmt, minRatio, label, srcObj, bump) {
    def({
      id, cat: "geo", sub, bump,
      make(r, level, o) {
        const t = U.clamp(level - bump, 1, 5);
        for (let k = 0; k < 25; k++) {
          const focus = o.iso ? BY[o.iso] : null;
          let pool = C.filter(c => Math.abs(c.tier - t) <= 1 && c[key] > 0);
          if (level >= 3 && r() < 0.7) { const cont = focus ? focus.cont : r.pick(Object.keys(CONT)); pool = pool.filter(c => c.cont === cont); }
          if (pool.length < 4) continue;
          let set = r.sample(pool, 4);
          if (focus && !set.includes(focus)) set = [focus].concat(set.filter(x => x !== focus).slice(0, 3));
          const sorted = set.slice().sort((a, b) => b[key] - a[key]);
          const ratio = sorted[0][key] / sorted[1][key];
          if (ratio < minRatio) continue;
          if (level >= 4 && ratio > 3) continue;   // niveaux élevés : écarts plus serrés
          if (level <= 2 && ratio < 1.6) continue;  // niveaux faciles : écarts nets
          const w = sorted[0];
          return build(r, { gen: id, cat: "geo", sub, d: U.clamp(Math.round((sorted.reduce((s, c) => s + c.tier, 0) / 4) + bump + (ratio < 1.6 ? 1 : 0)), 1, 5),
            q: `Lequel de ces pays a la plus ${label} ?`, answer: w.name, wrong: sorted.slice(1).map(x => x.name),
            ex: `${w.name} arrive en tête. Valeurs approximatives : ${sorted.map(c => `${c.name} ${fmt(c[key])}`).join(" ; ")}.`,
            info: w.fact, ctx: srcObj.nature === "contemp" ? "Donnée évolutive : l'écart entre la première et la deuxième valeur dépasse " + Math.round((minRatio - 1) * 100) + " %, ce qui rend la réponse robuste aux mises à jour." : "",
            src: srcObj.src, asOf: srcObj.asOf, nature: srcObj.nature, iso: w.iso, isos: set.map(c => c.iso),
            fpKey: id + "|" + set.map(c => c.iso).sort().join(","), concept: id + "|" + w.iso });
        }
        return null;
      },
      space() { return { n: estimateCombos(key, minRatio), exact: false, facts: C.length }; }
    });
  }
  function estimateCombos(key, minRatio) {
    const r = U.rng(42); let ok = 0; const N = 4000;
    for (let i = 0; i < N; i++) { const s = r.sample(C, 4).map(c => c[key]).sort((a, b) => b - a); if (s[0] / s[1] >= minRatio) ok++; }
    const n = C.length; const combos = n * (n - 1) * (n - 2) * (n - 3) / 24;
    return Math.round(combos * ok / N);
  }
  comparison("pop_cmp", "Population et démographie", "pop", U.pop, 1.25, "grande population", popSrc, 0.5);
  comparison("area_cmp", "Superficie et densité", "area", U.area, 1.15, "grande superficie", { src: META.areaSource, nature: "geo" }, 0.5);
  comparison("dens_cmp", "Superficie et densité", "density", U.density, 1.5, "forte densité de population", popSrc, 1.5);

  def({
    id: "pop_order", cat: "geo", sub: "Population et démographie", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => x.pop >= 0.05, o.iso); if (!c) return null;
      const factors = r.sample([0.1, 0.3, 3, 10, 0.03, 30].filter(f => c.pop * f >= 0.01 && c.pop * f <= 3000), 3);
      if (factors.length < 3) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Quelle est approximativement la population ${c.du} ?`, answer: "≈ " + U.pop(c.pop), wrong: factors.map(f => "≈ " + U.pop(c.pop * f)),
        ex: `${c.name} compte environ ${U.pop(c.pop)} (estimation ONU 2024). Sa densité est d'environ ${U.density(c.density)}.`,
        info: c.fact, ctx: "Les propositions diffèrent d'un facteur 3 au moins : il s'agit de connaître l'ordre de grandeur, pas le chiffre exact.",
        ...popSrc, fpKey: "pop|" + c.iso, concept: "pop|" + c.iso });
    },
    space: () => ({ n: C.length, exact: true })
  });

  // ---------- ÉCONOMIE : monnaies ----------
  const curCount = {}; C.forEach(c => { curCount[c.cur] = (curCount[c.cur] || 0) + 1; });
  def({
    id: "currency", cat: "eco", sub: "Monnaies", bump: 0.5, weight: 1.5,
    make(r, level, o) {
      const c = pickCountry(r, level - 0.5, () => true, o.iso); if (!c) return null;
      const near = C.filter(x => x.cont === c.cont && x.cur !== c.cur).map(x => x.cur);
      const far = C.filter(x => x.cur !== c.cur).map(x => x.cur);
      const pool = Array.from(new Set((level >= 3 ? r.shuffle(near) : []).concat(r.shuffle(far))));
      const wrong = pool.slice(0, 3).map(k => D.CURRENCIES[k]);
      const shared = C.filter(x => x.cur === c.cur && x !== c).map(x => x.name);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, c.cur === "EUR" ? -0.5 : 0.5), iso: c.iso,
        q: `Quelle est la monnaie officielle ${c.du} ?`, answer: D.CURRENCIES[c.cur], wrong,
        ex: `La monnaie ${c.du} est le ${D.CURRENCIES[c.cur]}.` + (shared.length ? ` Elle est aussi utilisée par : ${shared.slice(0, 8).join(", ")}${shared.length > 8 ? "…" : ""}.` : ""),
        info: c.fact, src: "Banques centrales nationales", asOf: META.verifiedAt, nature: "contemp",
        fpKey: "cur>" + c.iso, concept: "cur|" + c.iso });
    },
    space: () => ({ n: C.length, exact: true })
  });
  def({
    id: "currency_rev", cat: "eco", sub: "Monnaies", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => curCount[x.cur] === 1, o.iso); if (!c) return null;
      const others = pickOthers(r, C.filter(x => x.cur !== c.cur), 3, x => x.cont === c.cont, level); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Dans quel pays la monnaie officielle est-elle : ${D.CURRENCIES[c.cur]} ?`, answer: c.name, wrong: others.map(x => x.name),
        ex: `Le ${D.CURRENCIES[c.cur]} est la monnaie ${c.du}.`, info: c.fact,
        src: "Banques centrales nationales", asOf: META.verifiedAt, nature: "contemp", fpKey: "cur<" + c.iso, concept: "cur|" + c.iso });
    },
    space: () => ({ n: C.filter(x => curCount[x.cur] === 1).length, exact: true })
  });
  def({
    id: "cross_cur", cat: "eco", sub: "Monnaies", bump: 1.5,
    make(r, level, o) {
      const c = pickCountry(r, level - 1.5, x => capOk(x) && x.cur !== "EUR", o.iso); if (!c) return null;
      const pool = Array.from(new Set(r.shuffle(C.filter(x => x.cur !== c.cur && (level < 3 || x.cont === c.cont)).map(x => x.cur))));
      if (pool.length < 3) return null;
      return build(r, { gen: this.id, cat: "eco", sub: "Monnaies", d: diffOf(c.tier, 1.5), iso: c.iso,
        q: `Quelle est la monnaie du pays dont la capitale est ${c.capital} ?`, answer: D.CURRENCIES[c.cur], wrong: pool.slice(0, 3).map(k => D.CURRENCIES[k]),
        ex: `${c.capital} est la capitale ${c.du}, dont la monnaie est le ${D.CURRENCIES[c.cur]}.`,
        info: c.fact, ctx: "Question croisée géographie × économie : deux connaissances à mobiliser.",
        src: "Banques centrales nationales", asOf: META.verifiedAt, nature: "contemp", fpKey: "xcur|" + c.iso, concept: "xcur|" + c.iso });
    },
    space: () => ({ n: C.filter(x => capOk(x) && x.cur !== "EUR").length, exact: true })
  });

  // ---------- CULTURES : langues ----------
  const langOk = c => c.flags !== "lang-note";
  def({
    id: "language", cat: "cult", sub: "Langues", bump: 0.5,
    make(r, level, o) {
      const c = pickCountry(r, level - 0.5, langOk, o.iso); if (!c) return null;
      const l = r.pick(c.langs);
      const near = C.filter(x => x.cont === c.cont).flatMap(x => x.langs);
      const all = C.flatMap(x => x.langs);
      const pool = Array.from(new Set((level >= 3 ? r.shuffle(near) : []).concat(r.shuffle(all)))).filter(x => !c.langs.includes(x));
      const names = c.langs.map(k => D.LANGUAGES[k]);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, c.langs.length > 1 ? 1 : 0.5), iso: c.iso,
        q: `Laquelle de ces langues est une langue officielle ${c.du} ?`, answer: D.LANGUAGES[l], wrong: pool.slice(0, 3).map(k => D.LANGUAGES[k]),
        ex: `Langue${names.length > 1 ? "s" : ""} officielle${names.length > 1 ? "s" : ""} ${c.du} : ${names.join(", ")}.`, info: c.fact,
        src: "Constitutions nationales", nature: "hist", fpKey: "lang|" + c.iso + "|" + l, concept: "lang|" + c.iso });
    },
    space: () => ({ n: C.filter(langOk).reduce((s, c) => s + c.langs.length, 0), exact: true })
  });
  def({
    id: "language_rev", cat: "cult", sub: "Langues", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => langOk(x) && !["en", "fr", "ar", "es"].includes(x.langs[0]), o.iso); if (!c) return null;
      const l = c.langs[0];
      const others = pickOthers(r, C.filter(x => !x.langs.includes(l) && langOk(x)), 3, x => x.cont === c.cont, level); if (!others) return null;
      const also = C.filter(x => x !== c && x.langs.includes(l)).map(x => x.name);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Dans lequel de ces pays le ${D.LANGUAGES[l]} est-il langue officielle ?`, answer: c.name, wrong: others.map(x => x.name),
        ex: `Le ${D.LANGUAGES[l]} est langue officielle ${c.du}${also.length ? ", ainsi qu'en/au : " + also.join(", ") : ""}.`, info: c.fact,
        src: "Constitutions nationales", nature: "hist", fpKey: "lang<" + c.iso + "|" + l, concept: "lang|" + c.iso });
    },
    space: () => ({ n: C.filter(x => langOk(x) && !["en", "fr", "ar", "es"].includes(x.langs[0])).length, exact: true })
  });

  // ---------- POLITIQUE : régimes, organisations, dirigeants ----------
  const GOV_ASK = ["PRES", "SEMI", "PARL", "MPARL", "MABS", "UNI", "THEO", "DIR"];
  def({
    id: "gov", cat: "pol", sub: "Régimes politiques", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => GOV_ASK.includes(x.gov), o.iso); if (!c) return null;
      // On évite de mettre côte à côte « présidentielle » et « semi-présidentielle » aux niveaux faciles.
      let pool = GOV_ASK.filter(g => g !== c.gov);
      if (level <= 2) pool = pool.filter(g => !(["PRES", "SEMI"].includes(g) && ["PRES", "SEMI"].includes(c.gov)) && !(["PARL", "MPARL"].includes(g) && ["PARL", "MPARL"].includes(c.gov)));
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Quel est le régime politique ${c.du} ?`, answer: D.GOV[c.gov], wrong: r.sample(pool, 3).map(g => D.GOV[g]),
        ex: `${c.name} : ${D.GOV[c.gov]}. Classification simplifiée, état connu en ${U.asOfLabel(META.verifiedAt)}.`,
        info: c.fact, ctx: "Les régimes politiques peuvent évoluer (réformes constitutionnelles, coups d'État). Cette donnée est datée.",
        ...polSrc, fpKey: "gov|" + c.iso, concept: "gov|" + c.iso });
    },
    space: () => ({ n: C.filter(x => GOV_ASK.includes(x.gov)).length, exact: true })
  });
  def({
    id: "monarchy", cat: "pol", sub: "Régimes politiques", bump: 1,
    make(r, level, o) {
      const c = pickCountry(r, level - 1, x => ["MPARL", "MABS"].includes(x.gov), o.iso); if (!c) return null;
      const others = pickOthers(r, C.filter(x => ["PRES", "SEMI", "PARL"].includes(x.gov)), 3, x => x.cont === c.cont, level); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: "Lequel de ces pays est une monarchie ?", answer: c.name, wrong: others.map(x => x.name),
        ex: `${c.name} est une ${D.GOV[c.gov].toLowerCase()}. Les trois autres pays sont des républiques.`, info: c.fact,
        ...polSrc, fpKey: "mon|" + c.iso + "|" + others.map(x => x.iso).sort().join(","), concept: "mon|" + c.iso });
    },
    space: () => { const m = C.filter(x => ["MPARL", "MABS"].includes(x.gov)).length; return { n: m * 120, exact: false, facts: m }; }
  });

  const ORG_ASK = ["OTAN", "UE", "EURO", "G20", "BRICS", "OPEP", "ASEAN"];
  const ORG_LBL = { OTAN: "de l'OTAN", UE: "de l'Union européenne", EURO: "de la zone euro", G20: "du G20", BRICS: "des BRICS", OPEP: "de l'OPEP", ASEAN: "de l'ASEAN" };
  const orgMembers = k => D.ORGS[k].list.split(" ").filter(i => BY[i]);
  def({
    id: "org_member", cat: "pol", sub: "Organisations internationales", bump: 1, weight: 1.3,
    make(r, level, o) {
      const keys = o.iso ? ORG_ASK.filter(k => orgMembers(k).includes(o.iso)) : ORG_ASK;
      if (!keys.length) return null;
      const k = r.pick(keys), org = D.ORGS[k], mem = orgMembers(k);
      const excl = (org.exclude || "").split(" ");
      const c = o.iso ? BY[o.iso] : pickCountry(r, level - 1, x => mem.includes(x.iso), null); if (!c) return null;
      const others = pickOthers(r, C.filter(x => !mem.includes(x.iso) && !excl.includes(x.iso)), 3, x => x.cont === c.cont, Math.max(3, level)); if (!others) return null;
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, 1), iso: c.iso,
        q: `Lequel de ces pays est membre ${ORG_LBL[k]} ?`,
        answer: c.name, wrong: others.map(x => x.name),
        ex: `${c.name} est membre de : ${org.name}. ${org.members}, état connu en ${U.asOfLabel(org.asOf)}.`,
        info: org.facts[0], ctx: org.summary, src: org.source, asOf: org.asOf, nature: "contemp",
        fpKey: "org|" + k + "|" + c.iso, concept: "org|" + k + "|" + c.iso });
    },
    space: () => ({ n: ORG_ASK.reduce((s, k) => s + orgMembers(k).length, 0), exact: true })
  });
  def({
    id: "org_not", cat: "pol", sub: "Organisations internationales", bump: 2,
    make(r, level, o) {
      const k = r.pick(["OTAN", "UE", "EURO", "G20"]), org = D.ORGS[k], mem = orgMembers(k);
      const odd = pickCountry(r, level - 2, x => !mem.includes(x.iso) && ["EU", "AS", "NA"].includes(x.cont) && x.tier <= 3, o.iso); if (!odd) return null;
      const others = r.sample(mem.map(i => BY[i]).filter(x => x.cont === odd.cont || r() < 0.3), 3); if (others.length < 3) return null;
      const lbl = ORG_LBL[k];
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: U.clamp(odd.tier + 2, 1, 5), iso: odd.iso,
        q: `Lequel de ces pays n'est PAS membre ${lbl} ?`,
        answer: odd.name, wrong: others.map(x => x.name),
        ex: `${odd.name} n'est pas membre ${lbl}. ${org.members}, état connu en ${U.asOfLabel(org.asOf)}.`,
        info: org.facts[org.facts.length - 1], ctx: org.summary, src: org.source, asOf: org.asOf, nature: "contemp",
        fpKey: "orgn|" + k + "|" + odd.iso, concept: "orgn|" + k + "|" + odd.iso });
    },
    space: () => ({ n: ["OTAN", "UE", "EURO", "G20"].reduce((s, k) => s + C.filter(x => !orgMembers(k).includes(x.iso) && ["EU", "AS", "NA"].includes(x.cont) && x.tier <= 3).length, 0), exact: true })
  });
  def({
    id: "org_fact", cat: "pol", sub: "Organisations internationales", bump: 0,
    make(r, level, o) {
      if (o.iso) return null;
      const k = r.pick(Object.keys(D.ORGS)), org = D.ORGS[k];
      const kind = r.pick(["hq", "founded"]);
      if (kind === "hq") {
        if (/\(|siège/i.test(org.hq)) return null;
        const wrong = r.sample(["New York", "Genève", "Bruxelles", "Vienne", "Paris", "Jakarta", "Addis-Abeba", "Washington", "Francfort", "Londres", "Nairobi", "Rome"].filter(x => x !== org.hq), 3);
        return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: U.clamp(level, 2, 4),
          q: `Où se trouve le siège de l'organisation suivante : ${org.name} ?`, answer: org.hq, wrong,
          ex: `Le siège de ${org.short} est à ${org.hq}.`, info: org.facts[0], ctx: org.summary, src: org.source, nature: "hist",
          fpKey: "orghq|" + k, concept: "orghq|" + k });
      }
      const y = org.founded, wrong = r.sample([-15, -7, -3, 4, 9, 16, 22].map(d => y + d).filter(v => v <= 2025), 3).map(String);
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: U.clamp(level, 2, 5),
        q: `En quelle année a été créée l'organisation suivante : ${org.name} ?`, answer: String(y), wrong,
        ex: `${org.short} a été créée en ${y}. ${org.summary}`, info: org.facts[0], src: org.source, nature: "hist",
        fpKey: "orgy|" + k, concept: "orgy|" + k });
    },
    space: () => ({ n: Object.values(D.ORGS).filter(o => !/\(|siège/i.test(o.hq)).length + Object.keys(D.ORGS).length, exact: true })
  });
  def({
    id: "leader", cat: "pol", sub: "Chefs d'État et de gouvernement", bump: 0.5, weight: 1.2,
    make(r, level, o) {
      const isos = Object.keys(D.LEADERS).filter(i => BY[i]);
      const iso = o.iso ? (D.LEADERS[o.iso] ? o.iso : null) : r.pick(isos.filter(i => Math.abs(BY[i].tier - (level - 0.5)) <= 1.5));
      if (!iso) return null;
      const c = BY[iso], [hs, hg] = D.LEADERS[iso];
      const which = hg && r() < 0.5 ? 1 : 0;
      const name = which ? hg : hs;
      const pool = Array.from(new Set(Object.values(D.LEADERS).flat().filter(n => n && n !== hs && n !== hg)));
      const role = which ? "chef du gouvernement" : "chef de l'État";
      return build(r, { gen: this.id, cat: this.cat, sub: this.sub, d: diffOf(c.tier, which ? 1.5 : 0.5), iso,
        q: `Selon les données vérifiées en ${U.asOfLabel(D.LEADERS_AS_OF)}, qui est ${role} ${c.du} ?`, answer: name, wrong: r.sample(pool, 3),
        ex: `En ${U.asOfLabel(D.LEADERS_AS_OF)}, ${role} ${c.du} : ${name}.${hg && !which ? " Chef du gouvernement : " + hg + "." : ""}${which ? " Chef de l'État : " + hs + "." : ""}`,
        info: c.fact, ctx: "Donnée politique évolutive : elle peut avoir changé depuis la date de vérification. Consultez une source officielle à jour.",
        src: D.LEADERS_SOURCE, asOf: D.LEADERS_AS_OF, nature: "contemp", fpKey: "lead|" + iso + "|" + which, concept: "lead|" + iso + "|" + which });
    },
    space: () => ({ n: Object.values(D.LEADERS).reduce((s, l) => s + (l[1] ? 2 : 1), 0), exact: true })
  });

  W.WKA.generators = G;
  W.WKA.byIso = BY;
})(typeof window !== "undefined" ? window : globalThis);
