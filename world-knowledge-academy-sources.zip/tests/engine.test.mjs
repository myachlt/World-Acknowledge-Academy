// Tests du moteur et intégrité des données : node tests/engine.test.mjs
import fs from "node:fs";
import vm from "node:vm";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "src");
const files = ["countries", "world", "bank", "bank_prat", "bank_plus", "countries_plus", "knowledge", "situations", "lang_vocab", "lang_en", "lang_es", "mapdata", "db_export"].map(f => `data/${f}.js`)
  .concat(["util", "generators", "extra", "lang", "store", "engine", "features"].map(f => `engine/${f}.js`));
const ctx = { console, Intl, Date, Math, JSON };
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of files) vm.runInContext(fs.readFileSync(path.join(root, f), "utf8"), ctx, { filename: f });
const { data: D, engine: E, util: U, generators: G, Store, lang: LG } = ctx.WKA;

let fails = 0, checks = 0;
const ok = (cond, msg) => { checks++; if (!cond) { fails++; console.log("ÉCHEC :", msg); } };

// 1. Intégrité des données pays
const BY = Object.fromEntries(D.countries.map(c => [c.iso, c]));
ok(D.countries.length === new Set(D.countries.map(c => c.iso)).size, "codes ISO uniques");
for (const c of D.countries) {
  ok(D.CURRENCIES[c.cur], `${c.iso} : monnaie inconnue ${c.cur}`);
  c.langs.forEach(l => ok(D.LANGUAGES[l], `${c.iso} : langue inconnue ${l}`));
  ok(D.GOV[c.gov], `${c.iso} : régime inconnu ${c.gov}`);
  ok(D.CONTINENTS[c.cont], `${c.iso} : continent inconnu`);
  ok(c.pop > 0 && c.area > 0, `${c.iso} : population/superficie`);
  ok(Math.abs(c.lat) <= 90 && Math.abs(c.lon) <= 180, `${c.iso} : coordonnées`);
  // Symétrie des frontières : si A touche B, B doit toucher A
  c.borders.filter(b => BY[b]).forEach(b => ok(BY[b].borders.includes(c.iso), `frontière non symétrique ${c.iso}-${b}`));
}
Object.keys(D.LEADERS).forEach(i => ok(BY[i], `dirigeant pour pays absent ${i}`));
Object.values(D.ORGS).forEach(o => (o.list || "").split(" ").filter(Boolean).forEach(i => ok(BY[i], `${o.short} : membre absent ${i}`)));
ok(D.ORGS.OTAN.list.split(" ").length === 32, "OTAN = 32 membres");
ok(D.ORGS.UE.list.split(" ").length === 27, "UE = 27 membres");
ok(D.ORGS.EURO.list.split(" ").length === 21, "zone euro = 21 membres");
ok(D.ORGS.G20.list.split(" ").length === 19, "G20 = 19 pays");

// 2. Banque rédigée : 4 options distinctes, pas de doublon de contenu ni de quasi-doublon
const keys = new Map();
for (const b of E.BANK) {
  const opts = [b.a, ...b.w];
  ok(opts.length === 4 && new Set(opts.map(U.norm)).size === 4, `options en double : ${b.q}`);
  ok(b.ex && b.info && b.src, `explication/info/source manquante : ${b.q}`);
  ok(E.CAT[b.cat] && E.CAT[b.cat].subs.includes(b.sub), `sous-catégorie inconnue ${b.cat}/${b.sub}`);
  ok(b.nature !== "contemp" || b.asOf, `donnée évolutive sans date : ${b.q}`);
  ok(!keys.has(b.fp), `doublon de contenu : ${b.q} / ${keys.get(b.fp)}`); keys.set(b.fp, b.q);
}
for (let i = 0; i < E.BANK.length; i++) for (let j = i + 1; j < E.BANK.length; j++) {
  const s = U.similarity(E.BANK[i].q, E.BANK[j].q);
  if (s > 0.75 && U.norm(E.BANK[i].a) === U.norm(E.BANK[j].a)) ok(false, `quasi-doublon : ${E.BANK[i].q} / ${E.BANK[j].q}`);
}
// Une reformulation doit produire la même empreinte de contenu
ok(U.contentKey("Quelle est la capitale de la France ?", "Paris") === U.contentKey("La capitale de la France, quelle est-elle ?", "Paris"), "empreinte insensible à la formulation");

// 3. Générateurs : 6 000 questions (culture générale et langues), toutes valides
const r = U.rng(7);
let made = 0;
for (let k = 0; k < 6000; k++) {
  const g = G[k % G.length], lvl = 1 + (k % (g.lang ? 6 : 5));
  const q = g.make(r, lvl, {});
  if (!q) continue; made++;
  ok(q.fp && q.concept && q.q && q.ex, `${g.id} : champs manquants`);
  ok(q.nature !== "contemp" || q.asOf, `${g.id} : donnée évolutive sans date`);
  const kind = q.kind || "mcq";
  if (kind === "mcq") {
    ok(q.opts.length === 4 && q.ans >= 0 && q.ans < 4, `${g.id} : réponse hors options`);
    ok(new Set(q.opts).size === 4, `${g.id} : options identiques — ${q.q} ${q.opts}`);
    ok(!/\bundefined\b|\bNaN\b|\bnull\b/.test([q.q, ...q.opts, q.ex].join(" | ")), `${g.id} : texte cassé — ${q.q} | ${q.ex}`);
  } else {
    // La bonne réponse, saisie telle quelle, doit être acceptée par le correcteur
    const good = kind === "input" ? q.accept[0] : kind === "match" ? q.pairs.map((_, i) => i)
      : kind === "cloze" ? q.parts.filter(x => typeof x !== "string").map(x => x.opts ? x.answer : x.accept[0])
      : kind === "passage" ? q.subqs.map(x => x.ans) : { text: q.model, ticks: q.criteria.map(() => true) };
    ok(LG.check(q, good).correct, `${g.id} : bonne réponse refusée (${kind})`);
    ok(!/undefined|NaN/.test(JSON.stringify(q)), `${g.id} : contenu cassé`);
  }
  if (g.id === "border") ok(BY[q.iso].borders.includes(D.countries.find(c => c.name === q.opts[q.ans]).iso), "frontière fausse");
  if (g.id === "pop_cmp") { const w = D.countries.find(c => c.name === q.opts[q.ans]); ok(q.isos.every(i => BY[i].pop <= w.pop), "comparaison population fausse"); }
}
ok(made > 4000, `trop de générations nulles (${made}/6000)`);

// 4. Session : aucune répétition d'empreinte ni de concept dans une même session, et entre sessions
const mem = {}; const adapter = { load: id => mem[id] || null, save: (id, v) => { mem[id] = JSON.parse(JSON.stringify(v)); return true; }, remove: id => delete mem[id] };
const st = new Store(adapter, "test");
const allFp = new Set(); let dupAcross = 0;
for (let s = 0; s < 30; s++) {
  const sess = new E.Session(st, { mode: "libre", count: 20, level: "adaptive" });
  const fps = new Set(), concepts = new Set();
  for (let i = 0; i < 20; i++) {
    const q = sess.next(); if (!q) break;
    ok(!fps.has(q.fp) && !concepts.has(q.concept), "répétition dans la session");
    fps.add(q.fp); concepts.add(q.concept);
    if (allFp.has(q.fp)) dupAcross++; allFp.add(q.fp);
    sess.answer(r() < 0.7 ? q.ans : (q.ans + 1) % 4, 4000);
  }
  sess.finish();
}
ok(dupAcross === 0, `${dupAcross} questions répétées sur 600 (30 sessions)`);
ok(st.s.sessions.length === 30 && st.s.stats.answered === 600, "statistiques cumulées");
ok(Object.keys(st.s.mistakes).length > 0, "erreurs enregistrées pour la révision");
const rev = new E.Session(st, { mode: "revision", count: 10 });
const rq = rev.next(); ok(rq && rq.review, "mode révision sert une erreur");
// Mode pays
const fr = new E.Session(st, { mode: "monde", iso: "JP", cats: ["geo", "pol", "eco", "cult"], count: 8 });
let jp = 0; for (let i = 0; i < 8; i++) { const q = fr.next(); if (!q) break; jp++; }
ok(jp >= 6, `quiz pays : seulement ${jp} questions`);
// Mode expert
const ex = new E.Session(st, { mode: "expert", count: 10 });
let hard = 0; for (let i = 0; i < 10; i++) { const q = ex.next(); if (!q) break; if (q.d >= 4) hard++; ex.answer(0, 1000); }
ok(hard >= 8, `mode expert : ${hard}/10 questions difficiles`);

const v = E.volume();
console.log(`\nVolume : ${v.exact} questions uniques (dont ${v.bank} rédigées), ≈ ${v.combos.toLocaleString("fr-FR")} combinaisons de comparaison, ${v.generators} générateurs, ${v.countries} pays.`);
console.log(Object.entries(v.per).map(([k, x]) => `${k}: ${x.exact} uniques + ${x.combos} comb.`).join(" | "));
console.log(`${checks - fails}/${checks} vérifications réussies.`);
process.exit(fails ? 1 : 0);
