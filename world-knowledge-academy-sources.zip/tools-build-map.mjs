import fs from "node:fs"; import vm from "node:vm"; import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const topo = require("world-atlas/countries-110m.json");
const { feature } = require("topojson-client");
const d3 = require("d3-geo");
const iso = require("i18n-iso-countries");
const ctx = {}; ctx.globalThis = ctx; vm.createContext(ctx);
vm.runInContext(fs.readFileSync("/mnt/project-files/world-knowledge-academy/src/data/countries.js", "utf8"), ctx);
const ours = new Set(ctx.WKA.data.countries.map(c => c.iso));
const fc = feature(topo, topo.objects.countries);
fc.features = fc.features.filter(f => f.properties.name !== "Antarctica");
const W = 960, H = 470;
const proj = d3.geoNaturalEarth1().fitExtent([[4, 4], [W - 4, H - 4]], fc);
const path = d3.geoPath(proj).digits(1);
const shapes = {}, bbox = {}, other = [], dots = {};
for (const f of fc.features) {
  let a2 = f.id ? iso.numericToAlpha2(f.id) : null;
  if (f.properties.name === "Kosovo") a2 = "XK";
  if (f.properties.name === "N. Cyprus") a2 = null;
  const d = path(f); if (!d) continue;
  if (a2 && ours.has(a2)) { shapes[a2] = (shapes[a2] ? shapes[a2] : "") + d; const b = path.bounds(f); bbox[a2] = b.flat().map(v => Math.round(v)); }
  else other.push(d);
}
// Russie / Fidji franchissent l'antiméridien : on garde la boîte la plus utile
for (const c of ctx.WKA.data.countries) { const p = proj([c.lon, c.lat]); dots[c.iso] = p.map(v => Math.round(v * 10) / 10); }
const missing = [...ours].filter(i => !shapes[i]);
const out = `/* Tracés des pays : Natural Earth 1:110m (domaine public) via world-atlas 2.0.2, projection Natural Earth I, 960×${H}.
 * Les micro-États absents à cette échelle sont représentés par un point. Fichier généré par build-map.mjs. */
(function (W) { W.WKA = W.WKA || {}; W.WKA.data = W.WKA.data || {};
W.WKA.data.MAP = ${JSON.stringify({ w: W, h: H, shapes, bbox, other, dots, small: missing })};
})(typeof window !== "undefined" ? window : globalThis);\n`;
fs.writeFileSync("/mnt/project-files/world-knowledge-academy/src/data/mapdata.js", out);
console.log("shapes", Object.keys(shapes).length, "missing", missing.join(" "), "size KB", Math.round(out.length / 1024));
