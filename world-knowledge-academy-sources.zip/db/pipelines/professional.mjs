// Base 13 : Professional Knowledge : construite par le pipeline practical (même lot éditorial, domaines Travail et Vie professionnelle).
import { readBase } from "../lib/core.mjs";
export async function build(log) { const k = readBase("professional", "knowledge_card"); log("  " + k.length + " fiches (construites par practical)"); return { counts: { knowledge_card: k.length }, qa: [] }; }
