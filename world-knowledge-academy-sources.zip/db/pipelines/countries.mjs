// Base 1 : Countries (pays et territoires) + langues + monnaies.
// Sources : REST Countries (miroir mledoze/countries, ODbL), datasets/country-codes (M49, noms ONU), ISO 4217,
// Wikidata (noms et capitales en français), Natural Earth (souveraineté des territoires).
// Recoupement : la maquette contient 173 pays vérifiés à la main (noms, capitales) ; tout désaccord est journalisé.
import { getResource, prov, parseCSV, norm, writeBase, TODAY } from "../lib/core.mjs";
import { restCountries, countryCodes, currencyCodes, naturalEarth, wikidata } from "../connectors/index.mjs";
import { appData } from "../lib/app.mjs";

const CONT = { EU: "Europe", AS: "Asie", AF: "Afrique", NA: "Amérique du Nord", SA: "Amérique du Sud", OC: "Océanie", AN: "Antarctique" };
const continentOf = c => c.region === "Europe" ? "EU" : c.region === "Asia" ? "AS" : c.region === "Africa" ? "AF" : c.region === "Oceania" ? "OC"
  : c.region === "Antarctic" ? "AN" : c.region === "Americas" ? (c.subregion === "South America" ? "SA" : "NA") : null;
// Cas dont le statut international est contesté : signalés, jamais tranchés par l'application.
const UN_OBSERVERS = { VAT: "Le Saint-Siège est État observateur non membre de l'ONU.", PSE: "La Palestine est État observateur non membre de l'ONU." };
const DISPUTED = { TWN: "Statut contesté : la République de Chine (Taïwan) n'est pas membre de l'ONU.", UNK: "Kosovo : indépendance reconnue par une partie des États membres de l'ONU.", XKX: "Kosovo : indépendance reconnue par une partie des États membres de l'ONU.", PSE: "Palestine : État observateur non membre de l'ONU.", ESH: "Sahara occidental : territoire non autonome selon l'ONU, statut contesté." };

export async function build(log) {
  const qa = [];
  const { countries: RC, fetch: fRC } = await restCountries();
  const { rows: CC, fetch: fCC } = await countryCodes();
  const { rows: CUR, fetch: fCUR } = await currencyCodes();
  const lc = await getResource("country_codes", "language-codes-full.csv", [{ url: "https://raw.githubusercontent.com/datasets/language-codes/main/data/language-codes-full.csv" }]);
  const LANGS = parseCSV(lc.text);
  const { geo: NE, fetch: fNE } = await naturalEarth("ne_50m_admin_0_countries");
  let WD = null, fWD = null;
  try {
    const r = await wikidata("countries_fr", `SELECT ?iso3 ?fr ?capFr ?capEn WHERE { ?c wdt:P298 ?iso3 . OPTIONAL { ?c rdfs:label ?fr FILTER(LANG(?fr)="fr") }
      OPTIONAL { ?c p:P36 ?cs . ?cs ps:P36 ?cap . FILTER NOT EXISTS { ?cs pq:P582 ?ce } OPTIONAL { ?cap rdfs:label ?capFr FILTER(LANG(?capFr)="fr") } OPTIONAL { ?cap rdfs:label ?capEn FILTER(LANG(?capEn)="en") } } }`);
    WD = new Map(); fWD = r.fetch;
    for (const b of r.rows) { const x = WD.get(b.iso3) || { fr: b.fr, caps: [] }; if (b.capFr || b.capEn) x.caps.push({ fr: b.capFr, en: b.capEn }); WD.set(b.iso3, x); }
  } catch (e) { log("  Wikidata injoignable : noms français pris dans REST Countries et la maquette (" + e.message.slice(0, 80) + ")"); }

  const app = appData();
  const APP = new Map(app.countries.map(c => [c.iso, c]));
  const ccBy3 = new Map(CC.map(r => [r["ISO3166-1-Alpha-3"], r]));
  const neBy3 = new Map(); NE.features.forEach(f => { const p = f.properties; [p.ADM0_A3, p.ISO_A3, p.ADM0_ISO].forEach(k => k && k !== "-99" && !neBy3.has(k) && neBy3.set(k, p)); });
  const neByName = new Map(NE.features.map(f => [f.properties.ADMIN, f.properties]));
  const iso3of2 = new Map(RC.map(c => [c.cca2, c.cca3]));

  const country = [], border = [], cLang = [], cCur = [], langMap = new Map(), curMap = new Map();
  for (const c of RC) {
    const iso3 = c.cca3, a = APP.get(c.cca2), cc = ccBy3.get(iso3), wd = WD && WD.get(iso3);
    const nameFr = (c.translations.fra || {}).common;
    const capEn = (c.capital || [])[0] || null;
    // Capitale en français : maquette (vérifiée) > Wikidata (capitale actuelle) > nom anglais de REST Countries
    const wdCap = wd && wd.caps.find(x => x.en && norm(x.en) === norm(capEn || "")) || (wd && wd.caps.length === 1 ? wd.caps[0] : null);
    let capFr = a ? a.capital : wdCap && wdCap.fr ? wdCap.fr : null;
    let status = "source_trusted", notes = [];
    const checks = [];
    if (a) {
      checks.push(norm(a.name) === norm(nameFr || "") || (wd && norm(a.name) === norm(wd.fr || "")));
      const capOk = (wd && wd.caps.some(x => norm(x.fr || "") === norm(a.capital))) || norm(a.capital) === norm(capEn || "");
      checks.push(capOk);
      if (!checks[0]) qa.push({ rule: "name_mismatch", severity: "info", target_id: "cty:" + iso3, message: `Nom FR : maquette « ${a.name} » / REST Countries « ${nameFr} »${wd ? " / Wikidata « " + wd.fr + " »" : ""}` });
      if (!capOk) qa.push({ rule: "capital_mismatch", severity: "warn", target_id: "cty:" + iso3, message: `Capitale : maquette « ${a.capital} » / REST Countries « ${capEn} »${wd ? " / Wikidata « " + wd.caps.map(x => x.fr || x.en).join(", ") + " »" : ""}` });
      if (checks.every(Boolean)) status = "cross_checked"; else notes.push("désaccord de nom ou de capitale entre sources, voir qa");
      if (a.capitalNote) notes.push(a.capitalNote);
      if (a.area && c.area > 0 && Math.abs(a.area - c.area) / a.area > 0.05) qa.push({ rule: "area_definition", severity: "info", target_id: "cty:" + iso3, message: `Superficie : maquette ${a.area} km² / REST Countries ${c.area} km² (définitions différentes : outre-mer, eaux intérieures ou territoires revendiqués)` });
    } else if (wd && wd.caps.length && capEn) {
      if (wd.caps.some(x => [x.en, x.fr].some(v => v && norm(v) === norm(capEn)))) status = "cross_checked";
      else { status = "needs_review"; capFr = null; qa.push({ rule: "capital_mismatch", severity: "warn", target_id: "cty:" + iso3, message: `Capitale : REST Countries « ${capEn} » / Wikidata « ${wd.caps.map(x => x.fr || x.en).join(", ")} » : à trancher` }); }
    }
    const ne = neBy3.get(iso3);
    let kind = c.independent ? "sovereign" : "territory", sovereign = null;
    if (DISPUTED[iso3]) { kind = "disputed"; notes.push(DISPUTED[iso3]); }
    if (kind === "territory" && ne && ne.SOVEREIGNT && ne.ADMIN !== ne.SOVEREIGNT) { const s = neByName.get(ne.SOVEREIGNT); if (s && s.ADM0_A3) sovereign = "cty:" + (s.ADM0_A3 === "FR1" ? "FRA" : s.ADM0_A3); }
    // Erreurs connues de la source : observateurs comptés comme membres de l'ONU
    if (UN_OBSERVERS[iso3] && c.unMember) { c.unMember = false; notes.push(UN_OBSERVERS[iso3]); qa.push({ rule: "source_error_corrected", severity: "info", target_id: "cty:" + iso3, message: "REST Countries indique unMember=true ; corrigé : " + UN_OBSERVERS[iso3] }); }
    const fetchMain = fRC;
    const pid = prov({ fetch: fetchMain, status, note: notes.join(" ") || null });
    const dem = c.demonyms || {};
    country.push({
      id: "cty:" + iso3, iso2: c.cca2, iso3, m49: c.ccn3 || (cc && cc.M49) || null,
      name_fr: a ? a.name : (wd && wd.fr) || nameFr || c.name.common, name_en: c.name.common, name_es: (c.translations.spa || {}).common || null,
      official_fr: (c.translations.fra || {}).official || null, official_en: c.name.official, official_es: (c.translations.spa || {}).official || null,
      kind, sovereign_id: sovereign, un_member: c.unMember ? 1 : 0,
      continent: continentOf(c), region: c.region, subregion: c.subregion || null,
      capital_city_id: null, capital_name: capFr || capEn, capital_name_en: capEn,
      area_km2: c.area > 0 ? c.area : null, lat: c.latlng ? c.latlng[0] : null, lon: c.latlng ? c.latlng[1] : null,
      landlocked: c.landlocked ? 1 : 0, tld: (c.tld || [])[0] || null,
      calling_code: c.idd && c.idd.root ? c.idd.root + ((c.idd.suffixes || []).length === 1 ? c.idd.suffixes[0] : "") : null,
      flag_emoji: c.flag || null, demonym_fr: dem.fra ? dem.fra.m : null, demonym_en: dem.eng ? dem.eng.m : null,
      wikidata: cc && cc.wikidata_id ? cc.wikidata_id.split("/").pop() : null,
      in_app: a ? 1 : 0, prov_id: pid
    });
    for (const b of c.borders || []) if (iso3 < b) border.push({ a: "cty:" + iso3, b: "cty:" + b, prov_id: prov({ fetch: fRC, status: "source_trusted" }) });
    for (const [code3, nameEn] of Object.entries(c.languages || {})) {
      const L = LANGS.find(l => l["alpha3-b"] === code3 || l["alpha3-t"] === code3);
      const id = "lang:" + code3;
      if (!langMap.has(id)) {
        const fr = L && L.French ? L.French.split(";")[0].trim() : null;
        langMap.set(id, { id, iso639_3: code3, iso639_1: L ? L.alpha2 || null : null, name_en: nameEn, name_fr: L && app.LANGUAGES[L.alpha2] ? app.LANGUAGES[L.alpha2] : fr });
      }
      cLang.push({ country_id: "cty:" + iso3, language_id: id, official: 1, prov_id: prov({ fetch: fRC, status: "source_trusted", note: "Langues officielles ou nationales selon REST Countries" }) });
    }
    for (const [code, cu] of Object.entries(c.currencies || {})) {
      const id = "cur:" + code;
      if (!curMap.has(id)) { const iso = CUR.find(r => r.AlphabeticCode === code); curMap.set(id, { id, code, name_en: cu.name, name_fr: app.CURRENCIES[code] || null, symbol: cu.symbol || null, numeric_code: iso ? iso.NumericCode : null, in_iso4217: iso ? 1 : 0 }); }
      cCur.push({ country_id: "cty:" + iso3, currency_id: id, prov_id: prov({ fetch: fRC, status: CUR.some(r => r.AlphabeticCode === code) ? "cross_checked" : "source_trusted" }) });
    }
  }
  // Pays de la maquette absents de la source : signalés, conservés tels quels
  for (const a of app.countries) if (!iso3of2.has(a.iso)) qa.push({ rule: "missing_in_source", severity: "warn", target_id: a.iso, message: `${a.name} est dans la maquette mais pas dans REST Countries` });
  // Voisins : recoupement avec la maquette
  const bset = new Set(border.map(b => b.a + b.b));
  for (const a of app.countries) for (const nb of a.borders) {
    const x = "cty:" + iso3of2.get(a.iso), y = "cty:" + iso3of2.get(nb);
    if (!bset.has(x < y ? x + y : y + x)) qa.push({ rule: "border_mismatch", severity: "info", target_id: x, message: `Frontière ${a.iso}-${nb} présente dans la maquette, absente de REST Countries` });
  }
  const counts = writeBase("countries", { country, country_border: border, language: [...langMap.values()], country_language: cLang, currency: [...curMap.values()], country_currency: cCur }, { csv: ["country"] });
  log(`  pays : ${country.length} (${country.filter(c => c.kind === "sovereign").length} États, ${country.filter(c => c.kind === "territory").length} territoires), ${country.filter(c => c.in_app).length} recoupés avec la maquette`);
  return { counts, qa };
}
