// Base 7 : English Vocabulary (A1-C2) — et, par alignement de sens, les traductions françaises et espagnoles.
// Ossature : liste CEFR-J 1.5 (A1-B2) + Octanove (C1-C2) pour les niveaux ; WordNet 3.0 pour les sens, définitions, exemples,
// synonymes, antonymes ; WOLF (français) et MCR (espagnol) pour des traductions rattachées à un SENS précis (synset) ;
// ipa-dict (anglais américain, MIT) pour la phonétique ; OpenSubtitles pour la fréquence.
// Contrôle : la liste trilingue vérifiée de la maquette sert d'étalon (précision mesurée, traductions confirmées).
import { prov, writeBase, slug, norm, loadWiktionary } from "../lib/core.mjs";
import { cefrj, wordnetZip, omwZip, frequency, ipa } from "../connectors/index.mjs";
import { loadWordNet, loadOMW } from "../lib/wordnet.mjs";
import { makeThemer, THEME_ROWS } from "../lib/themes.mjs";
import { appData } from "../lib/app.mjs";

const POS = { noun: "n", verb: "v", adjective: "a", adverb: "r" };
const POS_FR = { noun: "nom", verb: "verbe", adjective: "adjectif", adverb: "adverbe", pronoun: "pronom", preposition: "préposition", determiner: "déterminant", conjunction: "conjonction", number: "nombre", "modal auxiliary": "auxiliaire modal", "be-verb": "verbe", "do-verb": "verbe", "have-verb": "verbe", interjection: "interjection", "infinitive-to": "particule" };
const LV = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6 };
export const stripArticle = s => String(s || "").replace(/^(le |la |les |l'|l’|un |une |el |los |las |lo |to )/i, "").trim();
const MAX_SENSES = 3, MAX_TR = 3;

export async function build(log) {
  const qa = [];
  const { a1b2, c1c2, fetchA, fetchB } = await cefrj();
  const wz = await wordnetZip(), oz = await omwZip();
  log("  lecture de WordNet et des wordnets français/espagnol…");
  const wn = loadWordNet(wz.file), omw = loadOMW(oz.file);
  const themeOf = makeThemer(wn);
  const fEn = await frequency("en"), fFr = await frequency("fr"), fEs = await frequency("es");
  const iEn = await ipa("en_US");
  const rank = (m, w) => m.rank.get(w.toLowerCase()) || 999999;
  const WK = loadWiktionary("en");
  const pWkX = WK.fetch ? prov({ fetch: WK.fetch, status: "cross_checked", note: "Traduction présente à la fois dans le wordnet aligné et dans Wiktionary" }) : null;
  const pWk = WK.fetch ? prov({ fetch: WK.fetch, status: "source_trusted", note: "Traduction Wiktionary rattachée au sens par recouvrement des définitions" }) : null;
  const WPOS = { noun: ["noun"], verb: ["verb"], adjective: ["adj"], adverb: ["adv"], pronoun: ["pron"], preposition: ["prep"], determiner: ["det", "article"], conjunction: ["conj"], number: ["num"], interjection: ["intj"], "modal auxiliary": ["verb"], "be-verb": ["verb"], "do-verb": ["verb"], "have-verb": ["verb"], "infinitive-to": ["particle", "prep"] };
  const STOP = new Set("the a an of to in or and for with by as is be that which from on at it its any one used being having".split(" "));
  const toks = s => new Set(norm(s || "").split(" ").filter(w => w.length > 3 && !STOP.has(w)));
  const overlap = (a, b) => { const A = toks(a), B = toks(b); let n = 0; A.forEach(x => B.has(x) && n++); return n / Math.max(1, Math.min(A.size, B.size)); };

  // Étalon : vocabulaire trilingue vérifié de la maquette
  const app = appData(); const GOLD = new Map();
  for (const v of app.VOCAB || []) GOLD.set(norm(v.en) + "|" + (v.nat || ""), v);
  const goldByEn = new Map((app.VOCAB || []).map(v => [norm(v.en), v]));

  const pC = prov({ fetch: fetchA, status: "source_trusted", note: "Niveau CEFR-J 1.5" });
  const pO = prov({ fetch: fetchB, status: "source_trusted", note: "Niveau Octanove C1/C2 (CC BY-SA 4.0)" });
  const pWN = prov({ fetch: wz.fetch, status: "source_trusted" });
  const pFrAuto = prov({ fetch: oz.fetch, source: "omw_fra", status: "auto", note: "Traduction alignée par sens (WOLF), non relue" });
  const pEsAuto = prov({ fetch: oz.fetch, source: "omw_spa", status: "auto", note: "Traduction alignée par sens (MCR), non relue" });
  const pGold = prov({ source: "wka_editorial", status: "verified", note: "Confirmé par la liste trilingue vérifiée de la maquette" });

  const entries = [];
  for (const [rows, basis, p] of [[a1b2, "cefrj", pC], [c1c2, "octanove", pO]]) for (const r of rows) {
    if (!r.headword || !LV[r.CEFR]) continue;
    const variants = r.headword.split("/").map(s => s.trim()).filter(Boolean);
    const lemma = variants.find(v => /^[a-z][a-z' -]*$/.test(v)) || variants[0];
    entries.push({ lemma, variants, pos: r.pos.trim(), cefr: r.CEFR, basis, p });
  }
  const lexeme = [], sense = [], translation = [], relation = [], lexTheme = [];
  const ids = new Set(); let goldHitFr = 0, goldHitEs = 0, goldTotal = 0, top1Fr = 0, top1Es = 0;
  for (const e of entries) {
    const id = `lex:en:${slug(e.lemma)}:${slug(e.pos)}`;
    if (ids.has(id)) { const prev = lexeme.find(l => l.id === id); if (prev && LV[e.cefr] < LV[prev.cefr]) prev.cefr = e.cefr; continue; } // doublon : on garde le niveau le plus bas
    ids.add(id);
    const p = POS[e.pos];
    const offs = p ? (wn.index.get(e.lemma.toLowerCase() + "|" + p) || []) : [];
    const syns = offs.slice(0, MAX_SENSES).map(o => wn.synsets.get(o)).filter(Boolean);
    const synonyms = new Set(), antonyms = new Set();
    let frMain = null, esMain = null, bestFr = -1, bestEs = -1;
    const wk = WK.map.get(e.lemma); const wE = wk ? wk.entries.filter(x => (WPOS[e.pos] || []).includes(x.pos)) : [];
    const wTr = { fr: wE.flatMap(x => x.tr.filter(t => t.l === "fr")), es: wE.flatMap(x => x.tr.filter(t => t.l === "es")) };
    const wSet = { fr: new Set(wTr.fr.map(t => norm(t.w))), es: new Set(wTr.es.map(t => norm(t.w))) };
    const wkMain = { fr: null, es: null }, gender = { fr: null, es: null }, mainSrc = { fr: null, es: null };
    syns.forEach((s, k) => {
      const sid = `${id}#${k + 1}`;
      const ex = s.examples.find(x => x.toLowerCase().includes(e.lemma.toLowerCase().split(" ")[0].slice(0, 4))) || s.examples[0] || null;
      const th = themeOf(s.id);
      sense.push({ id: sid, lexeme_id: id, synset: "wn30:" + s.id, rank: k + 1, definition_en: s.defn, definition_fr: null, example: ex, example_fr: null, domain: th ? th.theme : null, prov_id: pWN });
      s.words.filter(w => w.toLowerCase() !== e.lemma.toLowerCase()).slice(0, 4).forEach(w => synonyms.add(w));
      for (const pt of s.ptr) if (pt.sym === "!") { const t = wn.synsets.get(pt.target); if (t) { const n = parseInt(pt.st.slice(2), 16); antonyms.add(t.words[(n || 1) - 1] || t.words[0]); } }
      for (const [lang, list, pAuto, fr] of [["fr", omw.fra.get(s.id) || [], pFrAuto, fFr], ["es", omw.spa.get(s.id) || [], pEsAuto, fEs]]) {
        const ranked = [...new Set(list)].map(w => ({ w, r: rank(fr, w.split(" ")[0]) })).sort((a, b) => a.r - b.r).slice(0, MAX_TR);
        let crossed = 0;
        ranked.forEach((t, j) => {
          const x = wSet[lang].has(norm(t.w));
          const conf = x ? Math.round((0.95 - k * 0.05) * 100) / 100 : Math.round(Math.max(0.1, (lang === "fr" ? 0.5 : 0.55) + (t.r < 20000 ? 0.15 : t.r < 50000 ? 0.05 : -0.15) - k * 0.1 - j * 0.05 - (wSet[lang].size ? 0.15 : 0)) * 100) / 100;
          if (x) crossed++;
          translation.push({ sense_id: sid, target_lang: lang, text: t.w, confidence: conf, prov_id: x ? pWkX : pAuto });
          const score = conf * (t.r < 999999 ? 1 : 0.5);
          if (lang === "fr" && score > bestFr) { bestFr = score; frMain = t.w; } if (lang === "es" && score > bestEs) { bestEs = score; esMain = t.w; }
        });
        // Aucun candidat confirmé : on rattache les traductions Wiktionary dont la définition recouvre celle du sens WordNet
        if (!crossed && wTr[lang].length) {
          const groups = new Map(); wTr[lang].forEach(t => (groups.get(t.s || "") || groups.set(t.s || "", []).get(t.s || "")).push(t));
          let best = null, bs = 0; for (const [g, arr] of groups) { const o = overlap(g, s.defn + " " + s.words.join(" ")); if (o > bs) { bs = o; best = arr; } }
          if (best && bs >= 0.34) best.slice(0, 2).forEach((t, j) => { if (!translation.some(x => x.sense_id === sid && x.target_lang === lang && x.text === t.w)) translation.push({ sense_id: sid, target_lang: lang, text: t.w, gender: t.g, confidence: Math.round((0.8 - k * 0.05 - j * 0.05) * 100) / 100, prov_id: pWk }); });
        }
      }
    });
    // Traduction principale : 1) traduction confirmée par deux sources du sens le plus courant ; 2) première traduction Wiktionary ; 3) meilleure traduction alignée
    for (const lang of ["fr", "es"]) {
      const mine = translation.filter(t => t.sense_id.startsWith(id + "#") && t.target_lang === lang);
      const firstGroup = wTr[lang].length ? wTr[lang].filter(t => t.s === wTr[lang][0].s) : [];
      const crossedT = mine.filter(t => t.prov_id === pWkX).sort((a, b) => b.confidence - a.confidence)[0];
      const pick = crossedT ? crossedT.text : firstGroup.length ? firstGroup[0].w : null;
      if (pick) { if (lang === "fr") frMain = pick; else esMain = pick; }
      mainSrc[lang] = crossedT ? "cross" : firstGroup.length ? "wiktionary" : (lang === "fr" ? frMain : esMain) ? "wordnet" : null;
      const gt = wTr[lang].find(t => norm(t.w) === norm(lang === "fr" ? frMain || "" : esMain || "")); gender[lang] = gt ? gt.g : null;
    }
    // Mots grammaticaux absents de WordNet : un sens par sens Wiktionary (traductions groupées par définition)
    if (!syns.length && wE.length) {
      const glosses = [...new Set([...wTr.fr, ...wTr.es].map(t => t.s || ""))].slice(0, MAX_SENSES);
      glosses.forEach((g, k) => { const sid = `${id}#${k + 1}`;
        const wsense = wE.flatMap(x => x.senses).find(x => overlap(x.gloss, g) > 0.3) || wE[0].senses[k] || {};
        sense.push({ id: sid, lexeme_id: id, synset: null, rank: k + 1, definition_en: g || wsense.gloss || null, definition_fr: null, example: (wsense.ex || [])[0] ? wsense.ex[0].t : null, example_fr: null, domain: null, prov_id: pWk });
        for (const lang of ["fr", "es"]) wTr[lang].filter(t => (t.s || "") === g).slice(0, MAX_TR).forEach((t, j) => translation.push({ sense_id: sid, target_lang: lang, text: t.w, gender: t.g, confidence: Math.round((0.8 - k * 0.1 - j * 0.05) * 100) / 100, prov_id: pWk })); });
    }
    if (wE.length) { wE.forEach(x => (x.syn || []).slice(0, 3).forEach(w => synonyms.add(w))); wE.forEach(x => (x.ant || []).slice(0, 3).forEach(w => antonyms.add(w))); }
    const ipas = wE.flatMap(x => x.ipa); const ipaUK = ipas.find(x => x.tags.some(t => /UK|Received-Pronunciation/.test(t))) || ipas.find(x => !x.tags.length);
    // Recoupement avec l'étalon
    const g = goldByEn.get(norm(e.lemma));
    let status = "source_trusted";
    if (g && (!p || POS[{ nom: "noun", verbe: "verb", adjectif: "adjective", adverbe: "adverb" }[g.nat]] === p || !g.nat)) {
      goldTotal++;
      const gFr = norm(stripArticle(g.fr)), gEs = norm(stripArticle(g.es));
      const trFr = translation.filter(t => t.sense_id.startsWith(id + "#") && t.target_lang === "fr");
      const trEs = translation.filter(t => t.sense_id.startsWith(id + "#") && t.target_lang === "es");
      const hFr = trFr.find(t => norm(t.text) === gFr), hEs = trEs.find(t => norm(t.text) === gEs);
      if (hFr) { goldHitFr++; hFr.prov_id = pGold; hFr.confidence = 1; } else if (trFr.length) qa.push({ rule: "translation_gold_miss", severity: "info", target_id: id, message: `FR attendu « ${gFr} », alignement : ${trFr.map(t => t.text).join(", ")}` });
      if (hEs) { goldHitEs++; hEs.prov_id = pGold; hEs.confidence = 1; } else if (trEs.length) qa.push({ rule: "translation_gold_miss", severity: "info", target_id: id, message: `ES attendu « ${gEs} », alignement : ${trEs.map(t => t.text).join(", ")}` });
      if (frMain && norm(frMain) === gFr) top1Fr++; if (esMain && norm(esMain) === gEs) top1Es++;
      frMain = stripArticle(g.fr); esMain = stripArticle(g.es); status = "verified";
    }
    if (!syns.length && p) qa.push({ rule: "not_in_wordnet", severity: "info", target_id: id, message: `${e.lemma} (${e.pos}) absent de WordNet` });
    const th = syns.length ? themeOf(syns[0].id) : null;
    const themeId = th ? th.theme : (POS[e.pos] ? "quotidien" : "grammaire");
    lexTheme.push({ lexeme_id: id, theme_id: "theme:" + themeId, basis: th ? th.basis : "default" });
    if (status !== "verified") { const mainCrossed = ["fr", "es"].every(lang => translation.some(t => t.sense_id.startsWith(id + "#") && t.target_lang === lang && t.prov_id === pWkX && norm(t.text) === norm(lang === "fr" ? frMain || "" : esMain || "")));
      if (mainCrossed) status = "cross_checked"; else if (!frMain || !esMain) status = "needs_review";
      else if (mainSrc.fr === "wordnet" || mainSrc.es === "wordnet") status = "auto"; }
    const ipaV = iEn.map.get(e.lemma.toLowerCase());
    lexeme.push({ id, lang: "en", lemma: e.lemma, variants: e.variants.length > 1 ? e.variants : null, pos: e.pos, pos_fr: POS_FR[e.pos] || e.pos, cefr: e.cefr, cefr_basis: e.basis,
      freq_rank: rank(fEn, e.lemma) < 999999 ? rank(fEn, e.lemma) : null, ipa: ipaV ? ipaV.replace(/^\/|\/$/g, "") : null, ipa_variant: ipaV ? "en-US" : null,
      ipa_uk: ipaUK ? ipaUK.ipa.replace(/^\/|\/$/g, "") : null, gender: null,
      fr: frMain, fr_gender: gender.fr, es: esMain, es_gender: gender.es, theme: themeId, synonyms: [...synonyms].slice(0, 6), antonyms: [...antonyms].slice(0, 4), senses: syns.length,
      status, prov_id: status === "verified" ? pGold : e.p });
  }
  // Relations internes à la base (synonymes/antonymes présents comme entrées)
  const byLemma = new Map(lexeme.map(l => [l.lemma.toLowerCase() + "|" + l.pos, l.id]));
  for (const l of lexeme) { for (const s of l.synonyms) { const t = byLemma.get(s.toLowerCase() + "|" + l.pos); if (t && t !== l.id) relation.push({ a: l.id, b: t, type: "synonym", prov_id: pWN }); }
    for (const s of l.antonyms) { const t = byLemma.get(s.toLowerCase() + "|" + l.pos); if (t && t !== l.id) relation.push({ a: l.id, b: t, type: "antonym", prov_id: pWN }); } }
  // Verbes à particule (phrasal verbs) : WordNet, filtrés par la fréquence d'usage annotée (SemCor) et une base de niveau A1-B1
  const phrasal = buildPhrasal(wn, lexeme, omw, fFr);
  const by = {}; lexeme.forEach(l => by[l.cefr] = (by[l.cefr] || 0) + 1);
  log(`  ${lexeme.length} mots anglais (${Object.entries(by).sort().map(([k, v]) => k + " " + v).join(", ")}), ${sense.length} sens, ${translation.filter(t => t.target_lang === "fr").length} traductions FR, ${translation.filter(t => t.target_lang === "es").length} ES`);
  log(`  phonétique : ${lexeme.filter(l => l.ipa).length} ; sans traduction FR : ${lexeme.filter(l => !l.fr).length} ; étalon : ${goldTotal} mots, FR retrouvé ${goldHitFr}, ES retrouvé ${goldHitEs} ; traduction principale exacte : FR ${top1Fr}, ES ${top1Es} ; Wiktionary : ${WK.map.size} mots`);
  qa.push({ rule: "gold_precision", severity: "info", target_id: "vocab_en", message: `Sur ${goldTotal} mots de l'étalon : traduction vérifiée présente parmi les candidates ${goldHitFr} (FR) / ${goldHitEs} (ES) ; traduction principale exacte ${top1Fr} (FR) / ${top1Es} (ES).` });
  const counts = writeBase("vocab_en", { lexeme, sense, translation, lexical_relation: relation, lexeme_theme: lexTheme, theme: THEME_ROWS, phrasal_verb: phrasal }, { csv: ["lexeme", "phrasal_verb"] });
  return { counts, qa };
}

function buildPhrasal(wn, lexeme, omw, fFr) {
  const base = new Map(lexeme.filter(l => l.pos === "verb").map(l => [l.lemma.toLowerCase(), l]));
  const PART = /^(\w+) (up|down|out|off|on|in|over|away|back|through|around|along|about|after|into|across|forward|apart)$/;
  // index.sense : clé de sens → nombre d'occurrences annotées (fréquence d'usage)
  const fs = require_fs(); const lines = fs.readFileSync(wn.dir + "/index.sense", "utf8").split("\n");
  const cnt = new Map(); for (const l of lines) { const [key, off, num, tag] = l.split(" "); if (!key) continue; const [lem, rest] = key.split("%"); if (rest[0] !== "2") continue; const lemma = lem.replace(/_/g, " ");
    if (!PART.test(lemma)) continue; const k = lemma + "|" + off + "-v"; cnt.set(k, Math.max(cnt.get(k) || 0, +tag)); }
  const out = [];
  for (const [k, n] of cnt) {
    const [lemma, sid] = k.split("|"); const m = PART.exec(lemma); const b = base.get(m[1]);
    if (!b || n < 2 || !["A1", "A2", "B1"].includes(b.cefr)) continue;
    const s = wn.synsets.get(sid); if (!s) continue;
    const fr = (omw.fra.get(sid) || []).map(w => ({ w, r: fFr.rank.get(w.split(" ")[0]) || 999999 })).sort((a, b) => a.r - b.r)[0];
    out.push({ id: `pv:${slug(lemma)}:${sid}`, phrasal: lemma, base_lexeme: b.id, particle: m[2], definition_en: s.defn, example: s.examples[0] || null, fr: fr ? fr.w : null,
      usage_count: n, cefr: n >= 10 ? "B1" : "B2", cefr_basis: "frequency_estimate", status: fr ? "auto" : "needs_review" });
  }
  return out.sort((a, b) => b.usage_count - a.usage_count);
}
import { createRequire } from "node:module";
const require_fs = () => createRequire(import.meta.url)("node:fs");
