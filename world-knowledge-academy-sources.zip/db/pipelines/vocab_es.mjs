// Base 8 : Spanish Vocabulary (A1-C2), dérivée des sens anglais et enrichie par Wiktionary.
import { buildTarget } from "../lib/vocab_target.mjs";
export const build = log => buildTarget("es", log);
