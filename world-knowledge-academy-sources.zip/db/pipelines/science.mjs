// Base 14 : Science — éléments chimiques (Wikidata, recoupés avec la table périodique de Bowserinator et la maquette),
// planètes, unités du Système international (lots rédigés de la maquette).
import { prov, writeBase, norm, getResource, editorialFetch } from "../lib/core.mjs";
import { wikidata } from "../connectors/index.mjs";
import { appData, appFile } from "../lib/app.mjs";

export async function build(log) {
  const qa = [];
  const app = appData();
  const element = [];
  let wd = [], fWD = null;
  try {
    const r = await wikidata("elements", `SELECT ?el ?num ?sym ?fr ?en ?mass ?year WHERE { ?el wdt:P31 wd:Q11344 ; wdt:P1086 ?num ; wdt:P246 ?sym .
      OPTIONAL { ?el rdfs:label ?fr FILTER(LANG(?fr)="fr") } OPTIONAL { ?el rdfs:label ?en FILTER(LANG(?en)="en") }
      OPTIONAL { ?el wdt:P2067 ?mass } OPTIONAL { ?el wdt:P575 ?d . BIND(YEAR(?d) AS ?year) } } ORDER BY ?num`);
    wd = r.rows; fWD = r.fetch;
  } catch (e) { log("  Wikidata injoignable : " + e.message.slice(0, 80)); }
  let ref = null, fRef = null;
  try { const r = await getResource("wikidata", "PeriodicTableJSON.json", [{ url: "https://raw.githubusercontent.com/Bowserinator/Periodic-Table-JSON/master/PeriodicTableJSON.json", via: "mirror" }]); ref = JSON.parse(r.text).elements; fRef = r.fetch; } catch {}
  const appEl = new Map(app.ELEMENTS.map(e => [e[0], e]));
  const byNum = new Map(); for (const b of wd) { const n = +b.num; if (n < 1 || n > 118 || byNum.has(n)) continue; byNum.set(n, b); }
  for (let n = 1; n <= 118; n++) {
    const b = byNum.get(n); const rf = ref && ref.find(x => x.number === n); const a = appEl.get(n);
    if (!b && !rf) continue;
    const sym = b ? b.sym : rf.symbol;
    const checks = [rf ? rf.symbol === sym : null, a ? a[1] === sym : null].filter(x => x !== null);
    const st = checks.length && checks.every(Boolean) ? "cross_checked" : checks.some(x => x === false) ? "conflict" : "source_trusted";
    if (st === "conflict") qa.push({ rule: "element_conflict", severity: "warn", target_id: "el:" + n, message: `Symbole Wikidata ${sym} / table ${rf && rf.symbol} / maquette ${a && a[1]}` });
    element.push({ id: "el:" + n, number: n, symbol: sym, name_fr: a ? a[2] : b && b.fr ? b.fr : null, name_en: b ? b.en : rf.name, category_en: rf ? rf.category : null, category_fr: a ? a[3] : null,
      atomic_mass: rf ? rf.atomic_mass : b && b.mass ? +b.mass : null, phase: rf ? rf.phase : null, discovered_by: rf ? rf.discovered_by : null, year: b && b.year ? +b.year : null,
      note_fr: app.ELEMENT_NOTES[sym] || null, status: st, prov_id: prov({ fetch: fWD || fRef, status: st, note: "Symbole et numéro recoupés : Wikidata, table périodique (Bowserinator, CC BY-SA 3.0)" + (a ? ", maquette" : "") }) });
  }
  const fApp = editorialFetch(appFile("knowledge")); const pApp = prov({ fetch: fApp, status: "editorial", checked_at: "2026-06-30" });
  const planet = app.PLANETS.map(p => ({ id: "planet:" + norm(p[0]).replace(/ /g, "-"), name_fr: p[0], order: p[1], kind: p[2], moons: p[3], fact_fr: p[4], prov_id: pApp }));
  const unit = app.UNITS.map(u => ({ id: "unit:" + u[2], quantity_fr: u[0], name_fr: u[1], symbol: u[2], system: "SI", prov_id: pApp }));
  log(`  éléments : ${element.length} (${element.filter(e => e.name_fr).length} noms français, ${element.filter(e => e.status === "cross_checked").length} recoupés)`);
  return { counts: writeBase("science", { element, planet, unit }, { csv: ["element"] }), qa };
}
