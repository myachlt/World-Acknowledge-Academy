// Base 10 : Grammar — points de grammaire anglais (CEFR-J Grammar Profile), points rédigés FR/EN/ES de la maquette,
// verbes irréguliers anglais (vérifiés contre WordNet) et tableaux de conjugaison espagnols.
import fs from "node:fs";
import path from "node:path";
import { DB, prov, writeBase, readBase, slug, norm, editorialFetch } from "../lib/core.mjs";
import { cefrjGrammar, wordnetZip } from "../connectors/index.mjs";
import { loadWordNet } from "../lib/wordnet.mjs";
import { appData, appFile } from "../lib/app.mjs";

const LV = ["A1", "A2", "B1", "B2", "C1", "C2"];
export async function build(log) {
  const qa = [];
  const app = appData();
  const grammar_point = [], verb_form = [], irregular = [];
  // 1. CEFR-J Grammar Profile (anglais, 501 items ; les notes non traduites du japonais sont écartées)
  const { rows, fetch } = await cefrjGrammar();
  const pG = prov({ fetch, status: "source_trusted", note: "CEFR-J Grammar Profile 20180315 (libellés en anglais)" });
  for (const r of rows) {
    const lvl = (r["CEFR-J Level"] || r["Core Inventory"] || r.EGP || "").match(/[ABC][12]/); if (!r["Grammatical Item"]) continue;
    grammar_point.push({ id: "gram:en:cefrj:" + r.ID, lang: "en", cefr: lvl ? lvl[0] : null, title_fr: null, title_en: r["Grammatical Item"], code: r["Shorthand Code"], sentence_type: r["Sentence Type"] || null, rule_fr: null, examples: null, prov_id: pG });
  }
  // 2. Points de grammaire rédigés (maquette) : un point par sous-thème, avec ses exercices rattachés dans la base de questions
  const fApp = editorialFetch(appFile("lang_en")), fAppEs = editorialFetch(appFile("lang_es"));
  for (const [lang, f] of [["en", fApp], ["es", fAppEs]]) {
    const subs = new Map(); for (const g of app.LANG[lang].grammar) { const k = g.sub; const x = subs.get(k) || { lvl: g.l, n: 0, ex: [] }; x.lvl = Math.min(x.lvl, g.l); x.n++; if (x.ex.length < 2) x.ex.push(g.ex); subs.set(k, x); }
    for (const [sub, x] of subs) grammar_point.push({ id: `gram:${lang}:${slug(sub)}`, lang, cefr: LV[x.lvl - 1], title_fr: sub, title_en: null, code: null, sentence_type: null, rule_fr: x.ex.join(" "), examples: null, exercises: x.n, prov_id: prov({ fetch: f, status: "editorial", checked_at: "2026-06-30" }) });
  }
  // 3. Verbes irréguliers anglais : lot éditorial vérifié forme par forme contre WordNet
  const file = path.join(DB, "editorial/irregular_verbs_en.json"); const ED = JSON.parse(fs.readFileSync(file, "utf8")); const fEd = editorialFetch(file);
  const wz = await wordnetZip(); const wn = loadWordNet(wz.file);
  const appIrr = new Map(app.LANG.en.irregular.map(v => [v[0], v]));
  let ok = 0;
  for (const line of ED.verbs) {
    const [base, past, pp, fr] = line.split("|");
    const known = new Set((wn.exc.verb.get(base) || []).map(x => x.toLowerCase()));
    const forms = [...past.split("/"), ...pp.split("/")].filter(f => f !== base);
    const regular = f => f === base + "ed" || f === base + "d" || f === base.replace(/y$/, "ied");
    const bad = forms.filter(f => !known.has(f) && !regular(f));
    const a = appIrr.get(base); const appOk = !a || (a[1] === past && a[2] === pp);
    if (!appOk) qa.push({ rule: "irregular_app_mismatch", severity: "warn", target_id: base, message: `Maquette ${a[1]}/${a[2]} ≠ lot ${past}/${pp}` });
    if (bad.length) qa.push({ rule: "irregular_form_unconfirmed", severity: "warn", target_id: base, message: `Forme(s) absente(s) de WordNet : ${bad.join(", ")}` }); else ok++;
    const st = bad.length ? "needs_review" : "cross_checked";
    const pid = prov({ fetch: fEd, status: st, checked_at: ED.checked_at, note: bad.length ? null : "Formes confirmées par WordNet 3.0 (verb.exc)" });
    const lid = `lex:en:${slug(base)}:verb`;
    irregular.push({ id: "irr:en:" + base, lexeme_id: lid, base, past, past_participle: pp, fr, status: st, prov_id: pid });
    verb_form.push({ lexeme_id: lid, tense: "past_simple", person: "all", form: past, irregular: 1, prov_id: pid }, { lexeme_id: lid, tense: "past_participle", person: "all", form: pp, irregular: 1, prov_id: pid });
  }
  log(`  verbes irréguliers anglais : ${irregular.length}, dont ${ok} confirmés forme par forme par WordNet`);
  // 4. Conjugaisons espagnoles (maquette)
  const P = ["yo", "tú", "él/ella/usted", "nosotros", "vosotros", "ellos/ellas/ustedes"];
  const pEs = prov({ fetch: fAppEs, status: "editorial", checked_at: "2026-06-30" });
  for (const [inf, fr, kind, tenses] of app.LANG.es.conj) for (const [tense, forms] of Object.entries(tenses)) forms.forEach((f, i) => verb_form.push({ lexeme_id: `lex:es:${slug(inf)}:verb`, tense, person: P[i], form: f, irregular: kind === "irrégulier" ? 1 : 0, prov_id: pEs }));
  // Lien vers le lexème réel (le verbe peut être rangé sous une autre étiquette, ex. « be » = be-verb) ; sinon lexeme_id reste vide
  const LEX = {}; for (const l of ["en", "es"]) { LEX[l] = new Map(); try { for (const x of readBase("vocab_" + l, "lexeme")) { const k = norm(x.lemma); if (!LEX[l].has(k) || /verb/.test(x.pos)) LEX[l].set(k, x.id); } } catch { } }
  const ids = new Set(); for (const l of ["en", "es"]) LEX[l].forEach(v => ids.add(v));
  const resolveLex = (lang, id, lemma) => ids.has(id) ? id : LEX[lang].get(norm(lemma)) || null;
  for (const vf of verb_form) { const [, lang, lemma] = vf.lexeme_id.split(":"); vf.lang = lang; vf.lemma = lemma.replace(/-/g, " "); vf.lexeme_id = resolveLex(lang, vf.lexeme_id, vf.lemma); }
  for (const ir of irregular) ir.lexeme_id = resolveLex("en", ir.lexeme_id, ir.base);
  log(`  formes verbales reliées à un lexème : ${verb_form.filter(v => v.lexeme_id).length}/${verb_form.length}`);
  const counts = writeBase("grammar", { grammar_point, verb_form, irregular_verb: irregular }, { csv: ["irregular_verb"] });
  return { counts, qa };
}
