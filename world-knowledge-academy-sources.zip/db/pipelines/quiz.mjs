// Base 15 : Quiz Database — questions indépendantes, chacune reliée aux connaissances dont elle dépend.
// Trois origines : (1) questions rédigées de la maquette, migrées ; (2) exercices de langue rédigés, migrés ;
// (3) questions générées depuis les bases (gabarits), dont la réponse est CALCULÉE à partir d'une donnée sourcée.
// Toute question passe les règles de lib/qa.mjs. Une donnée source non utilisable (conflit, à revoir, périmée) n'engendre aucune question.
import fs from "node:fs";
import path from "node:path";
import { OUT, prov, provs, readBase, writeBase, norm, slug, TODAY, editorialFetch } from "../lib/core.mjs";
import { appData, appFile } from "../lib/app.mjs";
import { checkQuestion, nearDuplicates, contentKey } from "../lib/qa.mjs";

// Générateur pseudo-aléatoire déterministe (même base → mêmes questions)
const seedOf = s => { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };
const rng = s => { let x = seedOf(s) || 1; return () => ((x = Math.imul(x ^ (x >>> 15), 2246822507) ^ Math.imul(x ^ (x >>> 13), 3266489909), (x ^= x >>> 16) >>> 0) / 4294967296); };
const shuffle = (a, r) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pickN = (arr, n, r, avoid = []) => { const av = new Set(avoid.map(norm)); const out = []; for (const x of shuffle(arr, r)) { if (out.length >= n) break; if (!av.has(norm(x)) && !out.some(o => norm(o) === norm(x))) out.push(x); } return out; };
const fmt = (v, dec = 0) => Number(v).toLocaleString("fr-FR", { maximumFractionDigits: dec, minimumFractionDigits: 0 });
const LV = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6 };

export async function build(log) {
  const qa = [];
  // Provenances déjà écrites + celles créées pendant ce passage (pas encore enregistrées sur disque)
  const FILE_PROV = new Map(JSON.parse(fs.readFileSync(path.join(OUT, "_core/provenance.json"), "utf8")).map(p => [p.id, p]));
  const PROV = { get: id => provs.get(id) || FILE_PROV.get(id), has: id => provs.has(id) || FILE_PROV.has(id) };
  // Une date historique (création d'une organisation) ne se périme pas : provenance dérivée sans date de validité
  const timeless = pid => { const p = PROV.get(pid); return p ? prov({ fetch: { id: p.fetch_id, source_id: p.source_id }, source: p.source_id, status: p.status, checked_at: p.checked_at, note: "Date historique, sans échéance" }) : pid; };
  const usable = pid => { const p = PROV.get(pid); return p && !["needs_review", "conflict", "rejected", "stale"].includes(p.status) && !(p.valid_until && p.valid_until < TODAY); };
  const questions = [], links = [];
  const add = (q, linkIds = []) => {
    const r = rng(q.id);
    if (q.choices && q.format !== "true_false") q.choices = shuffle(q.choices, r);
    q.content_key = contentKey(q.prompt + " " + (q.payload && q.payload.flag ? q.payload.flag : ""), q.answer);
    q.verified_at = q.verified_at || TODAY;
    questions.push(q); linkIds.filter(Boolean).forEach(t => links.push({ question_id: q.id, target_id: t, role: t.split(":")[0] }));
  };
  const app = appData();
  const countries = readBase("countries", "country"); const C = new Map(countries.map(c => [c.id, c]));
  const sov = countries.filter(c => c.kind === "sovereign");
  const borders = readBase("countries", "country_border");
  const nb = new Map(); borders.forEach(b => { (nb.get(b.a) || nb.set(b.a, new Set()).get(b.a)).add(b.b); (nb.get(b.b) || nb.set(b.b, new Set()).get(b.b)).add(b.a); });
  const curRows = readBase("countries", "currency"), cc = readBase("countries", "country_currency"); const CUR = new Map(curRows.map(x => [x.id, x]));
  const tier = new Map(app.countries.map(c => [c.iso, c.tier]));
  const diffOf = c => tier.get(c.iso2) || (c.un_member ? 4 : 5);
  const sameCont = c => sov.filter(x => x.continent === c.continent && x.id !== c.id);

  // ---------- 1. Questions rédigées de la maquette ----------
  const cards = [...readBase("practical", "knowledge_card"), ...readBase("professional", "knowledge_card")];
  const fBank = editorialFetch(appFile("bank"));
  for (const [i, b] of app.bank.entries()) {
    const id = `q:${b.cat}:ed:${slug(b.q).slice(0, 48)}`;
    const p = prov({ fetch: fBank, status: "editorial", checked_at: b.asOf ? b.asOf + "-30" : "2026-06-30", valid_until: b.nature === "contemp" ? "2027-06-30" : null, note: b.src || null });
    const L = []; const txt = norm(b.q + " " + b.a);
    for (const c of sov) if (c.name_fr.length > 4 && txt.includes(norm(c.name_fr))) L.push(c.id);
    for (const k of cards) if ((k.keywords || []).some(w => txt.includes(norm(w)))) L.push(k.id);
    add({ id, category: b.cat, subcategory: b.sub, difficulty: b.d, format: "mcq", prompt: b.q, payload: b.doc ? { doc: b.doc } : null, choices: [b.a, ...b.w], answer: b.a,
      explanation: b.ex, anecdote: b.info || null, context: b.ctx || null, keywords: null, generator: null, nature: b.nature, source_text: b.src || null, prov_id: p }, L);
  }
  // ---------- 2. Exercices de langue rédigés ----------
  for (const lang of ["en", "es"]) {
    const Lx = app.LANG[lang]; const f = editorialFetch(appFile("lang_" + lang)); const p = prov({ fetch: f, status: "editorial", checked_at: "2026-06-30" });
    Lx.grammar.forEach(g => add({ id: `q:${lang}:gram:${slug(g.q).slice(0, 50)}`, category: lang, subcategory: "Grammaire · " + g.sub, difficulty: g.l, format: "mcq", prompt: g.q, choices: [g.a, ...g.w], answer: g.a, explanation: g.ex, generator: null, prov_id: p }, [`gram:${lang}:${slug(g.sub)}`]));
    Lx.translations.forEach(t => add({ id: `q:${lang}:tr:${slug(t.fr).slice(0, 50)}`, category: lang, subcategory: "Traduction", difficulty: t.l, format: "translation", prompt: t.fr, choices: null, answer: t.accept[0], payload: { accept: t.accept }, explanation: "Traductions acceptées : " + t.accept.join(" / "), generator: null, prov_id: p }));
    Lx.corrections.forEach(t => add({ id: `q:${lang}:corr:${slug(t.wrong).slice(0, 50)}`, category: lang, subcategory: "Correction d'erreurs", difficulty: t.l, format: "input", prompt: t.wrong, answer: t.accept[0], payload: { accept: t.accept }, explanation: t.note || "Phrase corrigée : " + t.accept[0], generator: null, prov_id: p }));
    Lx.wordFormation.forEach(t => add({ id: `q:${lang}:wf:${slug(t.s).slice(0, 50)}`, category: lang, subcategory: "Formation des mots", difficulty: t.l, format: "cloze", prompt: t.s, answer: t.accept[0], payload: { stem: t.stem, accept: t.accept }, explanation: `À partir de ${t.stem} : ${t.accept.join(" / ")}`, generator: null, prov_id: p }));
    Lx.cloze.forEach(t => add({ id: `q:${lang}:cloze:${slug(t.title)}`, category: lang, subcategory: "Texte à trous", difficulty: t.l, format: "cloze", prompt: t.title, answer: (t.text.match(/\{\{([^|}]+)/g) || []).map(x => x.slice(2)), payload: { text: t.text }, explanation: "La première proposition de chaque trou est la bonne réponse.", generator: null, prov_id: p }));
    Lx.reading.forEach(t => add({ id: `q:${lang}:read:${slug(t.title)}`, category: lang, subcategory: "Compréhension écrite", difficulty: t.l, format: "reading", prompt: t.title, answer: t.qs.map(x => x[1]), payload: { text: t.text, genre: t.genre, questions: t.qs }, explanation: "Réponses : " + t.qs.map(x => x[1]).join(" ; "), generator: null, prov_id: p }));
    Lx.listening.forEach(t => add({ id: `q:${lang}:listen:${slug(t.title)}`, category: lang, subcategory: "Compréhension orale", difficulty: t.l, format: "listening", prompt: t.title, answer: t.qs.map(x => x[1]), payload: { lines: t.lines, questions: t.qs }, explanation: "Réponses : " + t.qs.map(x => x[1]).join(" ; "), generator: null, prov_id: p }));
  }
  // Situations (mises en situation)
  const fSit = editorialFetch(appFile("situations"));
  for (const s of app.SITUATIONS) (s.steps || []).forEach((st, i) => { if (!st.q || !st.a) return; add({ id: `q:${s.domain}:sit:${s.id}:${i + 1}`, category: s.domain, subcategory: "Situation · " + s.title, difficulty: s.lvl, format: "situation", prompt: st.q, payload: { situation: s.id, context: i === 0 ? s.context : null, doc: st.doc || (i === 0 ? s.doc : null) || null }, choices: [st.a, ...(st.w || [])], answer: st.a, explanation: st.ex || "", generator: null, prov_id: prov({ fetch: fSit, status: "editorial", checked_at: (s.asOf || "2026-06") + "-30" }) }, [`res:situation:${s.id}`]); });

  // ---------- 3. Questions générées depuis les bases ----------
  const gen = {};
  const genIds = new Set();
  const G = (name, q, L) => { if (genIds.has(q.id)) return; genIds.add(q.id); gen[name] = (gen[name] || 0) + 1; add(Object.assign({ generator: name }, q), L); };
  // 3a. Capitales (pays et inverse) — seulement si la capitale est recoupée
  for (const c of sov) {
    if (!usable(c.prov_id) || !c.capital_name || PROV.get(c.prov_id).status !== "cross_checked") continue;
    const r = rng("cap" + c.id); const others = sameCont(c).filter(x => x.capital_name && PROV.get(x.prov_id).status === "cross_checked");
    if (others.length < 3) continue;
    G("capital", { id: `q:geo:cap:${c.iso3}`, category: "geo", subcategory: "Capitales", difficulty: diffOf(c), format: "mcq", prompt: `Quelle est la capitale ${app.countries.find(a => a.iso === c.iso2) ? app.countries.find(a => a.iso === c.iso2).du : "de " + c.name_fr} ?`,
      choices: [c.capital_name, ...pickN(others.map(x => x.capital_name), 3, r, [c.capital_name])], answer: c.capital_name, explanation: `${c.capital_name} est la capitale de ${c.name_fr}.` + (PROV.get(c.prov_id).note ? " " + PROV.get(c.prov_id).note : ""), nature: "geo", prov_id: c.prov_id }, [c.id]);
    G("capital_rev", { id: `q:geo:caprev:${c.iso3}`, category: "geo", subcategory: "Capitales", difficulty: Math.min(6, diffOf(c) + 1), format: "mcq", prompt: `${c.capital_name} est la capitale de quel pays ?`,
      choices: [c.name_fr, ...pickN(others.map(x => x.name_fr), 3, r, [c.name_fr])], answer: c.name_fr, explanation: `${c.capital_name} est la capitale de ${c.name_fr} (${{ EU: "Europe", AS: "Asie", AF: "Afrique", NA: "Amérique du Nord", SA: "Amérique du Sud", OC: "Océanie" }[c.continent] || c.region}).`, nature: "geo", prov_id: c.prov_id }, [c.id]);
  }
  // 3b. Drapeaux (identification visuelle)
  for (const c of sov) { if (!c.flag_emoji) continue; const r = rng("flag" + c.id); const pool = [...(nb.get(c.id) || [])].map(i => C.get(i)).filter(x => x && x.kind === "sovereign").concat(sameCont(c));
    G("flag", { id: `q:geo:flag:${c.iso3}`, category: "geo", subcategory: "Drapeaux", difficulty: diffOf(c), format: "visual", prompt: "À quel pays appartient ce drapeau ?", payload: { flag: c.flag_emoji, iso2: c.iso2 },
      choices: [c.name_fr, ...pickN(pool.map(x => x.name_fr), 3, r, [c.name_fr])], answer: c.name_fr, explanation: `C'est le drapeau de ${c.name_fr}.`, nature: "geo", prov_id: c.prov_id }, [c.id]); }
  // 3c. Monnaies
  for (const c of sov) { const cur = cc.filter(x => x.country_id === c.id).map(x => CUR.get(x.currency_id)).filter(x => x && x.name_fr); if (cur.length !== 1 || !usable(cc.find(x => x.country_id === c.id).prov_id)) continue;
    const r = rng("cur" + c.id); const others = [...new Set(sameCont(c).flatMap(x => cc.filter(y => y.country_id === x.id).map(y => (CUR.get(y.currency_id) || {}).name_fr)).filter(Boolean))];
    if (others.length < 3) continue;
    G("currency", { id: `q:eco:cur:${c.iso3}`, category: "eco", subcategory: "Monnaies", difficulty: Math.min(6, diffOf(c) + 1), format: "mcq", prompt: `Quelle est la monnaie officielle de ${c.name_fr} ?`, choices: [cur[0].name_fr, ...pickN(others, 3, r, [cur[0].name_fr])], answer: cur[0].name_fr,
      explanation: `La monnaie de ${c.name_fr} est ${cur[0].name_fr} (code ISO ${cur[0].code}).`, nature: "contemp", prov_id: cc.find(x => x.country_id === c.id).prov_id }, [c.id, cur[0].id]); }
  // 3d. Frontières
  for (const c of sov) { const N = [...(nb.get(c.id) || [])].map(i => C.get(i)).filter(x => x && x.kind === "sovereign"); if (!N.length) continue; const r = rng("nb" + c.id);
    const ans = N[Math.floor(r() * N.length)]; const non = sameCont(c).filter(x => !(nb.get(c.id) || new Set()).has(x.id)); if (non.length < 3) continue;
    G("border", { id: `q:geo:border:${c.iso3}`, category: "geo", subcategory: "Frontières", difficulty: Math.min(6, diffOf(c) + 1), format: "mcq", prompt: `Lequel de ces pays a une frontière terrestre commune avec ${c.name_fr} ?`, choices: [ans.name_fr, ...pickN(non.map(x => x.name_fr), 3, r, [ans.name_fr])], answer: ans.name_fr,
      explanation: `Voisins terrestres de ${c.name_fr} : ${N.map(x => x.name_fr).join(", ")}.`, nature: "geo", prov_id: borders.find(b => (b.a === c.id && b.b === ans.id) || (b.b === c.id && b.a === ans.id)).prov_id }, [c.id, ans.id]); }
  // 3e. Pays enclavés (vrai/faux)
  for (const c of sov.filter(x => x.landlocked || (nb.get(x.id) || new Set()).size >= 3)) { if (diffOf(c) > 4) continue;
    G("landlocked", { id: `q:geo:landlocked:${c.iso3}`, category: "geo", subcategory: "Géographie physique", difficulty: 3, format: "true_false", prompt: `Vrai ou faux : ${c.name_fr} n'a aucun accès à la mer.`, choices: ["Vrai", "Faux"], answer: c.landlocked ? "Vrai" : "Faux",
      explanation: c.landlocked ? `${c.name_fr} est un pays enclavé, sans littoral.` : `${c.name_fr} possède un littoral.`, nature: "geo", prov_id: c.prov_id }, [c.id]); }
  // 3f. Sommets : pays du sommet (altitude recoupée)
  const feats = readBase("geography", "geo_feature"), fc = readBase("geography", "feature_country");
  const fcBy = new Map(); fc.forEach(x => (fcBy.get(x.feature_id) || fcBy.set(x.feature_id, []).get(x.feature_id)).push(x.country_id));
  for (const f of feats.filter(f => f.type === "peak" && f.elevation_m >= 2500 && f.name_fr && PROV.get(f.prov_id) && PROV.get(f.prov_id).status === "cross_checked")) {
    const cs = (fcBy.get(f.id) || []).map(i => C.get(i)).filter(Boolean); if (cs.length !== 1 || cs[0].kind !== "sovereign") continue; const c = cs[0]; const r = rng(f.id);
    const pool = [...(nb.get(c.id) || [])].map(i => C.get(i)).filter(x => x && x.kind === "sovereign").concat(sameCont(c)); if (pool.length < 3) continue;
    G("peak_country", { id: `q:geo:peak:${slug(f.name_en)}`, category: "geo", subcategory: "Montagnes", difficulty: f.elevation_m > 6000 ? 3 : 5, format: "mcq", prompt: `Dans quel pays se trouve le sommet ${f.name_fr} (${fmt(f.elevation_m)} m) ?`, choices: [c.name_fr, ...pickN(pool.map(x => x.name_fr), 3, r, [c.name_fr])], answer: c.name_fr,
      explanation: `${f.name_fr} culmine à ${fmt(f.elevation_m)} m et se situe en ${c.name_fr}.`, nature: "geo", prov_id: f.prov_id }, [f.id, c.id]); }
  // 3g. Fleuves : le plus long parmi quatre (longueur unique et existence recoupée, écart ≥ 15 %)
  const rivers = feats.filter(f => f.type === "river" && f.length_km && f.name_fr && PROV.get(f.prov_id) && PROV.get(f.prov_id).status === "cross_checked").sort((a, b) => b.length_km - a.length_km);
  for (let i = 0; i < rivers.length; i++) { const r = rng("riv" + i); const a = rivers[i]; const cand = rivers.filter(x => x.length_km <= a.length_km / 1.15); if (cand.length < 3) continue; const ds = pickN(cand.map(x => x.name_fr), 3, r);
    const all = [a, ...ds.map(n => rivers.find(x => x.name_fr === n))];
    G("river_longest", { id: `q:geo:river:${slug(a.name_en)}`, category: "geo", subcategory: "Fleuves", difficulty: 4, format: "mcq", prompt: "Lequel de ces cours d'eau est le plus long ?", choices: all.map(x => x.name_fr), answer: a.name_fr,
      explanation: all.map(x => `${x.name_fr} : ${fmt(x.length_km)} km`).join(" ; ") + ". Longueurs déclarées dans Wikidata : la mesure d'un fleuve varie selon la source retenue.", nature: "geo", prov_id: a.prov_id }, all.map(x => x.id)); }
  // 3h. Statistiques comparées (l'année de référence figure toujours dans la question)
  const obs = readBase("stats", "observation"), inds = readBase("stats", "indicator"); const IND = new Map(inds.map(i => [i.id, i]));
  const STATQ = [["ind:SP.POP.TOTL", "la population la plus nombreuse", 1.3, "ratio", "geo"], ["ind:NY.GDP.PCAP.CD", "le PIB par habitant le plus élevé", 1.3, "ratio", "eco"], ["ind:SP.DYN.LE00.IN", "l'espérance de vie la plus longue", 3, "diff", "env"],
    ["ind:IT.NET.USER.ZS", "la plus forte proportion d'utilisateurs d'Internet", 10, "diff", "eco"], ["ind:AG.LND.FRST.ZS", "la plus forte proportion de forêts", 10, "diff", "env"], ["ind:CO2_PC", "les émissions de CO2 par habitant les plus élevées", 1.4, "ratio", "env"],
    ["ind:HDI", "l'indice de développement humain le plus élevé", 0.05, "diff", "eco"], ["ind:SP.URB.TOTL.IN.ZS", "la plus forte proportion de population urbaine", 10, "diff", "geo"], ["ind:SP.DYN.TFRT.IN", "l'indice de fécondité le plus élevé", 0.5, "diff", "geo"]];
  for (const [ind, label, gap, mode, cat] of STATQ) {
    const I = IND.get(ind); const rows = obs.filter(o => o.indicator_id === ind && o.entity_id.startsWith("cty:") && C.get(o.entity_id) && C.get(o.entity_id).kind === "sovereign");
    const years = {}; rows.forEach(o => years[o.year] = (years[o.year] || 0) + 1);
    const year = +Object.entries(years).filter(([, n]) => n >= 120).map(([y]) => y).sort().pop(); if (!year) continue;
    const at = rows.filter(o => o.year === year && tier.get(C.get(o.entity_id).iso2) <= 3);
    const ok = (a, b) => mode === "ratio" ? a >= b * gap : a - b >= gap;
    for (let k = 0; k < 40; k++) {
      const r = rng(ind + k); const pick = shuffle(at, r).slice(0, 4); if (pick.length < 4) break; pick.sort((a, b) => b.value - a.value);
      if (!ok(pick[0].value, pick[1].value)) continue;
      const names = pick.map(o => C.get(o.entity_id).name_fr); const src = I.source_id === "worldbank" ? "la Banque mondiale" : I.source_id === "undp_hdr" ? "le PNUD" : "Our World in Data";
      G("stat_compare", { id: `q:${cat}:stat:${ind.slice(4)}:${pick.map(o => o.entity_id.slice(4)).sort().join("-")}`, category: cat, subcategory: "Statistiques mondiales", difficulty: 4, format: "mcq",
        prompt: `Selon ${src}, lequel de ces pays avait ${label} en ${year} ?`, choices: names, answer: names[0],
        explanation: pick.map(o => `${C.get(o.entity_id).name_fr} : ${fmt(o.value, I.decimals)} ${I.unit}`).join(" ; ") + ` (${year}).`, nature: "contemp", payload: { year, indicator: ind }, prov_id: pick[0].prov_id },
        [...pick.map(o => o.entity_id), ind]);
    }
  }
  // 3i. Organisations : adhésions recoupées, sièges, dates de création
  const orgs = readBase("organizations", "organization"), mem = readBase("organizations", "membership");
  for (const o of orgs) {
    const M = mem.filter(m => m.org_id === o.id && m.status === "member"); const Mset = new Set(M.map(m => m.country_id)); const r = rng(o.id);
    const crossed = M.filter(m => PROV.get(m.prov_id) && PROV.get(m.prov_id).status === "cross_checked" && usable(m.prov_id));
    if (Mset.size && Mset.size < 120) for (const m of shuffle(crossed, r).slice(0, 12)) {
      const c = C.get(m.country_id); const non = sov.filter(x => !Mset.has(x.id) && (x.continent === c.continent || r() < 0.2)); if (non.length < 3) continue;
      G("org_member", { id: `q:pol:member:${o.id.slice(4)}:${c.iso3}`, category: "pol", subcategory: "Organisations internationales", difficulty: 3, format: "mcq", prompt: `Lequel de ces pays est membre de l'organisation ${o.acronym_fr === o.name_fr ? o.name_fr : o.acronym_fr + " (" + o.name_fr + ")"} ?`,
        choices: [c.name_fr, ...pickN(non.map(x => x.name_fr), 3, r, [c.name_fr])], answer: c.name_fr, explanation: `${c.name_fr} fait partie des ${Mset.size} membres de l'organisation (état vérifié le ${PROV.get(m.prov_id).checked_at}).` + (o.note_fr ? " " + o.note_fr : ""), nature: "contemp", prov_id: m.prov_id }, [o.id, c.id]);
    }
    if (o.hq_city && usable(o.prov_id)) { const others = [...new Set(orgs.filter(x => x.hq_city && x.hq_city !== o.hq_city).map(x => x.hq_city.split(" (")[0]))];
      G("org_hq", { id: `q:pol:hq:${o.id.slice(4)}`, category: "pol", subcategory: "Organisations internationales", difficulty: 3, format: "mcq", prompt: `Dans quelle ville se trouve le siège de l'organisation ${o.acronym_fr === o.name_fr ? o.name_fr : o.acronym_fr + " (" + o.name_fr + ")"} ?`, choices: [o.hq_city.split(" (")[0], ...pickN(others, 3, r, [o.hq_city.split(" (")[0]])], answer: o.hq_city.split(" (")[0], explanation: `${o.name_fr} : siège à ${o.hq_city}. ${o.mission_fr}`, nature: "pol", prov_id: o.prov_id }, [o.id]); }
    if (o.founded) G("org_founded", { id: `q:hist:founded:${o.id.slice(4)}`, category: "hist", subcategory: "Organisations internationales", difficulty: 4, format: "mcq", prompt: `En quelle année a été créée l'organisation ${o.acronym_fr === o.name_fr ? o.name_fr : o.acronym_fr + " (" + o.name_fr + ")"} ?`,
      choices: [String(o.founded), ...pickN([o.founded - 12, o.founded - 6, o.founded + 5, o.founded + 11, o.founded + 17].filter(y => y <= 2026).map(String), 3, r)], answer: String(o.founded), explanation: `${o.name_fr} a été créée en ${o.founded}. ${o.mission_fr}`, nature: "hist", prov_id: timeless(o.prov_id) }, [o.id]);
  }
  // 3j. Chefs d'État (seulement recoupés et non périmés)
  for (const p of readBase("politics", "country_politics")) { if (!p.head_of_state || !usable(p.prov_id) || PROV.get(p.prov_id).status !== "cross_checked") continue; const c = C.get(p.country_id); const r = rng("hos" + c.id);
    const others = readBase("politics", "country_politics").filter(x => x.head_of_state && x.country_id !== c.id && !/;/.test(x.head_of_state)).map(x => x.head_of_state);
    G("head_of_state", { id: `q:pol:hos:${c.iso3}`, category: "pol", subcategory: "Dirigeants", difficulty: diffOf(c), format: "mcq", prompt: `Qui est le chef de l'État de ${c.name_fr} ?`, choices: [p.head_of_state, ...pickN(others, 3, r, [p.head_of_state])], answer: p.head_of_state,
      explanation: `${p.head_of_state} est chef de l'État de ${c.name_fr}${p.head_of_state_since ? " depuis le " + p.head_of_state_since : ""} (état vérifié le ${PROV.get(p.prov_id).checked_at}, à revérifier après le ${PROV.get(p.prov_id).valid_until}).`, nature: "contemp", prov_id: p.prov_id }, [c.id]); }
  // 3k. Histoire : titulaires d'une fonction à une date donnée
  const terms = readBase("history", "office_term"), persons = new Map(readBase("history", "person").map(p => [p.id, p]));
  for (const office of [...new Set(terms.map(t => t.office))]) {
    const T = terms.filter(t => t.office === office && /^\d{4}-/.test(t.start) && /^\d{4}-/.test(t.end || "") && t.start >= "1900" && persons.get(t.person_id) && persons.get(t.person_id).name && !/^Q\d+$/.test(persons.get(t.person_id).name)); const names = [...new Set(T.map(t => persons.get(t.person_id).name))];
    for (const t of T) { const y0 = +t.start.slice(0, 4) + 1, y1 = +t.end.slice(0, 4) - 1; if (y1 < y0) continue; const y = y0 + Math.floor((y1 - y0) / 2); const nm = persons.get(t.person_id).name;
      if (T.some(o => o !== t && o.start <= `${y}-06-30` && (o.end || "9999") >= `${y}-06-30` && persons.get(o.person_id).name !== nm)) continue; // chevauchement : question ambiguë
      const r = rng(office + t.start);
      G("office_holder", { id: `q:hist:office:${slug(office)}:${y}`, category: "hist", subcategory: "Dirigeants et fonctions", difficulty: 4, format: "mcq", prompt: `Qui occupait la fonction de ${office.charAt(0).toLowerCase() + office.slice(1)} au 30 juin ${y} ?`,
        choices: [nm, ...pickN(names, 3, r, [nm])], answer: nm, explanation: `${nm} a exercé cette fonction du ${t.start} au ${t.end}.`, nature: "hist", prov_id: t.prov_id }, [t.person_id]); }
  }
  const awards = readBase("history", "award"); const byYear = new Map(); awards.forEach(a => (byYear.get(a.year) || byYear.set(a.year, []).get(a.year)).push(a));
  for (const [y, arr] of byYear) { if (arr.length !== 1 || y < 1945) continue; const a = arr[0]; const r = rng("nobel" + y); const others = awards.filter(x => Math.abs(x.year - y) > 2 && Math.abs(x.year - y) < 30).map(x => x.laureate);
    G("nobel_peace", { id: `q:hist:nobel:${y}`, category: "hist", subcategory: "Prix Nobel de la paix", difficulty: 5, format: "mcq", prompt: `Qui a reçu le prix Nobel de la paix en ${y} ?`, choices: [a.laureate, ...pickN(others, 3, r, [a.laureate])], answer: a.laureate, explanation: `${a.laureate} : prix Nobel de la paix ${y}.`, nature: "hist", prov_id: a.prov_id }, [a.laureate_id]); }
  // 3l. Sciences : symboles chimiques
  const els = readBase("science", "element").filter(e => e.name_fr && e.status === "cross_checked");
  for (const e of els) { const r = rng(e.id); const d = e.number <= 30 ? 2 : e.number <= 56 ? 4 : 6;
    G("element_symbol", { id: `q:sci:sym:${e.symbol}`, category: "sci", subcategory: "Chimie", difficulty: d, format: "mcq", prompt: `Quel est le symbole chimique de l'élément « ${e.name_fr} » ?`, choices: [e.symbol, ...pickN(els.filter(x => x.symbol[0] === e.symbol[0] || Math.abs(x.number - e.number) < 6).map(x => x.symbol), 3, r, [e.symbol])], answer: e.symbol,
      explanation: `${e.name_fr[0].toUpperCase() + e.name_fr.slice(1)} : symbole ${e.symbol}, numéro atomique ${e.number}.` + (e.note_fr ? " " + e.note_fr : ""), nature: "sci", prov_id: e.prov_id }, [e.id]);
    G("element_name", { id: `q:sci:name:${e.symbol}`, category: "sci", subcategory: "Chimie", difficulty: Math.min(6, d + 1), format: "mcq", prompt: `Quel élément chimique a pour symbole ${e.symbol} ?`, choices: [e.name_fr, ...pickN(els.filter(x => Math.abs(x.number - e.number) < 10).map(x => x.name_fr), 3, r, [e.name_fr])], answer: e.name_fr,
      explanation: `${e.symbol} est le symbole de l'élément ${e.name_fr} (numéro atomique ${e.number}).`, nature: "sci", prov_id: e.prov_id }, [e.id]); }
  // 3m. Vocabulaire : traductions confirmées (étalon ou deux sources)
  for (const [lang, file] of [["en", "vocab_en"], ["es", "vocab_es"]]) {
    const lex = readBase(file, "lexeme").filter(l => ["verified", "cross_checked"].includes(l.status) && l.fr && l.lemma.length > 1);
    const byKey = new Map(); lex.forEach(l => { const k = l.pos + "|" + l.theme; (byKey.get(k) || byKey.set(k, []).get(k)).push(l); });
    const name = lang === "en" ? "anglais" : "espagnol";
    for (const l of lex) {
      const r = rng(l.id); const pool = (byKey.get(l.pos + "|" + l.theme) || []).filter(x => x.id !== l.id && Math.abs(LV[x.cefr] - LV[l.cefr]) <= 1 && norm(x.fr) !== norm(l.fr));
      const pool2 = pool.length >= 3 ? pool : lex.filter(x => x.pos === l.pos && x.id !== l.id && norm(x.fr) !== norm(l.fr));
      const ds = pickN(pool2.map(x => x.fr), 3, r, [l.fr]); if (ds.length < 3) continue;
      G("vocab_to_fr", { id: `q:${lang}:voc:${slug(l.lemma)}:${slug(l.pos)}`, category: lang, subcategory: "Vocabulaire · " + l.theme, difficulty: LV[l.cefr], format: "mcq", prompt: `Que signifie le mot ${name} « ${l.lemma} » (${l.pos_fr}) ?`, choices: [l.fr, ...ds], answer: l.fr,
        explanation: `« ${l.lemma} »${l.ipa ? " /" + l.ipa + "/" : ""} = ${l.fr}.` + (l.example ? ` Exemple : « ${l.example} »` : "") + (lang === "en" && l.es ? ` En espagnol : ${l.es}.` : ""), nature: "lang", prov_id: l.prov_id }, [l.id]);
    }
  }
  // ---------- Validation ----------
  const accepted = [], rejected = [];
  const seenKey = new Map();
  for (const q of questions) {
    const issues = checkQuestion(q, { provs: PROV });
    if (seenKey.has(q.content_key)) issues.push({ rule: "duplicate", severity: "error", message: "Doublon exact de " + seenKey.get(q.content_key) });
    if (issues.some(i => i.severity === "error")) { rejected.push({ id: q.id, generator: q.generator, issues }); continue; }
    seenKey.set(q.content_key, q.id);
    issues.forEach(i => qa.push({ rule: "question_" + i.rule, severity: i.severity, target_id: q.id, message: i.message }));
    q.status = PROV.get(q.prov_id) ? PROV.get(q.prov_id).status : "editorial"; accepted.push(q);
  }
  const near = nearDuplicates(accepted); near.forEach(n => qa.push({ rule: "near_duplicate", severity: "info", target_id: n.a, message: `Proche de ${n.b} (Jaccard ${n.jaccard})` }));
  const acceptedIds = new Set(accepted.map(q => q.id));
  const rej = {}; rejected.forEach(r => r.issues.filter(i => i.severity === "error").forEach(i => rej[i.rule] = (rej[i.rule] || 0) + 1));
  log(`  ${accepted.length} questions acceptées, ${rejected.length} rejetées (${Object.entries(rej).map(([k, v]) => k + " " + v).join(", ")})`);
  log("  générées : " + Object.entries(gen).map(([k, v]) => k + " " + v).join(" · "));
  fs.mkdirSync(path.join(OUT, "_quality"), { recursive: true }); fs.writeFileSync(path.join(OUT, "_quality/quiz_rejected.json"), JSON.stringify(rejected, null, 1));
  const by = {}; accepted.forEach(q => by[q.category] = (by[q.category] || 0) + 1);
  log("  par catégorie : " + Object.entries(by).map(([k, v]) => k + " " + v).join(" · "));
  return { counts: writeBase("quiz", { question: accepted, question_link: links.filter(l => acceptedIds.has(l.question_id)) }), qa };
}
