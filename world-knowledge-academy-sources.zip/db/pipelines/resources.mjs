// Base 16 : Learning Resources — fiches de cours, profils de pays, mises en situation, ressources naturelles,
// et parcours (une ressource par fiche pratique). Chaque ressource est reliée aux connaissances qu'elle couvre
// (pays, fiches, organisations…) et aux questions de la base Quiz qui portent sur les mêmes connaissances.
import { prov, readBase, writeBase, editorialFetch, norm } from "../lib/core.mjs";
import { appData, appFile } from "../lib/app.mjs";

const MAX_Q = 40; // questions reliées au plus par ressource

export async function build(log) {
  const qa = [];
  const app = appData();
  const countries = readBase("countries", "country"); const byIso2 = new Map(countries.map(c => [c.iso2, c]));
  const sov = countries.filter(c => c.kind === "sovereign");
  const cards = [...readBase("practical", "knowledge_card"), ...readBase("professional", "knowledge_card")];
  const orgs = readBase("organizations", "organization");
  const qlinks = readBase("quiz", "question_link"); const questions = readBase("quiz", "question");
  const qByTarget = new Map(); qlinks.forEach(l => (qByTarget.get(l.target_id) || qByTarget.set(l.target_id, []).get(l.target_id)).push(l.question_id));
  const qBySub = new Map(); questions.forEach(q => (qBySub.get(q.subcategory) || qBySub.set(q.subcategory, []).get(q.subcategory)).push(q.id));

  const resource = [], link = [];
  const add = (r, targets) => {
    resource.push(r); const T = [...new Set(targets.filter(Boolean))];
    T.forEach(t => link.push({ resource_id: r.id, target_id: t, role: t.split(":")[0] }));
    const qs = new Set(); for (const t of T) for (const q of qByTarget.get(t) || []) { if (qs.size >= MAX_Q) break; qs.add(q); }
    qs.forEach(q => link.push({ resource_id: r.id, target_id: q, role: "q" }));
    if (!T.length) qa.push({ rule: "resource_unlinked", severity: "warn", target_id: r.id, message: "Ressource reliée à aucune connaissance" });
  };
  const mentions = txt => { const t = norm(txt); const out = [];
    for (const c of sov) if (c.name_fr.length > 4 && t.includes(norm(c.name_fr))) out.push(c.id);
    for (const o of orgs) if (o.acronym_fr && o.acronym_fr.length > 2 && new RegExp("\\b" + norm(o.acronym_fr) + "\\b").test(t)) out.push(o.id);
    return out; };

  // 1. Fiches de cours rédigées (maquette)
  const pW = prov({ fetch: editorialFetch(appFile("world")), status: "editorial", checked_at: "2026-06-30" });
  for (const s of app.SHEETS) add({ id: "res:fiche:" + s.id, kind: "fiche", title_fr: s.title, level: null, base: s.type === "Événement" ? "history" : s.type === "Organisation" ? "organizations" : "general",
    body: s.body, tags: s.tags || [], prov_id: pW }, mentions(s.title + " " + s.body));

  // 2. Profils de pays (histoire, économie, culture) et ressources naturelles
  const pC = prov({ fetch: editorialFetch(appFile("countries_plus")), status: "editorial", checked_at: "2026-06-30" });
  for (const [iso2, p] of Object.entries(app.PROFILES)) { const c = byIso2.get(iso2);
    if (!c) { qa.push({ rule: "resource_country_unknown", severity: "error", target_id: "res:profil:" + iso2, message: "Code pays inconnu " + iso2 }); continue; }
    const body = [["Histoire", p.hist], ["Économie", p.eco], ["Culture", p.cult]].filter(x => x[1]).map(([h, t]) => `${h} : ${t}`).join("\n\n");
    add({ id: "res:profil:" + c.iso3, kind: "profil_pays", title_fr: "Profil : " + c.name_fr, level: null, base: "countries", body, tags: ["Pays", c.continent], prov_id: pC }, [c.id]); }
  for (const [iso2, txt] of Object.entries(app.RES)) { const c = byIso2.get(iso2); if (!c) continue;
    add({ id: "res:ressources:" + c.iso3, kind: "fiche", title_fr: "Ressources naturelles : " + c.name_fr, level: null, base: "geography", body: txt, tags: ["Économie", "Ressources naturelles"], prov_id: pC }, [c.id]); }

  // 3. Mises en situation (documents réels simplifiés)
  const pS = prov({ fetch: editorialFetch(appFile("situations")), status: "editorial", checked_at: "2026-06-30" });
  for (const s of app.SITUATIONS) {
    const kws = new Set(norm(s.title + " " + s.context).split(" ").filter(w => w.length > 5));
    const kc = cards.filter(k => (k.keywords || []).some(w => kws.has(norm(w)))).map(k => k.id);
    add({ id: "res:situation:" + s.id, kind: "mise_en_situation", title_fr: s.title, level: s.lvl ? "N" + s.lvl : null, base: s.domain === "en" ? "vocab_en" : s.domain === "es" ? "vocab_es" : "practical",
      body: s.context, tags: [s.sub].filter(Boolean), source_text: s.src || null, as_of: s.asOf || null, prov_id: pS }, [...kc, ...mentions(s.context)]);
  }

  // 4. Une ressource de lecture par fiche pratique / professionnelle (même provenance, même date de validité)
  for (const k of cards) {
    const sameSub = (qBySub.get(k.domain) || []).slice(0, 10);
    add({ id: "res:lecture:" + k.id.slice(3), kind: "fiche_pratique", title_fr: k.title_fr, level: null, base: k.base, body: k.summary_fr, tags: [k.domain], prov_id: k.prov_id }, [k.id]);
    sameSub.forEach(q => link.push({ resource_id: "res:lecture:" + k.id.slice(3), target_id: q, role: "q" }));
  }

  // Dédoublonnage des liens
  const seen = new Set(); const links = link.filter(l => { const key = l.resource_id + "|" + l.target_id; if (seen.has(key)) return false; seen.add(key); return true; });
  const byKind = {}; resource.forEach(r => byKind[r.kind] = (byKind[r.kind] || 0) + 1);
  log(`  ressources : ${Object.entries(byKind).map(([k, v]) => k + " " + v).join(" · ")} ; liens : ${links.length} (dont ${links.filter(l => l.role === "q").length} vers des questions)`);
  return { counts: writeBase("resources", { resource, resource_link: links }), qa };
}
