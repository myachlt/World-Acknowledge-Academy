// Base 6 : International Organizations — fiches et adhésions.
// Listes de membres : lot éditorial daté (sites officiels), avec trois contrôles automatiques :
//   1. le nombre de membres de la liste = le nombre officiel annoncé ;
//   2. l'identifiant Wikidata déclaré désigne bien l'organisation (libellé anglais) ;
//   3. chaque adhésion est recoupée avec Wikidata (P463). Concordance → « recoupé » ; sinon reste « éditorial » et l'écart est journalisé.
import fs from "node:fs";
import path from "node:path";
import { DB, prov, norm, writeBase, readBase, addDays, editorialFetch } from "../lib/core.mjs";
import { wikidata } from "../connectors/index.mjs";
import { appData } from "../lib/app.mjs";

export async function build(log) {
  const qa = [];
  const file = path.join(DB, "editorial/organizations.json"); const ED = JSON.parse(fs.readFileSync(file, "utf8")); const fEd = editorialFetch(file);
  const countries = readBase("countries", "country"); const by2 = new Map(countries.map(c => [c.iso2, c])); const by3 = new Map(countries.map(c => [c.iso3, c]));
  const app = appData();
  const validUntil = addDays(ED.checked_at, ED.valid_days);
  // Wikidata : libellés des QID déclarés + membres (P463 sans date de fin)
  const qids = ED.orgs.map(o => "wd:" + o.qid);
  let labels = new Map(), wdMembers = new Map(), fWD = null;
  try {
    const r = await wikidata("org_labels", `SELECT ?o ?en WHERE { VALUES ?o { ${qids.join(" ")} } ?o rdfs:label ?en FILTER(LANG(?en)="en") }`);
    r.rows.forEach(b => labels.set(b.o.split("/").pop(), b.en));
    const m = await wikidata("org_members", `SELECT ?o ?iso3 WHERE { VALUES ?o { ${qids.join(" ")} } ?c p:P463 ?st . ?st ps:P463 ?o . ?c wdt:P298 ?iso3 . FILTER NOT EXISTS { ?st pq:P582 ?end } }`);
    fWD = m.fetch; m.rows.forEach(b => { const q = b.o.split("/").pop(); (wdMembers.get(q) || wdMembers.set(q, new Set()).get(q)).add(b.iso3); });
  } catch (e) { log("  Wikidata injoignable : adhésions non recoupées (" + e.message.slice(0, 80) + ")"); }

  const organization = [], membership = [];
  for (const o of ED.orgs) {
    const wl = labels.get(o.qid);
    const qidOk = !wl || norm(wl).split(" ").some(w => w.length > 3 && norm(o.name_en).includes(w)) || norm(wl) === norm(o.acronym_en) || (o.wd_label && norm(wl) === norm(o.wd_label));
    if (wl && !qidOk) qa.push({ rule: "wikidata_id_mismatch", severity: "warn", target_id: "org:" + o.id, message: `QID ${o.qid} = « ${wl} », attendu « ${o.name_en} » : recoupement désactivé pour cette organisation` });
    organization.push({ id: "org:" + o.id, acronym_fr: o.acronym_fr, acronym_en: o.acronym_en, name_fr: o.name_fr, name_en: o.name_en, founded: o.founded, hq_city: o.hq_city,
      hq_country_id: o.hq ? "cty:" + o.hq : null, kind: o.kind, mission_fr: o.mission_fr, note_fr: o.note || o.expected_note || null, url: o.url, wikidata: qidOk ? o.qid : null,
      expected_members: o.expected || null, prov_id: prov({ fetch: fEd, status: "editorial", checked_at: ED.checked_at, valid_until: validUntil }) });
    let list = [];
    if (o.members_from === "un_member") list = countries.filter(c => c.un_member).map(c => c.iso2);
    else if (o.members) list = o.members.split(" ");
    if (!list.length) continue;
    // Contrôle 1 : nombre officiel
    if (o.expected && list.length !== o.expected) qa.push({ rule: "member_count", severity: "error", target_id: "org:" + o.id, message: `${list.length} membres listés pour ${o.expected} annoncés` });
    const dup = list.filter((x, i) => list.indexOf(x) !== i); if (dup.length) qa.push({ rule: "member_duplicate", severity: "error", target_id: "org:" + o.id, message: "Doublons : " + dup.join(" ") });
    // Contrôle 3 : recoupement Wikidata
    const W = qidOk ? wdMembers.get(o.qid) : null;
    let agree = 0;
    for (const iso2 of list) {
      const c = by2.get(iso2); if (!c) { qa.push({ rule: "unknown_country", severity: "error", target_id: "org:" + o.id, message: "Code pays inconnu : " + iso2 }); continue; }
      const ok = W && W.has(c.iso3); if (ok) agree++;
      membership.push({ org_id: "org:" + o.id, country_id: c.id, status: "member", since: null,
        prov_id: prov({ fetch: ok ? fWD : fEd, source: ok ? "wikidata" : "wka_editorial", status: ok ? "cross_checked" : (o.members_from ? "source_trusted" : "editorial"),
          // recoupé : la liste officielle et Wikidata concordent à la date de la requête Wikidata, qui devient la date de vérification
          checked_at: ok ? fWD.retrieved_at.slice(0, 10) : ED.checked_at, valid_until: ok ? addDays(fWD.retrieved_at.slice(0, 10), ED.valid_days) : validUntil, note: ok ? "Liste officielle recoupée avec Wikidata (P463)" : null }) });
    }
    for (const iso2 of (o.suspended || "").split(" ").filter(Boolean)) membership.push({ org_id: "org:" + o.id, country_id: "cty:" + by2.get(iso2).iso3, status: "suspended", since: null, prov_id: prov({ fetch: fEd, status: "editorial", checked_at: ED.checked_at, valid_until: validUntil }) });
    if (W) { const extra = [...W].filter(i => !list.includes((by3.get(i) || {}).iso2)); if (extra.length) qa.push({ rule: "membership_extra_in_wikidata", severity: "info", target_id: "org:" + o.id, message: `Wikidata compte aussi : ${extra.join(" ")} (anciens membres sans date de fin, observateurs ou erreurs)` }); }
    // Recoupement avec les listes de la maquette (même clé française)
    const appKey = { NATO: "OTAN", EU: "UE", EUROZONE: "EURO", G20: "G20", BRICS: "BRICS", OPEC: "OPEP", ASEAN: "ASEAN" }[o.id];
    if (appKey && app.ORGS[appKey] && app.ORGS[appKey].list) { const al = app.ORGS[appKey].list.split(" "); const miss = list.filter(x => !al.includes(x)), extra = al.filter(x => !list.includes(x));
      if (miss.length || extra.length) qa.push({ rule: "app_list_mismatch", severity: "warn", target_id: "org:" + o.id, message: `Maquette : manque ${miss.join(" ") || "—"}, en trop ${extra.join(" ") || "—"}` }); }
    log(`  ${o.acronym_fr} : ${list.length}/${o.expected || "?"} membres, ${W ? agree + " recoupés avec Wikidata" : "non recoupé"}`);
  }
  const counts = writeBase("organizations", { organization, membership });
  return { counts, qa };
}
