// Base 3 : World Statistics — séries annuelles par pays (format long : entité × indicateur × année).
// Chaque valeur garde SON année de référence ; la « dernière valeur » d'un pays peut dater de 2021 pour un indicateur et de 2024 pour un autre.
// Les indicateurs sensibles (pauvreté, Gini, dépenses militaires…) sont marqués pour une surveillance renforcée.
import { prov, writeBase, readBase, num } from "../lib/core.mjs";
import { worldBankIndicator, undpHDI, owid } from "../connectors/index.mjs";

export const INDICATORS = [
  // code, nom FR, unité, décimales, sensible, définition
  ["SP.POP.TOTL", "Population totale", "habitants", 0, 0, "Population résidente au milieu de l'année, toutes nationalités."],
  ["NY.GDP.MKTP.CD", "PIB (dollars courants)", "USD", 0, 0, "Produit intérieur brut aux prix du marché, en dollars américains courants."],
  ["NY.GDP.PCAP.CD", "PIB par habitant (dollars courants)", "USD", 0, 0, "PIB divisé par la population de milieu d'année."],
  ["NY.GDP.PCAP.PP.CD", "PIB par habitant en parité de pouvoir d'achat", "USD PPA", 0, 0, "PIB par habitant converti en dollars internationaux (PPA)."],
  ["NY.GDP.MKTP.KD.ZG", "Croissance du PIB", "%", 1, 0, "Variation annuelle du PIB à prix constants."],
  ["FP.CPI.TOTL.ZG", "Inflation (prix à la consommation)", "%", 1, 0, "Variation annuelle de l'indice des prix à la consommation."],
  ["SL.UEM.TOTL.ZS", "Taux de chômage (estimation OIT)", "%", 1, 0, "Part de la population active sans emploi, estimation modélisée de l'OIT."],
  ["SP.DYN.LE00.IN", "Espérance de vie à la naissance", "années", 1, 0, "Nombre moyen d'années qu'un nouveau-né vivrait si les conditions de mortalité restaient constantes."],
  ["SP.DYN.TFRT.IN", "Indice de fécondité", "enfants par femme", 2, 0, "Nombre moyen d'enfants par femme."],
  ["SP.URB.TOTL.IN.ZS", "Population urbaine", "% de la population", 1, 0, "Part de la population vivant en zone urbaine (définitions nationales)."],
  ["EN.POP.DNST", "Densité de population", "hab./km²", 1, 0, "Population divisée par la superficie des terres."],
  ["AG.LND.FRST.ZS", "Surface forestière", "% du territoire", 1, 0, "Part des terres couvertes de forêts."],
  ["IT.NET.USER.ZS", "Utilisateurs d'Internet", "% de la population", 1, 0, "Part des personnes ayant utilisé Internet au cours des 3 derniers mois."],
  ["EG.ELC.ACCS.ZS", "Accès à l'électricité", "% de la population", 1, 0, "Part de la population ayant accès à l'électricité."],
  ["SE.ADT.LITR.ZS", "Taux d'alphabétisation des adultes", "% des 15 ans et plus", 1, 0, "Part des 15 ans et plus sachant lire et écrire un texte simple."],
  ["SH.XPD.CHEX.GD.ZS", "Dépenses de santé", "% du PIB", 1, 0, "Dépenses courantes de santé rapportées au PIB."],
  ["SE.XPD.TOTL.GD.ZS", "Dépenses publiques d'éducation", "% du PIB", 1, 0, "Dépenses publiques d'éducation rapportées au PIB."],
  ["MS.MIL.XPND.GD.ZS", "Dépenses militaires", "% du PIB", 1, 1, "Dépenses militaires rapportées au PIB (SIPRI)."],
  ["SI.POV.GINI", "Indice de Gini", "indice 0-100", 1, 1, "Inégalités de revenu ou de consommation (0 = égalité parfaite). Enquêtes irrégulières : années très variables selon les pays."],
  ["SI.POV.DDAY", "Extrême pauvreté (moins de 3 $ par jour, PPA)", "% de la population", 1, 1, "Part de la population vivant sous le seuil international d'extrême pauvreté. Enquêtes irrégulières."],
  ["NE.EXP.GNFS.ZS", "Exportations de biens et services", "% du PIB", 1, 0, "Valeur des exportations rapportée au PIB."]
];
const AGG = { WLD: "Monde", EUU: "Union européenne", HIC: "Pays à revenu élevé", LIC: "Pays à faible revenu", SSF: "Afrique subsaharienne", EAS: "Asie de l'Est et Pacifique", LCN: "Amérique latine et Caraïbes" };

export async function build(log) {
  const qa = [];
  const countries = readBase("countries", "country"); const ok3 = new Set(countries.map(c => c.iso3));
  const entityOf = iso3 => ok3.has(iso3) ? "cty:" + iso3 : AGG[iso3] ? "agg:" + iso3 : null;
  const indicator = [], observation = [];
  for (const [code, name, unit, dec, sens, def] of INDICATORS) {
    indicator.push({ id: "ind:" + code, code, name_fr: name, name_en: null, unit, decimals: dec, source_id: "worldbank", definition_fr: def, sensitive: sens });
    try {
      const { points, fetch } = await worldBankIndicator(code, { from: 2000 });
      let n = 0;
      for (const p of points) { const e = entityOf(p.iso3); if (!e) continue;
        observation.push({ entity_id: e, indicator_id: "ind:" + code, year: p.year, value: p.value, derived: 0,
          prov_id: prov({ fetch, ref_year: p.year, status: fetch.via === "primary" ? "source_trusted" : "source_trusted", note: fetch.via === "mirror" ? "Copie CSV de l'indicateur Banque mondiale (datasets/*)" : null }) }); n++; }
      log(`  ${code} : ${n} valeurs (${fetch.via === "primary" ? "API Banque mondiale" : "miroir"})`);
    } catch (e) { qa.push({ rule: "source_unreachable", severity: "warn", target_id: "ind:" + code, message: e.message.slice(0, 200) }); log(`  ${code} : indisponible`); }
  }
  // IDH (PNUD) : publié avec deux ans de décalage
  indicator.push({ id: "ind:HDI", code: "HDI", name_fr: "Indice de développement humain (IDH)", name_en: "Human Development Index", unit: "indice 0-1", decimals: 3, source_id: "undp_hdr", definition_fr: "Moyenne géométrique de trois dimensions : santé (espérance de vie), éducation (durée de scolarisation), niveau de vie (RNB par habitant, PPA).", sensitive: 0 });
  try {
    const { points, fetch } = await undpHDI(); let n = 0;
    for (const p of points) { if (p.year < 2000) continue; const e = entityOf(p.iso3); if (!e) continue;
      observation.push({ entity_id: e, indicator_id: "ind:HDI", year: p.year, value: p.value, derived: 0, prov_id: prov({ fetch, ref_year: p.year, status: "source_trusted" }) }); n++; }
    log(`  IDH : ${n} valeurs`);
  } catch (e) { qa.push({ rule: "source_unreachable", severity: "warn", target_id: "ind:HDI", message: e.message.slice(0, 200) }); log("  IDH : indisponible"); }
  // Our World in Data : CO2 par habitant, part des renouvelables
  const OW = [["co2", "co2_per_capita", "CO2_PC", "Émissions de CO2 par habitant", "t de CO2 par habitant", 2, "Émissions de CO2 d'origine fossile et industrielle (hors usage des terres), par habitant."],
    ["energy", "renewables_share_energy", "REN_SHARE", "Part des renouvelables dans l'énergie primaire", "% de l'énergie primaire", 1, "Part des énergies renouvelables (hydraulique, solaire, éolien, biomasse…) dans la consommation d'énergie primaire."],
    ["energy", "low_carbon_share_elec", "LOWC_ELEC", "Électricité bas carbone", "% de l'électricité", 1, "Part de l'électricité produite à partir du nucléaire et des renouvelables."]];
  const owCache = {};
  for (const [kind, col, id, name, unit, dec, def] of OW) {
    indicator.push({ id: "ind:" + id, code: col, name_fr: name, name_en: null, unit, decimals: dec, source_id: kind === "co2" ? "owid_co2" : "owid_energy", definition_fr: def, sensitive: 0 });
    try {
      owCache[kind] = owCache[kind] || await owid(kind); const { rows, fetch } = owCache[kind]; let n = 0;
      for (const r of rows) { const y = +r.year, v = num(r[col]); if (y < 2000 || v === null || !r.iso_code) continue; const e = entityOf(r.iso_code) || (r.country === "World" ? "agg:WLD" : null); if (!e) continue;
        observation.push({ entity_id: e, indicator_id: "ind:" + id, year: y, value: v, derived: 0, prov_id: prov({ fetch, ref_year: y, status: "source_trusted" }) }); n++; }
      log(`  ${id} : ${n} valeurs (Our World in Data)`);
    } catch (e) { qa.push({ rule: "source_unreachable", severity: "warn", target_id: "ind:" + id, message: e.message.slice(0, 200) }); }
  }
  // Contrôles : valeurs aberrantes (bornes physiques) et sauts brutaux d'une année sur l'autre
  const BOUNDS = { "ind:SP.DYN.LE00.IN": [20, 95], "ind:SP.DYN.TFRT.IN": [0.5, 9], "ind:HDI": [0.2, 1], "ind:SP.URB.TOTL.IN.ZS": [0, 100], "ind:IT.NET.USER.ZS": [0, 100], "ind:EG.ELC.ACCS.ZS": [0, 100], "ind:AG.LND.FRST.ZS": [0, 100], "ind:SE.ADT.LITR.ZS": [0, 100], "ind:SI.POV.GINI": [15, 75] };
  for (const o of observation) { const b = BOUNDS[o.indicator_id]; if (b && (o.value < b[0] || o.value > b[1])) qa.push({ rule: "out_of_bounds", severity: "warn", target_id: `${o.entity_id}/${o.indicator_id}/${o.year}`, message: `Valeur ${o.value} hors bornes [${b}]` }); }
  const series = new Map(); observation.forEach(o => { const k = o.entity_id + "|" + o.indicator_id; (series.get(k) || series.set(k, []).get(k)).push(o); });
  for (const [k, arr] of series) { if (!/SP.POP.TOTL/.test(k)) continue; arr.sort((a, b) => a.year - b.year);
    for (let i = 1; i < arr.length; i++) if (arr[i].year === arr[i - 1].year + 1 && Math.abs(arr[i].value / arr[i - 1].value - 1) > 0.15) qa.push({ rule: "population_jump", severity: "info", target_id: k, message: `Saut de population de ${Math.round((arr[i].value / arr[i - 1].value - 1) * 100)} % entre ${arr[i - 1].year} et ${arr[i].year}` }); }
  // Recoupement : population Banque mondiale vs base pays de la maquette (ONU 2024, arrondie au million près)
  const counts = writeBase("stats", { indicator, observation, aggregate: Object.entries(AGG).map(([k, v]) => ({ id: "agg:" + k, name_fr: v })) });
  return { counts, qa };
}
