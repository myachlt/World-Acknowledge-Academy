// Base 4 : Politics — régimes, dirigeants en fonction, institutions.
// Dirigeants : Wikidata (fonction en cours = déclaration sans date de fin), recoupés avec la liste vérifiée de la maquette.
// Ces données d'actualité reçoivent une date de validité courte (60 jours) : passé ce délai, elles sont marquées périmées
// et exclues des quiz tant que la synchronisation ne les a pas revérifiées.
import fs from "node:fs";
import path from "node:path";
import { DB, prov, norm, writeBase, readBase, addDays, TODAY, editorialFetch } from "../lib/core.mjs";
import { wikidata } from "../connectors/index.mjs";
import { appData } from "../lib/app.mjs";

const VALID_DAYS = 60;
const sameName = (a, b) => { if (!a || !b) return false; const x = norm(a), y = norm(b); return x === y || x.includes(y) || y.includes(x) || x.split(" ").pop() === y.split(" ").pop(); };

export async function build(log) {
  const qa = [];
  const file = path.join(DB, "editorial/institutions.json"); const ED = JSON.parse(fs.readFileSync(file, "utf8")); const fEd = editorialFetch(file);
  const countries = readBase("countries", "country"); const by2 = new Map(countries.map(c => [c.iso2, c]));
  const app = appData();
  const APPC = new Map(app.countries.map(c => [c.iso, c]));
  const pEd = prov({ fetch: fEd, status: "editorial", checked_at: ED.checked_at });
  const political_system = ED.systems.map(s => ({ ...s, id: "sys:" + s.id, prov_id: pEd }));
  const institution = ED.institutions.map(i => ({ id: "inst:" + i.id, scope: i.scope, name_fr: i.name_fr, acronym: null, role_fr: i.role_fr, composition_fr: i.composition_fr, seat: i.seat, founded: i.founded, parent_id: null, url: i.source, prov_id: pEd }));

  // Dirigeants (Wikidata)
  let WD = new Map(), fWD = null;
  try {
    const r = await wikidata("leaders", `SELECT ?iso3 ?hosLabel ?hosStart ?hogLabel ?hogStart WHERE {
      ?c wdt:P298 ?iso3 ; wdt:P31 wd:Q3624078 .
      OPTIONAL { ?c p:P35 ?s1 . ?s1 ps:P35 ?hos . FILTER NOT EXISTS { ?s1 pq:P582 ?e1 } OPTIONAL { ?s1 pq:P580 ?hosStart } }
      OPTIONAL { ?c p:P6 ?s2 . ?s2 ps:P6 ?hog . FILTER NOT EXISTS { ?s2 pq:P582 ?e2 } OPTIONAL { ?s2 pq:P580 ?hogStart } }
      SERVICE wikibase:label { bd:serviceParam wikibase:language "fr,en". } }`);
    fWD = r.fetch;
    for (const b of r.rows) {
      const x = WD.get(b.iso3) || { hos: new Map(), hog: new Map() };
      if (b.hosLabel && !/^Q\d+$/.test(b.hosLabel)) x.hos.set(b.hosLabel, b.hosStart ? b.hosStart.slice(0, 10) : null);
      if (b.hogLabel && !/^Q\d+$/.test(b.hogLabel)) x.hog.set(b.hogLabel, b.hogStart ? b.hogStart.slice(0, 10) : null);
      WD.set(b.iso3, x);
    }
  } catch (e) { log("  Wikidata injoignable : seuls les dirigeants vérifiés de la maquette sont repris (" + e.message.slice(0, 80) + ")"); }

  const country_politics = [];
  let agree = 0, disagree = 0;
  for (const c of countries.filter(c => c.kind !== "territory")) {
    const a = APPC.get(c.iso2), w = WD.get(c.iso3), L = app.LEADERS[c.iso2];
    const hos = w ? [...w.hos.keys()] : [], hog = w ? [...w.hog.keys()] : [];
    let status = w ? "source_trusted" : "editorial", note = [];
    let headState = hos.join(" ; ") || null, headGov = hog.join(" ; ") || null;
    if (L) {
      const okS = !w || hos.some(h => sameName(h, L[0]));
      const okG = !w || L[1] === null || hog.some(h => sameName(h, L[1]));
      if (w && okS && okG) { status = "cross_checked"; agree++; }
      else if (w) { status = "conflict"; disagree++; note.push(`Maquette (juin 2026) : ${L[0]}${L[1] ? " / " + L[1] : ""}`);
        qa.push({ rule: "leader_conflict", severity: "warn", target_id: c.id, message: `${c.name_fr} : Wikidata « ${headState || "—"} / ${headGov || "—"} » ≠ maquette « ${L[0]} / ${L[1] || "—"} »` }); }
      if (!w) { headState = L[0]; headGov = L[1]; }
    }
    if (hos.length > 1 && c.iso3 !== "AND" && c.iso3 !== "SMR" && c.iso3 !== "CHE") { note.push("Plusieurs titulaires actuels déclarés : à vérifier"); if (status !== "conflict") status = "needs_review"; }
    country_politics.push({ country_id: c.id, system_id: a ? "sys:" + a.gov : null, system_basis: a ? "Classification éditoriale de la maquette (juin 2026)" : null,
      head_of_state: headState, head_of_state_since: w && hos.length === 1 ? w.hos.get(hos[0]) : null,
      head_of_government: headGov, head_of_government_since: w && hog.length === 1 ? w.hog.get(hog[0]) : null, legislature: null,
      prov_id: prov({ fetch: fWD || fEd, status, valid_until: addDays(TODAY, VALID_DAYS), note: note.join(" ") || null }) });
  }
  log(`  dirigeants : ${country_politics.filter(p => p.head_of_state).length} États renseignés ; recoupement maquette : ${agree} concordants, ${disagree} divergents`);
  const counts = writeBase("politics", { political_system, country_politics, institution });
  return { counts, qa };
}
