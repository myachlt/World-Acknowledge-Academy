// Base 5 : World History — événements datés (lot rédigé de la maquette), personnalités et fonctions (Wikidata, avec dates de début et de fin).
// Les séries de titulaires (présidents français, secrétaires généraux de l'ONU, présidents américains) et les lauréats du prix Nobel de la paix
// viennent de Wikidata ; chaque ligne garde ses dates. Les événements rédigés gardent leur précision (année seulement).
import { prov, writeBase, slug, editorialFetch } from "../lib/core.mjs";
import { wikidata } from "../connectors/index.mjs";
import { appData, appFile } from "../lib/app.mjs";

const OFFICES = [["Q191954", "Président de la République française", "FRA"], ["Q11696", "Président des États-Unis", "USA"], ["Q81066", "Secrétaire général des Nations unies", null], ["Q1587677", "Premier ministre français", "FRA"]];

export async function build(log) {
  const qa = [];
  const app = appData();
  const fEv = editorialFetch(appFile("knowledge")); const pEv = prov({ fetch: fEv, status: "editorial", checked_at: "2026-06-30" });
  const event = app.EVENTS.map(([y, name, period, fact]) => ({ id: `ev:${y}:${slug(name).slice(0, 50)}`, name_fr: name, start: String(y), end: null, precision: "year", period, theme: period, summary_fr: fact, prov_id: pEv }));
  const fSh = editorialFetch(appFile("world")); const pSh = prov({ fetch: fSh, status: "editorial", checked_at: "2026-06-30" });
  const person = [], office_term = [], award = [];
  try {
    for (const [q, label, cty] of OFFICES) {
      const r = await wikidata("office_" + q, `SELECT ?p ?fr ?en ?start ?end ?born ?died WHERE { ?p p:P39 ?st . ?st ps:P39 wd:${q} . OPTIONAL { ?st pq:P580 ?start } OPTIONAL { ?st pq:P582 ?end }
        OPTIONAL { ?p rdfs:label ?fr FILTER(LANG(?fr)="fr") } OPTIONAL { ?p rdfs:label ?en FILTER(LANG(?en)="en") } OPTIONAL { ?p wdt:P569 ?born } OPTIONAL { ?p wdt:P570 ?died } }`);
      const seen = new Set();
      for (const b of r.rows) {
        if (!b.start) continue; const pid = "person:" + b.p.split("/").pop(); const k = pid + b.start; if (seen.has(k)) continue; seen.add(k);
        if (!person.some(x => x.id === pid)) person.push({ id: pid, name: b.fr || b.en || b.p.split("/").pop(), name_missing: b.fr || b.en ? 0 : 1, born: b.born ? b.born.slice(0, 10) : null, died: b.died ? b.died.slice(0, 10) : null, country_id: cty ? "cty:" + cty : null, role_fr: label, summary_fr: null, prov_id: prov({ fetch: r.fetch, status: "source_trusted" }) });
        office_term.push({ person_id: pid, office: label, start: b.start.slice(0, 10), end: b.end ? b.end.slice(0, 10) : null, prov_id: prov({ fetch: r.fetch, status: "source_trusted", note: "Fonction et dates Wikidata (P39, P580, P582)" }) });
      }
      log(`  ${label} : ${office_term.filter(t => t.office === label).length} mandats`);
    }
    const r = await wikidata("nobel_peace", `SELECT ?p ?fr ?en ?year WHERE { ?p p:P166 ?st . ?st ps:P166 wd:Q35637 ; pq:P585 ?d . BIND(YEAR(?d) AS ?year)
      OPTIONAL { ?p rdfs:label ?fr FILTER(LANG(?fr)="fr") } OPTIONAL { ?p rdfs:label ?en FILTER(LANG(?en)="en") } }`);
    for (const b of r.rows) award.push({ award: "Prix Nobel de la paix", year: +b.year, laureate: b.fr || b.en, laureate_id: "wd:" + b.p.split("/").pop(), prov_id: prov({ fetch: r.fetch, status: "source_trusted" }) });
    log(`  prix Nobel de la paix : ${award.length} lauréats`);
  } catch (e) { log("  Wikidata injoignable : " + e.message.slice(0, 80)); }
  // Contrôle : un mandat ne peut pas finir avant de commencer ; les mandats d'une même fonction ne se chevauchent pas (sauf intérims)
  for (const t of office_term) if (t.end && t.end < t.start) qa.push({ rule: "date_order", severity: "error", target_id: t.person_id, message: `${t.office} : fin ${t.end} avant début ${t.start}` });
  return { counts: writeBase("history", { event, person, office_term, award }, { csv: ["event"] }), qa };
}
