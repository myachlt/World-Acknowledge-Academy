// Bases 12 et 13 : Practical Knowledge (droit, finances, santé, numérique, vie quotidienne) et Professional Knowledge (travail, entreprise).
// Lot rédigé à partir de Service-Public.fr et Légifrance. Données sensibles : relecture humaine obligatoire, validité limitée (180 jours),
// chaque montant ou délai porte sa date d'effet quand elle est connue.
import fs from "node:fs";
import path from "node:path";
import { DB, prov, writeBase, addDays, editorialFetch } from "../lib/core.mjs";

export const PRO_DOMAINS = ["Travail", "Vie professionnelle"];
export async function build(log) {
  const qa = [];
  const file = path.join(DB, "editorial/practical_fr.json"); const ED = JSON.parse(fs.readFileSync(file, "utf8")); const f = editorialFetch(file);
  const p = prov({ fetch: f, source: "service_public", status: "editorial", checked_at: ED.checked_at, valid_until: addDays(ED.checked_at, ED.valid_days), note: "Rédigé d'après Service-Public.fr / Légifrance ; relecture humaine requise" });
  const cards = ED.cards.map(c => ({ id: "kc:" + (PRO_DOMAINS.includes(c.domain) ? "pro" : "prat") + ":" + c.id, base: PRO_DOMAINS.includes(c.domain) ? "professional" : "practical", domain: c.domain,
    title_fr: c.title, summary_fr: c.summary, body_fr: c.body, jurisdiction: "FR", key_figures: c.figures, source_urls: c.sources, keywords: c.keywords, sensitive: 1, prov_id: p }));
  for (const c of cards) { if (!c.source_urls.length) qa.push({ rule: "missing_source", severity: "error", target_id: c.id, message: "Fiche sans source" });
    for (const k of c.key_figures) if (!k.since && /€|%|jours|mois|ans/.test(k.value)) qa.push({ rule: "figure_without_date", severity: "info", target_id: c.id, message: `« ${k.label} : ${k.value} » sans date d'effet` }); }
  const prat = cards.filter(c => c.base === "practical"), pro = cards.filter(c => c.base === "professional");
  writeBase("professional", { knowledge_card: pro });
  log(`  ${prat.length} fiches pratiques, ${pro.length} fiches professionnelles`);
  return { counts: Object.assign(writeBase("practical", { knowledge_card: prat }), { professional_cards: pro.length }), qa };
}
