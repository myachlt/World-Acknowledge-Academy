// Base 2 : Geography — villes, capitales, reliefs, mers, lacs, déserts, fleuves.
// Sources : Natural Earth (domaine public : noms FR/EN/ES, altitudes, identifiants Wikidata), GeoNames (villes),
// Wikidata (longueur des fleuves, superficie des lacs, altitude pour recoupement).
// Règle : une mesure n'est retenue que si elle vient d'une source ; les mesures calculées à partir d'une géométrie
// ne sont jamais publiées comme des faits.
import { prov, norm, slug, num, writeBase, readBase } from "../lib/core.mjs";
import { naturalEarth, wikidata } from "../connectors/index.mjs";

// Point dans polygone (GeoJSON Polygon / MultiPolygon), pour rattacher un point à un pays.
function inRing(x, y, ring) { let ins = false; for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) { const [xi, yi] = ring[i], [xj, yj] = ring[j]; if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) ins = !ins; } return ins; }
function inGeom(x, y, g) { const polys = g.type === "Polygon" ? [g.coordinates] : g.type === "MultiPolygon" ? g.coordinates : []; return polys.some(p => inRing(x, y, p[0]) && !p.slice(1).some(h => inRing(x, y, h))); }

const TYPE = { mountain: "peak", "spot elevation": "peak", depression: "depression", plateau: "plateau", pass: "pass", cape: "cape",
  ocean: "ocean", sea: "sea", bay: "bay", gulf: "gulf", strait: "strait", channel: "channel", sound: "sound", reef: "reef",
  Lake: "lake", "Alkaline Lake": "lake", Reservoir: "reservoir", Desert: "desert", "Range/mtn": "range", Plateau: "plateau", Plain: "plain", Basin: "basin",
  Island: "island", "Island group": "island_group", Peninsula: "peninsula", "Pen/cape": "peninsula", Delta: "delta", Tundra: "tundra", Valley: "valley", Isthmus: "isthmus", Continent: "continent" };
const CONT_NE = { Europe: "EU", Asia: "AS", Africa: "AF", "North America": "NA", "South America": "SA", Oceania: "OC", Antarctica: "AN" };

export async function build(log) {
  const qa = [];
  const countries = readBase("countries", "country");
  if (!countries.length) throw new Error("Construire d'abord la base countries");
  const byIso3 = new Map(countries.map(c => [c.iso3, c]));
  const { geo: ADM } = await naturalEarth("ne_50m_admin_0_countries");
  const admin = ADM.features.map(f => ({ iso3: [f.properties.ISO_A3, f.properties.ADM0_A3, f.properties.ADM0_ISO].find(k => k && byIso3.has(k)), geom: f.geometry })).filter(a => a.iso3);
  const countryAt = (lon, lat) => { const a = admin.find(a => inGeom(lon, lat, a.geom)); return a ? a.iso3 : null; };

  // ---------- Villes et capitales (Natural Earth populated places) ----------
  const { geo: PP, fetch: fPP } = await naturalEarth("ne_10m_populated_places_simple");
  const city = []; const capitalOf = new Map();
  for (const f of PP.features) {
    const p = f.properties; const iso3 = byIso3.has(p.adm0_a3) ? p.adm0_a3 : byIso3.has(p.sov_a3) ? p.sov_a3 : null;
    const isCap = /Admin-0 capital/.test(p.featurecla) && !/alt/i.test(p.featurecla);
    if (!isCap && !(p.pop_max >= 1000000) && !p.worldcity) continue; // on garde capitales, villes mondiales et villes > 1 million
    const id = "city:ne:" + p.ne_id;
    city.push({ id, name: p.name, name_fr: null, country_id: iso3 ? "cty:" + iso3 : null, is_capital: isCap ? 1 : 0, population: p.pop_max > 0 ? p.pop_max : null,
      population_year: null, population_note: "Agglomération (pop_max Natural Earth), année non précisée par la source : à ne pas utiliser pour des comparaisons fines",
      lat: p.latitude, lon: p.longitude, prov_id: prov({ fetch: fPP, status: "source_trusted" }) });
    if (isCap && iso3) capitalOf.set(iso3, (capitalOf.get(iso3) || []).concat(id));
  }
  // Recoupement capitale Natural Earth / capitale de la base pays
  const cityById = new Map(city.map(c => [c.id, c]));
  for (const c of countries) {
    const ids = capitalOf.get(c.iso3) || [];
    const match = ids.find(id => [c.capital_name, c.capital_name_en].some(n => n && norm(cityById.get(id).name).includes(norm(n).split(" ")[0])));
    if (match) { const ct = cityById.get(match); ct.name_fr = c.capital_name; ct.capital_check = "cross_checked"; }
    else if (c.kind === "sovereign") qa.push({ rule: "capital_unmatched", severity: "info", target_id: c.id, message: `Capitale « ${c.capital_name} » non retrouvée parmi les capitales Natural Earth (${ids.map(i => cityById.get(i).name).join(", ") || "aucune"})` });
  }

  // ---------- Reliefs, mers, régions physiques ----------
  const feat = [], fc = [];
  const addFeature = (type, p, fetch, extra) => {
    const nameEn = p.name_en || p.NAME_EN || p.name || p.NAME; if (!nameEn) return null;
    const id = `geo:${type}:${slug(nameEn)}`; if (feat.some(x => x.id === id)) return null;
    const row = Object.assign({ id, type, name_en: nameEn, name_fr: p.name_fr || p.NAME_FR || null, name_es: p.name_es || p.NAME_ES || null,
      continent: CONT_NE[p.region || p.REGION] || null, elevation_m: null, length_km: null, area_km2: null, lat: null, lon: null,
      wikidata: p.wikidataid || p.WIKIDATAID || null, prov_id: prov({ fetch, status: "source_trusted" }) }, extra || {});
    feat.push(row); return row;
  };
  const { geo: EP, fetch: fEP } = await naturalEarth("ne_10m_geography_regions_elevation_points");
  for (const f of EP.features) { const p = f.properties; const r = addFeature(TYPE[p.featurecla] || "peak", p, fEP, { elevation_m: num(p.elevation), lat: p.lat_y, lon: p.long_x });
    if (r) { const iso = countryAt(p.long_x, p.lat_y); if (iso) fc.push({ feature_id: r.id, country_id: "cty:" + iso, method: "point_in_polygon" }); } }
  const { geo: MP, fetch: fMP } = await naturalEarth("ne_50m_geography_marine_polys");
  for (const f of MP.features) addFeature(TYPE[f.properties.featurecla] || f.properties.featurecla, f.properties, fMP);
  const { geo: RP, fetch: fRP } = await naturalEarth("ne_50m_geography_regions_polys");
  for (const f of RP.features) if (TYPE[f.properties.FEATURECLA] && f.properties.FEATURECLA !== "Continent") addFeature(TYPE[f.properties.FEATURECLA], f.properties, fRP);
  const { geo: LK, fetch: fLK } = await naturalEarth("ne_50m_lakes");
  for (const f of LK.features) if (f.properties.name) addFeature(TYPE[f.properties.featurecla] || "lake", f.properties, fLK);

  // ---------- Wikidata : fleuves (longueur), lacs (superficie), recoupement des altitudes ----------
  try {
    const rv = await wikidata("rivers", `SELECT ?r ?fr ?en ?es ?len (GROUP_CONCAT(DISTINCT ?iso; separator=" ") AS ?isos) ?mouthFr WHERE {
      ?r wdt:P31 wd:Q4022 ; p:P2043/psn:P2043/wikibase:quantityAmount ?len . FILTER(?len >= 1000000)
      OPTIONAL { ?r rdfs:label ?fr FILTER(LANG(?fr)="fr") } OPTIONAL { ?r rdfs:label ?en FILTER(LANG(?en)="en") } OPTIONAL { ?r rdfs:label ?es FILTER(LANG(?es)="es") }
      OPTIONAL { ?r wdt:P17 ?c . ?c wdt:P298 ?iso } OPTIONAL { ?r wdt:P403 ?m . ?m rdfs:label ?mouthFr FILTER(LANG(?mouthFr)="fr") }
    } GROUP BY ?r ?fr ?en ?es ?len ?mouthFr`);
    const seen = new Map();
    for (const b of rv.rows) {
      const q = b.r.split("/").pop(); const km = Math.round(+b.len / 1000);
      if (!b.en && !b.fr) continue;
      const prev = seen.get(q); if (prev) { prev.lengths.add(km); continue; }
      const row = { id: `geo:river:${slug(b.en || b.fr)}`, type: "river", name_en: b.en || b.fr, name_fr: b.fr || null, name_es: b.es || null, continent: null, elevation_m: null,
        length_km: km, area_km2: null, lat: null, lon: null, wikidata: q, mouth_fr: b.mouthFr || null, lengths: new Set([km]) };
      seen.set(q, row);
      (b.isos || "").split(" ").filter(i => byIso3.has(i)).forEach(i => fc.push({ feature_id: row.id, country_id: "cty:" + i, method: "wikidata_P17" }));
    }
    // Recoupement d'existence : un fleuve de plus de 1 500 km doit figurer dans le tracé Natural Earth 1:10m
    const { geo: NR, fetch: fNR } = await naturalEarth("ne_10m_rivers_lake_centerlines");
    const neRivers = new Set(NR.features.map(f => norm(f.properties.name_en || f.properties.name || "")).filter(Boolean));
    const known = n => n && [...neRivers].some(x => x && (x === norm(n) || norm(n).includes(x) || x.includes(norm(n))));
    for (const r of seen.values()) {
      r.ne_match = known(r.name_en) ? 1 : 0;
      // Plusieurs longueurs déclarées = longueur contestée : on garde la plus courante… non : on n'en garde aucune comme « fait », on signale.
      if (r.lengths.size > 1) { r.length_km = null; r.length_values = [...r.lengths].sort((a, b) => a - b); r.prov_id = prov({ fetch: rv.fetch, status: "conflict", note: "Longueurs divergentes selon les références : " + r.length_values.join(" / ") + " km" });
        qa.push({ rule: "river_length_conflict", severity: "info", target_id: r.id, message: `${r.name_fr || r.name_en} : ${r.length_values.join(" / ")} km` }); }
      else if (r.length_km >= 1500 && !r.ne_match) { r.prov_id = prov({ fetch: rv.fetch, status: "needs_review", note: "Longueur Wikidata non recoupée : fleuve absent du tracé Natural Earth" });
        qa.push({ rule: "river_unconfirmed", severity: "warn", target_id: r.id, message: `${r.name_fr || r.name_en} : ${r.length_km} km selon Wikidata, absent de Natural Earth` }); }
      else r.prov_id = prov({ fetch: rv.fetch, status: r.ne_match ? "cross_checked" : "source_trusted", note: "Longueur déclarée dans Wikidata (P2043)" + (r.ne_match ? ", existence recoupée avec Natural Earth" : "") });
      delete r.lengths; if (!feat.some(x => x.id === r.id)) feat.push(r);
    }
  } catch (e) { log("  Wikidata (fleuves) injoignable : " + e.message.slice(0, 100)); }
  // Altitudes et superficies : recoupement Wikidata pour les entités Natural Earth qui portent un identifiant
  try {
    const ids = feat.filter(f => f.wikidata && (f.type === "peak" || f.type === "lake")).map(f => "wd:" + f.wikidata);
    const res = new Map();
    for (let i = 0; i < ids.length; i += 250) {
      const r = await wikidata("measures_" + i, `SELECT ?x ?elev ?area WHERE { VALUES ?x { ${ids.slice(i, i + 250).join(" ")} }
        OPTIONAL { ?x p:P2044/psn:P2044/wikibase:quantityAmount ?elev } OPTIONAL { ?x p:P2046/psn:P2046/wikibase:quantityAmount ?area } }`);
      for (const b of r.rows) { const q = b.x.split("/").pop(); const o = res.get(q) || { elev: [], area: [], fetch: r.fetch }; if (b.elev) o.elev.push(+b.elev); if (b.area) o.area.push(+b.area / 1e6); res.set(q, o); }
    }
    for (const f of feat) {
      const w = f.wikidata && res.get(f.wikidata); if (!w) continue;
      if (f.type === "peak" && f.elevation_m != null && w.elev.length) {
        const ok = w.elev.some(e => Math.abs(e - f.elevation_m) <= 10);
        f.prov_id = prov({ fetch: w.fetch, status: ok ? "cross_checked" : "conflict", note: ok ? "Altitude Natural Earth recoupée avec Wikidata (±10 m)" : `Altitude Natural Earth ${f.elevation_m} m / Wikidata ${[...new Set(w.elev.map(Math.round))].join(", ")} m` });
        if (!ok) qa.push({ rule: "elevation_conflict", severity: "info", target_id: f.id, message: `${f.name_fr || f.name_en} : NE ${f.elevation_m} m / Wikidata ${[...new Set(w.elev.map(Math.round))].join(", ")} m` });
      }
      if (f.type === "lake" && w.area.length === 1) { f.area_km2 = Math.round(w.area[0]); f.prov_id = prov({ fetch: w.fetch, status: "source_trusted", note: "Superficie déclarée dans Wikidata (P2046)" }); }
    }
  } catch (e) { log("  Wikidata (altitudes) injoignable : " + e.message.slice(0, 100)); }

  const counts = writeBase("geography", { city, geo_feature: feat, feature_country: fc }, { csv: ["geo_feature"] });
  log(`  ${city.filter(c => c.is_capital).length} capitales, ${feat.length} entités physiques (${feat.filter(f => f.name_fr).length} avec nom français)`);
  return { counts, qa };
}
