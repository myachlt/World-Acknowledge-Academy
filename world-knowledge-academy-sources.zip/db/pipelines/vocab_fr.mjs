// Base 9 : French Vocabulary, dérivée des sens anglais (dictionnaire pivot de l application).
import { buildTarget } from "../lib/vocab_target.mjs";
export const build = log => buildTarget("fr", log);
