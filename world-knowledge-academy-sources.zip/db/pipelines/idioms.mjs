// Base 11 : Idioms — expressions idiomatiques, faux amis, verbes à particule (anglais, espagnol).
// Sources : lots rédigés de la maquette (expressions, faux amis, phrasal verbs avec exemple) + phrasal verbs fréquents issus de WordNet.
import fs from "node:fs";
import path from "node:path";
import { DB, prov, writeBase, readBase, slug, editorialFetch } from "../lib/core.mjs";
import { appData, appFile } from "../lib/app.mjs";

const LV = ["A1", "A2", "B1", "B2", "C1", "C2"];
export async function build(log) {
  const qa = [];
  const app = appData(); const idiom = [];
  const seen = new Set();
  const push = r => { const k = r.lang + "|" + r.text.toLowerCase(); if (seen.has(k)) { qa.push({ rule: "duplicate", severity: "info", target_id: r.id, message: "Doublon : " + r.text }); return; } seen.add(k); idiom.push(r); };
  for (const lang of ["en", "es"]) {
    const f = editorialFetch(appFile("lang_" + lang)); const p = prov({ fetch: f, status: "editorial", checked_at: "2026-06-30" });
    for (const [text, eq, l] of app.LANG[lang].idioms) push({ id: `idiom:${lang}:${slug(text).slice(0, 60)}`, lang, text, meaning_fr: eq, literal_fr: null, equivalent_fr: eq, example: null, cefr: LV[l - 1], kind: "idiom", prov_id: p });
    for (const [w, real, trap, l] of app.LANG[lang].falseFriends) push({ id: `ff:${lang}:${slug(w)}`, lang, text: w, meaning_fr: real, literal_fr: null, equivalent_fr: null, false_friend_fr: trap, example: null, cefr: LV[l - 1], kind: "false_friend", prov_id: p });
    for (const ph of app.LANG[lang].phrasal || []) push({ id: `pv:${lang}:${slug(ph[0])}`, lang, text: ph[0], meaning_fr: ph[1], literal_fr: null, equivalent_fr: null, example: ph[2], cefr: LV[ph[3] - 1], kind: "phrasal_verb", prov_id: p });
  }
  // Lot éditorial complémentaire (si présent)
  const extra = path.join(DB, "editorial/idioms.json");
  if (fs.existsSync(extra)) { const ED = JSON.parse(fs.readFileSync(extra, "utf8")); const f = editorialFetch(extra); const p = prov({ fetch: f, status: "editorial", checked_at: ED.checked_at });
    for (const x of ED.items) push({ id: `${x.kind === "false_friend" ? "ff" : "idiom"}:${x.lang}:${slug(x.text).slice(0, 60)}`, lang: x.lang, text: x.text, meaning_fr: x.meaning_fr, literal_fr: x.literal_fr || null, equivalent_fr: x.equivalent_fr || null, false_friend_fr: x.false_friend_fr || null, example: x.example || null, cefr: x.cefr, kind: x.kind || "idiom", prov_id: p }); }
  // Phrasal verbs fréquents (WordNet + fréquence annotée), issus de la base anglaise
  for (const pv of readBase("vocab_en", "phrasal_verb")) { if (!pv.fr) continue;
    push({ id: pv.id, lang: "en", text: pv.phrasal, meaning_fr: pv.fr, literal_fr: null, equivalent_fr: null, definition_en: pv.definition_en, example: pv.example, cefr: pv.cefr, kind: "phrasal_verb", prov_id: prov({ source: "wordnet", status: "auto", note: "Phrasal verb WordNet ; traduction alignée par sens (WOLF), non relue" }) }); }
  const by = {}; idiom.forEach(i => by[i.lang + " " + i.kind] = (by[i.lang + " " + i.kind] || 0) + 1);
  log("  " + Object.entries(by).map(([k, v]) => k + " : " + v).join(" · "));
  return { counts: writeBase("idioms", { idiom }, { csv: ["idiom"] }), qa };
}
