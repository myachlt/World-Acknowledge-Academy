# World Knowledge Academy : bases de données

Ce dossier contient les bases de l'application, construites à partir de sources identifiées. Il fournit les connecteurs, les scripts d'import, la synchronisation, le contrôle qualité, une base SQLite et l'export vers l'application.

Ce ne sont pas des API branchées : les données sont téléchargées, contrôlées, puis stockées. On les trouve dans `db/data/` (JSON, plus CSV pour les grandes tables) et dans `db/wka.sqlite`.

## Utilisation

```
node db/run.mjs                      # reconstruit les 16 bases (télécharge ce qui manque, cache dans db/raw/)
node db/run.mjs --only=stats,quiz    # seulement certaines bases
node db/run.mjs --offline            # sans réseau, depuis le cache
node db/run.mjs --refresh            # force le re-téléchargement
node db/enrich/wiktionary.mjs es     # enrichit le vocabulaire (genre, API, exemples) depuis le Wiktionnaire (reprise possible)
node db/build_sqlite.mjs             # charge tout dans db/wka.sqlite et contrôle l'intégrité
node db/report.mjs                   # rapport qualité : db/data/_quality/RAPPORT_QUALITE.md et report.json
node db/export_app.mjs               # extrait embarqué dans l'application : src/data/db_export.js
node db/sync.mjs [--run]             # péremption + échéancier des sources (+ reconstruction des bases dues)
node db/import/batch.mjs lot.json [--dry-run] [--reviewed-by=Nom]   # import contrôlé d'un lot externe
node build.mjs                       # reconstruit l'application (dist/)
```

Pour la synchronisation automatique, planifier une fois par jour `node db/sync.mjs --run`, via cron, une tâche planifiée ou GitHub Actions. Le réseau doit autoriser les hôtes suivants : api.worldbank.org, hdr.undp.org, query.wikidata.org, www.wikidata.org, raw.githubusercontent.com et kaikki.org.

## Les 16 bases (état au 22 novembre 2026)

| # | Base | Contenu | Sources |
|---|---|---|---|
| 1 | Countries | 250 pays et territoires (194 États souverains), 324 frontières, 153 langues, 160 monnaies | mledoze/countries (miroir REST Countries), ISO 4217, ISO 3166, Wikidata ; recoupé avec la maquette |
| 2 | Geography | 602 villes dont 202 capitales, 1 500 éléments physiques (fleuves, sommets, lacs, mers…) | Natural Earth, GeoNames, Wikidata (longueurs, altitudes recoupées à ±10 m) |
| 3 | World Statistics | 25 indicateurs, 114 397 observations depuis 2000, chacune avec son année | Banque mondiale (21 indicateurs), PNUD (IDH), Our World in Data (CO2, énergie) |
| 4 | Politics | 198 fiches pays (régime, chef d'État et de gouvernement), 11 systèmes politiques, 19 institutions | Wikidata (validité 60 jours), lot rédigé |
| 5 | World History | 66 événements datés, 119 personnalités, 130 mandats (dates de début et de fin), 146 prix Nobel de la paix | Wikidata, lot rédigé |
| 6 | International Organizations | 38 organisations, 637 adhésions | Sites officiels (lot rédigé), recoupés avec Wikidata (P463) |
| 7 | English Vocabulary | 9 777 mots, 20 545 sens, 62 841 traductions rattachées au sens, 571 verbes à particule, synonymes et antonymes | CEFR-J, Octanove, WordNet 3.0, OMW (WOLF, MCR), Wiktionnaire, ipa-dict, FrequencyWords |
| 8 | Spanish Vocabulary | 8 788 mots (genre, API, exemples) | même chaîne, alignée par sens sur l'anglais |
| 9 | French Vocabulary | 8 757 mots | même chaîne |
| 10 | Grammar | 569 points de grammaire, 149 verbes irréguliers anglais (tous confirmés par WordNet), 664 formes conjuguées | CEFR-J Grammar Profile, lot rédigé, maquette |
| 11 | Idioms | 351 expressions et faux amis | WordNet, maquette |
| 12 | Practical Knowledge | 23 fiches (logement, consommation, finances, santé, numérique, papiers, droit) avec montants et délais datés | Service-Public.fr, Légifrance (rédigé, validité 180 jours) |
| 13 | Professional Knowledge | 8 fiches (contrat de travail, rupture, congés…) | idem |
| 14 | Science | 118 éléments (tous recoupés), 8 planètes, 14 unités du SI | Wikidata, table périodique Bowserinator, maquette |
| 15 | Quiz Database | 11 271 questions validées, 22 importées par lot (en attente de relecture), 42 rejetées | migrées de la maquette, générées depuis les bases, lots |
| 16 | Learning Resources | 109 ressources (fiches, 31 profils pays, mises en situation, fiches pratiques), 1 325 liens dont 1 213 vers des questions | maquette, bases 12-13 |

`db/wka.sqlite` contient 318 783 lignes dans 46 tables. Le contrôle ne trouve aucune clé étrangère en défaut et aucune provenance orpheline. Le schéma documenté est `schema/schema.sql`. Le schéma effectif est régénéré à chaque chargement dans `schema/schema_effective.sql`.

## Identifiants et relations

Chaque objet porte un identifiant stable et préfixé :

- `cty:FRA`, `city:…`, `geo:…`, `ind:SP.POP.TOTL`, `org:UN`, `person:Q…`, `ev:1789:…`, `el:26`
- `lex:en:house:noun`, avec son sens `lex:en:house:noun#1`
- `gram:…`, `idiom:…`, `kc:prat:finances-tva`, `q:geo:cap:FRA`, `res:profil:FRA`

Les relations sont portées par :

- `country_border`, `country_language`, `country_currency`, `feature_country`, `membership`
- `office_term`, `lexeme_link` (mot espagnol ou français ↔ sens anglais), `lexical_relation`
- `question_link` (question ↔ pays, organisation, fiche, lexème…), `resource_link` (ressource ↔ connaissances et questions)

## Provenance : chaque donnée est tracée

Chaque ligne porte un `prov_id`. La provenance (`_core/provenance.json`) indique :

- la source et sa licence (`sources.json`, 26 sources) ;
- la récupération (`_core/fetch.json` : URL, date de récupération, date de mise à jour annoncée par la source, empreinte SHA-256) ;
- l'année de référence de la donnée ;
- la date de vérification et la date de validité ;
- un statut de vérification.

Les statuts possibles sont les suivants :

- `verified` : vérifié sur un étalon ;
- `cross_checked` : deux sources indépendantes concordent ;
- `source_trusted` : une seule source officielle ;
- `editorial` : rédigé et relu ;
- `auto` ;
- `estimated` : par exemple, un niveau de langue déduit ;
- `needs_review` ;
- `conflict` ;
- `stale` ;
- `rejected`.

Règles appliquées :

- **Une valeur manquante reste vide.** Par exemple, la population d'une ville sans année reçoit une note « année non précisée ».
- **L'année d'une statistique est celle à laquelle elle se rapporte, pas celle du téléchargement.** Une donnée mise à jour automatiquement n'est donc pas pour autant annuelle.
- **Les données d'actualité ont une validité limitée** : dirigeants 60 jours, listes de membres 120 jours, montants et règles pratiques 180 jours. Une fois périmée, une donnée ne produit plus de question.
- **Licences respectées.** Seules des sources libres ou citables sont utilisées. Le dictionnaire de prononciation britannique, sous GPL, est écarté. Les textes officiels sont reformulés, jamais recopiés en masse.

## Contrôle qualité

- **Données** : chaque pipeline recoupe ses sources et inscrit les écarts dans `_quality/pipeline_issues.json` (1 325 signalements). Exemples :
  - capitales périmées dans Natural Earth ;
  - longueurs de fleuves contradictoires ;
  - dirigeants divergents entre Wikidata et la maquette ;
  - sauts de population ;
  - liste OPEP de la maquette sans la Guinée équatoriale.
- **Questions** (`lib/qa.mjs`), règles vérifiées sur chaque question :
  - champs obligatoires, format et difficulté ;
  - 4 propositions distinctes, réponse présente parmi les propositions ;
  - texte cassé ;
  - provenance connue et utilisable, donnée non périmée ;
  - doublon exact (rejet) et quasi-doublon (signalé).
- **Traductions** : chaque traduction est rattachée à un sens (synset WordNet), puis recoupée avec le Wiktionnaire. Elle est mesurée sur l'étalon de 144 mots de l'application : la traduction principale est juste 121 fois sur 144 en français et 112 fois sur 144 en espagnol. Seules les traductions recoupées ou vérifiées sont embarquées dans l'application.
- **Lots externes** (`import/`, ChatGPT, contributeurs) : voir `import/CONSIGNES_LOTS.md`.
  - Ils passent les mêmes règles que ci-dessus.
  - S'y ajoutent : source obligatoire, date de vérification, vérification de la réponse contre les bases (capitale, monnaie, continent, symbole chimique, date ou siège d'une organisation, traduction), et validité de 180 jours pour les thèmes sensibles.
  - Sans relecture humaine, une question importée n'est pas servie aux joueurs.
  - Le jeu d'essai `import/tests/lot_fautif.json` montre les 7 rejets attendus.

## Intégration dans l'application

`db/export_app.mjs` embarque dans l'application :

- 686 questions issues des bases, uniquement des données utilisables : statistiques datées, membres d'organisations, dates de création, titulaires de fonctions, prix Nobel de la paix, frontières ;
- un dictionnaire de référence de 4 396 mots anglais et 4 619 mots espagnols ;
- l'état des bases.

La page « Données et sources » de l'application affiche les volumes, les statuts, la fraîcheur, les sources et les licences, ainsi que le contrôle des questions. Elle propose aussi une recherche dans le dictionnaire, avec ajout au dictionnaire personnel.

## Limites connues

- **Contenus pratiques et professionnels** : rédigés d'après Service-Public.fr, ils demandent une relecture juridique avant publication.
- **Dirigeants** : 5 conflits entre Wikidata et la maquette ne produisent aucune question tant qu'ils ne sont pas tranchés.
- **Niveaux CECRL espagnols et français** : ce sont des estimations. Les niveaux anglais viennent de CEFR-J et d'Octanove.
- **Traductions automatiques** : même recoupée, une traduction peut garder un sens secondaire. Par exemple, « carbon » est traduit par « charbon ». C'est pourquoi le statut reste visible.
- **Exemples** : les exemples de phrases en français sont rares, car le Wiktionnaire français en fournit peu sous une forme exploitable.
- **Organisations** : les listes de membres rédigées (état de juin 2026) sont périmées depuis le 28 octobre 2026, sauf celles que Wikidata confirme. Il faut les revérifier.
- **Lots** : le premier lot (`culture-generale-lot-01`, 22 questions) attend une relecture humaine. Aucun lot ChatGPT n'a été produit, faute d'accès.
