Lot test-lot-fautif : 0 acceptées, 7 rejetées {"answer_contradicts_data":3,"missing_source":1,"duplicate":1,"answer_not_in_choices":1,"stale":2}
# Lot test-lot-fautif

Auteur : Test de contrôle qualité (jeu d'essai) · créé le 2026-11-22 · importé le 2026-11-22
Licence déclarée : Jeu d'essai
Relecture humaine : non (questions au statut needs_review, non servies aux joueurs)

**0 acceptées, 7 rejetées** sur 7.

## Rejets

- `q:geo:imp:t-capitale-fausse` Quelle est la capitale du Canada ?
  - **answer_contradicts_data** : Capitale de Canada = Ottawa : la réponse contredit la base
- `q:hist:imp:t-sans-source` En quelle année a eu lieu la bataille de Marignan ?
  - **missing_source** : Source absente (URL ou référence exigée)
- `q:sci:imp:t-doublon` Quel est le symbole chimique de l'élément « or » ?
  - **duplicate** : Doublon exact de q:sci:sym:Au
- `q:geo:imp:t-reponse-absente` Quel est le plus long fleuve du monde ?
  - **answer_not_in_choices** : La bonne réponse ne figure pas parmi les propositions
- `q:pol:imp:t-perime` Qui est le Premier ministre du Royaume-Uni en 2024 ?
  - **stale** : Donnée périmée depuis le 2024-08-28
  - **stale** : Thème sensible vérifié le 2024-03-01 : plus de 180 jours
- `q:sci:imp:t-symbole-faux` Quel est le symbole chimique du fer ?
  - **answer_contradicts_data** : Symbole de fer = Fe : la réponse contredit la base
- `q:hist:imp:t-org-annee` En quelle année a été créée l'OTAN ?
  - **answer_contradicts_data** : Création de OTAN = 1949 : la réponse contredit la base

## Acceptées

