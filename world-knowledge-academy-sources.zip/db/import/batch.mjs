// Import d'un lot éditorial externe (questions rédigées par une IA générative, un contributeur…).
// Usage : node db/import/batch.mjs <lot.json> [--dry-run] [--reviewed-by="Nom"]
//
// Le lot passe exactement les mêmes règles que les questions générées (lib/qa.mjs), plus des contrôles propres aux lots :
//  - source obligatoire (URL ou référence) et date de vérification plausible ;
//  - liens vers les connaissances : chaque identifiant cité doit exister dans les bases ;
//  - vérification de la réponse contre les bases quand c'est possible (capitale, monnaie, continent, symbole chimique,
//    année de création ou siège d'une organisation, traduction d'un mot) : une contradiction rejette la question ;
//  - doublons exacts (rejet) et quasi-doublons (signalés) contre toute la base Quiz et les lots déjà importés ;
//  - thèmes sensibles (politique, droit, économie, actualité) : validité limitée à 180 jours et relecture humaine obligatoire.
// Sans --reviewed-by, toute question acceptée entre au statut « needs_review » : elle est stockée mais pas servie aux joueurs.
import fs from "node:fs";
import path from "node:path";
import { OUT, DB, TODAY, prov, provs, editorialFetch, readBase, norm, slug, addDays, flushProvenance, fetches } from "../lib/core.mjs";
import { checkQuestion, contentKey, FORMATS, SENSITIVE_CATS } from "../lib/qa.mjs";

const args = process.argv.slice(2);
const file = args.find(a => !a.startsWith("--"));
const DRY = args.includes("--dry-run");
const reviewer = (args.find(a => a.startsWith("--reviewed-by=")) || "").slice(14) || null;
if (!file) { console.error("Usage : node db/import/batch.mjs <lot.json> [--dry-run] [--reviewed-by=Nom]"); process.exit(1); }

const lot = JSON.parse(fs.readFileSync(file, "utf8"));
const meta = lot.batch || {};
const errors = [];
for (const k of ["id", "author", "created_at", "license_declaration"]) if (!meta[k]) errors.push(`batch.${k} manquant`);
if (!Array.isArray(lot.items) || !lot.items.length) errors.push("items vide");
if (errors.length) { console.error("Lot refusé : " + errors.join(", ")); process.exit(2); }
const batchId = "batch:" + slug(meta.id);

// ---------- Index des connaissances existantes ----------
const C = readBase("countries", "country"); const CBY = new Map(C.map(c => [c.id, c]));
const CUR = new Map(readBase("countries", "currency").map(x => [x.id, x])); const CC = readBase("countries", "country_currency");
const ORG = readBase("organizations", "organization"); const EL = readBase("science", "element");
const CARDS = [...readBase("practical", "knowledge_card"), ...readBase("professional", "knowledge_card")];
const known = new Set();
for (const [base, table] of [["countries", "country"], ["organizations", "organization"], ["science", "element"], ["science", "planet"], ["science", "unit"], ["history", "person"], ["history", "event"], ["practical", "knowledge_card"], ["professional", "knowledge_card"], ["vocab_en", "lexeme"], ["vocab_es", "lexeme"], ["grammar", "grammar_point"], ["idioms", "idiom"], ["stats", "indicator"], ["resources", "resource"]])
  try { readBase(base, table).forEach(r => known.add(r.id)); } catch { }
const CONT = { AF: "Afrique", EU: "Europe", AS: "Asie", NA: "Amérique du Nord", SA: "Amérique du Sud", OC: "Océanie", AN: "Antarctique" };
const vocab = {}; for (const l of ["en", "es"]) { vocab[l] = new Map(); try { readBase("vocab_" + l, "lexeme").forEach(x => { const k = norm(x.lemma); (vocab[l].get(k) || vocab[l].set(k, []).get(k)).push(x); }); } catch { } }
const transl = {}; for (const l of ["en", "es"]) try { transl[l] = new Map(); readBase("vocab_" + l, "translation").forEach(t => { if (t.target_lang !== "fr") return; const lid = t.sense_id.split("#")[0]; (transl[l].get(lid) || transl[l].set(lid, new Set()).get(lid)).add(norm(t.text)); }); } catch { transl[l] = new Map(); }

// Questions existantes (base Quiz + lots déjà importés, sauf ce lot s'il est ré-importé)
const IMPORTED = path.join(OUT, "quiz/imported.json");
const prevImported = fs.existsSync(IMPORTED) ? JSON.parse(fs.readFileSync(IMPORTED, "utf8")) : [];
const existing = [...readBase("quiz", "question"), ...prevImported.filter(q => q.batch_id !== batchId)];
const keyIndex = new Map(existing.map(q => [q.content_key, q.id]));
const tokens = s => new Set(norm(s).split(" ").filter(w => w.length > 2));
const byAnswer = new Map(); existing.forEach(q => { const k = norm(typeof q.answer === "string" ? q.answer : JSON.stringify(q.answer)); (byAnswer.get(k) || byAnswer.set(k, []).get(k)).push(q); });

// ---------- Vérification de la réponse contre les bases ----------
function verifyAnswer(q, links) {
  const P = norm(q.prompt), A = norm(String(q.answer)); const out = [];
  const countries = links.map(id => CBY.get(id)).filter(Boolean);
  const say = (ok, what) => out.push(ok ? { rule: "answer_confirmed", severity: "info", message: what + " : conforme à la base" } : { rule: "answer_contradicts_data", severity: "error", message: what + " : la réponse contredit la base" });
  for (const c of countries) {
    if (/capitale/.test(P) && c.capital_name && A !== norm(c.capital_name) && !A.includes(norm(c.capital_name)) && !(c.capital_name_en && A === norm(c.capital_name_en))) {
      if (norm(q.prompt).includes(norm(c.name_fr))) say(false, `Capitale de ${c.name_fr} = ${c.capital_name}`);
    } else if (/capitale/.test(P) && c.capital_name && norm(q.prompt).includes(norm(c.name_fr))) say(true, `Capitale de ${c.name_fr}`);
    if (/monnaie|devise/.test(P) && norm(q.prompt).includes(norm(c.name_fr))) { const cur = CC.filter(x => x.country_id === c.id).map(x => CUR.get(x.currency_id)).filter(Boolean);
      if (cur.length) say(cur.some(k => A.includes(norm(k.name_fr || k.name_en || "")) || A.includes(norm(k.code || ""))), `Monnaie de ${c.name_fr} = ${cur.map(k => k.name_fr || k.name_en).join(" / ")}`); }
    if (/continent/.test(P) && CONT[c.continent] && Object.values(CONT).some(v => A === norm(v)) && norm(q.prompt).includes(norm(c.name_fr))) say(A === norm(CONT[c.continent]), `Continent de ${c.name_fr} = ${CONT[c.continent]}`);
  }
  for (const id of links.filter(x => x.startsWith("org:"))) { const o = ORG.find(x => x.id === id); if (!o) continue;
    if (/annee|cree|fondee|fonde/.test(P) && /^\d{4}$/.test(A) && o.founded) say(+A === o.founded, `Création de ${o.acronym_fr || o.name_fr} = ${o.founded}`);
    if (/siege/.test(P) && o.hq_city) say(A.includes(norm(o.hq_city.split(" (")[0])), `Siège de ${o.acronym_fr || o.name_fr} = ${o.hq_city}`); }
  for (const id of links.filter(x => x.startsWith("el:"))) { const e = EL.find(x => x.id === id); if (!e) continue;
    if (/symbole/.test(P)) say(A === norm(e.symbol), `Symbole de ${e.name_fr} = ${e.symbol}`); }
  if (["en", "es"].includes(q.category) && ["translation", "mcq"].includes(q.format)) {
    const m = q.prompt.match(/[«"]\s*([^»"]+?)\s*[»"]/); if (m) { const lex = vocab[q.category].get(norm(m[1])) || [];
      if (lex.length) { const ok = lex.some(l => (transl[q.category].get(l.id) || new Set()).has(A) || norm(l.fr || "") === A);
        out.push(ok ? { rule: "translation_confirmed", severity: "info", message: `Traduction de « ${m[1]} » confirmée par la base` } : { rule: "translation_unconfirmed", severity: "warn", message: `Traduction de « ${m[1]} » absente de la base : à vérifier` }); } }
  }
  return out;
}

// ---------- Contrôle de chaque question ----------
const f = editorialFetch(path.resolve(file)); f.source_id = "external_batch"; f.via = "batch"; fetches.set(f.id, f);
const accepted = [], rejected = [];
const seenInBatch = new Map();
for (const [i, it] of lot.items.entries()) {
  const sensitive = SENSITIVE_CATS.has(it.category) || it.nature === "contemp";
  const vdate = it.verification_date || null;
  const status = !reviewer ? "needs_review" : "editorial";
  const valid_until = sensitive ? addDays(vdate || TODAY, 180) : null;
  const source = it.source || {};
  const p = prov({ fetch: f, source: "external_batch", status, checked_at: vdate, valid_until, note: [`Lot ${meta.id} (${meta.author}${meta.tool ? ", " + meta.tool : ""})`, reviewer ? "relu par " + reviewer : "relecture humaine requise", source.url || source.text].filter(Boolean).join(" · ") });
  const q = { id: it.id ? "q:" + it.category + ":imp:" + slug(it.id) : `q:${it.category}:imp:${slug(meta.id)}:${i + 1}`, category: it.category, subcategory: it.subcategory || null, difficulty: it.difficulty,
    format: it.format, prompt: it.question, payload: it.payload || null, choices: it.choices || null, answer: it.answer, explanation: it.explanation, anecdote: it.anecdote || null, context: it.context || null,
    keywords: it.keywords || null, generator: null, nature: it.nature || (sensitive ? "contemp" : "stable"), source_text: [source.text, source.url].filter(Boolean).join(" — ") || null,
    prov_id: p, verified_at: vdate, status, batch_id: batchId };
  q.content_key = contentKey(q.prompt, q.answer);
  const links = (it.linked_ids || []).filter(Boolean);
  // Le statut needs_review du lot est voulu (relecture en attente) : seule la règle source_status est ignorée ici
  const issues = checkQuestion(q, { provs }).filter(x => x.rule !== "source_status");
  const E = (rule, message) => issues.push({ rule, severity: "error", message }); const W = (rule, message) => issues.push({ rule, severity: "warn", message });
  if (!source.url && !source.text) E("missing_source", "Source absente (URL ou référence exigée)");
  if (source.url && !/^https:\/\//.test(source.url)) W("source_url", "URL de source non sécurisée ou invalide");
  if (!vdate || !/^\d{4}-\d{2}-\d{2}$/.test(vdate)) E("verification_date", "Date de vérification absente ou mal formée (AAAA-MM-JJ)");
  else if (vdate > TODAY) E("verification_date", "Date de vérification dans le futur");
  else if (sensitive && addDays(vdate, 180) < TODAY) E("stale", `Thème sensible vérifié le ${vdate} : plus de 180 jours`);
  if (!it.anecdote) W("anecdote", "Anecdote absente");
  if (!Array.isArray(it.keywords) || !it.keywords.length) W("keywords", "Mots-clés absents");
  const unknown = links.filter(id => !known.has(id)); if (unknown.length) W("unknown_link", "Identifiants inconnus : " + unknown.join(", "));
  if (!links.length) W("no_link", "Question reliée à aucune connaissance");
  if (it.category === "prat" && !links.some(id => id.startsWith("kc:"))) W("no_card", "Question pratique non reliée à une fiche");
  issues.push(...verifyAnswer(q, links.filter(id => known.has(id))));
  if (keyIndex.has(q.content_key)) E("duplicate", "Doublon exact de " + keyIndex.get(q.content_key));
  if (seenInBatch.has(q.content_key)) E("duplicate", "Doublon dans le lot : " + seenInBatch.get(q.content_key));
  const same = byAnswer.get(norm(typeof q.answer === "string" ? q.answer : JSON.stringify(q.answer))) || []; const tk = tokens(q.prompt);
  for (const o of same) { const to = tokens(o.prompt); let n = 0; tk.forEach(w => to.has(w) && n++); const j = n / (tk.size + to.size - n || 1); if (j >= 0.7) { W("near_duplicate", `Proche de ${o.id} (Jaccard ${j.toFixed(2)})`); break; } }
  const rec = { id: q.id, prompt: q.prompt, issues };
  if (issues.some(x => x.severity === "error")) { rejected.push(rec); continue; }
  seenInBatch.set(q.content_key, q.id);
  if (issues.some(x => x.rule === "answer_confirmed" || x.rule === "translation_confirmed") && !issues.some(x => x.severity === "warn")) q.answer_checked = true;
  q.qa = issues.filter(x => x.severity !== "info").map(x => x.message);
  accepted.push({ q, links, issues });
}

// ---------- Rapport ----------
const outDir = path.join(OUT, "imports", slug(meta.id)); const rules = {};
rejected.forEach(r => r.issues.filter(x => x.severity === "error").forEach(x => rules[x.rule] = (rules[x.rule] || 0) + 1));
const md = [`# Lot ${meta.id}`, "", `Auteur : ${meta.author}${meta.tool ? " (" + meta.tool + ")" : ""} · créé le ${meta.created_at} · importé le ${TODAY}`, `Licence déclarée : ${meta.license_declaration}`, `Relecture humaine : ${reviewer || "non (questions au statut needs_review, non servies aux joueurs)"}`, "",
  `**${accepted.length} acceptées, ${rejected.length} rejetées** sur ${lot.items.length}.`, "",
  rejected.length ? "## Rejets\n\n" + rejected.map(r => `- \`${r.id}\` ${r.prompt}\n` + r.issues.filter(x => x.severity === "error").map(x => `  - **${x.rule}** : ${x.message}`).join("\n")).join("\n") : "",
  "", "## Acceptées\n", ...accepted.map(({ q, issues }) => `- \`${q.id}\` ${q.prompt} → **${q.answer}**` + (issues.length ? "\n" + issues.map(x => `  - ${x.severity === "info" ? "✓" : "⚠"} ${x.rule} : ${x.message}`).join("\n") : ""))].join("\n");
console.log(`Lot ${meta.id} : ${accepted.length} acceptées, ${rejected.length} rejetées ${JSON.stringify(rules)}`);
if (DRY) { console.log(md); process.exit(0); }
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "accepted.json"), JSON.stringify(accepted.map(a => a.q), null, 1));
fs.writeFileSync(path.join(outDir, "rejected.json"), JSON.stringify(rejected, null, 1));
fs.writeFileSync(path.join(outDir, "report.md"), md);
// Questions importées (fusion : un lot ré-importé remplace sa version précédente) et liens
const imported = prevImported.filter(q => q.batch_id !== batchId).concat(accepted.map(a => a.q));
fs.writeFileSync(IMPORTED, JSON.stringify(imported, null, 1));
const LF = path.join(OUT, "quiz/imported_link.json"); const prevL = fs.existsSync(LF) ? JSON.parse(fs.readFileSync(LF, "utf8")) : [];
const ids = new Set(accepted.map(a => a.q.id)); const oldIds = new Set(prevImported.filter(q => q.batch_id === batchId).map(q => q.id));
fs.writeFileSync(LF, JSON.stringify(prevL.filter(l => !ids.has(l.question_id) && !oldIds.has(l.question_id)).concat(accepted.flatMap(a => a.links.filter(id => known.has(id)).map(t => ({ question_id: a.q.id, target_id: t, role: t.split(":")[0] })))), null, 1));
// Registre des lots
const BF = path.join(OUT, "imports/import_batch.json"); const batches = fs.existsSync(BF) ? JSON.parse(fs.readFileSync(BF, "utf8")) : [];
fs.writeFileSync(BF, JSON.stringify(batches.filter(b => b.id !== batchId).concat([{ id: batchId, base: "quiz", file: path.relative(DB, path.resolve(file)), author: meta.author + (meta.tool ? " (" + meta.tool + ")" : ""), received_at: TODAY, accepted: accepted.length, rejected: rejected.length, reviewed_by: reviewer, report: path.relative(DB, path.join(outDir, "report.md")) }]), null, 1));
flushProvenance();
console.log("Rapport : " + path.relative(process.cwd(), path.join(outDir, "report.md")));
