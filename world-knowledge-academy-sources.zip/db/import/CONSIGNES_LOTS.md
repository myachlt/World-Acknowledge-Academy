# Lots éditoriaux externes : consignes et contrôle

Un lot est un fichier JSON au format de `template_quiz.json`. Il peut être rédigé par une personne ou par une IA générative (ChatGPT, Claude…). Il entre dans la base par une seule porte :

```
node db/import/batch.mjs db/import/inbox/mon-lot.json --dry-run            # contrôle sans rien écrire
node db/import/batch.mjs db/import/inbox/mon-lot.json                      # import, questions au statut needs_review
node db/import/batch.mjs db/import/inbox/mon-lot.json --reviewed-by="Mya"  # import après relecture humaine
```

## Ce que vérifie l'import

| Règle | Effet |
|---|---|
| Champs obligatoires, format connu, difficulté 1-6, 4 propositions (2 en vrai/faux), réponse présente parmi les propositions, propositions distinctes | rejet |
| Texte cassé (undefined, NaN, null) | rejet |
| Source absente (URL ou référence) | rejet |
| Date de vérification absente, mal formée ou dans le futur | rejet |
| Thème sensible (politique, droit, économie, actualité) vérifié il y a plus de 180 jours | rejet |
| Réponse contredite par les bases (capitale, monnaie, continent, symbole chimique, année de création ou siège d'une organisation) | rejet |
| Doublon exact d'une question existante ou d'une autre question du lot | rejet |
| Quasi-doublon (mêmes mots à 70 % et même réponse) | signalé |
| Traduction absente du dictionnaire de la base | signalé |
| Identifiant de connaissance inconnu, question non reliée, question pratique sans fiche | signalé |
| Réponse dans la question, explication trop courte, anecdote ou mots-clés absents | signalé |

Chaque question acceptée reçoit une provenance « external_batch » qui garde le lot, l'auteur, l'outil, la source citée, la date de vérification et le nom du relecteur. Sans relecture (`--reviewed-by`), elle reste au statut `needs_review` : elle est stockée et visible dans le rapport, mais l'application ne la sert pas aux joueurs.

Sorties : `db/data/imports/<lot>/report.md`, `accepted.json`, `rejected.json` ; questions dans `db/data/quiz/imported.json` (ré-importer un lot remplace sa version précédente) ; registre dans `db/data/imports/import_batch.json`.

## Consigne à donner à une IA générative

> Rédige N questions de culture générale en français pour World Knowledge Academy, au format JSON du modèle joint. Règles :
> 1. Chaque question porte sur un fait vérifiable et cite une source précise (URL officielle ou encyclopédique) que tu as réellement consultée, avec la date de vérification. Si tu n'es pas certain d'un fait, n'écris pas la question.
> 2. Pas de reprise de texte protégé : reformule toujours.
> 3. Quatre propositions plausibles et de même nature (quatre années, quatre villes…), une seule bonne réponse, la réponse ne doit pas apparaître dans la question.
> 4. L'explication dit pourquoi la réponse est juste en une ou deux phrases ; l'anecdote apporte un fait complémentaire.
> 5. Pour une donnée qui peut changer (dirigeant, chiffre, loi, tarif), mets "nature": "contemp" et indique l'année de la donnée dans la question (« en 2025 »).
> 6. Relie chaque question aux identifiants de connaissances fournis (pays cty:ISO3, organisations org:…, éléments el:numéro, fiches kc:…).

Une IA qui écrit « je ne peux pas vérifier » ou ne donne pas de source produit des questions qui seront rejetées : c'est voulu.
