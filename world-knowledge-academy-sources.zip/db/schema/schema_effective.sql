-- Schéma effectif de db/wka.sqlite, généré par db/build_sqlite.mjs le 2026-11-22
CREATE VIEW latest_observation AS
  SELECT o.* FROM observation o
  WHERE o.year = (SELECT MAX(year) FROM observation o2 WHERE o2.entity_id = o.entity_id AND o2.indicator_id = o.indicator_id);

CREATE TABLE aggregate (id TEXT PRIMARY KEY, name_fr TEXT NOT NULL);

CREATE TABLE award (award TEXT NOT NULL, year INTEGER NOT NULL, laureate TEXT NOT NULL, laureate_id TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE card_link (card_id TEXT REFERENCES knowledge_card(id), target_id TEXT NOT NULL, PRIMARY KEY (card_id, target_id));

CREATE TABLE city (
  id TEXT PRIMARY KEY,                 -- city:<geonameid> ou city:ne:<id>
  name TEXT NOT NULL, name_fr TEXT, country_id TEXT REFERENCES country(id),
  is_capital INTEGER, population INTEGER, population_year INTEGER, lat REAL, lon REAL,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
, "population_note", "capital_check");

CREATE TABLE country (
  id TEXT PRIMARY KEY,                 -- cty:FRA (ISO 3166-1 alpha-3)
  iso2 TEXT UNIQUE, iso3 TEXT UNIQUE NOT NULL, m49 TEXT,
  name_fr TEXT NOT NULL, name_en TEXT NOT NULL, name_es TEXT,
  official_fr TEXT, official_en TEXT, official_es TEXT,
  kind TEXT NOT NULL,                  -- 'sovereign' | 'territory' | 'disputed'
  sovereign_id TEXT REFERENCES country(id), -- pour un territoire
  un_member INTEGER, continent TEXT, region TEXT, subregion TEXT,
  capital_city_id TEXT REFERENCES city(id), capital_name TEXT,
  area_km2 REAL, lat REAL, lon REAL, landlocked INTEGER,
  tld TEXT, calling_code TEXT, flag_emoji TEXT, demonym_fr TEXT, demonym_en TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
, "capital_name_en", "wikidata", "in_app");

CREATE TABLE country_border (a TEXT REFERENCES country(id), b TEXT REFERENCES country(id), prov_id TEXT REFERENCES provenance(id), PRIMARY KEY (a, b));

CREATE TABLE country_currency (country_id TEXT REFERENCES country(id), currency_id TEXT REFERENCES currency(id), prov_id TEXT REFERENCES provenance(id), PRIMARY KEY (country_id, currency_id));

CREATE TABLE country_language (country_id TEXT REFERENCES country(id), language_id TEXT REFERENCES language(id), official INTEGER, prov_id TEXT REFERENCES provenance(id), PRIMARY KEY (country_id, language_id));

CREATE TABLE country_politics (
  country_id TEXT PRIMARY KEY REFERENCES country(id), system_id TEXT REFERENCES political_system(id),
  head_of_state TEXT, head_of_state_since TEXT, head_of_government TEXT, head_of_government_since TEXT,
  legislature TEXT, prov_id TEXT NOT NULL REFERENCES provenance(id)  -- valid_until obligatoire (donnée d'actualité)
, "system_basis");

CREATE TABLE currency (id TEXT PRIMARY KEY, code TEXT, name_en TEXT, name_fr TEXT, symbol TEXT, numeric_code TEXT, "in_iso4217");

CREATE TABLE element (id TEXT PRIMARY KEY, number INTEGER UNIQUE NOT NULL, symbol TEXT NOT NULL, name_fr TEXT, name_en TEXT, category_en TEXT, category_fr TEXT, atomic_mass REAL, phase TEXT, discovered_by TEXT, year INTEGER, note_fr TEXT, status TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE event (
  id TEXT PRIMARY KEY, name_fr TEXT NOT NULL, start TEXT NOT NULL, end TEXT, precision TEXT, -- 'year' | 'month' | 'day'
  period TEXT, theme TEXT, summary_fr TEXT, prov_id TEXT NOT NULL REFERENCES provenance(id)
);

CREATE TABLE event_link (event_id TEXT REFERENCES event(id), target_id TEXT NOT NULL, role TEXT, PRIMARY KEY (event_id, target_id, role));

CREATE TABLE feature_country (feature_id TEXT REFERENCES geo_feature(id), country_id TEXT REFERENCES country(id), method TEXT, PRIMARY KEY (feature_id, country_id));

CREATE TABLE fetch (
  id TEXT PRIMARY KEY,                 -- ex. fetch:worldbank:SP.POP.TOTL:2026-11-22
  source_id TEXT NOT NULL REFERENCES source(id),
  url TEXT NOT NULL, via TEXT NOT NULL, -- 'primary' | 'mirror' | 'editorial'
  retrieved_at TEXT NOT NULL,           -- ISO 8601, date de NOTRE récupération
  source_updated_at TEXT,               -- date de mise à jour annoncée par la source (Last-Modified, métadonnées), sinon NULL
  sha256 TEXT, bytes INTEGER, http_status INTEGER
);

CREATE TABLE geo_feature (
  id TEXT PRIMARY KEY,                 -- geo:peak:everest, geo:river:nile…
  type TEXT NOT NULL,                  -- peak | river | lake | sea | ocean | gulf | desert | range | plateau | plain | island | basin…
  name_en TEXT NOT NULL, name_fr TEXT, continent TEXT,
  elevation_m REAL, length_km REAL, area_km2 REAL, lat REAL, lon REAL,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
, "name_es", "wikidata");

CREATE TABLE grammar_point (id TEXT PRIMARY KEY, lang TEXT NOT NULL, cefr TEXT, title_fr TEXT, title_en TEXT, code TEXT, sentence_type TEXT, rule_fr TEXT, examples TEXT, exercises TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id), CHECK (title_fr IS NOT NULL OR title_en IS NOT NULL));

CREATE TABLE idiom (id TEXT PRIMARY KEY, lang TEXT NOT NULL, text TEXT NOT NULL, meaning_fr TEXT NOT NULL, literal_fr TEXT, equivalent_fr TEXT, example TEXT, cefr TEXT, kind TEXT, prov_id TEXT NOT NULL REFERENCES provenance(id), "false_friend_fr", "definition_en");

CREATE TABLE import_batch (id TEXT PRIMARY KEY, base TEXT NOT NULL, file TEXT, author TEXT, received_at TEXT, accepted INTEGER, rejected INTEGER, report TEXT, "reviewed_by");

CREATE TABLE indicator (
  id TEXT PRIMARY KEY,                 -- ind:SP.POP.TOTL, ind:HDI…
  code TEXT, name_fr TEXT NOT NULL, name_en TEXT, unit TEXT, decimals INTEGER,
  source_id TEXT REFERENCES source(id), definition_fr TEXT, sensitive INTEGER DEFAULT 0
);

CREATE TABLE institution (
  id TEXT PRIMARY KEY, scope TEXT,     -- 'FR' | 'EU' | 'INT'…
  name_fr TEXT NOT NULL, acronym TEXT, role_fr TEXT, composition_fr TEXT, seat TEXT, founded INTEGER,
  parent_id TEXT REFERENCES institution(id), url TEXT, prov_id TEXT NOT NULL REFERENCES provenance(id)
);

CREATE TABLE irregular_verb (id TEXT PRIMARY KEY, lexeme_id TEXT REFERENCES lexeme(id), base TEXT NOT NULL, past TEXT NOT NULL, past_participle TEXT NOT NULL, fr TEXT, status TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE knowledge_card (
  id TEXT PRIMARY KEY,                 -- kc:prat:droit:bail-preavis
  base TEXT NOT NULL,                  -- practical | professional | science | politics | history | geography | organizations
  domain TEXT, title_fr TEXT NOT NULL, summary_fr TEXT NOT NULL, body_fr TEXT,
  jurisdiction TEXT,                   -- 'FR' pour le droit français
  key_figures TEXT,                    -- JSON : montants, seuils, délais avec leur date d'effet
  source_urls TEXT,                    -- JSON
  sensitive INTEGER DEFAULT 0,         -- droit, santé, finances : relecture obligatoire
  prov_id TEXT NOT NULL REFERENCES provenance(id)
, "keywords");

CREATE TABLE language (id TEXT PRIMARY KEY, iso639_3 TEXT, iso639_1 TEXT, name_en TEXT, name_fr TEXT);

CREATE TABLE lexeme (
  id TEXT PRIMARY KEY,                 -- lex:en:house:noun
  lang TEXT NOT NULL,                  -- en | es | fr
  lemma TEXT NOT NULL, pos TEXT NOT NULL,
  cefr TEXT, cefr_basis TEXT,          -- 'cefrj' | 'octanove' | 'frequency_estimate' | 'editorial'
  freq_rank INTEGER, ipa TEXT, ipa_variant TEXT, gender TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id), "variants", "pos_fr", "ipa_uk", "fr", "fr_gender", "es", "es_gender", "theme", "synonyms", "antonyms", "senses", "status", "ipa_source", "en", "definition_en", "example", "example_en",
  UNIQUE (lang, lemma, pos)
);

CREATE TABLE lexeme_link (lexeme_id TEXT NOT NULL REFERENCES lexeme(id), en_lexeme_id TEXT REFERENCES lexeme(id), sense_id TEXT REFERENCES sense(id), confidence REAL, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE lexeme_theme (lexeme_id TEXT REFERENCES lexeme(id), theme_id TEXT REFERENCES theme(id), basis TEXT, PRIMARY KEY (lexeme_id, theme_id));

CREATE TABLE lexical_relation (a TEXT NOT NULL, b TEXT NOT NULL, type TEXT NOT NULL, prov_id TEXT REFERENCES provenance(id), PRIMARY KEY (a, b, type));

CREATE TABLE membership (
  org_id TEXT REFERENCES organization(id), country_id TEXT REFERENCES country(id),
  status TEXT NOT NULL DEFAULT 'member', since INTEGER, prov_id TEXT NOT NULL REFERENCES provenance(id),
  PRIMARY KEY (org_id, country_id, status)
);

CREATE TABLE observation (
  entity_id TEXT NOT NULL,             -- cty:FRA, ou agrégat region:WLD
  indicator_id TEXT NOT NULL REFERENCES indicator(id),
  year INTEGER NOT NULL, value REAL NOT NULL,
  derived INTEGER DEFAULT 0,           -- 1 si calculé (ex. PIB/hab = PIB / population)
  prov_id TEXT NOT NULL REFERENCES provenance(id),
  PRIMARY KEY (entity_id, indicator_id, year)
);

CREATE TABLE office_term (person_id TEXT NOT NULL REFERENCES person(id), office TEXT NOT NULL, start TEXT NOT NULL, "end" TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE organization (
  id TEXT PRIMARY KEY, acronym_fr TEXT, acronym_en TEXT, name_fr TEXT NOT NULL, name_en TEXT,
  founded INTEGER, hq_city TEXT, hq_country_id TEXT REFERENCES country(id), kind TEXT, mission_fr TEXT, url TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
, "note_fr", "wikidata", "expected_members");

CREATE TABLE person (id TEXT PRIMARY KEY, name TEXT NOT NULL, born TEXT, died TEXT, country_id TEXT REFERENCES country(id), role_fr TEXT, summary_fr TEXT, prov_id TEXT NOT NULL REFERENCES provenance(id), "name_missing");

CREATE TABLE phrasal_verb (id TEXT PRIMARY KEY, phrasal TEXT NOT NULL, base_lexeme TEXT REFERENCES lexeme(id), particle TEXT, definition_en TEXT, example TEXT, fr TEXT, usage_count INTEGER, cefr TEXT, cefr_basis TEXT, status TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE planet (id TEXT PRIMARY KEY, name_fr TEXT NOT NULL, "order" INTEGER, kind TEXT, moons INTEGER, fact_fr TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE political_system (id TEXT PRIMARY KEY, name_fr TEXT NOT NULL, definition_fr TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE provenance (
  id TEXT PRIMARY KEY,
  fetch_id TEXT REFERENCES fetch(id),
  source_id TEXT NOT NULL REFERENCES source(id),
  ref_year INTEGER,                    -- année sur laquelle porte la donnée, si pertinente
  valid_until TEXT,                    -- date au-delà de laquelle la donnée doit être revérifiée (actualité, montants…)
  status TEXT NOT NULL REFERENCES verification_status(code),
  checked_at TEXT,                     -- date de la dernière vérification (humaine ou automatique)
  note TEXT
);

CREATE TABLE qa_issue (id INTEGER PRIMARY KEY AUTOINCREMENT, rule TEXT NOT NULL, severity TEXT NOT NULL, target_id TEXT, message TEXT NOT NULL, detected_at TEXT NOT NULL, "base");

CREATE TABLE question (
  id TEXT PRIMARY KEY,                 -- q:<base>:<gabarit>:<clé>
  category TEXT NOT NULL, subcategory TEXT, difficulty INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 6),
  format TEXT NOT NULL,                -- mcq | true_false | cloze | match | translation | visual | reading | listening | reasoning | situation
  prompt TEXT NOT NULL, payload TEXT,  -- JSON : document, image, texte, audio, paires…
  choices TEXT,                        -- JSON
  answer TEXT NOT NULL,                -- JSON
  explanation TEXT NOT NULL, anecdote TEXT, context TEXT,
  keywords TEXT,                       -- JSON
  nature TEXT,                         -- stable (geo, hist, sci, lang) ou contemp (actualité : à revérifier)
  source_text TEXT,                    -- source citée en clair
  status TEXT,                         -- statut de vérification hérité de la donnée source (ou needs_review pour un lot importé)
  batch_id TEXT,                       -- lot d'import externe, NULL sinon
  content_key TEXT NOT NULL,           -- empreinte normalisée pour la détection des doublons
  generator TEXT,                      -- gabarit qui l'a produite, NULL si rédigée
  prov_id TEXT NOT NULL REFERENCES provenance(id),
  verified_at TEXT, "qa", "answer_checked",
  UNIQUE (content_key)
);

CREATE TABLE question_link (question_id TEXT REFERENCES question(id), target_id TEXT NOT NULL, role TEXT, PRIMARY KEY (question_id, target_id));

CREATE TABLE resource (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, -- fiche | profil_pays | mise_en_situation | fiche_pratique | cours | exercice | examen
  title_fr TEXT NOT NULL, level TEXT, base TEXT, body TEXT, tags TEXT, source_text TEXT, as_of TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
);

CREATE TABLE resource_link (resource_id TEXT REFERENCES resource(id), target_id TEXT NOT NULL, role TEXT, PRIMARY KEY (resource_id, target_id));

CREATE TABLE sense (
  id TEXT PRIMARY KEY, lexeme_id TEXT NOT NULL REFERENCES lexeme(id), synset TEXT, rank INTEGER,
  definition_en TEXT, definition_fr TEXT, example TEXT, example_fr TEXT, domain TEXT,
  prov_id TEXT NOT NULL REFERENCES provenance(id)
);

CREATE TABLE source (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, publisher TEXT, homepage TEXT,
  license TEXT NOT NULL, license_url TEXT, attribution TEXT,
  check_every_days INTEGER, data_cadence TEXT
, "access");

CREATE TABLE theme (id TEXT PRIMARY KEY, name_fr TEXT NOT NULL, name_en TEXT, name_es TEXT, parent_id TEXT REFERENCES theme(id));

CREATE TABLE translation (
  sense_id TEXT NOT NULL REFERENCES sense(id), target_lang TEXT NOT NULL, text TEXT NOT NULL,
  confidence REAL, prov_id TEXT NOT NULL REFERENCES provenance(id), "gender",
  PRIMARY KEY (sense_id, target_lang, text)
);

CREATE TABLE unit (id TEXT PRIMARY KEY, quantity_fr TEXT, name_fr TEXT NOT NULL, symbol TEXT NOT NULL, system TEXT, prov_id TEXT REFERENCES provenance(id));

CREATE TABLE verb_form (lang TEXT NOT NULL, lemma TEXT NOT NULL, lexeme_id TEXT REFERENCES lexeme(id), tense TEXT NOT NULL, person TEXT NOT NULL, form TEXT NOT NULL, irregular INTEGER, prov_id TEXT REFERENCES provenance(id), PRIMARY KEY (lang, lemma, tense, person));

CREATE TABLE verification_status (
  code TEXT PRIMARY KEY, label_fr TEXT NOT NULL, usable_in_app INTEGER NOT NULL
);

CREATE INDEX obs_ind_year ON observation(indicator_id, year);
