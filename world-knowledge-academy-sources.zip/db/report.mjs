// Rapport qualité global : node db/report.mjs → db/data/_quality/RAPPORT_QUALITE.md et report.json
// Pour chaque base : volumes, répartition des statuts de vérification, sources et licences, fraîcheur, signalements.
import fs from "node:fs";
import path from "node:path";
import { DB, OUT, TODAY } from "./lib/core.mjs";

const read = f => fs.existsSync(path.join(OUT, f)) ? JSON.parse(fs.readFileSync(path.join(OUT, f), "utf8")) : null;
const provs = new Map(read("_core/provenance.json").map(p => [p.id, p]));
const fetches = read("_core/fetch.json"); const lastFetch = {}; fetches.forEach(f => { if (!lastFetch[f.source_id] || f.retrieved_at > lastFetch[f.source_id]) lastFetch[f.source_id] = f.retrieved_at; });
const SOURCES = JSON.parse(fs.readFileSync(path.join(DB, "sources.json"), "utf8")).sources; const SRC = new Map(SOURCES.map(s => [s.id, s]));
const issues = read("_quality/pipeline_issues.json") || [];
const NAMES = { countries: "1. Countries (pays)", geography: "2. Geography", stats: "3. World Statistics", politics: "4. Politics", history: "5. World History", organizations: "6. International Organizations",
  vocab_en: "7. English Vocabulary", vocab_es: "8. Spanish Vocabulary", vocab_fr: "9. French Vocabulary", grammar: "10. Grammar", idioms: "11. Idioms", practical: "12. Practical Knowledge",
  professional: "13. Professional Knowledge", science: "14. Science", quiz: "15. Quiz Database", resources: "16. Learning Resources" };
const ST_FR = { verified: "vérifié", cross_checked: "recoupé", source_trusted: "source de référence", auto: "automatique", estimated: "estimé", editorial: "rédigé", needs_review: "à revoir", conflict: "conflit", stale: "périmé", rejected: "rejeté" };

const bases = [];
for (const [base, label] of Object.entries(NAMES)) {
  const dir = path.join(OUT, base); if (!fs.existsSync(dir)) { bases.push({ base, label, missing: true }); continue; }
  const tables = {}, status = {}, sources = {}; let rows = 0, withProv = 0, expiring = 0, stale = 0;
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith(".json"))) {
    const data = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")); if (!Array.isArray(data)) continue;
    tables[f.replace(".json", "")] = data.length; rows += data.length;
    for (const r of data) { if (!r.prov_id) continue; const p = provs.get(r.prov_id); if (!p) continue; withProv++;
      const st = p.valid_until && p.valid_until < TODAY ? "stale" : (r.status && base.startsWith("vocab") ? r.status : p.status);
      status[st] = (status[st] || 0) + 1; sources[p.source_id] = (sources[p.source_id] || 0) + 1;
      if (p.valid_until && p.valid_until < TODAY) stale++; else if (p.valid_until && p.valid_until <= new Date(Date.now() + 60 * 864e5).toISOString().slice(0, 10)) expiring++; }
  }
  const iss = issues.filter(i => i.base === base); const bySev = {}; iss.forEach(i => bySev[i.severity] = (bySev[i.severity] || 0) + 1);
  const byRule = {}; iss.forEach(i => byRule[i.rule] = (byRule[i.rule] || 0) + 1);
  bases.push({ base, label, tables, rows, with_provenance: withProv, status, sources: Object.entries(sources).sort((a, b) => b[1] - a[1]).map(([id, n]) => ({ id, rows: n, name: SRC.get(id)?.name, license: SRC.get(id)?.license, last_retrieved: lastFetch[id] || null })),
    stale, expiring_60d: expiring, issues: bySev, issue_rules: byRule });
}
const quizRej = read("_quality/quiz_rejected.json") || []; const imported = read("quiz/imported.json") || []; const batches = read("imports/import_batch.json") || [];
const qs = read("quiz/question.json") || []; const qCat = {}; qs.concat(imported).forEach(q => qCat[q.category] = (qCat[q.category] || 0) + 1);
const qGen = {}; qs.forEach(q => { const k = q.generator ? "générée" : q.batch_id ? "lot importé" : "rédigée"; qGen[k] = (qGen[k] || 0) + 1; });
const sqlite = read("_quality/sqlite_build.json"); const sync = read("_quality/sync_report.json");
const report = { generated_at: new Date().toISOString(), today: TODAY, bases,
  quiz: { accepted: qs.length, imported: imported.length, imported_needs_review: imported.filter(q => q.status === "needs_review").length, rejected: quizRej.length, rejected_rules: quizRej.reduce((a, r) => { r.issues.filter(i => i.severity === "error").forEach(i => a[i.rule] = (a[i.rule] || 0) + 1); return a; }, {}), by_category: qCat, by_origin: qGen, batches },
  sqlite: sqlite && { total_rows: sqlite.total_rows, tables: Object.keys(sqlite.tables).length, bytes: sqlite.bytes, foreign_key_violations: sqlite.foreign_key_violations, orphan_provenance: sqlite.orphan_provenance },
  sync: sync && { checked_at: sync.checked_at, stale_total: sync.stale_total, sources_due: sync.sources_due, schedule: sync.schedule.map(s => ({ source: s.source, last_retrieved: s.last_retrieved, next_check: s.next_check })) },
  sources: SOURCES.map(s => ({ id: s.id, name: s.name, publisher: s.publisher, license: s.license, license_url: s.license_url, attribution: s.attribution, cadence: s.data_cadence, check_every_days: s.check_every_days, last_retrieved: lastFetch[s.id] || null })) };
fs.writeFileSync(path.join(OUT, "_quality/report.json"), JSON.stringify(report, null, 1));

const n = x => Number(x).toLocaleString("fr-FR");
const md = [`# Rapport qualité des bases — ${TODAY}`, "",
  `Base SQLite : ${sqlite ? n(sqlite.total_rows) + " lignes, " + Object.keys(sqlite.tables).length + " tables, " + (sqlite.bytes / 1e6).toFixed(1) + " Mo ; clés étrangères en défaut : " + Object.values(sqlite.foreign_key_violations).reduce((a, b) => a + b, 0) + " ; provenances orphelines : " + Object.values(sqlite.orphan_provenance).reduce((a, b) => a + b, 0) : "non construite"}.`,
  `Synchronisation : ${sync ? sync.stale_total + " provenances périmées ; sources à revérifier : " + (sync.sources_due.join(", ") || "aucune") : "jamais lancée"}.`, "",
  "| Base | Lignes | Statuts de vérification | Périmé | Signalements (erreur / avert. / info) |", "|---|---:|---|---:|---|",
  ...bases.filter(b => !b.missing).map(b => `| ${b.label} | ${n(b.rows)} | ${Object.entries(b.status).sort((x, y) => y[1] - x[1]).map(([k, v]) => `${ST_FR[k] || k} ${n(v)}`).join(", ")} | ${b.stale} | ${b.issues.error || 0} / ${b.issues.warn || 0} / ${b.issues.info || 0} |`),
  "", "## Base Quiz", "", `${n(qs.length)} questions validées (${Object.entries(qGen).map(([k, v]) => k + " " + n(v)).join(", ")}), ${imported.length} importées par lots (${report.quiz.imported_needs_review} en attente de relecture), ${quizRej.length} rejetées par le contrôle (${Object.entries(report.quiz.rejected_rules).map(([k, v]) => k + " " + v).join(", ")}).`,
  "", "Par catégorie : " + Object.entries(qCat).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${n(v)}`).join(" · "),
  "", "## Principaux signalements par base", "",
  ...bases.filter(b => !b.missing && Object.keys(b.issue_rules).length).map(b => `- **${b.label}** : ` + Object.entries(b.issue_rules).sort((x, y) => y[1] - x[1]).slice(0, 6).map(([k, v]) => `${k} (${v})`).join(", ")),
  "", "## Sources et licences", "", "| Source | Licence | Dernière récupération | Revérification |", "|---|---|---|---|",
  ...report.sources.map(s => `| ${s.name} | ${s.license} | ${s.last_retrieved ? s.last_retrieved.slice(0, 10) : "—"} | tous les ${s.check_every_days} j |`)].join("\n");
fs.writeFileSync(path.join(OUT, "_quality/RAPPORT_QUALITE.md"), md + "\n");
console.log(md.split("\n").slice(0, 26).join("\n"));
