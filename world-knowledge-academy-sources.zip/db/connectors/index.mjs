// Connecteurs vers les sources. Chaque connecteur essaie d'abord l'API officielle, puis un miroir ouvert si l'API est injoignable.
// Les données brutes sont mises en cache dans db/raw/<source>/ avec leur date de récupération et leur empreinte.
import { getResource, parseCSV, num } from "../lib/core.mjs";

const GH = "https://raw.githubusercontent.com";

// ---------- Banque mondiale ----------
// API : https://api.worldbank.org/v2/country/all/indicator/<code>?format=json&per_page=20000&date=1990:2030
// Chaque point porte sa propre année ("date") : on la conserve comme année de référence.
const WB_MIRRORS = { "SP.POP.TOTL": `${GH}/datasets/population/main/data/population.csv`, "NY.GDP.MKTP.CD": `${GH}/datasets/gdp/main/data/gdp.csv` };
export async function worldBankIndicator(code, { from = 1990 } = {}) {
  const api = `https://api.worldbank.org/v2/country/all/indicator/${code}?format=json&per_page=20000&date=${from}:2030`;
  const urls = [{ url: api, via: "primary" }];
  if (WB_MIRRORS[code]) urls.push({ url: WB_MIRRORS[code], via: "mirror" });
  const r = await getResource("worldbank", code + (urls.length > 1 ? ".auto" : ".json"), urls);
  let points;
  if (r.fetch.via === "primary") {
    const j = JSON.parse(r.text); const meta = j[0] || {};
    if (meta.lastupdated) r.fetch.source_updated_at = new Date(meta.lastupdated).toISOString();
    points = (j[1] || []).filter(p => p.value !== null && p.countryiso3code).map(p => ({ iso3: p.countryiso3code, year: +p.date, value: p.value }));
  } else {
    points = parseCSV(r.text).map(x => ({ iso3: x["Country Code"], year: +x.Year, value: num(x.Value) })).filter(p => p.value !== null && p.iso3);
  }
  return { points, fetch: r.fetch };
}

// ---------- PNUD : IDH ----------
// Le fichier « composite indices time series » contient hdi_1990 … hdi_<N-2>. On garde chaque année avec sa valeur.
export async function undpHDI() {
  const urls = [
    "https://hdr.undp.org/sites/default/files/2025_HDR/HDR25_Composite_indices_complete_time_series.csv",
    "https://hdr.undp.org/sites/default/files/2023-24_HDR/HDR23-24_Composite_indices_complete_time_series.csv"
  ].map(url => ({ url, via: "primary" }));
  const r = await getResource("undp_hdr", "composite_indices.csv", urls);
  const rows = parseCSV(r.text.replace(/^﻿/, ""));
  const points = [];
  for (const row of rows) for (const [k, v] of Object.entries(row)) {
    const m = /^hdi_(\d{4})$/.exec(k); if (m && num(v) !== null && /^[A-Z]{3}$/.test(row.iso3)) points.push({ iso3: row.iso3, year: +m[1], value: num(v) });
  }
  return { points, fetch: r.fetch };
}

// ---------- REST Countries (miroir : mledoze/countries, même modèle de données) ----------
export async function restCountries() {
  const urls = [
    { url: "https://restcountries.com/v3.1/all?fields=cca2,cca3,ccn3,name,translations,capital,region,subregion,continents,area,latlng,landlocked,borders,languages,currencies,tld,idd,independent,unMember,demonyms,flag", via: "primary" },
    { url: `${GH}/mledoze/countries/master/countries.json`, via: "mirror" }
  ];
  const r = await getResource("restcountries", "countries.json", urls);
  if (r.fetch.via === "mirror") r.fetch.source_id = "mledoze";
  return { countries: JSON.parse(r.text), fetch: r.fetch };
}

export async function countryCodes() {
  const r = await getResource("country_codes", "country-codes.csv", [{ url: `${GH}/datasets/country-codes/main/data/country-codes.csv` }]);
  return { rows: parseCSV(r.text), fetch: r.fetch };
}
export async function currencyCodes() {
  const r = await getResource("iso4217", "codes-all.csv", [{ url: `${GH}/datasets/currency-codes/main/data/codes-all.csv` }]);
  return { rows: parseCSV(r.text), fetch: r.fetch };
}
export async function worldCities() {
  const r = await getResource("geonames_cities", "world-cities.csv", [{ url: `${GH}/datasets/world-cities/main/data/world-cities.csv` }]);
  return { rows: parseCSV(r.text), fetch: r.fetch };
}

// ---------- Natural Earth ----------
export async function naturalEarth(layer) {
  const urls = [{ url: `${GH}/nvkelso/natural-earth-vector/master/geojson/${layer}.geojson`, via: "mirror" }];
  const r = await getResource("naturalearth", layer + ".geojson", urls);
  return { geo: JSON.parse(r.text), fetch: r.fetch };
}

// ---------- Our World in Data ----------
export async function owid(kind) {
  const id = kind === "co2" ? "owid_co2" : "owid_energy";
  const url = kind === "co2" ? `${GH}/owid/co2-data/master/owid-co2-data.csv` : `${GH}/owid/energy-data/master/owid-energy-data.csv`;
  const r = await getResource(id, kind + ".csv", [{ url }]);
  return { rows: parseCSV(r.text), fetch: r.fetch };
}

// ---------- Wikidata (SPARQL) ----------
// Requêtes prêtes : chefs d'État et de gouvernement en fonction (avec date de début), adhésions aux organisations.
export const WIKIDATA_QUERIES = {
  leaders: `SELECT ?iso3 ?hosLabel ?hosStart ?hogLabel ?hogStart WHERE {
    ?c wdt:P298 ?iso3 ; wdt:P31 wd:Q3624078 .
    OPTIONAL { ?c p:P35 ?s1 . ?s1 ps:P35 ?hos . FILTER NOT EXISTS { ?s1 pq:P582 ?e1 } OPTIONAL { ?s1 pq:P580 ?hosStart } }
    OPTIONAL { ?c p:P6 ?s2 . ?s2 ps:P6 ?hog . FILTER NOT EXISTS { ?s2 pq:P582 ?e2 } OPTIONAL { ?s2 pq:P580 ?hogStart } }
    SERVICE wikibase:label { bd:serviceParam wikibase:language "fr,en". } }`,
  memberships: org => `SELECT ?iso3 ?start WHERE { ?c wdt:P298 ?iso3 ; p:P463 ?st . ?st ps:P463 wd:${org} . FILTER NOT EXISTS { ?st pq:P582 ?end } OPTIONAL { ?st pq:P580 ?start } }`,
  names_fr: `SELECT ?iso3 ?fr WHERE { ?c wdt:P298 ?iso3 ; rdfs:label ?fr . FILTER(LANG(?fr) = "fr") }`
};
export async function wikidata(name, query) {
  const url = "https://query.wikidata.org/sparql?format=json&query=" + encodeURIComponent(query);
  const h = (await import("node:crypto")).createHash("md5").update(query).digest("hex").slice(0, 8); // la clé de cache dépend de la requête
  const r = await getResource("wikidata", `${name}.${h}.json`, [{ url, via: "primary" }]);
  const j = JSON.parse(r.text);
  return { rows: j.results.bindings.map(b => Object.fromEntries(Object.entries(b).map(([k, v]) => [k, v.value]))), fetch: r.fetch };
}

// ---------- Vocabulaire ----------
export async function cefrj() {
  const a = await getResource("cefrj", "cefrj-1.5.csv", [{ url: `${GH}/openlanguageprofiles/olp-en-cefrj/master/cefrj-vocabulary-profile-1.5.csv` }]);
  const b = await getResource("octanove", "octanove-c1c2.csv", [{ url: `${GH}/openlanguageprofiles/olp-en-cefrj/master/octanove-vocabulary-profile-c1c2-1.0.csv` }]);
  return { a1b2: parseCSV(a.text), c1c2: parseCSV(b.text), fetchA: a.fetch, fetchB: b.fetch };
}
export async function cefrjGrammar() {
  const r = await getResource("cefrj_grammar", "cefrj-grammar.csv", [{ url: `${GH}/openlanguageprofiles/olp-en-cefrj/master/cefrj-grammar-profile-20180315.csv` }]);
  return { rows: parseCSV(r.text), fetch: r.fetch };
}
export async function wordnetZip() { return getResource("wordnet", "wordnet.zip", [{ url: `${GH}/nltk/nltk_data/gh-pages/packages/corpora/wordnet.zip` }], { binary: true }); }
export async function omwZip() { return getResource("omw_fra", "omw-1.4.zip", [{ url: `${GH}/nltk/nltk_data/gh-pages/packages/corpora/omw-1.4.zip` }], { binary: true }); }
export async function frequency(lang) {
  const r = await getResource("freq_opensubs", `${lang}_50k.txt`, [{ url: `${GH}/hermitdave/FrequencyWords/master/content/2018/${lang}/${lang}_50k.txt` }]);
  const rank = new Map(); r.text.split("\n").forEach((l, i) => { const w = l.split(" ")[0]; if (w && !rank.has(w)) rank.set(w, i + 1); });
  return { rank, fetch: r.fetch };
}
export async function ipa(locale) {
  const r = await getResource("ipa_dict", `${locale}.txt`, [{ url: `${GH}/open-dict-data/ipa-dict/master/data/${locale}.txt` }]);
  const map = new Map(); for (const l of r.text.split("\n")) { const [w, p] = l.split("\t"); if (w && p) map.set(w.toLowerCase(), p.split(",")[0].trim()); }
  return { map, fetch: r.fetch };
}
// Wiktionary via kaikki.org : une entrée par mot (définitions, prononciations, traductions par sens). Utilisé en enrichissement ciblé.
export async function wiktionaryWord(lang, word) {
  const L = { en: "English", es: "Spanish", fr: "French" }[lang];
  const w = encodeURIComponent(word);
  const p = word.length > 1 ? `${word[0]}/${word.slice(0, 2)}` : `${word[0]}/${word[0]}`;
  const url = `https://kaikki.org/dictionary/${L}/meaning/${encodeURIComponent(p[0])}/${encodeURIComponent(p.slice(2))}/${w}.jsonl`;
  const r = await getResource("wiktionary", `${lang}/${word.replace(/[^\w-]/g, "_")}.jsonl`, [{ url, via: "primary" }]);
  return { entries: r.text.split("\n").filter(Boolean).map(l => JSON.parse(l)), fetch: r.fetch };
}
