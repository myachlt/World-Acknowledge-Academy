// Orchestrateur : node db/run.mjs [--only=countries,stats] [--offline] [--refresh]
// 1) récupère les sources (cache dans db/raw), 2) construit chaque base dans db/data/<base>/,
// 3) contrôle qualité (db/data/_quality), 4) charge tout dans db/wka.sqlite, 5) exporte vers l'application.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

// Node n'utilise le proxy HTTP(S) de l'environnement que si NODE_USE_ENV_PROXY=1 : on se relance si besoin.
if ((process.env.HTTPS_PROXY || process.env.https_proxy) && !process.env.NODE_USE_ENV_PROXY) {
  const r = spawnSync(process.execPath, ["--no-warnings", ...process.argv.slice(1)], { stdio: "inherit", env: { ...process.env, NODE_USE_ENV_PROXY: "1" } });
  process.exit(r.status ?? 1);
}

const { flushProvenance, OUT, NOW } = await import("./lib/core.mjs");
const ORDER = ["countries", "geography", "stats", "politics", "organizations", "history", "vocab_en", "vocab_es", "vocab_fr", "grammar", "idioms", "practical", "professional", "science", "quiz", "resources"];
const only = (process.argv.find(a => a.startsWith("--only=")) || "").slice(7).split(",").filter(Boolean);
const steps = only.length ? ORDER.filter(s => only.includes(s)) : ORDER;
const log = m => console.log(m);
const report = { started_at: NOW, steps: {} };
let qaAll = [];
for (const s of steps) {
  const f = path.join(path.dirname(new URL(import.meta.url).pathname), "pipelines", s + ".mjs");
  if (!fs.existsSync(f)) { log(`- ${s} : pas encore de pipeline`); continue; }
  const t = Date.now(); log(`- ${s}…`);
  try {
    const mod = await import(f);
    const r = await mod.build(log);
    report.steps[s] = { ok: true, ms: Date.now() - t, counts: r.counts };
    (r.qa || []).forEach(q => qaAll.push({ base: s, ...q }));
    log(`  ${Object.entries(r.counts).map(([k, v]) => `${k}=${v}`).join(" · ")} (${((Date.now() - t) / 1000).toFixed(1)} s)`);
  } catch (e) { report.steps[s] = { ok: false, error: e.message }; log(`  ÉCHEC ${s} : ${e.stack}`); }
  flushProvenance();
}
// Journal QA par base (fusionné : les bases non reconstruites gardent leur journal)
const qdir = path.join(OUT, "_quality"); fs.mkdirSync(qdir, { recursive: true });
const qf = path.join(qdir, "pipeline_issues.json");
const prev = fs.existsSync(qf) ? JSON.parse(fs.readFileSync(qf, "utf8")).filter(q => !steps.includes(q.base)) : [];
fs.writeFileSync(qf, JSON.stringify(prev.concat(qaAll), null, 1));
fs.writeFileSync(path.join(qdir, "last_run.json"), JSON.stringify(report, null, 1));
log(`Terminé. ${qaAll.length} signalements qualité dans db/data/_quality/pipeline_issues.json`);
