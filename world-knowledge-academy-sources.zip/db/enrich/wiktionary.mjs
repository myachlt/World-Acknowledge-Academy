// Enrichissement Wiktionary (via kaikki.org) : traductions par sens, genre, phonétique britannique, exemples.
// Usage : node db/enrich/wiktionary.mjs en|es [--limit=N] [--concurrency=4]
// Reprise automatique : les mots déjà traités sont sautés. Le brut n'est pas conservé (≈100 Ko par mot) : seul l'extrait utile
// est écrit dans db/raw/wiktionary/<lang>_compact.jsonl, avec la date de récupération de chaque mot.
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
if ((process.env.HTTPS_PROXY || process.env.https_proxy) && !process.env.NODE_USE_ENV_PROXY) {
  const r = spawnSync(process.execPath, ["--no-warnings", ...process.argv.slice(1)], { stdio: "inherit", env: { ...process.env, NODE_USE_ENV_PROXY: "1" } }); process.exit(r.status ?? 1);
}
const { RAW, readBase } = await import("../lib/core.mjs");
const lang = process.argv[2] || "en";
const limit = +((process.argv.find(a => a.startsWith("--limit=")) || "").slice(8) || 1e9);
const conc = +((process.argv.find(a => a.startsWith("--concurrency=")) || "").slice(14) || 4);
const L = { en: "English", es: "Spanish", fr: "French" }[lang];
const out = path.join(RAW, "wiktionary", `${lang}_compact.jsonl`); fs.mkdirSync(path.dirname(out), { recursive: true });
const done = new Set(fs.existsSync(out) ? fs.readFileSync(out, "utf8").split("\n").filter(Boolean).map(l => JSON.parse(l).q) : []);
// Mots à traiter : lexèmes de la base de la langue, du niveau le plus simple au plus difficile
const lex = lang === "en" ? readBase("vocab_en", "lexeme") : readBase("vocab_es", "lexeme");
const order = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5, C2: 6 };
const words = [...new Set(lex.sort((a, b) => (order[a.cefr] || 9) - (order[b.cefr] || 9) || (a.freq_rank || 1e9) - (b.freq_rank || 1e9)).map(l => l.lemma))].filter(w => !done.has(w)).slice(0, limit);
console.log(`${words.length} mots à interroger (${done.size} déjà faits)`);
const keepLang = new Set(["fr", "es", "en"]);
function compact(word, entries) {
  return { q: word, at: new Date().toISOString(), entries: entries.filter(e => e.word && e.word.toLowerCase() === word.toLowerCase()).map(e => ({
    pos: e.pos, gender: (e.head_templates || []).map(h => h.expansion || "").join(" ").match(/\b(m|f|m or f|mf)\b/) ? (e.head_templates[0].args || {})[1] || null : null,
    tags: [...new Set((e.senses || []).flatMap(s => s.tags || []).filter(t => ["masculine", "feminine"].includes(t)))],
    senses: (e.senses || []).slice(0, 8).map(s => ({ gloss: (s.glosses || [])[0] || null, tags: (s.tags || []).filter(t => !/^(form-of|alt-of)$/.test(t)).slice(0, 6),
      ex: (s.examples || []).filter(x => x.text && x.text.length < 160).slice(0, 2).map(x => ({ t: x.text, en: x.english || x.translation || null })) })).filter(s => s.gloss),
    tr: (e.translations || []).filter(t => keepLang.has(t.code || t.lang_code) && t.word).map(t => ({ l: t.code || t.lang_code, w: t.word, s: t.sense || null, g: (t.tags || []).filter(x => /masculine|feminine/.test(x)).map(x => x[0]).join("") || null, r: (t.tags || []).filter(x => /^[A-Z]/.test(x)).slice(0, 3) })),
    ipa: (e.sounds || []).filter(s => s.ipa && /^\//.test(s.ipa)).slice(0, 6).map(s => ({ ipa: s.ipa, tags: (s.tags || []).slice(0, 3) })),
    syn: (e.synonyms || []).map(s => s.word).slice(0, 8), ant: (e.antonyms || []).map(s => s.word).slice(0, 6)
  })) };
}
let n = 0, fail = 0; const t0 = Date.now();
async function one(word) {
  const p = word.length > 1 ? `${word[0]}/${word.slice(0, 2)}` : `${word[0]}/${word[0]}`;
  const url = `https://kaikki.org/dictionary/${L}/meaning/${p.split("/").map(encodeURIComponent).join("/")}/${encodeURIComponent(word)}.jsonl`;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "WorldKnowledgeAcademy-DataBuilder/1.0" }, signal: AbortSignal.timeout(60000) });
      if (r.status === 404) { fs.appendFileSync(out, JSON.stringify({ q: word, at: new Date().toISOString(), entries: [], missing: true }) + "\n"); return; }
      if (!r.ok) throw new Error("HTTP " + r.status);
      const entries = (await r.text()).split("\n").filter(Boolean).map(l => JSON.parse(l));
      fs.appendFileSync(out, JSON.stringify(compact(word, entries)) + "\n"); return;
    } catch (e) { await new Promise(r => setTimeout(r, 1500 * (attempt + 1))); if (attempt === 2) { fail++; } }
  }
}
const queue = words.slice();
await Promise.all(Array.from({ length: conc }, async () => { while (queue.length) { const w = queue.shift(); await one(w); if (++n % 250 === 0) console.log(`${n}/${words.length} (${Math.round((Date.now() - t0) / 1000)} s, ${fail} échecs)`); } }));
fs.writeFileSync(out + ".meta.json", JSON.stringify({ url: `https://kaikki.org/dictionary/${L}/`, via: "primary", retrieved_at: new Date().toISOString(), source_updated_at: null, words: done.size + n, failures: fail }, null, 1));
console.log(`Terminé : ${n} mots, ${fail} échecs.`);
