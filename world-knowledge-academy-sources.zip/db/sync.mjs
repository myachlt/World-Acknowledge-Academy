// Synchronisation : node db/sync.mjs [--run] [--force=source1,source2]
//  1. Péremption : toute provenance dont la date de validité est dépassée passe au statut « stale » (l'ancien statut est gardé
//     dans la note). Les questions qui en dépendent ne sont plus servies (règle « stale » de lib/qa.mjs et de l'export).
//  2. Échéancier : pour chaque source, compare la date de dernière récupération à sa fréquence de contrôle (sources.json,
//     check_every_days). Une source « due » désigne les bases à reconstruire.
//  3. Avec --run : reconstruit ces bases en forçant le téléchargement (--refresh), puis la base Quiz et les ressources,
//     recharge SQLite, régénère le rapport qualité et l'export de l'application.
// À planifier (cron, tâche planifiée, GitHub Actions) une fois par jour : sans --run il ne fait que marquer et lister.
import fs from "node:fs";
import path from "node:path";
process.removeAllListeners("warning");
import { spawnSync } from "node:child_process";
import { DB, OUT, TODAY } from "./lib/core.mjs";

const RUN = process.argv.includes("--run");
const FORCE = ((process.argv.find(a => a.startsWith("--force=")) || "").slice(8)).split(",").filter(Boolean);
const PF = path.join(OUT, "_core/provenance.json");
const provs = JSON.parse(fs.readFileSync(PF, "utf8"));
const fetches = JSON.parse(fs.readFileSync(path.join(OUT, "_core/fetch.json"), "utf8"));
const SOURCES = JSON.parse(fs.readFileSync(path.join(DB, "sources.json"), "utf8")).sources;

// 1. Péremption
const newlyStale = [];
for (const p of provs) if (p.valid_until && p.valid_until < TODAY && !["stale", "rejected"].includes(p.status)) {
  p.note = [p.note, `périmé le ${p.valid_until} (statut précédent : ${p.status})`].filter(Boolean).join(" · "); p.status = "stale"; newlyStale.push(p.id); }
if (newlyStale.length) fs.writeFileSync(PF, JSON.stringify(provs, null, 1));
const soon = provs.filter(p => p.valid_until && p.valid_until >= TODAY && p.valid_until <= new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10)).length;
// Dans SQLite aussi
const SQL = path.join(DB, "wka.sqlite");
if (newlyStale.length && fs.existsSync(SQL)) { const { DatabaseSync } = await import("node:sqlite"); const db = new DatabaseSync(SQL);
  const st = db.prepare("UPDATE provenance SET status = 'stale', note = ? WHERE id = ?"); const byId = new Map(provs.map(p => [p.id, p]));
  db.exec("BEGIN"); newlyStale.forEach(id => st.run(byId.get(id).note, id)); db.exec("COMMIT"); db.close(); }

// Bases concernées par chaque source (d'après les provenances réellement utilisées)
const provSrc = new Map(provs.map(p => [p.id, p.source_id])); const basesOf = {}; const staleSet = new Set(newlyStale.length ? newlyStale : provs.filter(p => p.status === "stale").map(p => p.id)); const staleBases = new Set();
for (const base of fs.readdirSync(OUT)) { const d = path.join(OUT, base); if (base.startsWith("_") || base === "imports" || !fs.statSync(d).isDirectory()) continue;
  for (const f of fs.readdirSync(d)) if (f.endsWith(".json")) { const txt = fs.readFileSync(path.join(d, f), "utf8"); for (const m of new Set(txt.match(/prov:[0-9a-f]{12}/g) || [])) { if (staleSet.has(m)) staleBases.add(base); const s = provSrc.get(m); if (s) (basesOf[s] = basesOf[s] || new Set()).add(base); } } }

// 2. Échéancier des sources
const last = {}; for (const f of fetches) if (!last[f.source_id] || f.retrieved_at > last[f.source_id]) last[f.source_id] = f.retrieved_at;
const schedule = SOURCES.map(s => { const l = last[s.id] || null; const age = l ? Math.floor((Date.now() - Date.parse(l)) / 864e5) : null;
  const due = FORCE.includes(s.id) || (l && s.check_every_days && age >= s.check_every_days);
  return { source: s.id, name: s.name, last_retrieved: l, age_days: age, check_every_days: s.check_every_days, due: !!due, next_check: l && s.check_every_days ? new Date(Date.parse(l) + s.check_every_days * 864e5).toISOString().slice(0, 10) : null, bases: [...(basesOf[s.id] || [])] }; });
const dueBases = new Set(); schedule.filter(s => s.due).forEach(s => s.bases.forEach(b => dueBases.add(b)));
const PIPE = { practical: ["practical", "professional"] };
const report = { checked_at: new Date().toISOString(), newly_stale: newlyStale.length, stale_total: provs.filter(p => p.status === "stale").length, expiring_within_30_days: soon,
  bases_with_new_stale_data: [...staleBases], sources_due: schedule.filter(s => s.due).map(s => s.source), bases_to_rebuild: [...dueBases], schedule, ran: false };
console.log(`Provenances périmées ce jour : ${newlyStale.length} (total ${report.stale_total}) · expirent dans les 30 jours : ${soon}`);
console.log(`Sources à revérifier : ${report.sources_due.join(", ") || "aucune"} → bases : ${report.bases_to_rebuild.join(", ") || "aucune"}`);
if (staleBases.size) console.log(`Bases contenant des données périmées (à revérifier, surtout les lots rédigés) : ${[...staleBases].join(", ")}`);

// 3. Reconstruction
if (RUN && (dueBases.size || newlyStale.length)) {
  const only = [...new Set([...dueBases].flatMap(b => PIPE[b] || [b]).concat(["quiz", "resources"]))];
  const step = (args, label) => { console.log("→ " + label); const r = spawnSync(process.execPath, args, { stdio: "inherit", cwd: path.resolve(DB, "..") }); if (r.status) throw new Error(label + " : échec"); };
  if (dueBases.size) step(["db/run.mjs", "--only=" + only.join(","), "--refresh"], "reconstruction " + only.join(", "));
  else step(["db/run.mjs", "--only=quiz,resources"], "base Quiz (retrait des questions périmées)");
  step(["--no-warnings", "db/build_sqlite.mjs"], "SQLite"); step(["db/report.mjs"], "rapport qualité"); step(["db/export_app.mjs"], "export application");
  report.ran = true; report.rebuilt = only;
}
fs.writeFileSync(path.join(OUT, "_quality/sync_report.json"), JSON.stringify(report, null, 1));
