// Charge toutes les bases (db/data/**) dans une base SQLite unique : db/wka.sqlite
// Usage : node db/build_sqlite.mjs
//  1. applique db/schema/schema.sql ;
//  2. charge chaque fichier JSON dans sa table. Une colonne présente dans les données mais absente du schéma est ajoutée
//     (et signalée) ; une table sans définition dans le schéma est créée à partir des données (et signalée) ;
//  3. relie chaque pays à sa capitale (country.capital_city_id) ;
//  4. contrôle l'intégrité référentielle (PRAGMA foreign_key_check) et écrit le schéma effectif dans db/schema/schema_effective.sql.
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { DB, OUT, TODAY } from "./lib/core.mjs";

const FILE = path.join(DB, "wka.sqlite");
if (fs.existsSync(FILE)) fs.rmSync(FILE);
const db = new DatabaseSync(FILE);
db.exec("PRAGMA journal_mode = OFF; PRAGMA synchronous = OFF; PRAGMA foreign_keys = OFF;");
db.exec(fs.readFileSync(path.join(DB, "schema/schema.sql"), "utf8"));
db.exec("PRAGMA foreign_keys = OFF;"); // le schéma active les clés étrangères : on les contrôle en fin de chargement

const read = f => JSON.parse(fs.readFileSync(path.join(OUT, f), "utf8"));
const exists = f => fs.existsSync(path.join(OUT, f));
// fichier → table (les fichiers absents de cette liste sont chargés dans une table du même nom)
const ALIAS = { "vocab_es/link.json": "lexeme_link", "vocab_fr/link.json": "lexeme_link", "quiz/imported.json": "question", "quiz/imported_link.json": "question_link",
  "imports/import_batch.json": "import_batch", "_quality/pipeline_issues.json": "qa_issue" };
const SKIP = new Set(["_core/source.json", "_quality/last_run.json", "_quality/quiz_rejected.json", "_quality/report.json", "_quality/sync_report.json"]);

const notes = []; const counts = {};
const cols = t => db.prepare(`PRAGMA table_info("${t}")`).all().map(c => c.name);
const val = v => v === undefined || v === null ? null : typeof v === "object" ? JSON.stringify(v) : typeof v === "boolean" ? (v ? 1 : 0) : v;

function load(table, rows, label) {
  if (!rows.length) return;
  const keys = [...new Set(rows.slice(0, 2000).flatMap(r => Object.keys(r)))];
  let have = cols(table);
  if (!have.length) {
    db.exec(`CREATE TABLE "${table}" (${keys.map(k => `"${k}"`).join(", ")})`); have = keys;
    notes.push(`Table « ${table} » créée depuis les données (${label}) : à ajouter au schéma documenté`);
  }
  for (const k of keys) if (!have.includes(k)) { db.exec(`ALTER TABLE "${table}" ADD COLUMN "${k}"`); notes.push(`Colonne ${table}.${k} ajoutée depuis ${label}`); }
  const st = db.prepare(`INSERT OR IGNORE INTO "${table}" (${keys.map(k => `"${k}"`).join(", ")}) VALUES (${keys.map(() => "?").join(", ")})`);
  let ok = 0, ko = 0, err = null;
  db.exec("BEGIN");
  for (const r of rows) { try { const res = st.run(...keys.map(k => val(r[k]))); res.changes ? ok++ : ko++; } catch (e) { ko++; err = err || e.message; } }
  db.exec("COMMIT");
  counts[table] = (counts[table] || 0) + ok;
  if (ko) notes.push(`${label} → ${table} : ${ko} lignes ignorées (doublon de clé ou contrainte)${err ? " — " + err : ""}`);
}

// Sources (depuis db/sources.json, la référence), puis récupérations et provenances
const SOURCES = JSON.parse(fs.readFileSync(path.join(DB, "sources.json"), "utf8")).sources;
load("source", SOURCES.map(s => ({ id: s.id, name: s.name, publisher: s.publisher, homepage: s.homepage, license: s.license, license_url: s.license_url, attribution: s.attribution, access: s.access, check_every_days: s.check_every_days, data_cadence: s.data_cadence })), "sources.json");
load("fetch", read("_core/fetch.json"), "_core/fetch.json");
load("provenance", read("_core/provenance.json"), "_core/provenance.json");

const files = [];
for (const dir of fs.readdirSync(OUT)) { const d = path.join(OUT, dir); if (!fs.statSync(d).isDirectory() || dir === "_core") continue;
  for (const f of fs.readdirSync(d)) if (f.endsWith(".json")) files.push(dir + "/" + f); }
// Les tables mères d'abord (pays, lexèmes…) pour la lisibilité ; l'intégrité est contrôlée à la fin
files.sort((a, b) => (a.includes("link") || a.includes("_link") ? 1 : 0) - (b.includes("link") ? 1 : 0));
for (const f of files) {
  if (SKIP.has(f)) continue;
  const table = ALIAS[f] || path.basename(f, ".json");
  let rows = read(f); if (!Array.isArray(rows)) continue;
  if (table === "qa_issue") rows = rows.map(r => ({ base: r.base, rule: r.rule, severity: r.severity, target_id: r.target_id || null, message: r.message, detected_at: TODAY }));
  load(table, rows, f);
}

// Capitales : country.capital_city_id
const upd = db.prepare("UPDATE country SET capital_city_id = (SELECT id FROM city WHERE city.country_id = country.id AND city.is_capital = 1 ORDER BY population DESC LIMIT 1)");
upd.run();
const capLinked = db.prepare("SELECT COUNT(*) n FROM country WHERE capital_city_id IS NOT NULL").get().n;

// Intégrité référentielle
const fk = db.prepare("PRAGMA foreign_key_check").all();
const fkBy = {}; fk.forEach(x => { const k = x.table + " → " + x.parent; fkBy[k] = (fkBy[k] || 0) + 1; });
// Provenance obligatoire : toute ligne qui porte un prov_id doit le trouver
const orphanProv = {};
for (const { name } of db.prepare("SELECT name FROM sqlite_schema WHERE type='table'").all()) {
  if (!cols(name).includes("prov_id") || name === "provenance") continue;
  const n = db.prepare(`SELECT COUNT(*) n FROM "${name}" WHERE prov_id IS NOT NULL AND prov_id NOT IN (SELECT id FROM provenance)`).get().n;
  if (n) orphanProv[name] = n;
}
db.exec("PRAGMA foreign_keys = ON; ANALYZE;");
fs.writeFileSync(path.join(DB, "schema/schema_effective.sql"), "-- Schéma effectif de db/wka.sqlite, généré par db/build_sqlite.mjs le " + TODAY + "\n" +
  db.prepare("SELECT sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY type DESC, name").all().map(r => r.sql + ";").join("\n\n") + "\n");
db.close();

const total = Object.values(counts).reduce((a, b) => a + b, 0);
const summary = { built_at: new Date().toISOString(), file: "db/wka.sqlite", bytes: fs.statSync(FILE).size, tables: counts, total_rows: total, capitals_linked: capLinked, foreign_key_violations: fkBy, orphan_provenance: orphanProv, notes };
fs.writeFileSync(path.join(OUT, "_quality/sqlite_build.json"), JSON.stringify(summary, null, 1));
console.log(`db/wka.sqlite : ${total.toLocaleString("fr-FR")} lignes dans ${Object.keys(counts).length} tables (${(summary.bytes / 1e6).toFixed(1)} Mo)`);
console.log(`Capitales reliées : ${capLinked} · violations de clés étrangères : ${fk.length} ${JSON.stringify(fkBy)} · provenances orphelines : ${JSON.stringify(orphanProv)}`);
notes.forEach(n => console.log("  - " + n));
