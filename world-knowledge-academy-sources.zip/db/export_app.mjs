// Export des bases vers l'application : node db/export_app.mjs → src/data/db_export.js
// L'application reste autonome (hors ligne) : on y embarque un extrait COMPACT et uniquement des données utilisables :
//  - les questions générées depuis les bases que l'application ne sait pas produire elle-même (statistiques datées,
//    organisations, titulaires de fonctions, prix Nobel, frontières, pays enclavés) et les lots importés RELUS ;
//    jamais une question dont la donnée est en conflit, à revoir ou périmée ;
//  - le dictionnaire anglais et espagnol limité aux traductions recoupées ou vérifiées ;
//  - l'état des bases (volumes, statuts, sources, licences, fraîcheur, contrôle qualité) pour la page « Données et sources ».
import fs from "node:fs";
import path from "node:path";
import { DB, OUT, TODAY } from "./lib/core.mjs";

const read = f => fs.existsSync(path.join(OUT, f)) ? JSON.parse(fs.readFileSync(path.join(OUT, f), "utf8")) : [];
const provs = new Map(read("_core/provenance.json").map(p => [p.id, p]));
const SRC = new Map(JSON.parse(fs.readFileSync(path.join(DB, "sources.json"), "utf8")).sources.map(s => [s.id, s]));
const BAD = new Set(["needs_review", "conflict", "rejected", "stale"]);
const usable = q => { const p = provs.get(q.prov_id); if (!p) return false; if (BAD.has(p.status) || BAD.has(q.status)) return false; return !(p.valid_until && p.valid_until < TODAY); };

// Sous-catégories de l'application (le moteur ne sert que des sous-catégories connues)
const SUB = { stat_compare: { geo: "Population et démographie", eco: "Concepts économiques", env: "Climat" }, org_member: "Organisations internationales", org_hq: "Organisations internationales",
  org_founded: { hist: "Histoire contemporaine" }, office_holder: "Grandes personnalités", nobel_peace: "Grandes personnalités", border: "Frontières", landlocked: "Géographie physique" };
const IMPORT_SUB = { geo: "Géographie physique", pol: "Organisations internationales", hist: "Histoire contemporaine", eco: "Concepts économiques", sci: "Physique", cult: "Arts et littérature", env: "Climat", prat: "Vie quotidienne" };
const KEEP = new Set(Object.keys(SUB));
const questions = read("quiz/question.json"), imported = read("quiz/imported.json");
const bank = []; const skipped = {};
for (const q of questions.concat(imported)) {
  const fromBatch = !!q.batch_id;
  if (!fromBatch && !KEEP.has(q.generator)) continue;
  if (q.format !== "mcq" || (q.choices || []).length !== 4 || ["en", "es"].includes(q.category)) continue;
  if (!usable(q)) { skipped[q.generator || "lot"] = (skipped[q.generator || "lot"] || 0) + 1; continue; }
  const s = fromBatch ? IMPORT_SUB[q.category] : typeof SUB[q.generator] === "string" ? SUB[q.generator] : SUB[q.generator][q.category];
  if (!s) continue;
  const p = provs.get(q.prov_id);
  bank.push({ id: q.id, cat: q.category, sub: s, d: Math.min(5, q.difficulty), q: q.prompt, a: q.answer, w: q.choices.filter(c => c !== q.answer), ex: q.explanation, info: q.anecdote || provNote(p), ctx: "",
    src: q.source_text || (p && p.note && p.source_id !== "wka_editorial" ? p.note : sourceName(p)), nature: q.nature === "contemp" ? "contemp" : q.nature === "geo" ? "geo" : "hist",
    asOf: q.nature === "contemp" && p ? (p.checked_at || "").slice(0, 7) : null, st: p ? p.status : null, pi: q.anecdote ? 0 : 1 }); // pi : le complément est la note de provenance (pas une anecdote)
}
function provNote(p) { if (!p) return ""; const L = { verified: "vérifiée", cross_checked: "recoupée entre deux sources", source_trusted: "issue d'une source de référence", editorial: "rédigée et relue" };
  return `Donnée ${L[p.status] || p.status} (${sourceName(p)}${p.ref_year ? ", année " + p.ref_year : ""}), contrôlée le ${new Date(p.checked_at + "T12:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}.`; }
function sourceName(p) { if (!p) return ""; const s = SRC.get(p.source_id); return s ? s.name : p.source_id; }

// Dictionnaire : [mot, nature, niveau, français, API, thème, statut(v = vérifié, r = recoupé), genre]
const dict = {};
for (const l of ["en", "es"]) dict[l] = read(`vocab_${l}/lexeme.json`).filter(x => ["verified", "cross_checked"].includes(x.status) && x.fr && x.lemma.length > 1)
  .sort((a, b) => (a.freq_rank || 1e9) - (b.freq_rank || 1e9))
  .map(x => [x.lemma, x.pos_fr || x.pos, x.cefr || "", x.fr, l === "en" ? x.ipa_uk || x.ipa || "" : x.ipa || "", x.theme || "", x.status === "verified" ? "v" : "r", x.gender || ""]);

const report = read("_quality/report.json");
const out = {
  built_at: new Date().toISOString().slice(0, 10),
  bases: (report.bases || []).filter(b => !b.missing).map(b => ({ label: b.label, rows: b.rows, status: b.status, stale: b.stale, issues: b.issues, sources: b.sources.map(s => s.id) })),
  quiz: report.quiz && { accepted: report.quiz.accepted, imported: report.quiz.imported, imported_needs_review: report.quiz.imported_needs_review, rejected: report.quiz.rejected, rejected_rules: report.quiz.rejected_rules, by_category: report.quiz.by_category, batches: report.quiz.batches.map(b => ({ id: b.id, author: b.author, received_at: b.received_at, accepted: b.accepted, rejected: b.rejected, reviewed_by: b.reviewed_by })) },
  sqlite: report.sqlite, sync: report.sync && { checked_at: report.sync.checked_at, stale_total: report.sync.stale_total, sources_due: report.sync.sources_due },
  sources: (report.sources || []).map(s => ({ id: s.id, name: s.name, publisher: s.publisher, license: s.license, license_url: s.license_url, cadence: s.cadence, every: s.check_every_days, last: s.last_retrieved ? s.last_retrieved.slice(0, 10) : null })),
  in_app: { questions: bank.length, by_generator: bank.reduce((a, q) => { const g = q.id.split(":")[2]; a[g] = (a[g] || 0) + 1; return a; }, {}), withheld: skipped, dict_en: dict.en.length, dict_es: dict.es.length }
};
const js = `/* World Knowledge Academy — Extrait des bases de données (généré par db/export_app.mjs le ${TODAY}, ne pas modifier à la main)
 * Questions issues des bases (données sourcées, statut vérifié, recoupé ou source de référence, non périmées),
 * dictionnaire anglais/espagnol recoupé et état des bases pour la page « Données et sources ».
 */
(function (W) {
  const D = W.WKA.data;
  D.DB = ${JSON.stringify(out)};
  D.DB.dict = ${JSON.stringify(dict)};
  const Q = ${JSON.stringify(bank)};
  Q.forEach(q => { q.db = true; D.bank.push(q); });
})(typeof window !== "undefined" ? window : globalThis);
`;
fs.writeFileSync(path.join(DB, "../src/data/db_export.js"), js);
console.log(`src/data/db_export.js : ${bank.length} questions (${JSON.stringify(out.in_app.by_generator)}), retenues hors application : ${JSON.stringify(skipped)}, dictionnaire EN ${dict.en.length} / ES ${dict.es.length}, ${(js.length / 1024).toFixed(0)} Ko`);
