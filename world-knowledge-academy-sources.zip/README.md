# World Knowledge Academy : maquette v0.2

Maquette HTML jouable, pensée d'abord pour le mobile. Ouvrez `dist/index.html` dans un navigateur, sur ordinateur ou téléphone. Aucune installation n'est nécessaire et la maquette fonctionne hors ligne : seules les polices viennent de Google Fonts. Toute la progression est enregistrée dans le navigateur (localStorage).

- Construire : `node build.mjs` (produit `dist/index.html` et `dist/app.html`)
- Tester le moteur : `node tests/engine.test.mjs` (31 655 vérifications, toutes réussies)

## Ce qui est nouveau en v0.2

| Demande | Ce qui est fait | Limite actuelle |
|---|---|---|
| Anglais et espagnol séparés | Deux catégories autonomes, niveaux A1 à C2, niveau adaptatif propre à chaque langue | — |
| Test de positionnement | 14 questions de difficulté progressive, qui proposent un niveau | Indicatif, pas un test certifié |
| Exercices variés | 22 types : vocabulaire, traduction de mots, associations, images, écoute, intrus, synonymes et antonymes, définitions, expressions, faux amis, scènes, grammaire, conjugaison, phrasal verbs (anglais), textes à trous, compréhension écrite, compréhension orale, traduction de phrases, correction d'erreurs, formation des mots, transformation, expression écrite | Peu de textes longs : 5 à 6 par langue et par type |
| Examens | Entraînements inspirés du Cambridge (B1 à C2) et du DELE (B1 à C1), chronométrés, notés par compétence | Formats « inspirés de », pas des sujets officiels |
| Prononciation | Écoute en anglais britannique ou américain, en espagnol d'Espagne ou d'Amérique latine, vitesse réglable, enregistrement et réécoute | Pas de note de prononciation automatique |
| Dictionnaire trilingue | Ajout, modification, suppression, recherche, filtres, tri, écoute, export CSV et import de thèmes (184 mots) | — |
| Révision intelligente | Boîtes de Leitner (1, 3, 7, 16 puis 35 jours) et 7 directions de révision | — |
| Vie pratique | Droit, finances, travail, quotidien, santé, numérique | 74 questions seulement, à étoffer et à faire relire |
| Documents | Tableaux, graphiques et cartes, avec des questions de raisonnement | — |
| Carte du monde | Vraie carte (Natural Earth) avec zoom, déplacement, couleurs de maîtrise, parcours par continent, fiche pays et comparateur | Profil détaillé rédigé pour 31 pays sur 173 |
| Situations | Scénarios en plusieurs étapes : voyage, administration, travail… | — |
| Quotidien | Défi du jour, mot du jour, le saviez-vous, mes lacunes, glossaire | — |
| Charte graphique | Crème, sauge, bleu pétrole, terracotta et jaune doux, avec thèmes clair et sombre | Aucune reprise de la charte TREDI |

## Architecture (3 couches séparées)

- `src/data/` : les contenus (pays, banques de questions, langues, carte), sans aucune logique.
- `src/engine/` : le moteur (sessions, anti-répétition, niveau adaptatif, correction tolérante, dictionnaire, examens). Il n'a pas d'interface et se teste dans Node.
- `src/ui/` : l'interface (fichiers core, learn, langs, world, notebook et me, plus les styles).

Cette séparation se reporte telle quelle dans une application mobile : les couches data et engine se réutilisent, seule l'interface change.

## Volume réel (honnête)

La maquette compte 11 478 questions exactes uniques, dont 1 666 en anglais et 2 136 en espagnol. S'y ajoutent environ 90 millions de combinaisons de comparaison générées, surtout en géographie. Le moteur compte 76 générateurs et couvre 173 pays. Les catégories Sciences, Environnement et Vie pratique restent les plus minces.

## Ce qui dépend d'une API ou d'une base de données

Tout fonctionne aujourd'hui sans serveur, grâce à des versions de démonstration :

1. **Voix (synthèse vocale)** : c'est celle du navigateur. La qualité et les accents disponibles dépendent de l'appareil. Une API de synthèse vocale donnerait un rendu plus homogène.
2. **Micro** : l'enregistrement est bloqué dans l'aperçu publié, mais fonctionne quand on ouvre le fichier local `dist/index.html`.
3. **Correction de l'expression écrite** : pour l'instant, c'est une auto-évaluation guidée avec un texte modèle. Une correction fine (grammaire, lexique, cohérence) demande une API d'IA.
4. **Note de prononciation** : elle demande une API de reconnaissance vocale.
5. **Comptes, synchronisation entre appareils, classements** : ils demandent une vraie base de données et une authentification. Aujourd'hui, tout est stocké localement, avec un export et un import en JSON.
6. **Données évolutives** (population, dirigeants, PIB) : elles sont figées et datées (sources : ONU 2024, Banque mondiale). Une mise à jour automatique demanderait des API ouvertes, comme celles de la Banque mondiale ou REST Countries.
7. **Illustrations et articles** : les images sont des émojis. De vraies illustrations ou des extraits d'articles posent des questions de droits d'auteur.
8. **Non chargés** : l'IDH et le coefficient de Gini.

## Fiabilité

- Chaque question affiche sa source et la date de la donnée. Un bouton « Signaler une erreur » enregistre le signalement dans le profil.
- La correction accepte une réponse sans accent mais le signale, et montre une comparaison mot à mot.
- Les contenus de langue sont originaux. Les examens s'inspirent des formats Cambridge et DELE sans reprendre de sujets officiels.
- À faire relire avant une mise en production : la partie Vie pratique (droit, santé, finances) et les profils pays.

## Bases de données (v0.3)

Les 16 bases de l'application (pays, géographie, statistiques, politique, histoire, organisations, vocabulaire anglais/espagnol/français, grammaire, expressions, connaissances pratiques et professionnelles, sciences, questions, ressources) sont construites dans `db/` à partir de sources identifiées, avec provenance, licence, date et statut de vérification pour chaque donnée. Voir [db/README.md](db/README.md). L'application en embarque un extrait contrôlé (`src/data/db_export.js`) et les présente dans la page « Données et sources ».
