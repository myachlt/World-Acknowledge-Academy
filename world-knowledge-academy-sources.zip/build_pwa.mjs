// Version installable (PWA) : node build.mjs && node build_pwa.mjs  ->  pwa/
// pwa/ contient tout ce qu'il faut publier sur GitHub Pages : index.html, manifeste, service worker (hors ligne), icônes.
import fs from "node:fs";
const u = p => new URL(p, import.meta.url);
const VERSION = "0.3." + new Date().toISOString().slice(0, 10).replace(/-/g, "");
let html = fs.readFileSync(u("dist/index.html"), "utf8");
html = html.replace("<title>World Knowledge Academy</title>", `<title>World Knowledge Academy</title>
<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#1F5966">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="WK Academy">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32.png">
<link rel="icon" type="image/svg+xml" href="icons/icon.svg">`);
html = html.replace("</body>", `<script>
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
</script>
</body>`);
fs.mkdirSync(u("pwa/icons/"), { recursive: true });
fs.writeFileSync(u("pwa/index.html"), html);
fs.writeFileSync(u("pwa/manifest.webmanifest"), JSON.stringify({
  name: "World Knowledge Academy", short_name: "WK Academy", description: "Culture générale mondiale, anglais, espagnol et vie pratique.",
  lang: "fr", start_url: "./", scope: "./", display: "standalone", orientation: "portrait", background_color: "#F6F1E7", theme_color: "#1F5966",
  icons: [{ src: "icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" }, { src: "icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    { src: "icons/maskable-192.png", sizes: "192x192", type: "image/png", purpose: "maskable" }, { src: "icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }]
}, null, 2));
fs.writeFileSync(u("pwa/sw.js"), `// Service worker : l'application fonctionne hors ligne après la première visite.
const CACHE = "wka-${VERSION}";
const CORE = ["./", "index.html", "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png", "icons/apple-touch-icon.png", "icons/icon.svg"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);
  // Page : réseau d'abord (pour recevoir les mises à jour), cache si hors ligne
  if (e.request.mode === "navigate") { e.respondWith(fetch(e.request).then(r => { caches.open(CACHE).then(c => c.put("index.html", r.clone())); return r; }).catch(() => caches.match("index.html"))); return; }
  // Polices et icônes : cache d'abord
  if (url.origin === location.origin || /fonts\\.(googleapis|gstatic)\\.com$/.test(url.hostname))
    e.respondWith(caches.match(e.request).then(m => m || fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put(e.request, c)); return r; })));
});
`);
console.log("pwa/ prêt (version " + VERSION + ")");
